-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local scriptParent: Instance = script.Parent
local assetService: AssetService = game:GetService("AssetService")
local color3 = Color3.fromRGB(255, 190, 50)

local function shouldAffect(p1)
	if p1:GetAttribute("IgnoreSkin") == true or p1:GetAttribute("IgnoreGoldenSkin") == true then
		return false
	end

	local lowerText = string.lower(p1.Name)

	for iterFirst, value in {
		"hitbox",
		"hurtbox",
		"humanoidrootpart",
		"fakehitbox",
		"fakebox",
		"fakecollider",
		"fakecollision",
		"camera",
		"collider",
		"collision"
	}, nil, nil do
		if string.find(lowerText, value, 1, true) then
			return false
		end
	end

	return true
end
local function getGoldenSurface()
	local uiAssets: Instance = game:GetService("ReplicatedStorage"):FindFirstChild("UIAssets")
	local v15: Instance = uiAssets

	if v15 then
		v15 = uiAssets:FindFirstChild("SkinMaterials")
	end

	local goldenSurfaceAppearance: Instance = v15 and v15:FindFirstChild("GoldenSurfaceAppearance")

	if goldenSurfaceAppearance and goldenSurfaceAppearance:IsA("SurfaceAppearance") then
		return goldenSurfaceAppearance
	end

	return nil
end
local function getSpecialMeshWorldSize(p2, p3, p4)
	local scale = p3.Scale
	local lowerText = string.lower(p2.Name)
	local v22 = p2.Parent and string.lower(p2.Parent.Name) or ""

	if lowerText:find("fakehead", 1, true) == nil then
		if v22:find("fakehead", 1, true) == nil then
		end
	end

	if p3.MeshId == "rbxassetid://82992952" then
		local absoluteValue = math.abs(scale.X)
		local v24 = math.max(0.05, absoluteValue * 0.94)
		local absoluteValue2 = math.abs(scale.Y)
		local v26 = math.max(0.05, absoluteValue2 * 0.94)
		local absoluteValue3 = math.abs(scale.Z)
		local v28 = math.max(0.05, absoluteValue3 * 0.94)
		local vector3 = Vector3.new(v24, v26, v28)

		return vector3
	end

	local v30 = p4 and p4.Size or p2.Size
	local absoluteValue = math.abs(v30.X * scale.X)
	local v32 = math.max(0.05, absoluteValue)
	local absoluteValue4 = math.abs(v30.Y * scale.Y)
	local v34 = math.max(0.05, absoluteValue4)
	local absoluteValue5 = math.abs(v30.Z * scale.Z)
	local v36 = math.max(0.05, absoluteValue5)
	local vector3 = Vector3.new(v32, v34, v36)

	return vector3
end
local function shouldUseSpecialMeshOverlay(p5)
	if p5.Transparency >= 0.95 then
		return false
	end

	return true
end
local function createGoldMeshPartFromSpecialMesh(parent, p7, p8)
	if p7.MeshId == "" or not not parent:FindFirstChild("GoldenSpecialMeshPart") or parent.Transparency >= 0.95 then
		return
	end

	local ok, result = pcall(function()
		local v65 = Content.fromUri(p7.MeshId)

		return assetService:CreateMeshPartAsync(v65, {
			CollisionFidelity = Enum.CollisionFidelity.Box,
			RenderFidelity = Enum.RenderFidelity.Automatic
		})
	end)

	if not ok or not result or not result:IsA("MeshPart") then
		return
	end

	result.Name = "GoldenSpecialMeshPart"
	result:SetAttribute("GoldenSpecialMeshOverlay", true)
	pcall(function()
		result.TextureID = ""
	end)
	result.Size = getSpecialMeshWorldSize(parent, p7, result)

	local parentCFrame = parent.CFrame
	local cFrame = CFrame.new(p7.Offset)

	result.CFrame = parentCFrame * cFrame
	result.Anchored = false
	result.CanCollide = false
	result.CanTouch = false
	result.CanQuery = false
	result.Massless = true
	result.CastShadow = parent.CastShadow
	result.Transparency = math.min(parent.Transparency, 0.02)
	result.Material = Enum.Material.Metal
	result.Color = color3
	result.Reflectance = 0.25

	if p8 then
		local clone = p8:Clone()

		clone.Name = "GoldenSurfaceAppearance"
		clone.Parent = result
	end

	result.Parent = parent

	local goldenSpecialMeshWeld: WeldConstraint = Instance.new("WeldConstraint")

	goldenSpecialMeshWeld.Name = "GoldenSpecialMeshWeld"
	goldenSpecialMeshWeld.Part0 = parent
	goldenSpecialMeshWeld.Part1 = result
	goldenSpecialMeshWeld.Parent = result
	parent.Transparency = 1

	if p7:GetAttribute("GoldenOriginalScale") == nil then
		local scale = p7.Scale
		local text: string = tostring(scale.X)
		local text2: string = tostring(scale.Y)
		local text3: string = tostring(scale.Z)

		p7:SetAttribute("GoldenOriginalScale", text .. "," .. text2 .. "," .. text3)
	end

	p7.Scale = Vector3.new(0, 0, 0)
end
local function applyGold()
	if scriptParent:GetAttribute("GoldenEnabled") ~= true and scriptParent:GetAttribute("SkinIndex") ~= "Golden" then
		local goldenEnabled: Instance = scriptParent:FindFirstChild("GoldenEnabled")
		local skinIndex: Instance = scriptParent:FindFirstChild("SkinIndex")
		local v54 = goldenEnabled and goldenEnabled:IsA("BoolValue") and goldenEnabled.Value == true
		local v55 = skinIndex

		if v55 then
			v55 = skinIndex:IsA("StringValue") and skinIndex.Value == "Golden"
		end

		if not v54 and not v55 then
			return
		end
	end

	local v56 = getGoldenSurface()

	for iterFirst, iterSecond in scriptParent:GetDescendants() do
		if iterSecond:IsA("MeshPart") then
			if iterSecond.Name ~= "GoldenSpecialMeshPart" and shouldAffect(iterSecond) then
				pcall(function()
					iterSecond.TextureID = ""
				end)

				for iterFirst2, iterSecond2 in iterSecond:GetChildren() do
					if iterSecond2:IsA("SurfaceAppearance") and iterSecond2.Name ~= "GoldenSurfaceAppearance" then
						iterSecond2.Parent = nil
					end
				end

				if v56 and not iterSecond:FindFirstChild("GoldenSurfaceAppearance") then
					local clone = v56:Clone()

					clone.Name = "GoldenSurfaceAppearance"
					clone.Parent = iterSecond
				end

				iterSecond.Material = Enum.Material.Metal
				iterSecond.Color = color3
				iterSecond.Reflectance = 0.25
			elseif iterSecond.Name == "GoldenSpecialMeshPart" then
				iterSecond.Material = Enum.Material.Metal
				iterSecond.Color = color3
				iterSecond.Reflectance = 0.25

				if v56 and not iterSecond:FindFirstChild("GoldenSurfaceAppearance") then
					local clone = v56:Clone()

					clone.Name = "GoldenSurfaceAppearance"
					clone.Parent = iterSecond
				end
			end
		elseif iterSecond:IsA("BasePart") then
			if shouldAffect(iterSecond) then
				if iterSecond:IsA("UnionOperation") then
					pcall(function()
						iterSecond.UsePartColor = true
					end)
				end

				iterSecond.Material = Enum.Material.Metal
				iterSecond.Color = color3
				iterSecond.Reflectance = 0.25
			end
		elseif iterSecond:IsA("SpecialMesh") then
			local v63 = iterSecond.Parent

			if v63 and v63:IsA("BasePart") and shouldAffect(v63) then
				iterSecond.TextureId = ""
				iterSecond.VertexColor = Vector3.new(color3.R, color3.G, color3.B)
				createGoldMeshPartFromSpecialMesh(v63, iterSecond, v56)
			else
				iterSecond.TextureId = ""
				iterSecond.VertexColor = Vector3.new(color3.R, color3.G, color3.B)
			end
		elseif not iterSecond:IsA("Decal") and not iterSecond:IsA("Texture") then
			if iterSecond:IsA("Shirt") then
				iterSecond.ShirtTemplate = ""
			elseif iterSecond:IsA("Pants") then
				iterSecond.PantsTemplate = ""
			elseif iterSecond:IsA("ShirtGraphic") then
				iterSecond.Graphic = ""
			end
		else
			iterSecond.Texture = ""
			iterSecond.Transparency = 1
			iterSecond.Color3 = color3
		end
	end
end

applyGold()
scriptParent:GetAttributeChangedSignal("GoldenEnabled"):Connect(function()
	task.defer(applyGold)
end)
scriptParent:GetAttributeChangedSignal("SkinIndex"):Connect(function()
	task.defer(applyGold)
end)
scriptParent.DescendantAdded:Connect(function()
	task.defer(applyGold)
end)
task.spawn(function()
	for _ = 1, 75 do
		if not scriptParent.Parent then
			return
		end

		applyGold()
		task.wait(0.2)
	end
end)
