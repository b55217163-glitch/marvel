-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local humanoidRootPart: Instance = script.Parent:WaitForChild("HumanoidRootPart")
local running: Instance = humanoidRootPart:FindFirstChild("Running")

if running then
	running:Destroy()
end

humanoidRootPart.ChildAdded:Connect(function(p1: Instance)
	if p1:IsA("Sound") and p1.Name == "Running" then
		p1:Destroy()
	end
end)
