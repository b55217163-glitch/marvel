--[[
		Thank you for using UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

		IMPORTANT: Original Source of these Scripts was RECOVERED: ["ReplicatedStorage.Characters.Springtrap.Fx.Balloon.Sound","ReplicatedStorage.Characters.Steve_H.Fx.DeathDustin.Sound","ReplicatedStorage.Characters.Steve_H.Fx.Dustin.Sound"]

		!! GETHIDDENPROPERTY ISSUES !!
		Your executor's gethiddenproperty couldn't read these types, so data may be missing or wrong.
		Tell your executor's developers. Affected types:
				Failed reads: ["Color3uint8","Enum","NetAssetRef","OptionalCoordinateFrame"]

		ServerStorage, ServerScriptService and Server Scripts are IMPOSSIBLE to save because of FilteringEnabled.

		Images, meshes, textures, sounds etc. failed to load or look invisible? Those assets are private. Try https://github.com/kartFr/Asset-Reuploader or similar.

		Player doesn't spawn? Move or delete the scripts in StarterPlayer, then run game:GetService("Players").CharacterAutoLoads = true
		Use "Play Here" instead of "Play" to spawn where your Camera is.

		Chat broken? Delete everything in TextChatService/Chat, or run game:GetService("Chat"):ClearAllChildren() game:GetService("TextChatService"):ClearAllChildren()

		Union/MeshPart collisions broken? Run this in the Studio Command Bar:


		local C = game:GetService("CoreGui")
		local E = Enum.CollisionFidelity:GetEnumItems()
		local O = {}

		for _, v in game:GetDescendants() do
			if v:IsA("TriangleMeshPart") and not v:IsDescendantOf(C) then
				local c = v.CollisionFidelity
				O[v] = c
				v.CollisionFidelity = E[1] ~= c and E[1] or E[2]
			end
		end

		for v, c in O do
			v.CollisionFidelity = c
		end
		print("Done")

		Camera stuck? Run this in the Studio Command Bar:

		workspace.CurrentCamera.CameraType = Enum.CameraType.Fixed

		Or destroy the Camera.

		Settings:
		{"SavePlayerCharacters":false,"CompressionLevel":9,"Callback":false,"ShowStatus":true,"IgnoreDefaultPlayerScripts":false,"NilInstancesFixes":{"Attachments must be parented to a BasePart or another Attachment":null,"BaseWrap":null,"Animator":null,"Attachment":null,"PackageLink":null,"AdPortal":null},"IgnoreList":["CoreGui","CorePackages"],"__DEBUG_MODE":false,"KillAllScripts":false,"DecompileJobless":false,"Binary":true,"Decompile":true,"IgnoreNotArchivable":true,"OptionsAliasesInverse":{"SkipScripts":"Decompile","DisableCompression":"CompressionMode","NullifyScripts":"Decompile","noscripts":"Decompile","NoDecompile":"Decompile","Overwrite":"AvoidFileOverwrite","XML":"Binary","RemovePlayers":"IsolatePlayers","RemovePlayerCharacters":"SavePlayerCharacters"},"RecoverScriptsFromAssets":true,"DecompileIgnore":["Chat","CoreGui","CorePackages"],"IgnoreSpecialProperties":false,"BoostFPS":false,"IsModel":false,"NilInstances":true,"OptionsAliases":{"DecompilerTimeout":"DecompileTimeout","Path":"FilePath","SavePlayersData":"IsolatePlayers","ClassIgnoreList":"IgnoreList","Blacklist":"IgnoreList","IgnoreRobloxPlayerScripts":"IgnoreDefaultPlayerScripts","EmbedBytecode":"SaveBytecode","ScriptDecompile":"Decompile","StatusText":"ShowStatus","NoXML":"Binary","Compress":"CompressionMode","IgnoreInstances":"IgnoreList","AnonymousMode":"Anonymous","SaveStarterPlayer":"IsolateStarterPlayer","Compression":"CompressionMode","Decompiler":"Decompile","IgnoreClasses":"IgnoreList","SaveModel":"Object","DecompileScripts":"Decompile","Progress":"ShowStatus","IgnoreProperty":"IgnoreProperties","timeout":"DecompileTimeout","Verbose":"__DEBUG_MODE","IgnoreArchivable":"IgnoreNotArchivable","Status":"ShowStatus","SaveScripts":"Decompile","Clipboard":"CopyToClipboard","InstancesBlacklist":"IgnoreList","IsolatePlayerGui":"IsolateLocalPlayer","UseDecompiler":"Decompile","SavePlayers":"IsolatePlayers","SaveCharacters":"SavePlayerCharacters","IgnoreDefaultProps":"IgnoreDefaultProperties","Debug":"__DEBUG_MODE","SaveNonCreatable":"SaveNotCreatable","Root":"Object","SaveNilInstances":"NilInstances","FileName":"FilePath","Model":"Object","SaveLocalPlayer":"IsolateLocalPlayer","SavePlayerGui":"IsolateLocalPlayer","SaveAsBinary":"Binary","InstanceIgnoreList":"IgnoreList","Players":"IsolatePlayers","SaveNil":"NilInstances","LocalPlayer":"IsolateLocalPlayer","ShowProgress":"ShowStatus"},"IsolateLocalPlayerCharacter":false,"RiskyServicesDisabled":{"Reflection":false,"Encoding":false,"UGC":true},"ExtraInstances":[],"TreatUnionsAsParts":false,"ReadMe":true,"IgnoreProperties":[],"NotCreatableFixes":["","AdvancedDragger","AnimationTrack","Dragger","Player","PlayerGui","PlayerMouse","PlayerScripts","ScreenshotHud","StudioData","TextChatMessage","TextSource","TouchTransmitter","Translator"],"SharedBinaryStrings":false,"IsolateStarterPlayer":true,"DecompileTimeout":10,"IsolatePlayers":true,"AlternativeWritefile":true,"mode":"full","SaveCacheInterval":56320,"ShutdownWhenDone":false,"SourceCache":false,"BytecodeTimeout":3,"FilePath":"Place_8657766101_[Хэллоуин] Удивительный поединок_06-11-2026_15-24-16","CompressionMode":"zstd","Anonymous":false,"Object":null,"IgnoreDefaultProperties":true,"IgnorePropertiesOfNotScriptsOnScriptsMode":false,"AvoidFileOverwrite":true,"SaveNotCreatable":false,"IsolateLocalPlayer":false,"SafeMode":false,"AntiIdle":true,"CopyToClipboard":false,"SaveBytecode":false,"scriptcache":true}

		Elapsed time: 159.915319 seconds                         
		Date (UTC): 6 November 2026 10:24:25 PlaceId: 8657766101 PlaceVersion: 51034 Client Version: 2.745.1142 Platform: Android Executor: Delta 1.0.745.1142 arm64
]]