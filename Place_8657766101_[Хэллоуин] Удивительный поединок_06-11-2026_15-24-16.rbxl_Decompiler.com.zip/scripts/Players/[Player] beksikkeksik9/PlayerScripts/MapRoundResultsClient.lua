-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local mapRoundResults: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MapRoundResults")
local mapRoundResultsGui: ScreenGui = Instance.new("ScreenGui")

mapRoundResultsGui.Name = "MapRoundResultsGui"
mapRoundResultsGui.ResetOnSpawn = false
mapRoundResultsGui.IgnoreGuiInset = true
mapRoundResultsGui.Enabled = false
mapRoundResultsGui.DisplayOrder = 62
mapRoundResultsGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

local root: CanvasGroup = Instance.new("CanvasGroup")

root.Name = "Root"
root.AnchorPoint = Vector2.new(0.5, 0.5)
root.Position = UDim2.new(0.5, 0, 0.24, 0)
root.Size = UDim2.new(0, 620, 0, 185)
root.BackgroundTransparency = 1
root.Visible = false
root.Parent = mapRoundResultsGui

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 1
uiScale.Parent = root

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.new(0, 0, 0, 0)
title.Size = UDim2.new(1, 0, 0, 34)
title.Font = Enum.Font.Arcade
title.Text = "TOP FIGHTERS THIS ROUND"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextStrokeTransparency = 0.45
title.TextScaled = true
title.Parent = root

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.new(0, 0, 0, 34)
subtitle.Size = UDim2.new(1, 0, 0, 22)
subtitle.Font = Enum.Font.Arcade
subtitle.Text = ""
subtitle.TextColor3 = Color3.fromRGB(220, 220, 220)
subtitle.TextStrokeTransparency = 0.65
subtitle.TextScaled = true
subtitle.Parent = root

local results: Frame = Instance.new("Frame")

results.Name = "Results"
results.BackgroundTransparency = 1
results.Position = UDim2.new(0, 0, 0, 63)
results.Size = UDim2.new(1, 0, 0, 118)
results.Parent = root

local uiListLayout: UIListLayout = Instance.new("UIListLayout")

uiListLayout.FillDirection = Enum.FillDirection.Horizontal
uiListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
uiListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
uiListLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiListLayout.Padding = UDim.new(0, 14)
uiListLayout.Parent = results

local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local t3: {[any]: any} = {}
local t4: {[any]: any} = {}
local t5: {[any]: any} = {}
local t6: {[any]: any} = { "🥇", "🥈", "🥉" }
local color3 = Color3.fromRGB(255, 219, 92)
local color32 = Color3.fromRGB(210, 220, 255)
local t7: {[any]: any} = { color3, color32, Color3.fromRGB(222, 150, 88) }

local function makeCard(layoutOrder)
	local frame: Frame = Instance.new("Frame")

	frame.Name = "Fighter" .. layoutOrder
	frame.LayoutOrder = layoutOrder
	frame.Size = UDim2.new(0, 190, 0, 112)
	frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	frame.BackgroundTransparency = 0.55
	frame.BorderSizePixel = 0
	frame.Visible = false
	frame.Parent = results

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 10)
	uiCorner.Parent = frame

	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = t7[layoutOrder] or Color3.fromRGB(255, 255, 255)
	uiStroke.Thickness = 1
	uiStroke.Transparency = 0.18
	uiStroke.Parent = frame
	t5[layoutOrder] = uiStroke

	local rank: TextLabel = Instance.new("TextLabel")

	rank.Name = "Rank"
	rank.BackgroundTransparency = 1
	rank.Position = UDim2.new(0.08, 0, 0.05, 0)
	rank.Size = UDim2.new(0.84, 0, 0, 26)
	rank.Font = Enum.Font.Arcade
	rank.Text = t6[layoutOrder] or tostring(layoutOrder)
	rank.TextColor3 = t7[layoutOrder] or Color3.fromRGB(255, 255, 255)
	rank.TextStrokeTransparency = 0.65
	rank.TextScaled = true
	rank.Parent = frame
	t2[layoutOrder] = rank

	local playerName: TextLabel = Instance.new("TextLabel")

	playerName.Name = "PlayerName"
	playerName.BackgroundTransparency = 1
	playerName.Position = UDim2.new(0.06, 0, 0.34, 0)
	playerName.Size = UDim2.new(0.88, 0, 0, 34)
	playerName.Font = Enum.Font.Arcade
	playerName.Text = "PLAYER"
	playerName.TextColor3 = Color3.fromRGB(255, 255, 255)
	playerName.TextStrokeTransparency = 0.5
	playerName.TextScaled = true
	playerName.Parent = frame
	t3[layoutOrder] = playerName

	local kills: TextLabel = Instance.new("TextLabel")

	kills.Name = "Kills"
	kills.BackgroundTransparency = 1
	kills.Position = UDim2.new(0.08, 0, 0.7, 0)
	kills.Size = UDim2.new(0.84, 0, 0, 25)
	kills.Font = Enum.Font.Arcade
	kills.Text = "0 KILLS"
	kills.TextColor3 = t7[layoutOrder] or Color3.fromRGB(210, 210, 210)
	kills.TextStrokeTransparency = 0.65
	kills.TextScaled = true
	kills.Parent = frame
	t4[layoutOrder] = kills
	t1[layoutOrder] = frame
end

for i = 1, 3 do
	makeCard(i)
end

local n1: number = 0

local function showGui()
	mapRoundResultsGui.Enabled = true
	root.Visible = true
	root.Position = UDim2.new(0.5, 0, 0.205, -16)
	root.GroupTransparency = 1
	uiScale.Scale = 0.94

	local tweenInfo = TweenInfo.new(0.38, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)

	tweenService:Create(root, tweenInfo, { GroupTransparency = 0, Position = UDim2.new(0.5, 0, 0.24, 0) }):Play()

	local tweenInfo2 = TweenInfo.new(0.38, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	tweenService:Create(uiScale, tweenInfo2, { Scale = 1 }):Play()
end
local function hideGui()
	if not mapRoundResultsGui.Enabled then
		return
	end

	local tweenInfo = TweenInfo.new(0.55, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut)
	local v39: Tween = tweenService:Create(root, tweenInfo, { GroupTransparency = 1, Position = UDim2.new(0.5, 0, 0.17, -34) })
	local tweenInfo3 = TweenInfo.new(0.55, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut)

	tweenService:Create(uiScale, tweenInfo3, { Scale = 0.88 }):Play()
	v39:Play()
	v39.Completed:Connect(function()
		mapRoundResultsGui.Enabled = false
		root.Visible = false
	end)
end
local function showNoEliminations(p2)
	title.Text = "TOP FIGHTERS THIS ROUND"

	if typeof(p2) == "string" and p2 ~= "" then
		subtitle.Text = string.upper(p2)
	else
		subtitle.Text = "NO ELIMINATIONS THIS ROUND"
	end

	t1[1].Visible = true
	t1[1].Size = UDim2.new(0, 430, 0, 112)
	t2[1].Text = "—"
	t3[1].Text = "NO ELIMINATIONS"
	t4[1].Text = "THIS ROUND"
	t5[1].Color = Color3.fromRGB(210, 210, 210)
	t2[1].TextColor3 = Color3.fromRGB(210, 210, 210)
	t4[1].TextColor3 = Color3.fromRGB(210, 210, 210)
	t1[2].Visible = false
	t1[3].Visible = false
end
local function showStandings(p3, p4)
	title.Text = "TOP FIGHTERS THIS ROUND"

	if typeof(p4) == "string" and p4 ~= "" then
		subtitle.Text = string.upper(p4)
	else
		subtitle.Text = "MAP RESULTS"
	end

	for i = 1, 3 do
		local v45 = p3 and p3[i]
		local v46 = t1[i]

		v46.Size = UDim2.new(0, 190, 0, 112)
		v46.Visible = v45 ~= nil

		if v45 then
			local numberValue = tonumber(v45.kills) or 0

			t2[i].Text = t6[i] or tostring(i)

			local v48 = t3[i]
			local stringUpper = string.upper
			local text: string = tostring(v45.name or "PLAYER")

			v48.Text = stringUpper(text)
			t4[i].Text = tostring(numberValue) .. (if numberValue == 1 then " KILL" else " KILLS")

			local v51 = t7[i] or Color3.fromRGB(255, 255, 255)

			t5[i].Color = v51
			t2[i].TextColor3 = v51
			t4[i].TextColor3 = v51
		end
	end
end

mapRoundResults.OnClientEvent:Connect(function(p5, p6)
	if p5 == "Show" then
		local t8 = typeof(p6) == "table" and p6 or {}
		local standings = t8.standings

		if typeof(standings) == "table" and not (#standings <= 0) then
			showStandings(standings, t8.mapName)
		else
			showNoEliminations(t8.mapName)
		end

		n1 += 1

		local v56: number = n1

		showGui()
		task.delay(5, function()
			if v56 == n1 then
				hideGui()
			end
		end)

		return
	end
end)
