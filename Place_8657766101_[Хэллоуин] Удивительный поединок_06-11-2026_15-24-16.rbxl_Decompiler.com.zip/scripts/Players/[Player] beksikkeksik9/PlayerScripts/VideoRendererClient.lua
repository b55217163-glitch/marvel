-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local userInputService: UserInputService = game:GetService("UserInputService")
local contentProvider: ContentProvider = game:GetService("ContentProvider")
local LocalPlayer: Player = players.LocalPlayer
local playerScripts: Instance = LocalPlayer:FindFirstChild("PlayerScripts")

if not playerScripts then
	playerScripts = LocalPlayer:WaitForChild("PlayerScripts")
end

local playVideoEffectLocal = playerScripts:FindFirstChild("PlayVideoEffectLocal")

if not playVideoEffectLocal then
	playVideoEffectLocal = Instance.new("BindableEvent")
	playVideoEffectLocal.Name = "PlayVideoEffectLocal"
	playVideoEffectLocal.Parent = playerScripts
end

local system: Instance = replicatedStorage:WaitForChild("System")
local videoEffectConfig = require(system:WaitForChild("VideoEffectConfig"))
local playVideoEffect: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("PlayVideoEffect")
local n1: number = 0
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local object = setmetatable({}, { __mode = "k" })
local t3: {[any]: any} = {}
local object2 = setmetatable({}, { __mode = "k" })
local object3 = setmetatable({}, { __mode = "k" })

local function forceSilentVideoStop(p1)
	if not p1 or not p1:IsA("VideoFrame") then
		return
	end

	pcall(function()
		p1.Volume = 0
		p1:Pause()
		p1.TimePosition = 0
	end)
end
local function scrubInactiveVideoGui()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")
	local videoGui: Instance = playerGui and playerGui:FindFirstChild("VideoGui")
	local v46: Instance = videoGui

	if v46 then
		v46 = videoGui:FindFirstChild("UpperFrame")
	end

	if not v46 then
		return
	end

	for iterFirst, iterSecond in v46:GetDescendants() do
		if iterSecond:IsA("VideoFrame") and not object2[iterSecond] then
			if iterSecond and iterSecond:IsA("VideoFrame") then
				pcall(function()
					iterSecond.Volume = 0
					iterSecond:Pause()
					iterSecond.TimePosition = 0
				end)
			end

			iterSecond.Visible = false
		end
	end
end

local t4: {[any]: any} = {}
local object4 = setmetatable({}, { __mode = "k" })
local u23: boolean = false

local function processWarmQueue()
	if u23 then
		return
	end

	u23 = true
	task.spawn(function()
		while #t4 > 0 do
			local v129 = table.remove(t4, 1)

			object4[v129] = nil

			if v129 and v129:IsA("VideoFrame") and v129.Parent and not t3[v129] then
				t3[v129] = true

				local visible = v129.Visible
				local backgroundTransparency = v129.BackgroundTransparency
				local timePosition = v129.TimePosition
				local volume = v129.Volume
				local t8: {[any]: any} = {}

				object3[v129] = t8
				pcall(function()
					v129:SetAttribute("PreloadWarmMuted", true)
					v129.Volume = 0
					v129.BackgroundTransparency = 1
					v129.Visible = true
					v129.TimePosition = 0
					v129:Play()
				end)
				task.wait(0.2)
				pcall(function()
					v129:Pause()
					v129.TimePosition = timePosition or 0
					v129.BackgroundTransparency = backgroundTransparency
					v129.Visible = visible
					v129:SetAttribute("PreloadWarmMuted", nil)

					if not object2[v129] and not v129.Visible then
						v129.Volume = 0
					else
						v129.Volume = volume
					end

					if object3[v129] == t8 then
						object3[v129] = nil
					end
				end)
				task.wait(0.1)
			end
		end

		u23 = false
	end)
end
local function warmVideoFrame(p2)
	if p2 and p2:IsA("VideoFrame") and not t3[p2] and not object4[p2] then
		object4[p2] = true
		t4[#t4 + 1] = p2

		if u23 then
			return
		end

		u23 = true
		task.spawn(function()
			while #t4 > 0 do
				local v135 = table.remove(t4, 1)

				object4[v135] = nil

				if v135 and v135:IsA("VideoFrame") and v135.Parent and not t3[v135] then
					t3[v135] = true

					local visible = v135.Visible
					local backgroundTransparency = v135.BackgroundTransparency
					local timePosition = v135.TimePosition
					local volume = v135.Volume
					local t9: {[any]: any} = {}

					object3[v135] = t9
					pcall(function()
						v135:SetAttribute("PreloadWarmMuted", true)
						v135.Volume = 0
						v135.BackgroundTransparency = 1
						v135.Visible = true
						v135.TimePosition = 0
						v135:Play()
					end)
					task.wait(0.2)
					pcall(function()
						v135:Pause()
						v135.TimePosition = timePosition or 0
						v135.BackgroundTransparency = backgroundTransparency
						v135.Visible = visible
						v135:SetAttribute("PreloadWarmMuted", nil)

						if not object2[v135] and not v135.Visible then
							v135.Volume = 0
						else
							v135.Volume = volume
						end

						if object3[v135] == t9 then
							object3[v135] = nil
						end
					end)
					task.wait(0.1)
				end
			end

			u23 = false
		end)

		return
	end
end
local function preloadVideoFrame(p3)
	if not p3 or not p3:IsA("VideoFrame") then
		return
	end

	local v51 = p3.Video
	local lazyVideoId = p3:GetAttribute("LazyVideoId")

	if (typeof(v51) ~= "string" or v51 == "") and typeof(lazyVideoId) == "string" and lazyVideoId ~= "" then
		v51 = lazyVideoId
		p3.Video = lazyVideoId
	end

	if typeof(v51) ~= "string" or v51 == "" then
		return
	end

	if t2[v51] then
		if not p3 or not p3:IsA("VideoFrame") or t3[p3] then
			return
		end

		if object4[p3] then
			return
		end

		object4[p3] = true
		t4[#t4 + 1] = p3

		if u23 then
			return
		end

		u23 = true
		task.spawn(function()
			while #t4 > 0 do
				local v141 = table.remove(t4, 1)

				object4[v141] = nil

				if v141 and v141:IsA("VideoFrame") and v141.Parent and not t3[v141] then
					t3[v141] = true

					local visible = v141.Visible
					local backgroundTransparency = v141.BackgroundTransparency
					local timePosition = v141.TimePosition
					local volume = v141.Volume
					local t10: {[any]: any} = {}

					object3[v141] = t10
					pcall(function()
						v141:SetAttribute("PreloadWarmMuted", true)
						v141.Volume = 0
						v141.BackgroundTransparency = 1
						v141.Visible = true
						v141.TimePosition = 0
						v141:Play()
					end)
					task.wait(0.2)
					pcall(function()
						v141:Pause()
						v141.TimePosition = timePosition or 0
						v141.BackgroundTransparency = backgroundTransparency
						v141.Visible = visible
						v141:SetAttribute("PreloadWarmMuted", nil)

						if not object2[v141] and not v141.Visible then
							v141.Volume = 0
						else
							v141.Volume = volume
						end

						if object3[v141] == t10 then
							object3[v141] = nil
						end
					end)
					task.wait(0.1)
				end
			end

			u23 = false
		end)

		return
	end

	t2[v51] = true
	task.spawn(function()
		pcall(function()
			contentProvider:PreloadAsync({ p3 })
		end)

		local v147 = p3

		if not v147 or not v147:IsA("VideoFrame") or t3[v147] then
			return
		end

		if object4[v147] then
			return
		end

		object4[v147] = true
		t4[#t4 + 1] = v147

		if u23 then
			return
		end

		u23 = true
		task.spawn(function()
			while #t4 > 0 do
				local v165 = table.remove(t4, 1)

				object4[v165] = nil

				if v165 and v165:IsA("VideoFrame") and v165.Parent and not t3[v165] then
					t3[v165] = true

					local visible = v165.Visible
					local backgroundTransparency = v165.BackgroundTransparency
					local timePosition = v165.TimePosition
					local volume = v165.Volume
					local t13: {[any]: any} = {}

					object3[v165] = t13
					pcall(function()
						v165:SetAttribute("PreloadWarmMuted", true)
						v165.Volume = 0
						v165.BackgroundTransparency = 1
						v165.Visible = true
						v165.TimePosition = 0
						v165:Play()
					end)
					task.wait(0.2)
					pcall(function()
						v165:Pause()
						v165.TimePosition = timePosition or 0
						v165.BackgroundTransparency = backgroundTransparency
						v165.Visible = visible
						v165:SetAttribute("PreloadWarmMuted", nil)

						if not object2[v165] and not v165.Visible then
							v165.Volume = 0
						else
							v165.Volume = volume
						end

						if object3[v165] == t13 then
							object3[v165] = nil
						end
					end)
					task.wait(0.1)
				end
			end

			u23 = false
		end)
	end)
end
local function bindVideoPreload(p4)
	if p4 and p4:IsA("VideoFrame") and not p4:GetAttribute("VideoPreloadBound") then
		p4:SetAttribute("VideoPreloadBound", true)
		preloadVideoFrame(p4)
		p4:GetPropertyChangedSignal("Video"):Connect(function()
			preloadVideoFrame(p4)
		end)

		return
	end
end
local function forEachDescendantBatched(p5, p6)
	task.spawn(function()
		local t11: {[any]: any} = { p5 }
		local n1: number = 0

		while #t11 > 0 do
			local v150 = table.remove(t11)

			p6(v150)

			local children = v150:GetChildren()

			for i = 1, #children do
				t11[#t11 + 1] = children[i]
			end

			n1 += 1

			if n1 >= 200 then
				n1 = 0
				task.wait()
			end
		end
	end)
end
local function preloadVideoTree(p7)
	if not p7 then
		return
	end

	local function v57(p8)
		if p8:IsA("VideoFrame") then
			bindVideoPreload(p8)
		end
	end

	task.spawn(function()
		local t12: {[any]: any} = { p7 }
		local n1: number = 0

		while #t12 > 0 do
			local v156 = table.remove(t12)

			v57(v156)

			local children = v156:GetChildren()

			for i = 1, #children do
				t12[#t12 + 1] = children[i]
			end

			n1 += 1

			if n1 >= 200 then
				n1 = 0
				task.wait()
			end
		end
	end)

	if p7:GetAttribute("VideoPreloadTreeBound") then
		return
	end

	p7:SetAttribute("VideoPreloadTreeBound", true)
	p7.DescendantAdded:Connect(function(p9)
		if p9:IsA("VideoFrame") then
			bindVideoPreload(p9)
		end
	end)
end
local function preloadContentTree(p10)
	if p10 and not object[p10] then
		object[p10] = true
		task.spawn(function()
			pcall(function()
				contentProvider:PreloadAsync({ p10 })
			end)
		end)

		return
	end
end
local function rememberTween(p11)
	t1[#t1 + 1] = p11
	p11.Completed:Once(function()
		for i = #t1, 1, -1 do
			if t1[i] == p11 then
				table.remove(t1, i)

				return
			end
		end
	end)

	return p11
end
local function cancelTweens()
	for i = #t1, 1, -1 do
		local v61 = t1[i]

		if v61 then
			pcall(function()
				v61:Cancel()
			end)
		end

		t1[i] = nil
	end
end
local function getVideoGuiParts()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

	if not playerGui then
		return nil
	end

	local videoGui: Instance = playerGui:FindFirstChild("VideoGui")
	local v64: Instance = videoGui

	if v64 then
		v64 = videoGui:FindFirstChild("UpperFrame")
	end

	if not v64 then
		return nil
	end

	local rendererVideo = v64:FindFirstChild("RendererVideo")

	if not rendererVideo then
		rendererVideo = Instance.new("VideoFrame")
		rendererVideo.Name = "RendererVideo"
		rendererVideo.BackgroundTransparency = 1
		rendererVideo.Transparency = 1
		rendererVideo.Visible = false
		rendererVideo.Size = UDim2.fromScale(1, 1)
		rendererVideo.Position = UDim2.fromScale(0, 0)
		rendererVideo.ZIndex = v64.ZIndex + 5
		rendererVideo.Parent = v64
	end

	return videoGui, v64, rendererVideo
end
local function safeStop(p12)
	if not p12 then
		return
	end

	pcall(function()
		p12:Pause()

		if not object2[p12] then
			p12.Volume = 0
		end
	end)
	pcall(function()
		p12.TimePosition = 0
	end)
end
local function safePlay(p13)
	if not p13 then
		return
	end

	safeStop(p13)
	pcall(function()
		p13:Play()
	end)
end
local function hideVideoChildren(p14, p15)
	for iterFirst, iterSecond in p14:GetChildren() do
		if iterSecond:IsA("VideoFrame") and iterSecond ~= p15 then
			object2[iterSecond] = nil
			iterSecond.Visible = false

			if iterSecond and iterSecond:IsA("VideoFrame") then
				pcall(function()
					iterSecond.Volume = 0
					iterSecond:Pause()
					iterSecond.TimePosition = 0
				end)
			end
		end
	end
end
local function getVideoTimeLength(p16, p17, p18)
	local numberValue = tonumber(p17) or 1
	local numberValue2: number? = tonumber(p18)

	if not p16 or not p16:IsA("VideoFrame") then
		return numberValue
	end

	local v77 = os.clock()

	while true do
		if not (os.clock() - v77 < 2) then
			break
		end

		local timeLength = p16.TimeLength

		if typeof(timeLength) == "number" and timeLength > 0 then
			return (math.min(timeLength, numberValue2 or 30))
		end

		task.wait(0.05)
	end

	return numberValue
end
local function resolveDuration(p19, p20, p21)
	local v82 = p20.HoldBeforeFade or p19.HoldBeforeFade
	local v83 = p20.Duration or p19.Duration
	local v84 = p20.FallbackDuration or p19.FallbackDuration
	local v85 = p20.MaxDuration or p19.MaxDuration

	if v82 == "TimeLength" then
		return getVideoTimeLength(p21, v84, v85), 0
	end

	if v83 == "TimeLength" then
		v83 = getVideoTimeLength(p21, v84, v85)
	end

	local numberValue: number? = tonumber(v82)
	local numberValue3: number? = tonumber(v83)

	return numberValue or 0, numberValue3 or 0
end
local function playEffect(p22, p23)
	local t5 = typeof(p23) == "table" and p23 or {}
	local v91 = videoEffectConfig[p22]

	if not v91 then
		warn("[VideoRenderer] Unknown video effect:", p22)

		return
	end

	n1 += 1

	local v92: number = n1

	cancelTweens()

	local v93, v94, v95 = getVideoGuiParts()

	if v94 and v95 then
		local foundChild = v94:FindFirstChild(t5.FrameName or v91.FrameName or p22)
		local v97 = foundChild and foundChild:IsA("VideoFrame") and foundChild or v95

		if foundChild and foundChild:IsA("VideoFrame") then
			preloadVideoFrame(foundChild)
		else
			local video = t5.Video or v91.Video

			if typeof(video) == "string" and video ~= "" then
				v95.Video = video
				v97 = v95
			end
		end

		if v97 == v95 and foundChild and foundChild:IsA("VideoFrame") then
			local v99 = foundChild.Video

			if v99 == "" then
				v99 = foundChild:GetAttribute("LazyVideoId")
			end

			if typeof(v99) == "string" and v99 ~= "" then
				v97.Video = v99
				v97.Looped = foundChild.Looped
				v97.Volume = foundChild.Volume
				v97.Size = t5.Size or v91.Size or foundChild.Size
				v97.Position = t5.Position or v91.Position or foundChild.Position
				v97.AnchorPoint = foundChild.AnchorPoint
				v97.BackgroundColor3 = foundChild.BackgroundColor3
				v97.BackgroundTransparency = v91.VideoBackgroundTransparency or foundChild.BackgroundTransparency
				v97.ZIndex = t5.VideoZIndex or v91.VideoZIndex or foundChild.ZIndex
			end
		end

		if not v97 or not v97:IsA("VideoFrame") then
			warn("[VideoRenderer] Missing VideoFrame for effect:", p22)

			return
		end

		hideVideoChildren(v94, v97)
		object2[v97] = true

		local userInputServiceMouseIconEnabled: boolean = userInputService.MouseIconEnabled
		local v101 = t5.HideMouse or v91.HideMouse

		if tonumber(v91.StartDelay) and v91.StartDelay > 0 then
			task.wait(v91.StartDelay)

			if v92 ~= n1 then
				return
			end
		end

		v94.Visible = true
		v94.BackgroundTransparency = t5.StartBackgroundTransparency or v91.StartBackgroundTransparency or 1

		if v91.UpperZIndex then
			v94.ZIndex = v91.UpperZIndex
		end

		v97.Visible = true
		v97.Transparency = t5.VideoTransparency or v91.VideoTransparency or v97.Transparency
		v97.BackgroundTransparency = t5.VideoBackgroundTransparency or v91.VideoBackgroundTransparency or v97.BackgroundTransparency

		if t5.VideoZIndex or v91.VideoZIndex then
			v97.ZIndex = t5.VideoZIndex or v91.VideoZIndex
		end

		if v97 then
			preloadVideoFrame(v97)
		end

		if v97 then
			safeStop(v97)
			pcall(function()
				v97:Play()
			end)
		end

		if v97:GetAttribute("PreloadWarmMuted") then
			v97:SetAttribute("PreloadWarmMuted", nil)
		end

		if v97.Volume <= 0 then
			local Volume = nil

			if foundChild and foundChild:IsA("VideoFrame") and foundChild ~= v97 then
				Volume = foundChild.Volume
			end

			v97.Volume = tonumber(t5.Volume or v91.Volume or Volume) or 1
		end

		if v101 then
			userInputService.MouseIconEnabled = false
		end

		local v103, v104 = resolveDuration(v91, t5, v97)

		if v103 > 0 then
			task.wait(v103)

			if v92 ~= n1 then
				return
			end
		end

		local numberValue = tonumber(t5.FadeInTime or v91.FadeInTime) or 0
		local backgroundTransparency = t5.FadeInBackgroundTransparency or v91.FadeInBackgroundTransparency

		if backgroundTransparency ~= nil then
			if numberValue > 0 then
				local tweenInfo = TweenInfo.new(numberValue)
				local v108: Tween = tweenService:Create(v94, tweenInfo, { BackgroundTransparency = backgroundTransparency })

				t1[#t1 + 1] = v108
				v108.Completed:Once(function()
					for i = #t1, 1, -1 do
						if t1[i] == v108 then
							table.remove(t1, i)

							return
						end
					end
				end)
				v108:Play()
			else
				v94.BackgroundTransparency = backgroundTransparency
			end
		end

		if v104 > 0 then
			task.wait(v104)

			if v92 ~= n1 then
				return
			end
		end

		v97.Visible = false

		if v101 then
			userInputService.MouseIconEnabled = userInputServiceMouseIconEnabled
		end

		local numberValue4 = tonumber(t5.FadeOutTime or v91.FadeOutTime) or 0

		if numberValue4 > 0 then
			local tweenInfo = TweenInfo.new(numberValue4)
			local v111: Tween = tweenService:Create(v94, tweenInfo, { BackgroundTransparency = 1 })

			t1[#t1 + 1] = v111
			v111.Completed:Once(function()
				for i = #t1, 1, -1 do
					if t1[i] == v111 then
						table.remove(t1, i)

						return
					end
				end
			end)
			v111:Play()

			local v112 = t5.EndVideoTransparency or v91.EndVideoTransparency

			if v112 ~= nil then
				local tweenInfo2 = TweenInfo.new(numberValue4)
				local v114: Tween = tweenService:Create(v97, tweenInfo2, { Transparency = v112 })

				t1[#t1 + 1] = v114
				v114.Completed:Once(function()
					for i = #t1, 1, -1 do
						if t1[i] == v114 then
							table.remove(t1, i)

							return
						end
					end
				end)
				v114:Play()
			end

			task.wait(numberValue4)
		else
			v94.BackgroundTransparency = 1
		end

		if v92 ~= n1 then
			return
		end

		safeStop(v97)
		object2[v97] = nil
		v94.Visible = false

		return
	end

	warn("[VideoRenderer] VideoGui.UpperFrame missing")
end

LocalPlayer.CharacterAdded:Connect(function()
	n1 += 1
	cancelTweens()
	task.defer(scrubInactiveVideoGui)
	task.delay(0.5, scrubInactiveVideoGui)
end)

if LocalPlayer.Character then
	task.defer(scrubInactiveVideoGui)
end

local v40 = (function()
	local t6: {[any]: any} = {}
	local t7: {[any]: any} = {}

	for k, v in pairs(videoEffectConfig) do
		local v119 = v.FrameName or k

		if typeof(v119) == "string" and v119 ~= "" and not t7[v119] then
			t7[v119] = true
			t6[#t6 + 1] = v119
		end
	end

	return t6
end)()

local function warmConfiguredVideoFrames()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")
	local videoGui: Instance = playerGui and playerGui:FindFirstChild("VideoGui")
	local v122: Instance = videoGui

	if v122 then
		v122 = videoGui:FindFirstChild("UpperFrame")
	end

	if not v122 then
		return
	end

	for i = 1, #v40 do
		local foundChild: Instance = v122:FindFirstChild(v40[i])

		if foundChild and foundChild:IsA("VideoFrame") then
			bindVideoPreload(foundChild)

			if not object2[foundChild] and not foundChild.Visible and foundChild and foundChild:IsA("VideoFrame") then
				pcall(function()
					foundChild.Volume = 0
					foundChild:Pause()
					foundChild.TimePosition = 0
				end)
			end

			preloadVideoFrame(foundChild)
		end
	end
end
local function scheduleConfiguredVideoWarmup()
	task.delay(0.2, warmConfiguredVideoFrames)
	task.delay(1.5, warmConfiguredVideoFrames)
	task.delay(4, warmConfiguredVideoFrames)
end

task.spawn(function()
	(LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")).ChildAdded:Connect(function(p24)
		if p24.Name == "VideoGui" then
			task.delay(0.2, warmConfiguredVideoFrames)
			task.delay(1.5, warmConfiguredVideoFrames)
			task.delay(4, warmConfiguredVideoFrames)
		end
	end)
	task.delay(0.2, warmConfiguredVideoFrames)
	task.delay(1.5, warmConfiguredVideoFrames)
	task.delay(4, warmConfiguredVideoFrames)
end)
playVideoEffect.OnClientEvent:Connect(function(p25, p26)
	if typeof(p25) == "string" then
		task.spawn(playEffect, p25, p26)

		return
	end
end)
playVideoEffectLocal.Event:Connect(function(p27, p28)
	if typeof(p27) == "string" then
		task.spawn(playEffect, p27, p28)

		return
	end
end)
