-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local userInputService: UserInputService = game:GetService("UserInputService")
local contextActionService: ContextActionService = game:GetService("ContextActionService")
local userInputServiceTouchEnabled: boolean = userInputService.TouchEnabled
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local menuRemotes: Instance = replicatedStorage:WaitForChild("MenuRemotes")
local saveMobileMovesetLayout: Instance = menuRemotes:WaitForChild("SaveMobileMovesetLayout")
local loadMobileMovesetLayout: Instance = menuRemotes:WaitForChild("LoadMobileMovesetLayout")
local combat: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat")

require(combat:WaitForChild("ComboBreakerConfig"))

local t1: {[any]: any} = {
	"MoveOne",
	"MoveTwo",
	"MoveThree",
	"MoveFour",
	"MoveFive",
	"SpecialMove",
	"Combat",
	"Guard",
	"Sprint",
	"ComboBreaker",
	"MoonKnightForm",
	"MrKnightForm"
}
local t2: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(0.07, 0, 0.13, 0),
	Size = UDim2.new(0.3, 0, 0.6, 0)
}
local t3: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(0.28, 0, 0.11, 0),
	Size = UDim2.new(0.3, 0, 0.6, 0)
}
local t4: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(0.5, 0, 0.11, 0),
	Size = UDim2.new(0.3, 0, 0.6, 0)
}
local t5: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(0.71, 0, 0.09, 0),
	Size = UDim2.new(0.3, 0, 0.6, 0)
}
local t6: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(0.92, 0, 0.08, 0),
	Size = UDim2.new(0.3, 0, 0.6, 0)
}
local t7: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(1.28, 0, 0.23, 0),
	Size = UDim2.new(0.21, 0, 0.44, 0)
}
local t8: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(1.43, 0, -2.06, 0),
	Size = UDim2.new(0.31, 0, 0.48, 0)
}
local t9: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(1.72, 0, -0.95, 0),
	Size = UDim2.new(0.24, 0, 0.36, 0)
}
local t10: {[any]: any} = {
	Visible = false,
	Position = UDim2.new(1.72, 0, -2.35, 0),
	Size = UDim2.new(0.24, 0, 0.36, 0)
}
local t11: {[any]: any} = {
	Visible = true,
	Position = UDim2.new(1.72, 0, -1.75, 0),
	Size = UDim2.new(0.24, 0, 0.36, 0)
}
local t12: {[any]: any} = {
	Visible = false,
	Position = UDim2.new(1.1999, 0, -2.6432, 0),
	Size = UDim2.new(0.237, 0, 0.5884, 0)
}
local t13: {[any]: any} = {
	Visible = false,
	Position = UDim2.new(1.2109, 0, -1.5337, 0),
	Size = UDim2.new(0.227, 0, 0.5, 0)
}
local t14 = {}
local t15 = {}
local t16 = {}
local t17: {[any]: any} = {}
local screenGui = nil
local u30: boolean = false
local u31 = nil
local u32 = nil
local u33 = nil
local t18: {[any]: any} = {}
local t19: {[any]: any} = {}
local t20: {[any]: any} = {}
local u37 = nil
local u38 = nil
local u39: boolean = false
local n1 = os.clock() + 2
local u41 = nil
local u42 = nil
local u43 = nil
local u44: boolean = false
local u45 = false
local u46 = nil
local u47 = nil

local function copyUDim2(p1)
	return UDim2.new(p1.X.Scale, p1.X.Offset, p1.Y.Scale, p1.Y.Offset)
end
local function uDim2ToData(p2)
	return {
		XScale = p2.X.Scale,
		XOffset = p2.X.Offset,
		YScale = p2.Y.Scale,
		YOffset = p2.Y.Offset
	}
end
local function dataToUDim2(p3, p4)
	if typeof(p3) == "table" then
		local uDim2New = UDim2.new
		local v102 = typeof(p3.XScale) == "number" and p3.XScale or p4.X.Scale
		local v103 = typeof(p3.XOffset) == "number" and p3.XOffset or p4.X.Offset
		local v104 = typeof(p3.YScale) == "number" and p3.YScale or p4.Y.Scale
		local typeName: string = typeof(p3.YOffset)

		return uDim2New(v102, v103, v104, typeName == "number" and p3.YOffset or p4.Y.Offset)
	end

	return p4
end

local t21: {[any]: any} = {
	MoveOne = t2,
	MoveTwo = t3,
	MoveThree = t4,
	MoveFour = t5,
	MoveFive = t6,
	SpecialMove = t7,
	Combat = t8,
	Guard = t9,
	Sprint = t10,
	ComboBreaker = t11,
	MoonKnightForm = t12,
	MrKnightForm = t13
}

local function getSafeSprintMarkerLayout(p5)
	local sprint = t21.Sprint

	if p5 and p5:IsA("GuiObject") and not (p5.AbsoluteSize.X <= 0) and not (p5.AbsoluteSize.Y <= 0) then
		local v108 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize.X or 0
		local v109 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize.Y or 0

		if v108 <= 0 or v109 <= 0 then
			local v110 = sprint.Position
			local uDim2 = UDim2.new(v110.X.Scale, v110.X.Offset, v110.Y.Scale, v110.Y.Offset)

			v110 = sprint.Size

			local uDim22 = UDim2.new(v110.X.Scale, v110.X.Offset, v110.Y.Scale, v110.Y.Offset)

			return {
				Position = uDim2,
				Size = uDim22,
				Visible = if sprint.Visible == false then false else true
			}
		end

		local uDim2 = UDim2.new((v108 - 155 - p5.AbsolutePosition.X) / p5.AbsoluteSize.X, 0, (v109 - 90 - p5.AbsolutePosition.Y) / p5.AbsoluteSize.Y, 0)
		local sprintSize = sprint.Size
		local uDim23 = UDim2.new(sprintSize.X.Scale, sprintSize.X.Offset, sprintSize.Y.Scale, sprintSize.Y.Offset)

		return {
			Position = uDim2,
			Size = uDim23,
			Visible = if sprint.Visible == false then false else true
		}
	end

	local v116 = sprint.Position
	local uDim2 = UDim2.new(v116.X.Scale, v116.X.Offset, v116.Y.Scale, v116.Y.Offset)

	v116 = sprint.Size

	local uDim24 = UDim2.new(v116.X.Scale, v116.X.Offset, v116.Y.Scale, v116.Y.Offset)

	return {
		Position = uDim2,
		Size = uDim24,
		Visible = if sprint.Visible == false then false else true
	}
end
local function getContextPreviewParent()
	local v119 = screenGui

	if not v119 then
		return nil
	end

	return v119
end

local t22: {[any]: any} = {
	MoveOne = {
		DisplayName = "Move 1",
		DragObject = "FirstButton",
		Parts = { "FirstButton", "One", "Onecd", "Oneletter", "OneMove" }
	},
	MoveTwo = {
		DisplayName = "Move 2",
		DragObject = "SecondButton",
		Parts = { "SecondButton", "Two", "Twocd", "TwoLetter", "TwoMove" }
	},
	MoveThree = {
		DisplayName = "Move 3",
		DragObject = "ThirdButton",
		Parts = { "ThirdButton", "Three", "Threecd", "ThirdLetter", "ThreeMove" }
	},
	MoveFour = {
		DisplayName = "Move 4",
		DragObject = "FourthButton",
		Parts = { "FourthButton", "Four", "Fourcd", "FourLetter", "FourMove" }
	},
	MoveFive = {
		DisplayName = "Move 5",
		DragObject = "FifthButton",
		Parts = { "FifthButton", "Five", "Fivecd", "FiveLetter", "FiveMove" }
	},
	SpecialMove = {
		DisplayName = "Special",
		DragObject = "EButton",
		Parts = { "EButton", "E", "Ecd", "ELetter", "Emove" }
	},
	Combat = {
		DisplayName = "Combat",
		DragObject = "M1Button",
		Parts = { "M1Button", "M1", "M1Letter", "M1Move", "M1cd" }
	},
	Guard = {
		DisplayName = "Guard",
		DragObject = "FButton",
		Parts = { "FButton", "F", "FLetter", "FMove" }
	},
	Sprint = {
		DisplayName = "Sprint",
		DragObject = "SprintButton",
		EditorOnly = true,
		Parts = { "SprintButton", "Sprint", "SprintLetter", "SprintMove" }
	},
	ComboBreaker = {
		DisplayName = "Combo Breaker",
		DragObject = "BreakerButton",
		Parts = { "BreakerButton", "Breaker", "BreakerLetter", "BreakerMove" }
	},
	MoonKnightForm = {
		DisplayName = "Moon Knight",
		DragObject = "EightButton",
		Parts = { "EightButton", "Eight", "Eightcd", "EightLetter", "EightMove" }
	},
	MrKnightForm = {
		DisplayName = "Mr. Knight",
		DragObject = "NinthButton",
		Parts = { "NinthButton", "Nine", "Ninecd", "NineLetter", "NineMove" }
	}
}

local function makeContextActionPreview(p6)
	local v121 = t22[p6]
	local v122 = t14[p6] or t21[p6]
	local v123 = screenGui
	local parent = if not v123 then nil else v123

	if v121 and v121.ContextAction and v122 and parent then
		local v125 = t20[p6]

		if v125 and v125.Parent then
			v125.Position = v122.Position
			v125.Size = v122.Size
			v125.Visible = u30 or u39

			return v125
		end

		local textButton: TextButton = Instance.new("TextButton")

		textButton.Name = p6 .. "PreviewButton"
		textButton.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
		textButton.BackgroundTransparency = 0.15
		textButton.BorderSizePixel = 0
		textButton.Position = v122.Position
		textButton.Size = v122.Size
		textButton.Font = Enum.Font.GothamBold
		textButton.Text = v121.DisplayName or p6
		textButton.TextColor3 = Color3.fromRGB(255, 255, 255)
		textButton.TextScaled = true
		textButton.ZIndex = 210
		textButton.Visible = u30 or u39
		textButton.Active = true
		textButton.Parent = parent

		local uiCorner: UICorner = Instance.new("UICorner")

		uiCorner.CornerRadius = UDim.new(0, 8)
		uiCorner.Parent = textButton
		t20[p6] = textButton

		return textButton
	end

	return nil
end
local function hideContextActionPreviews()
	for _, v in pairs(t20) do
		if v and v.Parent and v:IsA("GuiObject") then
			v.Visible = false
		end
	end
end
local function getContextActionButton(p7)
	local v131 = t22[p7]

	if not v131 or not v131.ContextAction then
		return nil
	end

	local ok, result = pcall(function()
		return contextActionService:GetButton(v131.DragObject or p7)
	end)

	if ok and result and result:IsA("GuiObject") then
		local v134 = t20[p7]

		if v134 then
			v134.Visible = false
		end

		return result
	end

	return (makeContextActionPreview(p7))
end
local function deepCopyLayout(p8)
	local u136
	local t24: {[any]: any} = {}

	for k, v in pairs(t21) do
		local v140 = p8 and p8[k]
		local v141 = v142

		if v140 then
			local v143 = v140.Position

			v141 = UDim2.new(v143.X.Scale, v143.X.Offset, v143.Y.Scale, v143.Y.Offset)
		end

		if not v140 or not v141 then
			local vPosition = v.Position

			v141 = UDim2.new(vPosition.X.Scale, vPosition.X.Offset, vPosition.Y.Scale, vPosition.Y.Offset)
		end

		local t25: {[any]: any} = { Position = v141, Size = v146, Visible = u136 }
		local v146 = v147

		if v140 then
			local v148 = v140.Size

			v146 = UDim2.new(v148.X.Scale, v148.X.Offset, v148.Y.Scale, v148.Y.Offset)
		end

		if not v140 or not v146 then
			local vSize = v.Size

			v146 = UDim2.new(vSize.X.Scale, vSize.X.Offset, vSize.Y.Scale, vSize.Y.Offset)
		end

		if v140 then
			local u136 = true

			if v140.Visible == false then
				u136 = v.Visible ~= false
			end
		else
			u136 = v.Visible ~= false
		end

		t24[k] = t25
	end

	return t24
end
local function copyLayoutEntry(p9, p10)
	local t26 = p10 or {}
	local t27: {[any]: any} = {
		Position = p9 and UDim2.new(p9.Position.X.Scale, p9.Position.X.Offset, p9.Position.Y.Scale, p9.Position.Y.Offset) or t26.Position,
		Size = p9 and UDim2.new(p9.Size.X.Scale, p9.Size.X.Offset, p9.Size.Y.Scale, p9.Size.Y.Offset) or t26.Size
	}
	local u154

	if p9 then
		u154 = true

		if p9.Visible == false then
			u154 = t26.Visible ~= false
		end
	else
		u154 = t26.Visible ~= false
	end

	t27.Visible = u154

	return t27
end
local function keepSessionLayout(p11)
	if p11 and t14[p11] then
		u44 = true
		u45 = true
		t15[p11] = copyLayoutEntry(t14[p11], t21[p11])
	end
end
local function keepAllSessionLayout()
	u44 = true
	u45 = true
	t15 = deepCopyLayout(t14)
end
local function captureLayoutFromHold(p12, p13)
	if not p12 then
		local v158 = deepCopyLayout(p13 or t21)
		local u159: boolean = false

		for _, v in ipairs(t1) do
			local v162 = t22[v]
			local v163 = v162 and v162.ContextAction and getContextActionButton(v)

			if v163 and v163:IsA("GuiObject") then
				local v164 = v163.Position
				local uDim2 = UDim2.new(v164.X.Scale, v164.X.Offset, v164.Y.Scale, v164.Y.Offset)

				v164 = v163.Size

				local uDim25 = UDim2.new(v164.X.Scale, v164.X.Offset, v164.Y.Scale, v164.Y.Offset)

				v158[v] = {
					Position = uDim2,
					Size = uDim25,
					Visible = if v163.Visible == false then false else true
				}
				u159 = true
			end
		end

		return u159 and v158 or nil
	end

	local v167 = deepCopyLayout(p13 or t21)

	for _, v in ipairs(t1) do
		local v170 = t22[v]
		local v171 = nil

		if v170 then
			v171 = if v170.ContextAction then getContextActionButton(v) else p12:FindFirstChild(v170.DragObject)
		end

		if v171 and v171:IsA("GuiObject") then
			local v172 = v171.Position
			local uDim2 = UDim2.new(v172.X.Scale, v172.X.Offset, v172.Y.Scale, v172.Y.Offset)

			v172 = v171.Size

			local uDim26 = UDim2.new(v172.X.Scale, v172.X.Offset, v172.Y.Scale, v172.Y.Offset)

			v167[v] = {
				Position = uDim2,
				Size = uDim26,
				Visible = if v171.Visible == false then false else true
			}
		end
	end

	return v167
end
local function getStudioResetLayout()
	local moveset: Instance = game:GetService("StarterGui"):FindFirstChild("Moveset")
	local v176: Instance = moveset

	if v176 then
		v176 = moveset:FindFirstChild("Frame")
	end

	local hold: Instance = v176 and v176:FindFirstChild("Hold")

	return (captureLayoutFromHold(hold, t21))
end
local function captureMainGameDefaultLayout(p14)
	local v179 = captureLayoutFromHold(p14, t16)

	if v179 then
		t16 = v179
	end
end
local function getResetLayout()
	local v180 = getStudioResetLayout()

	if not v180 then
		v180 = next(t16) and deepCopyLayout(t16) or deepCopyLayout(t21)
	end

	v180.Sprint = getSafeSprintMarkerLayout(u47())

	return v180
end
local function deserializeLayout(p15)
	local v182 = deepCopyLayout(t21)

	if typeof(p15) == "table" then
		for k, v in pairs(p15) do
			if v182[k] and typeof(v) == "table" then
				v182[k].Position = dataToUDim2(v.Position, v182[k].Position)
				v182[k].Size = dataToUDim2(v.Size, v182[k].Size)

				if v.Visible ~= nil then
					v182[k].Visible = v.Visible ~= false
				end
			end
		end

		return v182
	end

	return v182
end
local function serializeLayout(p16)
	local t28: {[any]: any} = {}

	for k, v in pairs(p16) do
		local vPosition = v.Position
		local vSize = v.Size

		t28[k] = {
			Position = {
				XScale = vPosition.X.Scale,
				XOffset = vPosition.X.Offset,
				YScale = vPosition.Y.Scale,
				YOffset = vPosition.Y.Offset
			},
			Size = {
				XScale = vSize.X.Scale,
				XOffset = vSize.X.Offset,
				YScale = vSize.Y.Scale,
				YOffset = vSize.Y.Offset
			},
			Visible = if v.Visible == false then false else true
		}
	end

	return t28
end

u47 = function()
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	return frame and frame:FindFirstChild("Hold")
end

local function setMovesetEditorVisible(p17)
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	if p17 then
		u37 = moveset and moveset:IsA("ScreenGui") and moveset.Enabled or nil
		u38 = frame and frame:IsA("GuiObject") and frame.Visible or nil

		if moveset and moveset:IsA("ScreenGui") then
			moveset.Enabled = true
		end

		if frame and frame:IsA("GuiObject") then
			frame.Visible = true

			return
		end
	else
		if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
			moveset.Enabled = u37
		end

		if frame and frame:IsA("GuiObject") and u38 ~= nil then
			frame.Visible = u38
		end

		hideContextActionPreviews()
		u37 = nil
		u38 = nil
	end
end
local function forceHideMovesetEditorPreview()
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	if moveset and moveset:IsA("ScreenGui") then
		moveset.Enabled = false
	end

	if frame and frame:IsA("GuiObject") then
		frame.Visible = true
	end

	hideContextActionPreviews()
	u37 = nil
	u38 = nil
end
local function getGroupObjects(p18, p19)
	local v200 = t22[p19]
	local t29: {[any]: any} = {}

	if not v200 then
		return t29
	end

	if v200.ContextAction then
		local v202 = getContextActionButton(p19)

		if v202 then
			table.insert(t29, v202)
		end

		return t29
	end

	if not p18 then
		return t29
	end

	for _, v in ipairs(v200.Parts) do
		local v = p18:FindFirstChild(v)

		if v and v:IsA("GuiObject") then
			table.insert(t29, v)
		end
	end

	return t29
end
local function getDragObject(p20, p21)
	local v208 = t22[p21]

	if v208 and v208.ContextAction then
		return (getContextActionButton(p21))
	end

	return v208 and p20 and p20:FindFirstChild(v208.DragObject)
end
local function captureDefaultOffsets(p22)
	t17 = {}

	for _, v in ipairs(t1) do
		local v212 = t22[v]
		local foundChild

		if v212 and v212.ContextAction then
			foundChild = getContextActionButton(v)
		else
			foundChild = v212 and p22

			if foundChild then
				foundChild = p22:FindFirstChild(v212.DragObject)
			end
		end

		if foundChild and foundChild:IsA("GuiObject") then
			t17[v] = {}

			local v214 = getGroupObjects(p22, v)

			for _, iterValue in ipairs(v214) do
				local v217 = t17[v]
				local v218 = iterValue.Name
				local uDim2 = UDim2.new(iterValue.Position.X.Scale - foundChild.Position.X.Scale, iterValue.Position.X.Offset - foundChild.Position.X.Offset, iterValue.Position.Y.Scale - foundChild.Position.Y.Scale, iterValue.Position.Y.Offset - foundChild.Position.Y.Offset)
				local t30: {[any]: any} = {
					PositionOffset = uDim2,
					SizeRatioX = foundChild.AbsoluteSize.X > 0 and iterValue.AbsoluteSize.X / foundChild.AbsoluteSize.X or 1,
					SizeRatioY = foundChild.AbsoluteSize.Y > 0 and iterValue.AbsoluteSize.Y / foundChild.AbsoluteSize.Y or 1
				}
				local v221 = iterValue.Size

				t30.OriginalSize = UDim2.new(v221.X.Scale, v221.X.Offset, v221.Y.Scale, v221.Y.Offset)
				v217[v218] = t30
			end
		end
	end
end
local function scaleOffset(p23, p24, p25)
	return UDim2.new(p23.X.Scale * p24, p23.X.Offset * p24, p23.Y.Scale * p25, p23.Y.Offset * p25)
end
local function applyGroupLayout(p26, p27)
	local v227 = t14[p27]
	local v228 = t22[p27]

	if v227 and (not not p26 or not not v228 and not not v228.ContextAction) then
		local v229 = t22[p27]
		local foundChild

		if v229 and v229.ContextAction then
			foundChild = getContextActionButton(p27)
		else
			foundChild = v229 and p26

			if foundChild then
				foundChild = p26:FindFirstChild(v229.DragObject)
			end
		end

		if not foundChild or not foundChild:IsA("GuiObject") then
			return
		end

		v229 = t17[p27] or {}

		local v231 = v229[foundChild.Name] and v229[foundChild.Name].OriginalSize or foundChild.Size
		local n1 = 1
		local n2 = 1

		if v231.X.Scale ~= 0 then
			n1 = v227.Size.X.Scale / v231.X.Scale
		elseif v231.X.Offset ~= 0 then
			n1 = v227.Size.X.Offset / v231.X.Offset
		end

		if v231.Y.Scale ~= 0 then
			n2 = v227.Size.Y.Scale / v231.Y.Scale
		elseif v231.Y.Offset ~= 0 then
			n2 = v227.Size.Y.Offset / v231.Y.Offset
		end

		v231 = v227.Visible ~= false

		if v228 and v228.EditorOnly then
			v231 = u30 or u39
		elseif u30 or u39 or v231 == false and t21[p27] and t21[p27].Visible == false and foundChild.Visible then
			v231 = true
		end

		if v228 and v228.ContextAction and foundChild == getContextActionButton(p27) and foundChild.Name ~= p27 .. "PreviewButton" then
			pcall(function()
				contextActionService:SetPosition(v228.DragObject or p27, v227.Position)
			end)
		end

		foundChild.Position = v227.Position
		foundChild.Size = v227.Size
		foundChild.Visible = v231
		foundChild.Active = true

		local v234 = getGroupObjects(p26, p27)

		for _, v in ipairs(v234) do
			local v237 = v229[v.Name]

			if v == foundChild then
				v.Position = v227.Position
				v.Size = v227.Size
			else
				local v238 = v237 and v237.PositionOffset or UDim2.new()
				local v239 = v227.Position
				local uDim2 = UDim2.new(v238.X.Scale * n1, v238.X.Offset * n1, v238.Y.Scale * n2, v238.Y.Offset * n2)

				v.Position = v239 + uDim2

				if v237 and v237.OriginalSize then
					v.Size = UDim2.new(v237.OriginalSize.X.Scale * n1, v237.OriginalSize.X.Offset * n1, v237.OriginalSize.Y.Scale * n2, v237.OriginalSize.Y.Offset * n2)
				end
			end

			v.Visible = v231

			local v241 = u30

			if not v241 then
				v241 = true

				if v ~= foundChild then
					v241 = v:IsA("GuiButton")
				end
			end

			v.Active = v241

			if v228 and v228.EditorOnly then
				v.Active = u30
			end
		end

		if v228 and v228.ContextAction and t20[p27] and foundChild ~= t20[p27] then
			local v242 = t20[p27]

			v242.Position = v227.Position
			v242.Size = v227.Size
			v242.Visible = u30 or u39
		end

		return
	end
end
local function applyLayoutToMoveset()
	local v243 = u47()

	u33 = v243

	if v243 and not next(t17) then
		captureDefaultOffsets(v243)
	elseif not next(t17) then
		captureDefaultOffsets(nil)
	end

	for _, v in ipairs(t1) do
		applyGroupLayout(v243, v)
	end
end
local function layoutHasSavedData(p28)
	if typeof(p28) == "table" then
		for k, v in pairs(p28) do
			if t21[k] and typeof(v) == "table" then
				return true
			end
		end

		return false
	end

	return false
end
local function loadSavedLayout()
	local ok, result = pcall(function()
		return loadMobileMovesetLayout:InvokeServer()
	end)

	if ok then
		u45 = layoutHasSavedData(result)
		t15 = deserializeLayout(result)
	else
		u45 = false
		t15 = deepCopyLayout(t21)
	end

	t14 = deepCopyLayout(t15)

	if not layoutHasSavedData(result) and t14.Sprint then
		t14.Sprint = getSafeSprintMarkerLayout(u47())
	end

	if u45 or userInputServiceTouchEnabled then
		applyLayoutToMoveset()
	end
end
local function makeButton(parent, name, text, p32, p33)
	local textButton: TextButton = Instance.new("TextButton")

	textButton.Name = name
	textButton.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	textButton.BackgroundTransparency = 0.15
	textButton.BorderSizePixel = 0
	textButton.Position = p32
	textButton.Size = p33
	textButton.Font = Enum.Font.GothamBold
	textButton.Text = text
	textButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	textButton.TextScaled = true
	textButton.ZIndex = 200
	textButton.Parent = parent

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 8)
	uiCorner.Parent = textButton

	return textButton
end
local function restoreMenuForSettings()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local frame: Instance = menu and menu:FindFirstChild("Frame")
	local controlsPage: Instance = frame and frame:FindFirstChild("ControlsPage")

	if menu and menu:IsA("ScreenGui") then
		menu.Enabled = u41 ~= nil and u41 or true
	end

	if frame and frame:IsA("GuiObject") then
		frame.Visible = u42 ~= nil and u42 or true
	end

	if controlsPage and controlsPage:IsA("GuiObject") then
		controlsPage.Visible = true
	end

	u41 = nil
	u42 = nil
	u43 = nil
end
local function hideMenuForDragMode()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local frame: Instance = menu and menu:FindFirstChild("Frame")
	local controlsPage: Instance = frame and frame:FindFirstChild("ControlsPage")

	if u41 == nil and menu and menu:IsA("ScreenGui") then
		u41 = menu.Enabled
	end

	if u42 == nil and frame and frame:IsA("GuiObject") then
		u42 = frame.Visible
	end

	if u43 == nil and controlsPage and controlsPage:IsA("GuiObject") then
		u43 = controlsPage.Visible
	end

	if frame and frame:IsA("GuiObject") then
		frame.Visible = false
	end

	if menu and menu:IsA("ScreenGui") then
		menu.Enabled = true
	end
end
local function makeEditorGui()
	if screenGui then
		return screenGui
	end

	screenGui = Instance.new("ScreenGui")
	screenGui.Name = "MobileMovesetLayoutEditor"
	screenGui.ResetOnSpawn = false
	screenGui.IgnoreGuiInset = true
	screenGui.Enabled = true
	screenGui.DisplayOrder = 999
	screenGui.Parent = playerGui

	local panel: Frame = Instance.new("Frame")

	panel.Name = "Panel"
	panel.Visible = false
	panel.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	panel.BackgroundTransparency = 0.22
	panel.BorderSizePixel = 0
	panel.Position = UDim2.new(0.02, 0, 0.18, 0)
	panel.Size = UDim2.new(0, 230, 0, 430)
	panel.ZIndex = 190
	panel.Parent = screenGui

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 10)
	uiCorner.Parent = panel

	local title: TextLabel = Instance.new("TextLabel")

	title.Name = "Title"
	title.BackgroundTransparency = 1
	title.Position = UDim2.new(0.04, 0, 0.02, 0)
	title.Size = UDim2.new(0.92, 0, 0, 32)
	title.Font = Enum.Font.GothamBold
	title.Text = "Mobile Moveset"
	title.TextColor3 = Color3.fromRGB(255, 255, 180)
	title.TextScaled = true
	title.ZIndex = 191
	title.Parent = panel

	local status: TextLabel = Instance.new("TextLabel")

	status.Name = "Status"
	status.BackgroundTransparency = 1
	status.Position = UDim2.new(0.04, 0, 0.1, 0)
	status.Size = UDim2.new(0.92, 0, 0, 42)
	status.Font = Enum.Font.Gotham
	status.Text = "Pick a button, then drag it."
	status.TextColor3 = Color3.fromRGB(255, 255, 255)
	status.TextScaled = true
	status.ZIndex = 191
	status.Parent = panel

	local buttonList: ScrollingFrame = Instance.new("ScrollingFrame")

	buttonList.Name = "ButtonList"
	buttonList.BackgroundTransparency = 1
	buttonList.BorderSizePixel = 0
	buttonList.Position = UDim2.new(0.04, 0, 0.21, 0)
	buttonList.Size = UDim2.new(0.92, 0, 0.47, 0)
	buttonList.CanvasSize = UDim2.new(0, 0, 0, 0)
	buttonList.AutomaticCanvasSize = Enum.AutomaticSize.Y
	buttonList.ScrollBarThickness = 4
	buttonList.ZIndex = 191
	buttonList.Parent = panel

	local uiListLayout: UIListLayout = Instance.new("UIListLayout")

	uiListLayout.Padding = UDim.new(0, 6)
	uiListLayout.Parent = buttonList

	for _, v in ipairs(t1) do
		local v272 = t22[v]
		local v273 = makeButton(buttonList, v, v272.DisplayName, UDim2.new(), UDim2.new(1, -6, 0, 32))

		v273.ZIndex = 192
		v273.MouseButton1Click:Connect(function()
			u31 = v
			status.Text = "Selected " .. v272.DisplayName
		end)
	end

	local uDim2 = UDim2.new(0.43, 0, 0, 34)

	makeButton(panel, "Smaller", "- Size", UDim2.new(0.04, 0, 0.69, 0), uDim2)
	makeButton(panel, "Bigger", "+ Size", UDim2.new(0.53, 0, 0.69, 0), uDim2)
	makeButton(panel, "HideShow", "Hide/Show", UDim2.new(0.04, 0, 0.7749999999999999, 0), uDim2)
	makeButton(panel, "ResetOne", "Reset One", UDim2.new(0.53, 0, 0.7749999999999999, 0), uDim2)
	makeButton(panel, "ResetAll", "Reset All", UDim2.new(0.04, 0, 0.86, 0), uDim2)
	makeButton(panel, "Save", "Save", UDim2.new(0.53, 0, 0.86, 0), uDim2)
	makeButton(panel, "Cancel", "Close", UDim2.new(0.04, 0, 0.945, 0), UDim2.new(0.92, 0, 0, 34))

	local v275 = makeButton(screenGui, "OpenButton", "Edit Mobile Moveset", UDim2.new(1, -190, 0, 110), UDim2.new(0, 170, 0, 42))

	v275.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	v275.Visible = false

	local v276 = makeButton(screenGui, "BackToSettings", "Back to Buttons", UDim2.new(0.5, -120, 0, 18), UDim2.new(0, 240, 0, 42))

	v276.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	v276.BackgroundTransparency = 0.5

	local menu: Instance = playerGui:FindFirstChild("Menu")
	local v278 = menu and menu:FindFirstChild("Frame") and menu.Frame:FindFirstChild("ControlsPage") and menu.Frame.ControlsPage:FindFirstChild("Tabs") and menu.Frame.ControlsPage.Tabs:FindFirstChild("KeyboardTab")

	if v278 and v278:IsA("TextButton") then
		v276.FontFace = v278.FontFace
		v276.TextStrokeColor3 = v278.TextStrokeColor3
		v276.TextStrokeTransparency = v278.TextStrokeTransparency
	else
		v276.Font = Enum.Font.Arcade
	end

	v276.TextColor3 = Color3.fromRGB(255, 255, 255)

	local uiCorner2 = v276:FindFirstChildOfClass("UICorner")

	if uiCorner2 then
		uiCorner2.CornerRadius = UDim.new(0, 10)
	end

	v276.Visible = false
	v278 = function()
		if not u31 then
			status.Text = "Select a move button first."

			return nil
		end

		return u31
	end
	panel.Smaller.MouseButton1Click:Connect(function()
		local v349

		if not u31 then
			status.Text = "Select a move button first."
			v349 = nil
		else
			v349 = u31
		end

		if not v349 then
			return
		end

		local v350 = t14[v349]

		v350.Size = UDim2.new(v350.Size.X.Scale * 0.92, v350.Size.X.Offset * 0.92, v350.Size.Y.Scale * 0.92, v350.Size.Y.Offset * 0.92)

		if v349 and t14[v349] then
			u44 = true
			u45 = true
			t15[v349] = copyLayoutEntry(t14[v349], t21[v349])
		end

		applyGroupLayout(u33, v349)
	end)
	panel.Bigger.MouseButton1Click:Connect(function()
		local v351

		if not u31 then
			status.Text = "Select a move button first."
			v351 = nil
		else
			v351 = u31
		end

		if not v351 then
			return
		end

		local v352 = t14[v351]

		v352.Size = UDim2.new(v352.Size.X.Scale * 1.08, v352.Size.X.Offset * 1.08, v352.Size.Y.Scale * 1.08, v352.Size.Y.Offset * 1.08)

		if v351 and t14[v351] then
			u44 = true
			u45 = true
			t15[v351] = copyLayoutEntry(t14[v351], t21[v351])
		end

		applyGroupLayout(u33, v351)
	end)
	panel.HideShow.MouseButton1Click:Connect(function()
		local v353

		if not u31 then
			status.Text = "Select a move button first."
			v353 = nil
		else
			v353 = u31
		end

		if not v353 then
			return
		end

		t14[v353].Visible = not t14[v353].Visible

		if v353 and t14[v353] then
			u44 = true
			u45 = true
			t15[v353] = copyLayoutEntry(t14[v353], t21[v353])
		end

		applyGroupLayout(u33, v353)
	end)
	panel.ResetOne.MouseButton1Click:Connect(function()
		local v354

		if not u31 then
			status.Text = "Select a move button first."
			v354 = nil
		else
			v354 = u31
		end

		if not v354 then
			return
		end

		u44 = true
		u45 = true

		local v355 = t14
		local v356 = getStudioResetLayout()

		if not v356 then
			v356 = next(t16) and deepCopyLayout(t16)

			if not v356 then
				v356 = deepCopyLayout(t21)
			end
		end

		v356.Sprint = getSafeSprintMarkerLayout(u47())
		v355[v354] = v356[v354]
		t15[v354] = copyLayoutEntry(t14[v354], t21[v354])
		v355 = u47()

		if v355 then
			u33 = v355
			applyGroupLayout(v355, v354)
		end

		status.Text = "Reset " .. t22[v354].DisplayName
	end)
	panel.ResetAll.MouseButton1Click:Connect(function()
		u44 = true
		u45 = true

		local v357 = getStudioResetLayout()

		if not v357 then
			v357 = next(t16) and deepCopyLayout(t16)

			if not v357 then
				v357 = deepCopyLayout(t21)
			end
		end

		v357.Sprint = getSafeSprintMarkerLayout(u47())
		t14 = v357
		t15 = deepCopyLayout(t14)
		v357 = u47()

		if v357 then
			u33 = v357
			captureDefaultOffsets(v357)

			for _, v in ipairs(t1) do
				applyGroupLayout(v357, v)
			end
		end

		status.Text = "Reset all mobile buttons. Press Save to keep it."
	end)
	panel.Save.MouseButton1Click:Connect(function()
		t15 = deepCopyLayout(t14)

		local v360 = serializeLayout(t15)

		saveMobileMovesetLayout:FireServer(v360)
		status.Text = "Saved mobile layout."
	end)
	panel.Cancel.MouseButton1Click:Connect(function()
		u30 = false
		u39 = false
		u32 = nil
		u31 = nil
		panel.Visible = false
		v275.Visible = false
		t14 = deepCopyLayout(t15)
		applyLayoutToMoveset()
		restoreMenuForSettings()

		if u46() then
			forceHideMovesetEditorPreview()

			return
		end

		local moveset: Instance = playerGui:FindFirstChild("Moveset")
		local frame: Instance = moveset and moveset:FindFirstChild("Frame")

		if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
			moveset.Enabled = u37
		end

		if frame and frame:IsA("GuiObject") and u38 ~= nil then
			frame.Visible = u38
		end

		hideContextActionPreviews()
		u37 = nil
		u38 = nil
	end)
	v275.MouseButton1Click:Connect(function()
		if os.clock() < n1 then
			return
		end

		u30 = true
		u39 = true
		setMovesetEditorVisible(true)
		panel.Visible = true
		v275.Visible = false
		applyLayoutToMoveset()
		status.Text = "Pick a button, then drag any visible piece."
	end)
	v276.MouseButton1Click:Connect(function()
		u30 = false
		u39 = false
		u32 = nil
		u31 = nil
		v276.Visible = false
		restoreMenuForSettings()

		if u46() then
			forceHideMovesetEditorPreview()

			return
		end

		local moveset: Instance = playerGui:FindFirstChild("Moveset")
		local frame: Instance = moveset and moveset:FindFirstChild("Frame")

		if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
			moveset.Enabled = u37
		end

		if frame and frame:IsA("GuiObject") and u38 ~= nil then
			frame.Visible = u38
		end

		hideContextActionPreviews()
		u37 = nil
		u38 = nil
	end)

	return screenGui
end
local function positionToParentScale(p34, p35)
	local absolutePosition = p34.AbsolutePosition
	local absoluteSize = p34.AbsoluteSize

	return UDim2.new(absoluteSize.X > 0 and (p35.X - absolutePosition.X) / absoluteSize.X or 0, 0, absoluteSize.Y > 0 and (p35.Y - absolutePosition.Y) / absoluteSize.Y or 0, 0)
end
local function positionToParentOffset(p36, p37)
	if p36 and p36:IsA("GuiObject") then
		local absolutePosition = p36.AbsolutePosition

		return UDim2.new(0, p37.X - absolutePosition.X, 0, p37.Y - absolutePosition.Y)
	end

	return UDim2.new(0, p37.X, 0, p37.Y)
end
local function positionToViewportScaleOffset(p38, _)
	local v289 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(0, 0)

	return UDim2.new(1, if v289.X > 0 then p38.X - v289.X else p38.X, 1, if v289.Y > 0 then p38.Y - v289.Y else p38.Y)
end
local function connectDragForAction(p40, p41)
	local v292 = t22[p41]
	local foundChild

	if v292 and v292.ContextAction then
		foundChild = getContextActionButton(p41)
	else
		foundChild = v292 and p40

		if foundChild then
			foundChild = p40:FindFirstChild(v292.DragObject)
		end
	end

	if not foundChild or not foundChild:IsA("GuiObject") then
		return
	end

	v292 = function(input)
		if not u30 then
		elseif input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
			u31 = p41
			u32 = {
				ActionName = p41,
				Input = input,
				StartPointer = input.Position,
				StartAbsolute = foundChild.AbsolutePosition,
				StartSize = foundChild.AbsoluteSize,
				ContextAction = t22[p41] and (if t22[p41].ContextAction == true then true else false),
				UseScaleDrag = t22[p41] and (if t22[p41].UseScaleDrag == true then true else false),
				DragParent = foundChild.Parent
			}

			return
		end
	end

	local v294 = getGroupObjects(p40, p41)

	for _, v in ipairs(v294) do
		local v297 = u30

		if not v297 then
			v297 = true

			if v ~= foundChild then
				v297 = v:IsA("GuiButton")
			end
		end

		v.Active = v297
		table.insert(t18, v.InputBegan:Connect(v292))
	end
end
local function disconnectDragConnections()
	for _, v in ipairs(t18) do
		v:Disconnect()
	end

	t18 = {}
end
local function connectMoveset(p43, p44)
	disconnectDragConnections()
	u33 = p43

	if not next(t16) then
		local v302 = captureLayoutFromHold(p43, t16)

		if v302 then
			t16 = v302
		end
	end

	captureDefaultOffsets(p43)

	if p44 ~= false then
		applyLayoutToMoveset()
	end

	for _, v in ipairs(t1) do
		connectDragForAction(p43, v)
	end
end

userInputService.InputChanged:Connect(function(input: InputObject)
	if not u30 or not u32 then
	elseif input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseMovement then
		local v306 = u33

		if not v306 and not u32.ContextAction then
			return
		end

		local n1 = input.Position - u32.StartPointer
		local startAbsolute = u32.StartAbsolute
		local vector2 = Vector2.new(n1.X, n1.Y)
		local n2 = startAbsolute + vector2

		if u32.UseScaleDrag then
			t14[u32.ActionName].Position = positionToViewportScaleOffset(n2, u32.StartSize)
		elseif u32.ContextAction then
			t14[u32.ActionName].Position = positionToParentOffset(u32.DragParent, n2)
		else
			t14[u32.ActionName].Position = positionToParentScale(v306, n2)
		end

		local actionName = u32.ActionName

		if actionName and t14[actionName] then
			u44 = true
			u45 = true
			t15[actionName] = copyLayoutEntry(t14[actionName], t21[actionName])
		end

		applyGroupLayout(v306, u32.ActionName)

		return
	end
end)
userInputService.InputEnded:Connect(function(input: InputObject)
	if u32 and (input == u32.Input or input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
		u32 = nil
	end
end)

local function ensureEditorClosed()
	u30 = false
	u39 = false
	u32 = nil

	if screenGui then
		local panel = screenGui:FindFirstChild("Panel")
		local openButton = screenGui:FindFirstChild("OpenButton")

		if panel and panel:IsA("GuiObject") then
			panel.Visible = false
		end

		local backToSettings = screenGui:FindFirstChild("BackToSettings")

		if backToSettings and backToSettings:IsA("GuiObject") then
			backToSettings.Visible = false
		end

		if openButton and openButton:IsA("GuiObject") then
			openButton.Visible = false
		end
	end

	hideContextActionPreviews()
end

u46 = function()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local frame: Instance = menu and menu:FindFirstChild("Frame")

	return (menu and menu:IsA("ScreenGui") and menu.Enabled and frame and frame:IsA("GuiObject") and frame.Visible) == true
end

local function exitEditModeForRespawn()
	u30 = false
	u39 = false
	u32 = nil
	u31 = nil

	if screenGui then
		local panel = screenGui:FindFirstChild("Panel")
		local backToSettings = screenGui:FindFirstChild("BackToSettings")
		local openButton = screenGui:FindFirstChild("OpenButton")

		if panel and panel:IsA("GuiObject") then
			panel.Visible = false
		end

		if backToSettings and backToSettings:IsA("GuiObject") then
			backToSettings.Visible = false
		end

		if openButton and openButton:IsA("GuiObject") then
			openButton.Visible = false
		end
	end

	restoreMenuForSettings()

	if u46() then
		forceHideMovesetEditorPreview()

		return
	end

	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
		moveset.Enabled = u37
	end

	if frame and frame:IsA("GuiObject") and u38 ~= nil then
		frame.Visible = u38
	end

	hideContextActionPreviews()
	u37 = nil
	u38 = nil
end
local function ensureBridge()
	local mobileMovesetLayoutBridge = playerGui:FindFirstChild("MobileMovesetLayoutBridge")

	if not mobileMovesetLayoutBridge or not mobileMovesetLayoutBridge:IsA("BindableFunction") then
		mobileMovesetLayoutBridge = Instance.new("BindableFunction")
		mobileMovesetLayoutBridge.Name = "MobileMovesetLayoutBridge"
		mobileMovesetLayoutBridge.Parent = playerGui
	end

	function mobileMovesetLayoutBridge.OnInvoke(p47, p48)
		if p47 == "Open" then
			u44 = true
			u30 = true
			u39 = true
			setMovesetEditorVisible(true)

			local v368 = u47()

			if v368 then
				connectMoveset(v368)
			end

			applyLayoutToMoveset()

			local panel = screenGui and screenGui:FindFirstChild("Panel")

			if panel and panel:IsA("GuiObject") then
				panel.Visible = false
			end

			return true
		end

		if p47 == "Close" then
			u30 = false
			u39 = false
			u32 = nil
			u31 = nil
			restoreMenuForSettings()

			if u46() then
				forceHideMovesetEditorPreview()
			else
				local moveset: Instance = playerGui:FindFirstChild("Moveset")
				local frame: Instance = moveset and moveset:FindFirstChild("Frame")

				if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
					moveset.Enabled = u37
				end

				if frame and frame:IsA("GuiObject") and u38 ~= nil then
					frame.Visible = u38
				end

				hideContextActionPreviews()
				u37 = nil
				u38 = nil
			end

			return true
		end

		if p47 == "Cancel" then
			t14 = deepCopyLayout(t15)
			applyLayoutToMoveset()
			u30 = false
			u39 = false
			u32 = nil
			u31 = nil
			restoreMenuForSettings()

			if u46() then
				forceHideMovesetEditorPreview()
			else
				local moveset: Instance = playerGui:FindFirstChild("Moveset")
				local movesetFrame: Instance = moveset and moveset:FindFirstChild("Frame")

				if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
					moveset.Enabled = u37
				end

				if movesetFrame and movesetFrame:IsA("GuiObject") and u38 ~= nil then
					movesetFrame.Visible = u38
				end

				hideContextActionPreviews()
				u37 = nil
				u38 = nil
			end

			return true
		end

		if p47 == "Save" then
			u44 = true
			u45 = true
			t15 = deepCopyLayout(t14)

			local v374 = serializeLayout(t15)

			saveMobileMovesetLayout:FireServer(v374)
			u30 = false
			u39 = false
			u32 = nil
			u31 = nil
			applyLayoutToMoveset()

			return true
		end

		if p47 ~= "Select" then
			if p47 == "ScaleDown" then
				local v375 = p48 and t14[p48]

				if v375 then
					v375.Size = UDim2.new(v375.Size.X.Scale * 0.92, v375.Size.X.Offset * 0.92, v375.Size.Y.Scale * 0.92, v375.Size.Y.Offset * 0.92)

					if p48 and t14[p48] then
						u44 = true
						u45 = true
						t15[p48] = copyLayoutEntry(t14[p48], t21[p48])
					end

					applyGroupLayout(u33, p48)

					return true
				end
			elseif p47 == "ScaleUp" then
				local v376 = p48 and t14[p48]

				if v376 then
					v376.Size = UDim2.new(v376.Size.X.Scale * 1.08, v376.Size.X.Offset * 1.08, v376.Size.Y.Scale * 1.08, v376.Size.Y.Offset * 1.08)

					if p48 and t14[p48] then
						u44 = true
						u45 = true
						t15[p48] = copyLayoutEntry(t14[p48], t21[p48])
					end

					applyGroupLayout(u33, p48)

					return true
				end
			elseif p47 == "MoveUp" or p47 == "MoveDown" then
				local v377 = p48 and t14[p48]

				if v377 then
					v377.Position = UDim2.new(v377.Position.X.Scale, v377.Position.X.Offset, v377.Position.Y.Scale, v377.Position.Y.Offset + (if p47 == "MoveUp" then -10 else 10))

					if p48 and t14[p48] then
						u44 = true
						u45 = true
						t15[p48] = copyLayoutEntry(t14[p48], t21[p48])
					end

					applyGroupLayout(u33, p48)

					return true
				end
			elseif p47 == "ToggleVisible" then
				local v378 = p48 and t14[p48]

				if v378 then
					v378.Visible = not v378.Visible

					if p48 and t14[p48] then
						u44 = true
						u45 = true
						t15[p48] = copyLayoutEntry(t14[p48], t21[p48])
					end

					applyGroupLayout(u33, p48)

					return v378.Visible
				end
			elseif p47 ~= "ResetOne" then
				if p47 == "ResetAll" then
					u44 = true
					u45 = true

					local v379 = getStudioResetLayout()

					if not v379 then
						v379 = next(t16) and deepCopyLayout(t16)

						if not v379 then
							v379 = deepCopyLayout(t21)
						end
					end

					v379.Sprint = getSafeSprintMarkerLayout(u47())
					t14 = v379
					t15 = deepCopyLayout(t14)
					t17 = {}
					v379 = u47()

					if v379 then
						u33 = v379
						captureDefaultOffsets(v379)

						for _, v in ipairs(t1) do
							applyGroupLayout(v379, v)
						end
					end

					return true
				end
			elseif p48 and t14[p48] then
				u44 = true
				u45 = true

				local v382 = t14
				local v383 = getStudioResetLayout()

				if not v383 then
					v383 = next(t16) and deepCopyLayout(t16)

					if not v383 then
						v383 = deepCopyLayout(t21)
					end
				end

				v383.Sprint = getSafeSprintMarkerLayout(u47())
				v382[p48] = v383[p48]
				t15[p48] = copyLayoutEntry(t14[p48], t21[p48])
				v382 = u47()

				if v382 then
					u33 = v382
					applyGroupLayout(v382, p48)
				end

				return true
			end

			return nil
		end

		if p48 and t14[p48] then
			u44 = true
			u31 = p48
			u30 = true
			u39 = true
			setMovesetEditorVisible(true)

			local v384 = u47()

			if v384 then
				connectMoveset(v384)
			else
				u33 = nil
				disconnectDragConnections()
				applyGroupLayout(nil, p48)
				connectDragForAction(nil, p48)
			end

			hideMenuForDragMode()

			local backToSettings = screenGui and screenGui:FindFirstChild("BackToSettings")

			if backToSettings and backToSettings:IsA("GuiObject") then
				backToSettings.Visible = true
			end

			return true
		end

		return false
	end
end

playerGui.ChildAdded:Connect(function(p49: Instance)
	if p49.Name == "Moveset" then
		task.wait(0.3)

		local v325 = u47()

		if v325 then
			connectMoveset(v325, userInputServiceTouchEnabled or u44 or u45)
		end

		if userInputServiceTouchEnabled or u44 or u45 then
			task.delay(0.75, applyLayoutToMoveset)
		end

		if not userInputServiceTouchEnabled and not u44 and not u45 then
			local v326 = getStudioResetLayout()

			if not v326 then
				v326 = next(t16) and deepCopyLayout(t16) or deepCopyLayout(t21)
			end

			v326.Sprint = getSafeSprintMarkerLayout(u47())
			t14 = v326
		end

		if u30 and u46() then
			forceHideMovesetEditorPreview()

			return
		end

		local moveset: Instance = playerGui:FindFirstChild("Moveset")
		local frame: Instance = moveset and moveset:FindFirstChild("Frame")

		if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
			moveset.Enabled = u37
		end

		if frame and frame:IsA("GuiObject") and u38 ~= nil then
			frame.Visible = u38
		end

		hideContextActionPreviews()
		u37 = nil
		u38 = nil

		return
	end
end)
LocalPlayer.CharacterAdded:Connect(function()
	u30 = false
	u39 = false
	u32 = nil
	u31 = nil

	local backToSettings = screenGui and screenGui:FindFirstChild("BackToSettings")

	if backToSettings and backToSettings:IsA("GuiObject") then
		backToSettings.Visible = false
	end

	task.wait(1)

	local v330 = u47()

	if v330 then
		connectMoveset(v330, userInputServiceTouchEnabled or u44 or u45)
	end

	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
		moveset.Enabled = u37
	end

	if frame and frame:IsA("GuiObject") and u38 ~= nil then
		frame.Visible = u38
	end

	hideContextActionPreviews()
	u37 = nil
	u38 = nil
end)
playerGui.ChildRemoved:Connect(function(p50: Instance)
	if p50.Name == "MobileMovesetLayoutBridge" then
		task.defer(ensureBridge)
	end
end);
(function()
	makeEditorGui()
	ensureBridge()
	ensureEditorClosed()

	local v334 = u47()
	local v335 = v334 and not next(t16) and captureLayoutFromHold(v334, t16)

	if v335 then
		t16 = v335
	end

	v335 = getStudioResetLayout()

	if not v335 then
		v335 = next(t16) and deepCopyLayout(t16)

		if not v335 then
			v335 = deepCopyLayout(t21)
		end
	end

	v335.Sprint = getSafeSprintMarkerLayout(u47())
	t14 = v335
	v335 = getStudioResetLayout()

	if not v335 then
		v335 = next(t16) and deepCopyLayout(t16)

		if not v335 then
			v335 = deepCopyLayout(t21)
		end
	end

	v335.Sprint = getSafeSprintMarkerLayout(u47())
	t15 = v335
	loadSavedLayout()

	if userInputServiceTouchEnabled or u44 or u45 then
		task.delay(0.75, applyLayoutToMoveset)
		task.delay(1.5, applyLayoutToMoveset)
	end

	ensureEditorClosed()

	if v334 then
		connectMoveset(v334, userInputServiceTouchEnabled or u44 or u45)
	end

	task.delay(1, function()
		if not u30 then
			ensureEditorClosed()

			if u46() then
				forceHideMovesetEditorPreview()

				return
			end

			local moveset: Instance = playerGui:FindFirstChild("Moveset")
			local frame: Instance = moveset and moveset:FindFirstChild("Frame")

			if moveset and moveset:IsA("ScreenGui") and u37 ~= nil then
				moveset.Enabled = u37
			end

			if frame and frame:IsA("GuiObject") and u38 ~= nil then
				frame.Visible = u38
			end

			hideContextActionPreviews()
			u37 = nil
			u38 = nil

			return
		end
	end)
end)()
task.delay(1.5, ensureBridge)

local t23: {[any]: any} = {}
local u92 = false

local function restoreMovesetAfterMenuCloses()
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")

	if moveset and moveset:IsA("ScreenGui") then
		moveset.Enabled = true
	end

	if frame and frame:IsA("GuiObject") then
		frame.Visible = true
	end

	local v338 = u47()

	if v338 then
		connectMoveset(v338, userInputServiceTouchEnabled or u44 or u45)
	end
end
local function syncMovesetForMenuState()
	local v339 = u46()

	if not u30 and v339 then
		forceHideMovesetEditorPreview()
	elseif u92 and not v339 then
		restoreMovesetAfterMenuCloses()
	end

	u92 = v339
end
local function disconnectMenuWatcher()
	for i = 1, #t23 do
		t23[i]:Disconnect()
	end

	t23 = {}
end
local function watchMenuState()
	disconnectMenuWatcher()

	local menu: Instance = playerGui:FindFirstChild("Menu")
	local frame: Instance = menu and menu:FindFirstChild("Frame")

	if menu and menu:IsA("ScreenGui") then
		local v343: {[any]: any} = t23
		local v344: RBXScriptSignal = menu:GetPropertyChangedSignal("Enabled")

		table.insert(v343, v344:Connect(syncMovesetForMenuState))
		table.insert(t23, menu.ChildAdded:Connect(function(p51: Instance)
			if p51.Name == "Frame" then
				task.defer(watchMenuState)
			end
		end))
		table.insert(t23, menu.ChildRemoved:Connect(function(p52: Instance)
			if p52.Name == "Frame" then
				task.defer(watchMenuState)
			end
		end))
	end

	if frame and frame:IsA("GuiObject") then
		local v345: {[any]: any} = t23
		local v346: RBXScriptSignal = frame:GetPropertyChangedSignal("Visible")

		table.insert(v345, v346:Connect(syncMovesetForMenuState))
	end

	u92 = u46()

	local v347 = u46()

	if not u30 and v347 then
		forceHideMovesetEditorPreview()
	elseif u92 and not v347 then
		restoreMovesetAfterMenuCloses()
	end

	u92 = v347
end

playerGui.ChildAdded:Connect(function(p53: Instance)
	if p53.Name == "Menu" then
		task.defer(watchMenuState)
	end
end)
watchMenuState()
