-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local LocalPlayer: Player = game:GetService("Players").LocalPlayer
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })

local function isGuiVisible(p1)
	local v15 = p1

	while v15 and v15 ~= game do
		if v15:IsA("GuiObject") and v15.Visible == false then
			return false
		end

		if v15:IsA("ScreenGui") and v15.Enabled == false then
			return false
		end

		v15 = v15.Parent
	end

	return true
end
local function restoreImage(p2)
	if not p2:IsA("ImageLabel") and not p2:IsA("ImageButton") then
		return
	end

	local lazyImageId = p2:GetAttribute("LazyImageId")

	if typeof(lazyImageId) == "string" and lazyImageId ~= "" and p2.Image == "" then
		p2.Image = lazyImageId
	end
end
local function clearImageIfHidden(p3)
	if not p3:IsA("ImageLabel") and not p3:IsA("ImageButton") then
		return
	end

	if isGuiVisible(p3) then
		restoreImage(p3)

		return
	end

	local lazyImageId = p3:GetAttribute("LazyImageId")

	if typeof(lazyImageId) == "string" and lazyImageId ~= "" and p3.Image ~= "" then
		p3.Image = ""
	end
end
local function cleanupImage(p4)
	local v21 = object2[p4]

	if v21 then
		for i = 1, #v21 do
			local v23 = v21[i]

			if v23 and v23.Connected then
				v23:Disconnect()
			end
		end
	end

	object2[p4] = nil
	object[p4] = nil
end
local function watchAncestorVisibility(p5, p6)
	local v26 = p5

	while v26 and v26 ~= game do
		if v26:IsA("GuiObject") then
			local v27 = v26:GetPropertyChangedSignal("Visible")

			table.insert(p6, v27:Connect(function()
				clearImageIfHidden(p5)
			end))
		elseif v26:IsA("ScreenGui") then
			local v28 = v26:GetPropertyChangedSignal("Enabled")

			table.insert(p6, v28:Connect(function()
				clearImageIfHidden(p5)
			end))
		end

		v26 = v26.Parent
	end
end
local function bindImage(p7)
	if not p7:IsA("ImageLabel") and not p7:IsA("ImageButton") then
	elseif object[p7] then
	elseif typeof(p7:GetAttribute("LazyImageId")) == "string" and p7:GetAttribute("LazyImageId") ~= "" then
		object[p7] = true
		p7:SetAttribute("LazyImageClientBound", true)

		local t1: {[any]: any} = {}

		object2[p7] = t1
		watchAncestorVisibility(p7, t1)
		table.insert(t1, p7.Destroying:Connect(function()
			cleanupImage(p7)
		end))
		clearImageIfHidden(p7)

		return
	end
end

local object3 = setmetatable({}, { __mode = "k" })

local function scan(p8)
	if not p8 then
		return
	end

	if not p8:IsA("ImageLabel") and not p8:IsA("ImageButton") then
		task.spawn(function()
			local t2: {[any]: any} = { p8 }
			local n1: number = 0

			while #t2 > 0 do
				local v37 = table.remove(t2)

				if v37:IsA("ImageLabel") or v37:IsA("ImageButton") then
					bindImage(v37)
				end

				local children = v37:GetChildren()

				for i = 1, #children do
					t2[#t2 + 1] = children[i]
				end

				n1 += 1

				if n1 >= 200 then
					n1 = 0
					task.wait()
				end
			end
		end)

		return
	end

	bindImage(p8)
end
local function watch(p9)
	if p9 and not object3[p9] then
		object3[p9] = true
		scan(p9)
		p9.DescendantAdded:Connect(function(p10: Instance)
			if p10:IsA("ImageLabel") or p10:IsA("ImageButton") then
				bindImage(p10)
			end
		end)

		return
	end
end

local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

if playerGui and not object3[playerGui] then
	object3[playerGui] = true
	scan(playerGui)
	playerGui.DescendantAdded:Connect(function(p11: Instance)
		if p11:IsA("ImageLabel") or p11:IsA("ImageButton") then
			bindImage(p11)
		end
	end)
end

LocalPlayer.ChildAdded:Connect(function(child: Instance)
	if not child:IsA("PlayerGui") or not child then
		return
	end

	if object3[child] then
		return
	end

	object3[child] = true
	scan(child)
	child.DescendantAdded:Connect(function(p10: Instance)
		if p10:IsA("ImageLabel") or p10:IsA("ImageButton") then
			bindImage(p10)
		end
	end)
end)
