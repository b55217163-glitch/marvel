-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local contextActionService: ContextActionService = game:GetService("ContextActionService")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")

local function isMenuVisible()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local frame: Instance = menu and menu:FindFirstChild("Frame")

	return (menu and menu:IsA("ScreenGui") and menu.Enabled and frame and frame:IsA("GuiObject") and frame.Visible) == true
end
local function hideSprintButton()
	pcall(function()
		contextActionService:UnbindAction("RunBind")
	end)
end
local function watchMenu(p1)
	if not p1 or not p1:IsA("ScreenGui") then
		return
	end

	p1:GetPropertyChangedSignal("Enabled"):Connect(function()
		if isMenuVisible() then
			pcall(function()
				contextActionService:UnbindAction("RunBind")
			end)
		end
	end)

	local frame = p1:FindFirstChild("Frame")

	if frame and frame:IsA("GuiObject") then
		frame:GetPropertyChangedSignal("Visible"):Connect(function()
			if isMenuVisible() then
				pcall(function()
					contextActionService:UnbindAction("RunBind")
				end)
			end
		end)
	end
end

local menu: Instance = playerGui:FindFirstChild("Menu")

if menu then
	watchMenu(menu)
end

playerGui.ChildAdded:Connect(function(p3: Instance)
	if p3.Name == "Menu" then
		watchMenu(p3)
		task.defer(function()
			if isMenuVisible() then
				pcall(function()
					contextActionService:UnbindAction("RunBind")
				end)
			end
		end)
	end
end)

if LocalPlayer.Character then
	local Character: Model = LocalPlayer.Character

	if Character then
		local humanoid: Instance = Character:FindFirstChildOfClass("Humanoid")

		if humanoid then
			humanoid.Died:Connect(function()
				pcall(function()
					contextActionService:UnbindAction("RunBind")
				end)
			end)
		end
	end
end

LocalPlayer.CharacterAdded:Connect(function(character: Model)
	if not character then
		return
	end

	local humanoid: Instance = character:FindFirstChildOfClass("Humanoid")

	if humanoid then
		humanoid.Died:Connect(function()
			pcall(function()
				contextActionService:UnbindAction("RunBind")
			end)
		end)
	end
end)
task.defer(function()
	if isMenuVisible() then
		pcall(function()
			contextActionService:UnbindAction("RunBind")
		end)
	end
end)
