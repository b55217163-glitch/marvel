-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local workspace: Workspace = game:GetService("Workspace")
local runService: RunService = game:GetService("RunService")
local u3 = nil
local n1: number = 0
local u5: boolean = false
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })

local function findMenuMapFolder()
	local menuMap: Instance = workspace:FindFirstChild("MenuMap")

	while not menuMap do
		workspace.ChildAdded:Wait()
		menuMap = workspace:FindFirstChild("MenuMap")
	end

	return menuMap
end
local function hasPlayableDanceAnimation(character)
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	local dance = character:FindFirstChild("Dance")
	local v30 = dance and dance:IsA("Animation")

	return humanoid, v30 and dance or nil
end
local function startDanceAnimation(character)
	if object2[character] then
		return false
	end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	local dance = character:FindFirstChild("Dance")
	local v34 = humanoid
	local v35 = dance and dance:IsA("Animation") and dance or nil

	if v34 and v35 then
		object2[character] = true
		task.spawn(function()
			task.wait(1)

			if not character.Parent or not v34.Parent or not v35.Parent then
				return
			end

			local animator = v34:FindFirstChildOfClass("Animator")

			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = v34
			end

			local ok, result = pcall(function()
				return animator:LoadAnimation(v35)
			end)

			if ok and result then
				result.Looped = true
				result:Play()
			else
				local v113 = character:GetFullName()
				local text: string = tostring(result)

				warn("[MenuMapClientRunner] Failed to play dance animation for " .. v113 .. ": " .. text)
			end
		end)

		return true
	end

	return false
end
local function getFixtureParts(p3)
	local base = p3:FindFirstChild("Base")
	local pan = p3:FindFirstChild("Pan")
	local tilt = p3:FindFirstChild("Tilt")
	local move = p3:FindFirstChild("Move")
	local handle = pan and pan:FindFirstChild("Handle")
	local center = pan and pan:FindFirstChild("Center")
	local v43 = tilt

	if v43 then
		v43 = tilt:FindFirstChild("Handle")
	end

	local h1 = tilt and tilt:FindFirstChild("H1")

	if base and handle and center and v43 and h1 then
		if not base:IsA("BasePart") or not handle:IsA("BasePart") or not center:IsA("BasePart") or not v43:IsA("BasePart") or not h1:IsA("BasePart") then
			return nil
		end

		return base, handle, center, v43, h1, move
	end

	return nil
end
local function degrees(p4)
	return (math.rad(p4))
end

local t1: {[any]: any} = {
	TurnSpeedDegrees = 160,
	MaxFixtures = 8,
	HelperPartTransparency = 1,
	PanRange = Vector2.new(0, 159),
	TiltRange = Vector2.new(-115, 115),
	Colors = {
		"Lime green",
		"Really red",
		"Really blue",
		"Hot pink",
		"Royal purple",
		"New Yeller",
		"Neon orange"
	}
}

local function randomLightColor()
	local colors = t1.Colors
	local randomNumber = math.random(1, #t1.Colors)

	return colors[randomNumber]
end
local function getOrCreateWeld(parent, name, part0, part1, c1)
	local foundChild = parent:FindFirstChild(name)

	if not foundChild or not foundChild:IsA("Weld") then
		foundChild = Instance.new("Weld")
		foundChild.Name = name
		foundChild.Parent = parent
	end

	foundChild.Part0 = part0
	foundChild.Part1 = part1
	foundChild.C1 = c1

	return foundChild
end
local function shortestPanDelta(p10, p11)
	return (p11 - p10 + 180) % 360 - 180
end
local function stepToward(p12, p13, p14)
	local n1 = p13 - p12
	local absoluteValue = math.abs(n1)

	if p14 >= absoluteValue then
		return p13, n1
	end

	local n2: number = if n1 > 0 then 1 else -1

	return p12 + n2 * p14, n2 * p14
end
local function stepTowardPan(p15, p16, p17)
	local n1 = (p16 - p15 + 180) % 360 - 180
	local absoluteValue = math.abs(n1)

	if p17 >= absoluteValue then
		return p16 % 360, n1
	end

	local n2: number = if n1 > 0 then 1 else -1

	return (p15 + n2 * p17) % 360, n2 * p17
end
local function startLightingFixture(parent, p19)
	if object[parent] then
		return false
	end

	local part0, part1, v72, v73, v74, v75 = getFixtureParts(parent)

	if not part0 then
		return false
	end

	object[parent] = true

	local n4 = 0
	local n2 = 0
	local randomNumber = math.random(t1.PanRange.X, t1.PanRange.Y)
	local randomNumber2 = math.random(t1.TiltRange.X, t1.TiltRange.Y)
	local n3 = 0
	local v81 = CFrame.fromEulerAnglesXYZ(0, 0, 0)
	local menuMapClientPan = parent:FindFirstChild("MenuMapClientPan")

	if not menuMapClientPan or not menuMapClientPan:IsA("Weld") then
		menuMapClientPan = Instance.new("Weld")
		menuMapClientPan.Name = "MenuMapClientPan"
		menuMapClientPan.Parent = parent
	end

	menuMapClientPan.Part0 = part0
	menuMapClientPan.Part1 = part1
	menuMapClientPan.C1 = v81 * CFrame.new(0, 1, 0)
	v81 = CFrame.fromEulerAnglesXYZ(-1.5707963267948966, 1.5707963267948966, 0)

	local menuMapClientTilt = parent:FindFirstChild("MenuMapClientTilt")

	if not menuMapClientTilt or not menuMapClientTilt:IsA("Weld") then
		menuMapClientTilt = Instance.new("Weld")
		menuMapClientTilt.Name = "MenuMapClientTilt"
		menuMapClientTilt.Parent = parent
	end

	menuMapClientTilt.Part0 = v72
	menuMapClientTilt.Part1 = v73
	menuMapClientTilt.C1 = v81 * CFrame.new(0, 0, 0)

	local function setColor()
		if v74.Parent then
			local brickColorNew = BrickColor.new
			local colors = t1.Colors
			local randomNumber3 = math.random(1, #t1.Colors)

			v74.BrickColor = brickColorNew(colors[randomNumber3])
			v74.Transparency = t1.HelperPartTransparency
		end

		local tilt = parent:FindFirstChild("Tilt")
		local part = tilt and tilt:FindFirstChild("Part")
		local v120 = part

		if v120 then
			v120 = part:FindFirstChild("DiscoLight")
		end

		if v120 and v120:IsA("Beam") then
			v120.Enabled = true
		end

		v120 = part

		if v120 then
			v120 = part:FindFirstChild("Part")
		end

		if v120 then
			local spotLight = v120:FindFirstChildOfClass("SpotLight")
			local surfaceLight = v120:FindFirstChildOfClass("SurfaceLight")

			if spotLight then
				spotLight.Enabled = true
			end

			if surfaceLight then
				surfaceLight.Enabled = true
			end
		end
	end

	setColor()

	local connection = nil

	if v75 and v75:IsA("Vector3Value") then
		connection = v75.Changed:Connect(function()
			randomNumber = v75.Value.X % 360
			randomNumber2 = math.clamp(v75.Value.Y, t1.TiltRange.X, t1.TiltRange.Y)

			local v123 = os.clock()
			local v124 = math.max(0, v75.Value.Z * 2)

			n3 = v123 + v124
		end)
	end

	local connection2 = nil

	connection2 = runService.RenderStepped:Connect(function(deltaTime: number)
		if parent.Parent and n1 == p19 then
			if os.clock() < n3 then
				return
			end

			local turnSpeedDegrees = t1.TurnSpeedDegrees
			local v127 = math.min(deltaTime, 0.1)
			local n5 = turnSpeedDegrees * v127
			local v129 = n4

			v127 = n2
			n4 = select(1, stepTowardPan(n4, randomNumber, n5))
			n2 = select(1, stepToward(n2, randomNumber2, n5))
			n5 = (n4 - v129 + 180) % 360 - 180
			v129 = n2 - v127

			if math.abs(n5) > 0.0001 then
				local menuMapClientPanC1 = menuMapClientPan.C1
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v132 = math.rad(n5)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v132, 0)

				menuMapClientPan.C1 = menuMapClientPanC1 * cFrame
			end

			if math.abs(v129) > 0.0001 then
				local menuMapClientTiltC1 = menuMapClientTilt.C1
				local v135 = CFrame.fromEulerAnglesXYZ
				local v136 = math.rad(v129)
				local v137 = v135(0, v136, 0)

				menuMapClientTilt.C1 = menuMapClientTiltC1 * v137
			end

			if math.abs((randomNumber - n4 + 180) % 360 - 180) < 0.01 and math.abs(n2 - randomNumber2) < 0.01 then
				randomNumber = math.random(t1.PanRange.X, t1.PanRange.Y)
				randomNumber2 = math.random(t1.TiltRange.X, t1.TiltRange.Y)
				setColor()
			end

			return
		end

		connection2:Disconnect()

		if connection then
			connection:Disconnect()
		end

		object[parent] = nil
	end)

	return true
end
local function looksLikeLightingFixture(p21)
	return getFixtureParts(p21) ~= nil
end

local t2: {[any]: any} = {
	Freddy = true,
	Bonnie = true,
	Chica = true,
	["Intelegent Lighting"] = true
}

local function shouldKeepMenuPartUnanchored(p22, p23)
	local v90 = p22

	while v90 and v90 ~= p23 do
		if p23 == v90.Parent and t2[v90.Name] then
			return true
		end

		v90 = v90.Parent
	end

	return false
end
local function optimizeRuntimeMenuMap(p24, p25)
	local v93 = p25 or p24:GetDescendants()

	for i = 1, #v93 do
		local v95 = v93[i]

		if v95:IsA("BasePart") then
			local v96 = v95
			local u97

			while v96 and v96 ~= p24 do
				if p24 == v96.Parent and t2[v96.Name] then
					u97 = true

					break
				end

				v96 = v96.Parent
			end

			if not v96 or v96 == p24 then
				u97 = false
			end

			if not u97 then
				v95.Anchored = true
			end

			v95.CanCollide = false
			v95.CanTouch = false
			v95.CanQuery = false
			v95.CastShadow = true

			if v95.Name == "H1" or v95.Name == "H2" then
				v95.Transparency = 1
			end
		elseif v95:IsA("BaseScript") then
			v95.Parent = nil
		end
	end
end
local function initializeCurrentMenuMap()
	u3 = u3 or findMenuMapFolder()
	n1 += 1

	local v98: number = n1

	task.wait(0.35)

	if n1 ~= v98 or not u3.Parent then
		return
	end

	local descendants = u3:GetDescendants()

	optimizeRuntimeMenuMap(u3, descendants)

	local n2: number = 0

	for i = 1, #descendants do
		if n2 >= 8 then
			break
		end

		local character = descendants[i]

		if character:IsA("Model") then
			local u103

			if object2[character] then
				u103 = false
			else
				local humanoid = character:FindFirstChildOfClass("Humanoid")
				local dance = character:FindFirstChild("Dance")
				local v106 = humanoid
				local v107 = dance and dance:IsA("Animation") and dance or nil

				if v106 and v107 then
					object2[character] = true
					task.spawn(function()
						task.wait(1)

						if not character.Parent or not v106.Parent or not v107.Parent then
							return
						end

						local animator = v106:FindFirstChildOfClass("Animator")

						if not animator then
							animator = Instance.new("Animator")
							animator.Parent = v106
						end

						local ok, result = pcall(function()
							return animator:LoadAnimation(v107)
						end)

						if ok and result then
							result.Looped = true
							result:Play()
						else
							local v141 = character:GetFullName()
							local text: string = tostring(result)

							warn("[MenuMapClientRunner] Failed to play dance animation for " .. v141 .. ": " .. text)
						end
					end)
					u103 = true
				else
					u103 = false
				end
			end

			if not u103 then
				continue
			end

			n2 += 1
		end
	end

	n2 = 0

	for i = 1, #descendants do
		if n2 >= t1.MaxFixtures then
			break
		end

		local v109 = descendants[i]

		if v109:IsA("Model") and getFixtureParts(v109) ~= nil and startLightingFixture(v109, v98) then
			n2 += 1
		end
	end
end
local function scheduleInitialize()
	if u5 then
		return
	end

	u5 = true
	task.delay(0.3, function()
		u5 = false
		initializeCurrentMenuMap()
	end)
end

u3 = findMenuMapFolder()
u3.ChildAdded:Connect(scheduleInitialize)
u3:GetAttributeChangedSignal("CurrentMenuMap"):Connect(scheduleInitialize)
u5 = true
task.delay(0.3, function()
	u5 = false
	initializeCurrentMenuMap()
end)
