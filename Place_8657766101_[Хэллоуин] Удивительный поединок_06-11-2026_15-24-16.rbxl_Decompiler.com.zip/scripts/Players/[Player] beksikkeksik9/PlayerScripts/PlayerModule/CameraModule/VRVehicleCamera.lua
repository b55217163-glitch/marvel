-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local ok, result = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserVRVehicleCameraOrbital")
end)

local u3 = ok and result
local t1: {[any]: any} = { 0, 30 }
local vrBaseCamera = require(script.Parent:WaitForChild("VRBaseCamera"))
local cameraUtils = require(script.Parent:WaitForChild("CameraUtils"))
local cameraInput = require(script.Parent:WaitForChild("CameraInput"))
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local vrService: VRService = game:GetService("VRService")
local lighting: Lighting = game:GetService("Lighting")
local LocalPlayer: Player = players.LocalPlayer
local cameraUtilsMapClamp = cameraUtils.mapClamp
local vehicleCamera: Instance = script.Parent:WaitForChild("VehicleCamera")
local v15 = require(vehicleCamera:FindFirstChild("VehicleCameraConfig"))
local raycastParams = RaycastParams.new()

raycastParams.FilterType = Enum.RaycastFilterType.Exclude
raycastParams.IgnoreWater = true

local function yawVelocity(p1, p2)
	local v26 = p2.YVector:Dot(p1)

	return (math.abs(v26))
end
local function computeCameraCFrame(p3, p4, p5)
	local v30 = math.atan2(p4.X, p4.Z)
	local cFrame = CFrame.new(p3.Position + p4 * p5)
	local v32 = CFrame.Angles(0, v30, 0)

	return cFrame * v32
end
local function vrOccludeDisplace(p6, p7, p8, p9)
	local v37 = math.atan2(p7.X, p7.Z)
	local cFrame = CFrame.new(p6.Position + p7 * p8)
	local v39 = CFrame.Angles(0, v37, 0)
	local n1 = cFrame * v39
	local CurrentCamera: Camera = workspace.CurrentCamera

	if not CurrentCamera then
		return n1
	end

	local v42 = p6.Position

	v39 = (n1.Position - v42) * Vector3.new(1, 0, 1)

	local magnitude = v39.Magnitude

	if magnitude < 0.5 then
		return n1
	end

	local filterDescendantsInstances: {[any]: any} = { CurrentCamera }

	if p9 then
		table.insert(filterDescendantsInstances, p9)
	end

	local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

	if localPlayerCharacter then
		table.insert(filterDescendantsInstances, localPlayerCharacter)
	end

	raycastParams.FilterDescendantsInstances = filterDescendantsInstances

	local unit = v39.Unit

	v37 = workspace:Raycast(v42, v39, raycastParams)

	if v37 and v37.Normal:Dot(unit) < 0 then
		local n2 = (v37.Position - v42).Magnitude - 0.5

		if n2 < magnitude then
			local v48 = math.max(n2, 0.5)

			return CFrame.new(p6.Position + unit * v48) * n1.Rotation
		end

		return n1
	end

	return n1
end

local v20 = OverlapParams.new()

v20.FilterType = Enum.RaycastFilterType.Exclude

local function findObstructions(p10, p11, p12, p13)
	local CurrentCamera: Camera = workspace.CurrentCamera

	if not CurrentCamera then
		return 0, {}
	end

	local v54 = p11.Position
	local v55: CFrame = vrService:GetUserCFrame(Enum.UserCFrame.Head)
	local cFrame = CFrame.new(v55.Position * CurrentCamera.HeadScale)
	local n1 = p10 * (cFrame * v55.Rotation)
	local n2 = n1.Position - v54
	local magnitude = n2.Magnitude

	if magnitude < 0.5 then
		return 0, {}
	end

	local filterDescendantsInstances: {[any]: any} = { CurrentCamera }

	if p13 then
		table.insert(filterDescendantsInstances, p13)
	end

	local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

	if localPlayerCharacter then
		table.insert(filterDescendantsInstances, localPlayerCharacter)
	end

	raycastParams.FilterDescendantsInstances = filterDescendantsInstances

	local v62 = workspace:Raycast(v54, n2, raycastParams)
	local t4

	if v62 then
		local v64 = (v62.Position - v54).Magnitude

		if magnitude > v64 then
			local v65 = n2.Unit:Dot(n1.LookVector)

			v65 = math.clamp((1 - -v65) / 0.1339745962155613, 0, 1)
			v65 = math.max(v65, 1 - v64 / p12, 0.15)

			local v66 = v62.Position
			local v67 = n1.Position
			local vector3 = Vector3.new(2, 2, (v67 - v66).Magnitude)
			local v69 = CFrame.lookAt((v66 + v67) / 2, v67)

			v20.FilterDescendantsInstances = filterDescendantsInstances

			local v70 = workspace:GetPartBoundsInBox(v69, vector3, v20)

			return v65, v70
		end

		t4 = {}

		return 0, t4
	end

	t4 = {}

	return 0, t4
end

local n1: number = 0.016666666666666666
local object = setmetatable({}, vrBaseCamera)

object.__index = object

function object.new()
	if not u3 then
		return require(script.Parent:WaitForChild("VRVehicleCameraDeprecated")).new()
	end

	local v71 = vrBaseCamera.new()
	local object2 = setmetatable(v71, object)

	object2.skipOcclusion = true
	object2:Reset()

	if object2.thirdPersonOptionChanged then
		object2.thirdPersonOptionChanged:Disconnect()
		object2.thirdPersonOptionChanged = nil
	end

	runService.Stepped:Connect(function(time: number, deltaTime: number)
		n1 = deltaTime
	end)

	return object2
end
function object.Reset(p16)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local currentCameraCameraSubject = CurrentCamera and CurrentCamera.CameraSubject

	assert(CurrentCamera, "VRVehicleCamera initialization error")
	assert(currentCameraCameraSubject)
	assert(currentCameraCameraSubject:IsA("VehicleSeat"))
	p16.lastOrbitalDir = nil
	p16.wasInFirstPerson = nil

	local v76 = currentCameraCameraSubject:GetConnectedParts(true)

	table.insert(v76, currentCameraCameraSubject)

	local v77, v78 = cameraUtils.getLooseBoundingSphere(v76)

	p16.vehicleModel = currentCameraCameraSubject:FindFirstAncestorOfClass("Model") or currentCameraCameraSubject.Parent
	p16.assemblyRadius = math.max(v78, 5)
	p16.assemblyOffset = currentCameraCameraSubject.CFrame:Inverse() * v77
	p16.gamepadZoomLevels = {}

	for key, value in t1 do
		table.insert(p16.gamepadZoomLevels, value * p16.headScale * p16.assemblyRadius / 10)
	end

	p16.lastCameraFocus = nil

	if not p16:IsInFirstPerson() then
		p16:SetCameraToSubjectDistance(p16.gamepadZoomLevels[#p16.gamepadZoomLevels])
	end

	p16.needsReset = false
end
function object._getThirdPersonLocalOffset(p17)
	local assemblyOffset = p17.assemblyOffset
	local vector3 = Vector3.new(0, p17.assemblyRadius * v15.verticalCenterOffset, 0)

	return assemblyOffset + vector3
end
function object._getFirstPersonLocalOffset(p18, p19)
	local Character: Model = LocalPlayer.Character
	local v87 = Character and Character.Parent and Character:FindFirstChild("Head")

	if v87 and v87:IsA("BasePart") then
		return p19:Inverse() * v87.Position
	end

	return p18:_getThirdPersonLocalOffset()
end
function object._vrOccludeVignette(p20, p21, p22, p23)
	local v92 = math.atan2(p22.X, p22.Z)
	local cFrame = CFrame.new(p21.Position + p22 * p23)
	local v94 = CFrame.Angles(0, v92, 0)
	local n1 = cFrame * v94
	local v96, v97 = findObstructions(n1, p21, p23, p20.vehicleModel)
	local vrFade = lighting:FindFirstChild("VRFade")

	if not vrFade then
		vrFade = Instance.new("ColorCorrectionEffect")
		vrFade.Name = "VRFade"
		vrFade.Parent = lighting
	end

	vrFade.Brightness = -v96

	if p20.lastOccludedParts then
		for iterFirst, iterSecond in p20.lastOccludedParts, nil, nil do
			iterSecond.LocalTransparencyModifier = 0
		end
	end

	if #v97 > 0 then
		for iterFirst2, iterSecond2 in v97 do
			iterSecond2.LocalTransparencyModifier = 1
		end

		p20:StartVREdgeBlur(LocalPlayer, true)
	end

	p20.lastOccludedParts = v97

	return n1
end
function object.Update(p24)
	local v104: number = n1

	n1 = 0
	p24:UpdateFadeFromBlack(v104)
	p24:UpdateEdgeBlur(LocalPlayer, v104)

	local v105, v106 = p24:_updateStepRotation(v104)

	return v105, v106
end
function object._updateStepRotation(p25, p26)
	local v109 = p25:GetSubjectCFrame()
	local v110 = p25:GetCameraToSubjectDistance()
	local v111 = cameraUtilsMapClamp(v110, 0.5, p25.assemblyRadius, 1, 0)
	local v112 = p25:_getThirdPersonLocalOffset()
	local v113 = p25:_getFirstPersonLocalOffset(v109)
	local v114 = v112:Lerp(v113, v111)
	local cFrameNew = CFrame.new
	local v116 = p25:GetCameraHeight()
	local vector3 = Vector3.new(0, v116, 0)
	local v118 = cFrameNew(v109 * v114 + vector3)

	if p25.needsReset or p25.recentered then
		p25.lastOrbitalDir = nil
		p25.needsReset = false
		p25.recentered = false
	end

	local v119 = p25.lastOrbitalDir

	if not v119 then
		v119 = (v109.LookVector * Vector3.new(-1, 0, -1)).Unit
		p25:StartFadeFromBlack()
	end

	v111 = (p25:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude > 2

	if not v111 then
		local v120 = p25:getRotation(p26)

		if math.abs(v120) > 0 then
			local v121 = CFrame.Angles(0, -v120, 0)
			local cFrame = CFrame.new(v119)

			v119 = (v121 * cFrame).Position.Unit
			p25.lastRotateTime = os.clock()
		end
	else
		cameraInput.getRotation(p26)
	end

	local n1

	if p25:IsInFirstPerson() then
		if not p25.wasInFirstPerson or v111 then
			v119 = (v109.LookVector * Vector3.new(-1, 0, -1)).Unit
			p25.wasInFirstPerson = true
		end

		local v124 = math.atan2(-v109.LookVector.X, -v109.LookVector.Z)

		if p25.lastVehicleYaw then
			local n2 = (v124 - p25.lastVehicleYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793

			if math.abs(n2) > 0.001 then
				local v126 = CFrame.Angles(0, n2, 0)
				local cFrame = CFrame.new(v119)

				v119 = (v126 * cFrame).Position.Unit
			end
		end

		p25.lastVehicleYaw = v124

		local v128 = math.atan2(v119.X, v119.Z)
		local cFrame = CFrame.new(v118.Position + v119 * v110)
		local v130 = CFrame.Angles(0, v128, 0)

		n1 = cFrame * v130
	else
		p25.wasInFirstPerson = false
		p25.lastVehicleYaw = nil

		local v131 = p25.lastRotateTime

		if v131 then
			v131 = os.clock() - p25.lastRotateTime < v15.autocorrectDelay
		end

		if v111 and not v131 then
			local unit = (v109.LookVector * Vector3.new(-1, 0, -1)).Unit
			local v133 = v119:Dot(unit)
			local v134 = math.clamp(v133, -1, 1)
			local v135 = math.acos(v134)

			v133 = p25:GetSubjectRotVelocity()

			local v136 = v109.YVector:Dot(v133)
			local absoluteValue = math.abs(v136)

			v133 = math.min(0.01 + v135 / 3.141592653589793 * 0.05 + absoluteValue * 0.02, 0.15)
			v119 = v119:Lerp(unit, v133)
		end

		n1 = vrOccludeDisplace(v118, v119, v110, p25.vehicleModel)
	end

	p25.lastOrbitalDir = v119

	local cFrame = CFrame.new(0, 0, -v110)

	return n1, n1 * cFrame
end

return object
