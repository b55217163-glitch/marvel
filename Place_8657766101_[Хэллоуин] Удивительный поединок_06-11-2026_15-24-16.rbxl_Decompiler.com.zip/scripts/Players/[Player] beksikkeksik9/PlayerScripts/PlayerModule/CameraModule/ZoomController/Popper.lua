-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local commonUtils: Instance = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local flagUtil = require(commonUtils:WaitForChild("FlagUtil"))
local cameraWrapper = require(commonUtils:WaitForChild("CameraWrapper"))
local connectionUtil = require(commonUtils:WaitForChild("ConnectionUtil"))
local v6 = flagUtil.getUserFlag("UserRaycastUpdateAPI2")
local v7 = flagUtil.getUserFlag("UserCurrentCameraUpdate2")
local v8 = flagUtil.getUserFlag("UserPlayerConnectionMemoryLeak")
local v9 = if v7 then cameraWrapper.new() else nil
local Workspace

if v7 then
	Workspace = nil
else
	Workspace = game
	Workspace = Workspace.Workspace
	Workspace = Workspace.CurrentCamera
end

if v7 then
	v9:Enable()
end

local mathMin = math.min
local mathTan = math.tan
local mathRad = math.rad
local rayNew = Ray.new
local raycastParams = RaycastParams.new()

raycastParams.IgnoreWater = true
raycastParams.FilterType = Enum.RaycastFilterType.Exclude
raycastParams.RespectCanCollide = true

local raycastParams2 = RaycastParams.new()

raycastParams2.IgnoreWater = true
raycastParams2.FilterType = Enum.RaycastFilterType.Include

local v17 = if v8 then connectionUtil.new() else nil

local function getTotalTransparency(p1)
	return 1 - (1 - p1.Transparency) * (1 - p1.LocalTransparencyModifier)
end
local function eraseFromEnd(p2, p3)
	for i = #p2, p3 + 1, -1 do
		p2[i] = nil
	end
end

local u20 = nil
local u21 = nil
local u23

if v7 then
	local function updateProjection()
		local v51 = v9:getCamera()
		local v52 = mathRad(v51.FieldOfView)
		local viewportSize = v51.ViewportSize

		v51 = viewportSize.X / viewportSize.Y
		u21 = mathTan(v52 / 2) * 2
		u20 = v51 * u21
	end

	v9:Connect("FieldOfView", updateProjection)
	v9:Connect("ViewportSize", updateProjection)

	local v24 = v9:getCamera()
	local v25 = mathRad(v24.FieldOfView)
	local viewportSize = v24.ViewportSize

	v24 = viewportSize.X / viewportSize.Y
	u21 = mathTan(v25 / 2) * 2
	u20 = v24 * u21
	u23 = v9:getCamera().NearPlaneZ
	v9:Connect("NearPlaneZ", function()
		u23 = v9:getCamera().NearPlaneZ
	end)
else
	local function v26()
		local v54 = mathRad(Workspace.FieldOfView)
		local workspaceViewportSize = Workspace.ViewportSize
		local n1 = workspaceViewportSize.X / workspaceViewportSize.Y

		u21 = mathTan(v54 / 2) * 2
		u20 = n1 * u21
	end

	Workspace:GetPropertyChangedSignal("FieldOfView"):Connect(v26)
	Workspace:GetPropertyChangedSignal("ViewportSize"):Connect(v26)

	local v27 = mathRad(Workspace.FieldOfView)
	local workspaceViewportSize = Workspace.ViewportSize
	local n1 = workspaceViewportSize.X / workspaceViewportSize.Y

	u21 = mathTan(v27 / 2) * 2
	u20 = n1 * u21
	u23 = Workspace.NearPlaneZ
	Workspace:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		u23 = Workspace.NearPlaneZ
	end)
end

local t1: {[any]: any} = {}
local t2: {[any]: any} = {}

local function refreshIgnoreList()
	local n1: number = 1
	t1 = {}

	for _, v in pairs(t2) do
		t1[n1] = v
		n1 += 1
	end
end
local function playerAdded(player)
	local function characterAdded(p5)
		t2[player] = p5

		local n1: number = 1
		t1 = {}

		for _, v in pairs(t2) do
			t1[n1] = v
			n1 += 1
		end
	end
	local function characterRemoving()
		t2[player] = nil

		local n1: number = 1
		t1 = {}

		for _, v in pairs(t2) do
			t1[n1] = v
			n1 += 1
		end
	end

	if v8 then
		local v63 = ("%*CharacterAdded"):format(player.UserId)

		v17:trackConnection(v63, player.CharacterAdded:Connect(characterAdded))
		v63 = ("%*CharacterRemoving"):format(player.UserId)
		v17:trackConnection(v63, player.CharacterRemoving:Connect(characterRemoving))
	else
		player.CharacterAdded:Connect(characterAdded)
		player.CharacterRemoving:Connect(characterRemoving)
	end

	if player.Character then
		t2[player] = player.Character

		local n1: number = 1
		t1 = {}

		for _, v in pairs(t2) do
			t1[n1] = v
			n1 += 1
		end
	end
end

players.PlayerAdded:Connect(playerAdded)
players.PlayerRemoving:Connect(function(player: Player)
	t2[player] = nil

	local n1: number = 1
	t1 = {}

	for _, v in pairs(t2) do
		t1[n1] = v
		n1 += 1
	end

	if v8 then
		local v71 = ("%*CharacterAdded"):format(player.UserId)

		v17:disconnect(v71)
		v71 = ("%*CharacterRemoving"):format(player.UserId)
		v17:disconnect(v71)
	end
end)

for _, v in ipairs(players:GetPlayers()) do
	playerAdded(v)
end

local n2: number = 1
t1 = {}

for _, v in pairs(t2) do
	t1[n2] = v
	n2 += 1
end

local u39 = nil
local RootPart = nil

if v7 then
	v9:Connect("CameraSubject", function()
		local cameraSubject = v9:getCamera().CameraSubject

		if cameraSubject and cameraSubject:IsA("Humanoid") then
			RootPart = cameraSubject.RootPart

			return
		end

		if cameraSubject and cameraSubject:IsA("BasePart") then
			RootPart = cameraSubject

			return
		end

		RootPart = nil
	end)
else
	Workspace:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		local workspaceCameraSubject = Workspace.CameraSubject

		if workspaceCameraSubject:IsA("Humanoid") then
			RootPart = workspaceCameraSubject.RootPart

			return
		end

		if workspaceCameraSubject:IsA("BasePart") then
			RootPart = workspaceCameraSubject

			return
		end

		RootPart = nil
	end)
end

local function canOcclude(p7)
	local u75
	local v76
	local v77
	local v78

	u75 = false

	if 1 - (1 - p7.Transparency) * (1 - p7.LocalTransparencyModifier) < 0.25 then
		if not v6 then
			u75 = p7.CanCollide

			if u75 then
				u75 = false
				v76 = u39
				v77 = p7:GetRootPart()

				if v76 == (v77 or p7) then
				else
					v78 = p7:IsA("TrussPart")
					u75 = not v78
				end
			end
		else
			u75 = false
			v76 = u39
			v77 = p7:GetRootPart()

			if v76 == (v77 or p7) then
			else
				v78 = p7:IsA("TrussPart")
				u75 = not v78
			end
		end
	end

	return u75
end
local function getCollisionPoint(p8, p9)
	local v81
	local n1
	local v83
	local v84
	local v85
	local v86
	local v87
	local state: number = 0

	while true do
		if state == 0 then
			state = if v6 then 1 else 4
		elseif state == 1 then
			raycastParams.FilterDescendantsInstances = t1
			v81 = workspace:Raycast(p8, p9, raycastParams)
			state = if v81 then 2 else 15
		elseif state == 2 then
			return v81.Position, true
		elseif state == 3 then
			state = 3
		elseif state == 4 then
			n1 = #t1
			state = 5
		elseif state == 5 then
			v83 = rayNew(p8, p9)
			v84, v85 = workspace:FindPartOnRayWithIgnoreList(v83, t1, false, true)
			state = if v84 then 6 else 11
		elseif state == 6 then
			state = if v84.CanCollide then 7 else 10
		elseif state == 7 then
			v86 = t1

			for i = #v86, n1 + 1, -1 do
				v86[i] = nil
			end

			state = 9
		elseif state == 9 then
			return v85, true
		elseif state == 10 then
			t1[#t1 + 1] = v84
			state = 11
		elseif state == 11 then
			state = if v84 then 12 else 13
		elseif state == 12 then
			state = 5
		elseif state == 13 then
			v87 = t1

			for i = #v87, n1 + 1, -1 do
				v87[i] = nil
			end

			state = 15
		elseif state == 15 then
			return p8 + p9, false
		elseif state == 16 then
			return
		end
	end
end
local function queryPoint(p10, p11, p12, p13)
	debug.profilebegin("queryPoint")

	local n1: number = #t1
	local n2 = p12 + u23
	local n3 = p10 + p11 * n2
	local n4 = math.huge
	local n5 = math.huge
	local v99 = p10
	local n6: number = 0

	if v6 then
		raycastParams.FilterDescendantsInstances = t1

		while true do
			local v101 = workspace:Raycast(v99, n3 - v99, raycastParams)

			if not v101 then
				break
			end

			n6 += 1

			local instance = v101.Instance
			local v103 = v101.Position
			local magnitude = (v103 - p10).Magnitude

			if n6 >= 64 then
				n5 = magnitude
			else
				local u105 = false

				if 1 - (1 - instance.Transparency) * (1 - instance.LocalTransparencyModifier) < 0.25 then
					if not v6 then
						u105 = instance.CanCollide
					end

					if v6 or u105 then
						u105 = false

						local v106 = u39
						local v107 = instance:GetRootPart()

						if v106 ~= (v107 or instance) then
							u105 = not instance:IsA("TrussPart")
						end
					end
				end

				if u105 then
					raycastParams2.FilterDescendantsInstances = { instance }

					if workspace:Raycast(n3, v103 - n3, raycastParams2) then
						if if p13 then workspace:Raycast(p13, n3 - p13, raycastParams2) or workspace:Raycast(n3, p13 - n3, raycastParams2) else false then
							n5 = magnitude
						elseif n2 < n4 then
							n4 = magnitude
						end
					else
						n5 = magnitude
					end
				end
			end

			raycastParams:AddToFilter(instance)
			v99 = v103 - p11 * 0.001

			if n5 < math.huge or not instance then
				break
			end
		end
	else
		while true do
			local v108 = rayNew(v99, n3 - v99)
			local v109, v110 = workspace:FindPartOnRayWithIgnoreList(v108, t1, false, true)

			n6 += 1

			if v109 then
				local u111: boolean = n6 >= 64
				local u112 = false

				if 1 - (1 - v109.Transparency) * (1 - v109.LocalTransparencyModifier) < 0.25 then
					if not v6 then
						u112 = v109.CanCollide
					end

					if v6 or u112 then
						u112 = false

						local v113 = u39
						local v114 = v109:GetRootPart()

						if v113 ~= (v114 or v109) then
							u112 = not v109:IsA("TrussPart")
						end
					end
				end

				if u112 or u111 then
					local v115 = rayNew(n3, v110 - n3)
					local t4: {[any]: any} = { v109 }
					local v117 = (v110 - p10).Magnitude

					if workspace:FindPartOnRayWithWhitelist(v115, t4, true) and not u111 then
						local u118 = false

						if p13 then
							local v119 = rayNew(p13, n3 - p13)
							local v120 = workspace:FindPartOnRayWithWhitelist(v119, t4, true)

							if not v120 then
								local v121 = rayNew(n3, p13 - n3)

								v120 = workspace:FindPartOnRayWithWhitelist(v121, t4, true)
							end

							u118 = v120
						end

						if u118 then
							n5 = v117
						elseif n2 < n4 then
							n4 = v117
						end
					else
						n5 = v117
					end
				end

				t1[#t1 + 1] = v109
				v99 = v110 - p11 * 0.001
			end

			if n5 < math.huge or not v109 then
				break
			end
		end

		local v122: {[any]: any} = t1

		for i = #v122, n1 + 1, -1 do
			v122[i] = nil
		end
	end

	debug.profileend()

	return n4 - u23, n5 - u23
end
local function queryViewport(p14, p15)
	debug.profilebegin("queryViewport")

	local p = p14.p
	local rightVector = p14.rightVector
	local upVector = p14.upVector
	local n1 = -p14.lookVector

	Workspace = if v7 then v9:getCamera() else Workspace

	local workspaceViewportSize = Workspace.ViewportSize
	local n2 = math.huge
	local n3 = math.huge

	for i = 0, 1 do
		local n4 = rightVector * ((i - 0.5) * u20)

		for j = 0, 1 do
			local n5 = p + u23 * (n4 + upVector * ((j - 0.5) * u21))
			local v137 = Workspace:ViewportPointToRay(workspaceViewportSize.x * i, workspaceViewportSize.y * j)
			local v138, v139 = queryPoint(n5, n1, p15, v137.Origin)

			if n2 > v139 then
				n2 = v139
			end

			if n3 > v138 then
				n3 = v138
			end
		end
	end

	debug.profileend()

	return n3, n2
end

local t3: {[any]: any} = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(0, 0.2)
}

local function testPromotion(p16, p17, p18)
	debug.profilebegin("testPromotion")

	local p = p16.p
	local rightVector = p16.rightVector
	local upVector = p16.upVector
	local n1 = -p16.lookVector

	debug.profilebegin("extrapolate")

	local v147 = getCollisionPoint(p, p18.posVelocity * 1.25)

	for i = 0, mathMin(1.25, p18.rotVelocity.magnitude + (v147 - p).Magnitude / p18.posVelocity.magnitude), 0.0625 do
		local v149 = p18.extrapolate(i)
		local v150 = queryPoint(v149.p, -v149.lookVector, p17)

		if p17 <= v150 then
			return false
		end
	end

	debug.profileend()
	debug.profilebegin("testOffsets")

	for _, v in ipairs(t3) do
		local v153 = getCollisionPoint(p, rightVector * v.x + upVector * v.y)

		if queryPoint(v153, (p + n1 * p17 - v153).Unit, p17) == math.huge then
			return false
		end
	end

	debug.profileend()
	debug.profileend()

	return true
end

return function(p19, p20, p21)
	debug.profilebegin("popper")
	u39 = RootPart and RootPart:GetRootPart() or RootPart

	local v157 = p20
	local v158, v159 = queryViewport(p19, p20)

	if v157 > v159 then
		v157 = v159
	end

	if v157 > v158 and testPromotion(p19, p20, p21) then
		v157 = v158
	end

	u39 = nil
	debug.profileend()

	return v157
end
