-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local vrService: VRService = game:GetService("VRService")

UserSettings():GetService("UserGameSettings")
require(script.Parent:WaitForChild("CameraInput"))
require(script.Parent:WaitForChild("CameraUtils"))

local commonUtils: Instance = script.Parent.Parent:WaitForChild("CommonUtils")
local v4 = require(commonUtils:WaitForChild("FlagUtil")).getUserFlag("UserVRRemoveLuaEdgeBlur")
local vrBaseCamera = require(script.Parent:WaitForChild("VRBaseCamera"))
local object = setmetatable({}, vrBaseCamera)

object.__index = object

function object.new()
	local v7 = vrBaseCamera.new()
	local object2 = setmetatable(v7, object)

	object2.lastUpdate = tick()
	object2.focusOffset = CFrame.new()
	object2:Reset()

	local playerScripts: Instance = players.LocalPlayer:WaitForChild("PlayerScripts")

	object2.controlModule = require(playerScripts.PlayerModule:WaitForChild("ControlModule"))
	object2.savedAutoRotate = true

	return object2
end
function object.Reset(p1)
	p1.needsReset = true
	p1.needsBlackout = true
	p1.motionDetTime = 0
	p1.blackOutTimer = 0
	p1.lastCameraResetPosition = nil
	vrBaseCamera.Reset(p1)
end
function object.Update(p2, p3)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local v14 = CurrentCamera.CFrame
	local v15 = CurrentCamera.Focus
	local LocalPlayer: Player = players.LocalPlayer

	p2:GetHumanoid()

	local currentCameraCameraSubject: Instance = CurrentCamera.CameraSubject

	if p2.lastUpdate == nil or p3 > 1 then
		p2.lastCameraTransform = nil
	end

	p2:UpdateFadeFromBlack(p3)

	if not v4 then
		p2:UpdateEdgeBlur(LocalPlayer, p3)
	end

	local lastSubjectPosition = p2.lastSubjectPosition
	local v19 = p2:GetSubjectPosition()

	if p2.needsBlackout then
		p2:StartFadeFromBlack()

		local v20 = math.clamp(p3, 0.0001, 0.1)

		p2.blackOutTimer = p2.blackOutTimer + v20

		if p2.blackOutTimer > 0.1 and game:IsLoaded() then
			p2.needsBlackout = false
			p2.needsReset = true
		end
	end

	if v19 and LocalPlayer and CurrentCamera then
		local v21 = p2:GetVRFocus(v19, p3)

		if not p2:IsInFirstPerson() then
			if vrService.ThirdPersonFollowCamEnabled then
				local v22, v23 = p2:UpdateThirdPersonFollowTransform(p3, v14, v21, lastSubjectPosition, v19)

				v14 = v22
				v15 = v23
			else
				local v24, v25 = p2:UpdateThirdPersonComfortTransform(p3, v14, v21, lastSubjectPosition, v19)

				v14 = v24
				v15 = v25
			end
		elseif vrService.AvatarGestures then
			local v26, v27 = p2:UpdateImmersionCamera(p3, v14, v21, lastSubjectPosition, v19)

			v14 = v26
			v15 = v27
		else
			local v28, v29 = p2:UpdateFirstPersonTransform(p3, v14, v21, lastSubjectPosition, v19)

			v14 = v28
			v15 = v29
		end

		p2.lastCameraTransform = v14
		p2.lastCameraFocus = v15
	end

	p2.lastUpdate = tick()

	return v14, v15
end
function object.GetAvatarFeetWorldYValue(_)
	local cameraSubject: Instance = workspace.CurrentCamera.CameraSubject

	if not cameraSubject then
	elseif cameraSubject:IsA("Humanoid") and cameraSubject.RootPart then
		local cameraSubjectRootPart = cameraSubject.RootPart

		return cameraSubjectRootPart.Position.Y - cameraSubjectRootPart.Size.Y / 2 - cameraSubject.HipHeight
	end

	return nil
end
function object.UpdateFirstPersonTransform(p5, p6, _, p8, p9, p10)
	if p5.needsReset then
		p5:StartFadeFromBlack()
		p5.needsReset = false
	end

	if not v4 and (p9 - p10).magnitude > 0.01 then
		p5:StartVREdgeBlur(players.LocalPlayer)
	end

	local p = p8.p
	local v40 = p5:GetCameraLookVector()

	v40 = Vector3.new(v40.X, 0, v40.Z).Unit

	local v41 = p5:getRotation(p6)
	local v42 = p5:CalculateNewLookVectorFromArg(v40, Vector2.new(v41, 0))
	local cFrame = CFrame.new(p - 0.5 * v42, p)

	return cFrame, p8
end
function object.UpdateImmersionCamera(p11, p12, _, _, _, p16)
	local v50 = p11:GetSubjectCFrame()
	local CurrentCamera: Camera = workspace.CurrentCamera
	local Character: Model = players.LocalPlayer.Character
	local v53 = p11:GetHumanoid()

	if not v53 then
		return CurrentCamera.CFrame, CurrentCamera.Focus
	end

	local humanoidRootPart: Instance = Character:FindFirstChild("HumanoidRootPart")

	if not humanoidRootPart then
		return CurrentCamera.CFrame, CurrentCamera.Focus
	end

	p11.characterOrientation = humanoidRootPart:FindFirstChild("CharacterAlignOrientation")

	if not p11.characterOrientation then
		local rootAttachment: Instance = humanoidRootPart:FindFirstChild("RootAttachment")

		if not rootAttachment then
			return
		end

		p11.characterOrientation = Instance.new("AlignOrientation")
		p11.characterOrientation.Name = "CharacterAlignOrientation"
		p11.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		p11.characterOrientation.Attachment0 = rootAttachment
		p11.characterOrientation.RigidityEnabled = true
		p11.characterOrientation.Parent = humanoidRootPart
	end

	if p11.characterOrientation.Enabled == false then
		p11.characterOrientation.Enabled = true
	end

	local v56

	if p11.needsReset then
		p11.needsReset = false
		p11.savedAutoRotate = v53.AutoRotate
		v53.AutoRotate = false

		if p11.NoRecenter then
			p11.NoRecenter = false
			vrService:RecenterUserHeadCFrame()
		end

		p11:StartFadeFromBlack()
		v56 = v50
	elseif v53.Sit then
		v56 = v50

		if not v4 and (v56.Position - CurrentCamera.CFrame.Position).Magnitude > 0.01 then
			p11:StartVREdgeBlur(players.LocalPlayer)
		end
	else
		local v57 = p11.controlModule:GetEstimatedVRTorsoFrame()

		p11.characterOrientation.CFrame = CurrentCamera.CFrame * v57

		if p11.controlModule.inputMoveVector.Magnitude > 0 then
			p11.motionDetTime = 0.1
		end

		if p11.controlModule.inputMoveVector.Magnitude > 0 or p11.motionDetTime > 0 then
			p11.motionDetTime = p11.motionDetTime - p12

			if not v4 then
				p11:StartVREdgeBlur(players.LocalPlayer)
			end

			local v58: CFrame = vrService:GetUserCFrame(Enum.UserCFrame.Head)
			local HumanoidRootPart = Character.HumanoidRootPart
			local n1 = CurrentCamera.CFrame * (v58.Rotation + v58.Position * CurrentCamera.HeadScale)
			local cFrame = CFrame.new(0, -0.7 * HumanoidRootPart.Size.Y / 2, 0)
			local lookVector = HumanoidRootPart.CFrame.LookVector
			local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)
			local n2 = p16 - (n1 * cFrame - vector3.Unit * HumanoidRootPart.Size.Y * 0.125).Position + CurrentCamera.CFrame.Position
			local vector32 = Vector3.new(n2.X, p16.Y, n2.Z)

			v56 = CurrentCamera.CFrame.Rotation + vector32
		else
			local rotation = CurrentCamera.CFrame.Rotation
			local vector3 = Vector3.new(CurrentCamera.CFrame.Position.X, p16.Y, CurrentCamera.CFrame.Position.Z)

			v56 = rotation + vector3
		end

		local v68 = p11:getRotation(p12)

		if math.abs(v68) > 0 then
			local v69 = vrService:GetUserCFrame(Enum.UserCFrame.Head)

			v69 = v69.Rotation + v69.Position * CurrentCamera.HeadScale

			local n3 = v56 * v69
			local cFrame = CFrame.new(n3.Position)
			local cFrameAngles = CFrame.Angles
			local v73 = math.rad(v68 * 90)
			local v74 = cFrameAngles(0, -v73, 0)
			local n4 = cFrame * v74 * n3.Rotation
			local v76 = v69:Inverse()

			v56 = n4 * v76
		end
	end

	return v56, v56 * CFrame.new(0, 0, -0.5)
end
function object.UpdateThirdPersonComfortTransform(p17, p18, p19, p20, p21, p22)
	local v83 = p17:GetCameraToSubjectDistance()

	if v83 < 0.5 then
		v83 = 0.5
	end

	if p21 == nil or p17.lastCameraFocus == nil then
		return p19, p20
	end

	local LocalPlayer: Player = players.LocalPlayer
	local v85 = p17.controlModule:GetMoveVector()
	local u86: boolean = true

	if not ((p21 - p22).magnitude > 0.01) then
		u86 = v85.magnitude > 0.01
	end

	if u86 then
		p17.motionDetTime = 0.1
	end

	p17.motionDetTime = p17.motionDetTime - p18

	if p17.motionDetTime > 0 then
		u86 = true
	end

	if u86 and not p17.needsReset then
		local lastCameraFocus = p17.lastCameraFocus

		p17.VRCameraFocusFrozen = true

		return p19, lastCameraFocus
	end

	v85 = true

	if p17.lastCameraResetPosition ~= nil then
		v85 = (p22 - p17.lastCameraResetPosition).Magnitude > 1
	end

	local v88 = p17:getRotation(p18)

	if math.abs(v88) > 0 then
		local v89 = p20:ToObjectSpace(p19)
		local v90 = CFrame.Angles(0, -v88, 0)

		p19 = p20 * v90 * v89
	end

	if p17.VRCameraFocusFrozen and v85 or p17.needsReset then
		vrService:RecenterUserHeadCFrame()
		p17.VRCameraFocusFrozen = false
		p17.needsReset = false
		p17.lastCameraResetPosition = p22
		p17:ResetZoom()
		p17:StartFadeFromBlack()

		local v91 = p17:GetHumanoid()
		local v92 = v91.Torso and v91.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
		local vector3 = Vector3.new(v92.X, 0, v92.Z)

		v92 = p20.Position - vector3 * v83

		local vector33 = Vector3.new(p20.Position.X, v92.Y, p20.Position.Z)

		p19 = CFrame.new(v92, vector33)
	end

	return p19, p20
end
function object.UpdateThirdPersonFollowTransform(p23, p24, _, _, p27, p28)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local v102 = p23:GetCameraToSubjectDistance()
	local v103 = p23:GetVRFocus(p28, p24)

	if p23.needsReset then
		p23.needsReset = false
		vrService:RecenterUserHeadCFrame()
		p23:ResetZoom()
		p23:StartFadeFromBlack()
	end

	if p23.recentered then
		local v104 = p23:GetSubjectCFrame()

		if not v104 then
			return CurrentCamera.CFrame, CurrentCamera.Focus
		end

		local n1 = v103 * v104.Rotation
		local cFrame = CFrame.new(0, 0, v102)
		local n2 = n1 * cFrame

		p23.focusOffset = v103:ToObjectSpace(n2)
		p23.recentered = false

		return n2, v103
	end

	local v108 = v103:ToWorldSpace(p23.focusOffset)
	local LocalPlayer: Player = players.LocalPlayer
	local controlModule = p23.controlModule
	local v111 = controlModule:GetMoveVector()
	local v113

	if (p27 - p28).magnitude > 0.01 or v111.magnitude > 0 then
		local v114 = controlModule:GetEstimatedVRTorsoFrame()
		local n3 = CurrentCamera.CFrame * (v114.Rotation + v114.Position * CurrentCamera.HeadScale)
		local lookVector = n3.LookVector
		local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)

		vector3 = CFrame.new(CurrentCamera.CFrame.Position + (v103.Position - vector3.Unit * v102) - n3.Position)
		v113 = v108:Lerp(vector3 * v108.Rotation, 0.01)
	else
		v113 = v108
	end

	v111 = p23:getRotation(p24)

	if math.abs(v111) > 0 then
		local v117 = v103:ToObjectSpace(v113)
		local v118 = CFrame.Angles(0, -v111, 0)

		v113 = v103 * v118 * v117
	end

	p23.focusOffset = v103:ToObjectSpace(v113)

	local cFrame = CFrame.new(0, 0, -v102)
	local n4 = v113 * cFrame

	if not v4 and (n4.Position - CurrentCamera.Focus.Position).Magnitude > 0.01 then
		p23:StartVREdgeBlur(players.LocalPlayer)
	end

	return v113, n4
end
function object.LeaveFirstPerson(p29)
	vrBaseCamera.LeaveFirstPerson(p29)
	p29.needsReset = true

	if p29.VRBlur then
		p29.VRBlur.Visible = false
	end

	if p29.characterOrientation then
		p29.characterOrientation.Enabled = false
	end

	local v122 = p29:GetHumanoid()

	if v122 then
		v122.AutoRotate = p29.savedAutoRotate
	end
end

return object
