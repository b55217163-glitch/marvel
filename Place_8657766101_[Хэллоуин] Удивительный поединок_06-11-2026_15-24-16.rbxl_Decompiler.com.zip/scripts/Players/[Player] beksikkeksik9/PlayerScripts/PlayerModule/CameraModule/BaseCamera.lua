-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")

game:GetService("UserInputService")

local vrService: VRService = game:GetService("VRService")
local service = UserSettings():GetService("UserGameSettings")
local commonUtils: Instance = script.Parent.Parent:WaitForChild("CommonUtils")
local connectionUtil = require(commonUtils:WaitForChild("ConnectionUtil"))

require(commonUtils:WaitForChild("FlagUtil"))

local cameraUtils = require(script.Parent:WaitForChild("CameraUtils"))
local zoomController = require(script.Parent:WaitForChild("ZoomController"))
local cameraToggleStateController = require(script.Parent:WaitForChild("CameraToggleStateController"))
local cameraInput = require(script.Parent:WaitForChild("CameraInput"))
local cameraUI = require(script.Parent:WaitForChild("CameraUI"))
local LocalPlayer: Player = players.LocalPlayer

Vector2.new(0, 0)

local t1: {[any]: any} = {
	CHARACTER_ADDED = "CHARACTER_ADDED",
	CAMERA_MODE_CHANGED = "CAMERA_MODE_CHANGED",
	CAMERA_MIN_DISTANCE_CHANGED = "CAMERA_MIN_DISTANCE_CHANGED",
	CAMERA_MAX_DISTANCE_CHANGED = "CAMERA_MAX_DISTANCE_CHANGED"
}
local module: {[any]: any} = {}

module.__index = module

function module.new()
	local object = setmetatable({}, module)

	object._connections = connectionUtil.new()
	object.gamepadZoomLevels = { 0, 10, 20 }
	object.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	object.cameraType = nil
	object.cameraMovementMode = nil
	object.lastCameraTransform = nil
	object.lastUserPanCamera = tick()
	object.humanoidRootPart = nil
	object.humanoidCache = {}
	object.lastSubject = nil
	object.lastSubjectPosition = Vector3.new(0, 5, 0)
	object.lastSubjectCFrame = CFrame.new(object.lastSubjectPosition)
	object.currentSubjectDistance = math.clamp(12.5, LocalPlayer.CameraMinZoomDistance, LocalPlayer.CameraMaxZoomDistance)
	object.inFirstPerson = false
	object.inMouseLockedMode = false
	object.resetCameraAngle = true
	object.enabled = false
	object.cameraChangedConn = nil
	object.shouldUseVRRotation = false
	object.VRRotationIntensityAvailable = false
	object.lastVRRotationIntensityCheckTime = 0
	object.lastVRRotationTime = 0
	object.vrRotateKeyCooldown = {}
	object.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	object.humanoidJumpOrigin = nil
	object.trackingHumanoid = nil
	object.cameraFrozen = false
	object.subjectStateChangedConn = nil
	object.gamepadZoomPressConnection = nil
	object.mouseLockOffset = Vector3.new(0, 0, 0)
	service:SetCameraYInvertVisible()
	service:SetGamepadCameraSensitivityVisible()

	return object
end
function module.GetModuleName(_)
	return "BaseCamera"
end
function module._setUpConfigurations(p2)
	p2._connections:trackConnection("CHARACTER_ADDED", LocalPlayer.CharacterAdded:Connect(function(character: Model)
		p2:OnCharacterAdded(character)
	end))
	p2.humanoidRootPart = nil

	local _connections = p2._connections
	local v18: RBXScriptSignal = LocalPlayer:GetPropertyChangedSignal("CameraMode")

	_connections:trackConnection("CAMERA_MODE_CHANGED", v18:Connect(function()
		p2:OnPlayerCameraPropertyChange()
	end))

	local v19 = p2._connections

	v18 = LocalPlayer:GetPropertyChangedSignal("CameraMinZoomDistance")
	v19:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", v18:Connect(function()
		p2:OnPlayerCameraPropertyChange()
	end))

	local v20 = p2._connections

	v18 = LocalPlayer:GetPropertyChangedSignal("CameraMaxZoomDistance")
	v20:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", v18:Connect(function()
		p2:OnPlayerCameraPropertyChange()
	end))
	p2:OnPlayerCameraPropertyChange()
end
function module.OnCharacterAdded(p4, _)
	p4.resetCameraAngle = p4.resetCameraAngle or p4:GetEnabled()
	p4.humanoidRootPart = nil
end
function module.GetHumanoidRootPart(p6)
	local humanoid = not p6.humanoidRootPart and LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid")

	if humanoid then
		p6.humanoidRootPart = humanoid.RootPart
	end

	return p6.humanoidRootPart
end
function module.GetBodyPartToFollow(_, p8, _)
	local v28 = p8:GetState() == Enum.HumanoidStateType.Dead and p8.Parent

	if v28 and v28:IsA("Model") then
		return v28:FindFirstChild("Head") or p8.RootPart
	end

	return p8.RootPart
end
function module.GetSubjectCFrame(p10)
	local v30 = p10.lastSubjectCFrame
	local CurrentCamera: Camera = workspace.CurrentCamera
	local currentCameraCameraSubject = CurrentCamera and CurrentCamera.CameraSubject

	if not currentCameraCameraSubject then
		return v30
	end

	if currentCameraCameraSubject:IsA("Humanoid") then
		local u33: boolean = currentCameraCameraSubject:GetState() == Enum.HumanoidStateType.Dead
		local v34 = currentCameraCameraSubject.CameraOffset

		if p10:GetIsMouseLocked() then
			v34 = Vector3.new()
		end

		local v35 = currentCameraCameraSubject.RootPart

		if u33 and currentCameraCameraSubject.Parent and currentCameraCameraSubject.Parent:IsA("Model") then
			v35 = currentCameraCameraSubject.Parent:FindFirstChild("Head") or v35
		end

		if v35 and v35:IsA("BasePart") then
			local vectorValue

			if currentCameraCameraSubject.RigType ~= Enum.HumanoidRigType.R15 then
				vectorValue = Vector3.new(0, 1.5, 0)
			elseif currentCameraCameraSubject.AutomaticScalingEnabled then
				vectorValue = Vector3.new(0, 1.5, 0)

				local currentCameraCameraSubjectRootPart = currentCameraCameraSubject.RootPart

				if v35 == currentCameraCameraSubjectRootPart then
					local vector3 = Vector3.new(0, (currentCameraCameraSubjectRootPart.Size.Y - 2) / 2, 0)

					vectorValue += vector3
				end
			else
				vectorValue = Vector3.new(0, 2, 0)
			end

			if u33 then
				vectorValue = Vector3.new(0, 0, 0)
			end

			local v39 = v35.CFrame
			local cFrame = CFrame.new(vectorValue + v34)

			v30 = v39 * cFrame
		end
	elseif currentCameraCameraSubject:IsA("BasePart") then
		v30 = currentCameraCameraSubject.CFrame
	elseif currentCameraCameraSubject:IsA("Model") then
		v30 = if currentCameraCameraSubject.PrimaryPart then currentCameraCameraSubject:GetPrimaryPartCFrame() else CFrame.new()
	end

	if v30 then
		p10.lastSubjectCFrame = v30
	end

	return v30
end
function module.GetSubjectVelocity(_)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local currentCameraCameraSubject = CurrentCamera and CurrentCamera.CameraSubject

	if not currentCameraCameraSubject then
		return Vector3.new(0, 0, 0)
	end

	if currentCameraCameraSubject:IsA("BasePart") then
		return currentCameraCameraSubject.Velocity
	end

	if currentCameraCameraSubject:IsA("Humanoid") then
		local currentCameraCameraSubjectRootPart = currentCameraCameraSubject.RootPart

		if currentCameraCameraSubjectRootPart then
			return currentCameraCameraSubjectRootPart.Velocity
		end
	else
		local v45 = currentCameraCameraSubject:IsA("Model") and currentCameraCameraSubject.PrimaryPart

		if v45 then
			return v45.Velocity
		end
	end

	return Vector3.new(0, 0, 0)
end
function module.GetSubjectRotVelocity(_)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local currentCameraCameraSubject = CurrentCamera and CurrentCamera.CameraSubject

	if not currentCameraCameraSubject then
		return Vector3.new(0, 0, 0)
	end

	if currentCameraCameraSubject:IsA("BasePart") then
		return currentCameraCameraSubject.RotVelocity
	end

	if currentCameraCameraSubject:IsA("Humanoid") then
		local currentCameraCameraSubjectRootPart = currentCameraCameraSubject.RootPart

		if currentCameraCameraSubjectRootPart then
			return currentCameraCameraSubjectRootPart.RotVelocity
		end
	else
		local v50 = currentCameraCameraSubject:IsA("Model") and currentCameraCameraSubject.PrimaryPart

		if v50 then
			return v50.RotVelocity
		end
	end

	return Vector3.new(0, 0, 0)
end
function module.StepZoom(p13)
	local currentSubjectDistance = p13.currentSubjectDistance
	local v53 = cameraInput.getZoomDelta()

	if math.abs(v53) > 0 then
		local v54 = if v53 > 0 then math.max(currentSubjectDistance + v53 * (currentSubjectDistance * 0.5 + 1), p13.FIRST_PERSON_DISTANCE_THRESHOLD) else math.max((currentSubjectDistance + v53) / (1 - v53 * 0.5), 0.5)

		if v54 < p13.FIRST_PERSON_DISTANCE_THRESHOLD then
			v54 = 0.5
		end

		p13:SetCameraToSubjectDistance(v54)
	end

	return zoomController.GetZoomRadius()
end
function module.GetSubjectPosition(p14)
	local v56 = p14.lastSubjectPosition
	local CurrentCamera: Camera = game.Workspace.CurrentCamera
	local currentCameraCameraSubject = CurrentCamera and CurrentCamera.CameraSubject

	if currentCameraCameraSubject then
		if currentCameraCameraSubject:IsA("Humanoid") then
			local u59: boolean = currentCameraCameraSubject:GetState() == Enum.HumanoidStateType.Dead
			local v60 = currentCameraCameraSubject.CameraOffset

			if p14:GetIsMouseLocked() then
				v60 = Vector3.new()
			end

			local v61 = currentCameraCameraSubject.RootPart

			if u59 and currentCameraCameraSubject.Parent and currentCameraCameraSubject.Parent:IsA("Model") then
				v61 = currentCameraCameraSubject.Parent:FindFirstChild("Head") or v61
			end

			if v61 and v61:IsA("BasePart") then
				local vectorValue

				if currentCameraCameraSubject.RigType ~= Enum.HumanoidRigType.R15 then
					vectorValue = Vector3.new(0, 1.5, 0)
				elseif currentCameraCameraSubject.AutomaticScalingEnabled then
					vectorValue = Vector3.new(0, 1.5, 0)

					if v61 == currentCameraCameraSubject.RootPart then
						local vector3 = Vector3.new(0, currentCameraCameraSubject.RootPart.Size.Y / 2 - 1, 0)

						vectorValue += vector3
					end
				else
					vectorValue = Vector3.new(0, 2, 0)
				end

				if u59 then
					vectorValue = Vector3.new(0, 0, 0)
				end

				local p = v61.CFrame.p
				local v65 = v61.CFrame:vectorToWorldSpace(vectorValue + v60)

				v56 = p + v65
			end
		elseif currentCameraCameraSubject:IsA("VehicleSeat") then
			local v66 = currentCameraCameraSubject.CFrame.p
			local v67 = currentCameraCameraSubject.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))

			v56 = v66 + v67
		elseif currentCameraCameraSubject:IsA("SkateboardPlatform") then
			v56 = currentCameraCameraSubject.CFrame.p + Vector3.new(0, 5, 0)
		elseif currentCameraCameraSubject:IsA("BasePart") then
			v56 = currentCameraCameraSubject.CFrame.p
		elseif currentCameraCameraSubject:IsA("Model") then
			if currentCameraCameraSubject.PrimaryPart then
				v56 = currentCameraCameraSubject:GetPrimaryPartCFrame().p
			else
				v56 = currentCameraCameraSubject:GetModelCFrame().p
			end
		end

		p14.lastSubject = currentCameraCameraSubject
		p14.lastSubjectPosition = v56

		return v56
	end

	return nil
end
function module.OnCurrentCameraChanged(p15)
	if p15.cameraSubjectChangedConn then
		p15.cameraSubjectChangedConn:Disconnect()
		p15.cameraSubjectChangedConn = nil
	end

	local CurrentCamera: Camera = game.Workspace.CurrentCamera

	if CurrentCamera then
		p15.cameraSubjectChangedConn = CurrentCamera:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			p15:OnNewCameraSubject()
		end)
		p15:OnNewCameraSubject()
	end
end
function module.OnPlayerCameraPropertyChange(p16)
	p16:SetCameraToSubjectDistance(p16.currentSubjectDistance)
end
function module.InputTranslationToCameraAngleChange(_, p18, p19)
	return p18 * p19
end
function module.GamepadZoomPress(p20)
	local v75 = p20:GetCameraToSubjectDistance()
	local v76 = LocalPlayer.CameraMaxZoomDistance

	for i = #p20.gamepadZoomLevels, 1, -1 do
		local v78 = p20.gamepadZoomLevels[i]

		if not (v76 < v78) then
			if v78 < LocalPlayer.CameraMinZoomDistance then
				v78 = LocalPlayer.CameraMinZoomDistance

				if v76 == v78 then
					break
				end
			end

			if v75 > v78 + (v76 - v78) / 2 then
				p20:SetCameraToSubjectDistance(v78)

				return
			end

			v76 = v78
		end
	end

	p20:SetCameraToSubjectDistance(p20.gamepadZoomLevels[#p20.gamepadZoomLevels])
end
function module.Enable(p21, p22)
	if p22 ~= p21.enabled then
		p21.enabled = p22
		p21:OnEnabledChanged()
	end
end
function module.OnEnabledChanged(p23)
	if p23.enabled then
		p23:_setUpConfigurations()
		cameraInput.setInputEnabled(true)
		p23.gamepadZoomPressConnection = cameraInput.gamepadZoomPress:Connect(function()
			p23:GamepadZoomPress()
		end)

		if LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			p23.currentSubjectDistance = 0.5

			if not p23.inFirstPerson then
				p23:EnterFirstPerson()
			end
		end

		if p23.cameraChangedConn then
			p23.cameraChangedConn:Disconnect()
			p23.cameraChangedConn = nil
		end

		p23.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			p23:OnCurrentCameraChanged()
		end)
		p23:OnCurrentCameraChanged()

		return
	end

	p23._connections:disconnectAll()
	cameraInput.setInputEnabled(false)

	if p23.gamepadZoomPressConnection then
		p23.gamepadZoomPressConnection:Disconnect()
		p23.gamepadZoomPressConnection = nil
	end

	p23:Cleanup()
end
function module.GetEnabled(p24)
	return p24.enabled
end
function module.Cleanup(p25)
	if p25.subjectStateChangedConn then
		p25.subjectStateChangedConn:Disconnect()
		p25.subjectStateChangedConn = nil
	end

	if p25.cameraChangedConn then
		p25.cameraChangedConn:Disconnect()
		p25.cameraChangedConn = nil
	end

	p25.lastCameraTransform = nil
	p25.lastSubjectCFrame = nil
	cameraUtils.restoreMouseBehavior()
end
function module.UpdateMouseBehavior(p26)
	if p26.isCameraToggle and service.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove == false then
		cameraUI.setCameraModeToastEnabled(true)
		cameraInput.enableCameraToggleInput()
		cameraToggleStateController(p26.inFirstPerson)

		return
	end

	cameraUI.setCameraModeToastEnabled(false)
	cameraInput.disableCameraToggleInput()

	if not p26.inFirstPerson and not p26.inMouseLockedMode then
		cameraUtils.restoreRotationType()

		if cameraInput.getRotationActivated() then
			cameraUtils.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)

			return
		end

		cameraUtils.restoreMouseBehavior()

		return
	end

	cameraUtils.setRotationTypeOverride(Enum.RotationType.CameraRelative)
	cameraUtils.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
end
function module.UpdateForDistancePropertyChange(p27)
	p27:SetCameraToSubjectDistance(p27.currentSubjectDistance)
end
function module.SetCameraToSubjectDistance(p28, p29)
	local currentSubjectDistance = p28.currentSubjectDistance

	if LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		p28.currentSubjectDistance = 0.5

		if not p28.inFirstPerson then
			p28:EnterFirstPerson()
		end
	else
		local v89 = math.clamp(p29, LocalPlayer.CameraMinZoomDistance, LocalPlayer.CameraMaxZoomDistance)

		if v89 < 1 then
			p28.currentSubjectDistance = 0.5

			if not p28.inFirstPerson then
				p28:EnterFirstPerson()
			end
		else
			p28.currentSubjectDistance = v89

			if p28.inFirstPerson then
				p28:LeaveFirstPerson()
			end
		end
	end

	local zoomControllerSetZoomParameters = zoomController.SetZoomParameters
	local v91 = p28.currentSubjectDistance
	local v92 = math.sign(p29 - currentSubjectDistance)

	zoomControllerSetZoomParameters(v91, v92)

	return p28.currentSubjectDistance
end
function module.SetCameraType(p30, p31)
	p30.cameraType = p31
end
function module.GetCameraType(p32)
	return p32.cameraType
end
function module.SetCameraMovementMode(p33, p34)
	p33.cameraMovementMode = p34
end
function module.GetCameraMovementMode(p35)
	return p35.cameraMovementMode
end
function module.SetIsMouseLocked(p36, p37)
	p36.inMouseLockedMode = p37
end
function module.GetIsMouseLocked(p38)
	return p38.inMouseLockedMode
end
function module.SetMouseLockOffset(p39, p40)
	p39.mouseLockOffset = p40
end
function module.GetMouseLockOffset(p41)
	return p41.mouseLockOffset
end
function module.InFirstPerson(p42)
	return p42.inFirstPerson
end
function module.EnterFirstPerson(p43)
	p43.inFirstPerson = true
	p43:UpdateMouseBehavior()
end
function module.LeaveFirstPerson(p44)
	p44.inFirstPerson = false
	p44:UpdateMouseBehavior()
end
function module.GetCameraToSubjectDistance(p45)
	return p45.currentSubjectDistance
end
function module.GetMeasuredDistanceToFocus(_)
	local CurrentCamera: Camera = game.Workspace.CurrentCamera

	if CurrentCamera then
		return (CurrentCamera.CoordinateFrame.p - CurrentCamera.Focus.p).magnitude
	end

	return nil
end
function module.GetCameraLookVector(_)
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end
function module.CalculateNewLookCFrameFromArg(p48, p49, p50)
	local v115 = p49 or p48:GetCameraLookVector()
	local v116 = math.asin(v115.Y)
	local v117 = math.clamp(p50.Y, v116 + -1.3962634015954636, v116 + 1.3962634015954636)
	local vector2 = Vector2.new(p50.X, v117)
	local cFrame = CFrame.new(Vector3.new(0, 0, 0), v115)
	local v120 = CFrame.Angles(0, -vector2.X, 0)
	local v121 = CFrame.Angles(-vector2.Y, 0, 0)

	return v120 * cFrame * v121
end
function module.CalculateNewLookVectorFromArg(p51, p52, p53)
	return p51:CalculateNewLookCFrameFromArg(p52, p53).LookVector
end
function module.CalculateNewLookVectorVRFromArg(p54, p55)
	local unit = ((p54:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit
	local vector2 = Vector2.new(p55.X, 0)
	local cFrame = CFrame.new(Vector3.new(0, 0, 0), unit)
	local v130 = CFrame.Angles(0, -vector2.X, 0)
	local v131 = CFrame.Angles(-vector2.Y, 0, 0)

	return ((v130 * cFrame * v131).LookVector * Vector3.new(1, 0, 1)).unit
end
function module.GetHumanoid(p56)
	local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

	if localPlayerCharacter then
		local v134 = p56.humanoidCache[LocalPlayer]

		if v134 and localPlayerCharacter == v134.Parent then
			return v134
		end

		p56.humanoidCache[LocalPlayer] = nil

		local humanoid = localPlayerCharacter:FindFirstChildOfClass("Humanoid")

		if humanoid then
			p56.humanoidCache[LocalPlayer] = humanoid
		end

		return humanoid
	end

	return nil
end
function module.GetHumanoidPartToFollow(_, p58, p59)
	if p59 == Enum.HumanoidStateType.Dead then
		local v139 = p58.Parent

		if v139 then
			return v139:FindFirstChild("Head") or p58.Torso
		end

		return p58.Torso
	end

	return p58.Torso
end
function module.OnNewCameraSubject(p60)
	if p60.subjectStateChangedConn then
		p60.subjectStateChangedConn:Disconnect()
		p60.subjectStateChangedConn = nil
	end
end
function module.IsInFirstPerson(p61)
	return p61.inFirstPerson
end
function module.Update(_, _)
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end
function module.GetCameraHeight(p64)
	if vrService.VREnabled and not p64.inFirstPerson then
		return 0.25881904510252074 * p64.currentSubjectDistance
	end

	return 0
end

return module
