-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local commonUtils: Instance = script.Parent.Parent:WaitForChild("CommonUtils")

if require(commonUtils:WaitForChild("FlagUtil")).getUserFlag("UserAllowAbilityControls") then
	local players: Players = game:GetService("Players")
	local abilityManagerActor = nil
	local humanoid = nil
	local bindableEvent: BindableEvent = Instance.new("BindableEvent")
	local connection = nil
	local u7: boolean = false

	local function characterAdded(character)
		abilityManagerActor = nil
		humanoid = nil

		if connection then
			connection:Disconnect()
			connection = nil
		end

		if character then
			abilityManagerActor = character:FindFirstChild("AbilityManagerActor")
			humanoid = character:FindFirstChildOfClass("Humanoid")

			while not humanoid do
				character.ChildAdded:wait()
				humanoid = character:FindFirstChildOfClass("Humanoid")
			end

			bindableEvent:Fire()
			connection = humanoid:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				bindableEvent:Fire()
			end)
		end
	end
	local function lazyInit()
		if u7 then
			return
		end

		u7 = true

		local LocalPlayer: Player = players.LocalPlayer

		if LocalPlayer then
			LocalPlayer.characterAdded:Connect(characterAdded)

			if LocalPlayer.Character then
				characterAdded(LocalPlayer.Character)
			end
		end
	end

	return {
		isEnabled = function()
			if not u7 then
				u7 = true

				local LocalPlayer: Player = players.LocalPlayer

				if LocalPlayer then
					LocalPlayer.characterAdded:Connect(characterAdded)

					if LocalPlayer.Character then
						characterAdded(LocalPlayer.Character)
					end
				end
			end

			local u13 = false

			if abilityManagerActor ~= nil then
				u13 = humanoid and not humanoid.EvaluateStateMachine
			end

			return u13
		end,
		GetEnabledChangedSignal = function()
			if not u7 then
				u7 = true

				local LocalPlayer: Player = players.LocalPlayer

				if LocalPlayer then
					LocalPlayer.characterAdded:Connect(characterAdded)

					if LocalPlayer.Character then
						characterAdded(LocalPlayer.Character)
					end
				end
			end

			return bindableEvent.Event
		end
	}
end
