-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local userInputService: UserInputService = game:GetService("UserInputService")
local contextActionService: ContextActionService = game:GetService("ContextActionService")

script.Parent.Parent:WaitForChild("CommonUtils")

local vector3 = Vector3.new()
local baseCharacterController = require(script.Parent:WaitForChild("BaseCharacterController"))
local object = setmetatable({}, baseCharacterController)

object.__index = object

function object.new(control_action_priority)
	local v7 = baseCharacterController.new()
	local object2 = setmetatable(v7, object)

	object2.CONTROL_ACTION_PRIORITY = control_action_priority
	object2.forwardValue = 0
	object2.backwardValue = 0
	object2.leftValue = 0
	object2.rightValue = 0
	object2.jumpEnabled = true

	return object2
end
function object.Enable(p2, p3)
	if p3 == p2.enabled then
		return true
	end

	p2.forwardValue = 0
	p2.backwardValue = 0
	p2.leftValue = 0
	p2.rightValue = 0
	p2.moveVector = vector3
	p2.jumpRequested = false
	p2:UpdateJump()

	if p3 then
		p2:BindContextActions()
		p2:ConnectFocusEventListeners()
	else
		p2._connectionUtil:disconnectAll()
	end

	p2.enabled = p3

	return true
end
function object.UpdateMovement(p4, p5)
	if p5 == Enum.UserInputState.Cancel then
		p4.moveVector = vector3

		return
	end

	p4.moveVector = Vector3.new(p4.leftValue + p4.rightValue, 0, p4.forwardValue + p4.backwardValue)
end
function object.UpdateJump(p6)
	p6.isJumping = p6.jumpRequested
end
function object.BindContextActions(p7)
	contextActionService:BindActionAtPriority("moveForwardAction", function(_, p9, _)
		p7.forwardValue = if p9 == Enum.UserInputState.Begin then -1 else 0
		p7:UpdateMovement(p9)

		return Enum.ContextActionResult.Pass
	end, false, p7.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterForward)
	contextActionService:BindActionAtPriority("moveBackwardAction", function(_, p12, _)
		p7.backwardValue = if p12 == Enum.UserInputState.Begin then 1 else 0
		p7:UpdateMovement(p12)

		return Enum.ContextActionResult.Pass
	end, false, p7.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterBackward)
	contextActionService:BindActionAtPriority("moveLeftAction", function(_, p15, _)
		p7.leftValue = if p15 == Enum.UserInputState.Begin then -1 else 0
		p7:UpdateMovement(p15)

		return Enum.ContextActionResult.Pass
	end, false, p7.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterLeft)
	contextActionService:BindActionAtPriority("moveRightAction", function(_, p18, _)
		p7.rightValue = if p18 == Enum.UserInputState.Begin then 1 else 0
		p7:UpdateMovement(p18)

		return Enum.ContextActionResult.Pass
	end, false, p7.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterRight)
	contextActionService:BindActionAtPriority("jumpAction", function(_, p21, _)
		p7.jumpRequested = p7.jumpEnabled and p21 == Enum.UserInputState.Begin
		p7:UpdateJump()

		return Enum.ContextActionResult.Pass
	end, false, p7.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterJump)
	p7._connectionUtil:trackBoundFunction("moveForwardAction", function()
		contextActionService:UnbindAction("moveForwardAction")
	end)
	p7._connectionUtil:trackBoundFunction("moveBackwardAction", function()
		contextActionService:UnbindAction("moveBackwardAction")
	end)
	p7._connectionUtil:trackBoundFunction("moveLeftAction", function()
		contextActionService:UnbindAction("moveLeftAction")
	end)
	p7._connectionUtil:trackBoundFunction("moveRightAction", function()
		contextActionService:UnbindAction("moveRightAction")
	end)
	p7._connectionUtil:trackBoundFunction("jumpAction", function()
		contextActionService:UnbindAction("jumpAction")
	end)
end
function object.ConnectFocusEventListeners(p23)
	local function onFocusReleased()
		p23.moveVector = vector3
		p23.forwardValue = 0
		p23.backwardValue = 0
		p23.leftValue = 0
		p23.rightValue = 0
		p23.jumpRequested = false
		p23:UpdateJump()
	end

	p23._connectionUtil:trackConnection("textBoxFocusReleased", userInputService.TextBoxFocusReleased:Connect(onFocusReleased))
	p23._connectionUtil:trackConnection("textBoxFocused", userInputService.TextBoxFocused:Connect(function(textboxFocused: TextBox)
		p23.jumpRequested = false
		p23:UpdateJump()
	end))
	p23._connectionUtil:trackConnection("windowFocusReleased", userInputService.WindowFocused:Connect(onFocusReleased))
end

return object
