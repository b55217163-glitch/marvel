-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local contentProvider: ContentProvider = game:GetService("ContentProvider")
local LocalPlayer: Player = players.LocalPlayer
local u5 = nil
local object = setmetatable({}, { __mode = "k" })
local t1: {[any]: any} = {}

local function getAssetNameForLog(p1)
	local ok, result = pcall(function()
		return p1:GetFullName()
	end)

	if ok then
		return string.format("%s [%s]", result, p1.ClassName)
	end

	return string.format("%s [%s]", p1.Name, p1.ClassName)
end
local function getAssetListForLog(p2)
	local t2: {[any]: any} = {}

	for iterFirst, iterSecond in p2 do
		table.insert(t2, getAssetNameForLog(iterSecond))
	end

	return table.concat(t2, " | ")
end
local function collectPreloadables(p3)
	local t3: {[any]: any} = {}

	if not p3 then
		return t3
	end

	t3[#t3 + 1] = p3

	for iterFirst, iterSecond in p3:GetDescendants() do
		if iterSecond:IsA("ImageLabel") or iterSecond:IsA("ImageButton") or iterSecond:IsA("Decal") or iterSecond:IsA("Texture") then
			t3[#t3 + 1] = iterSecond
		end
	end

	return t3
end
local function preloadAssetListBatched(p4, _)
	for i = 1, #p4, 40 do
		local t4: {[any]: any} = {}
		local v46 = math.min(i + 40 - 1, #p4)

		for j = i, v46 do
			table.insert(t4, p4[j])
		end

		pcall(function()
			contentProvider:PreloadAsync(t4)
		end)
		task.wait()
	end
end
local function preloadRoot(p6)
	if p6 and not object[p6] then
		object[p6] = true
		task.spawn(function()
			local v76 = collectPreloadables(p6)

			if #v76 > 0 then
				preloadAssetListBatched(v76, p6:GetFullName())

				return
			end
		end)

		return
	end
end
local function getCharacterSpecialAssetsRoot()
	local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")

	return uiAssets and uiAssets:FindFirstChild("CharacterSpecialAssets")
end
local function preloadCharacterSpecialByName(p7)
	if typeof(p7) == "string" and p7 ~= "" and not t1[p7] then
		local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")
		local v52: Instance = uiAssets

		if v52 then
			v52 = uiAssets:FindFirstChild("CharacterSpecialAssets")
		end

		local v53: Instance = v52 and v52:FindFirstChild(p7)

		if not v53 then
			return
		end

		t1[p7] = true

		if not v53 then
			return
		end

		if object[v53] then
			return
		end

		object[v53] = true
		task.spawn(function()
			local v77 = collectPreloadables(v53)

			if #v77 > 0 then
				preloadAssetListBatched(v77, v53:GetFullName())

				return
			end
		end)

		return
	end
end
local function preloadLiveCharacterSpecialByName(p8)
	if typeof(p8) ~= "string" or p8 == "" or not u5 then
		return
	end

	local characterSpecial = u5:FindFirstChild("CharacterSpecial")
	local v56 = characterSpecial and characterSpecial:FindFirstChild(p8)

	if not v56 then
		return
	end

	if object[v56] then
		return
	end

	object[v56] = true
	task.spawn(function()
		local v78 = collectPreloadables(v56)

		if #v78 > 0 then
			preloadAssetListBatched(v78, v56:GetFullName())

			return
		end
	end)
end
local function setupPlayerGui(p9)
	u5 = p9
	p9.ChildAdded:Connect(function(p10: Instance)
		if p10.Name == "CharacterSpecial" then
			task.defer(function()
				local selectedCharacter: any = LocalPlayer:GetAttribute("SelectedCharacter")

				if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and u5 then
					local characterSpecial = u5:FindFirstChild("CharacterSpecial")
					local v82 = characterSpecial and characterSpecial:FindFirstChild(selectedCharacter)

					if v82 and not object[v82] then
						object[v82] = true
						task.spawn(function()
							local v90 = collectPreloadables(v82)

							if #v90 > 0 then
								preloadAssetListBatched(v90, v82:GetFullName())

								return
							end
						end)
					end
				end

				local selected_duel_char: any = LocalPlayer:GetAttribute("SELECTED_DUEL_CHAR")

				if typeof(selected_duel_char) ~= "string" or selected_duel_char == "" then
					return
				end

				if not u5 then
					return
				end

				local characterSpecial = u5:FindFirstChild("CharacterSpecial")
				local v85 = characterSpecial and characterSpecial:FindFirstChild(selected_duel_char)

				if not v85 then
					return
				end

				if object[v85] then
					return
				end

				object[v85] = true
				task.spawn(function()
					local v91 = collectPreloadables(v85)

					if #v91 > 0 then
						preloadAssetListBatched(v91, v85:GetFullName())

						return
					end
				end)
			end)
		end
	end)
end

local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

if playerGui then
	u5 = playerGui
	playerGui.ChildAdded:Connect(function(p11: Instance)
		if p11.Name == "CharacterSpecial" then
			task.defer(function()
				local selectedCharacter: any = LocalPlayer:GetAttribute("SelectedCharacter")

				if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and u5 then
					local characterSpecial = u5:FindFirstChild("CharacterSpecial")
					local v82 = characterSpecial and characterSpecial:FindFirstChild(selectedCharacter)

					if v82 and not object[v82] then
						object[v82] = true
						task.spawn(function()
							local v90 = collectPreloadables(v82)

							if #v90 > 0 then
								preloadAssetListBatched(v90, v82:GetFullName())

								return
							end
						end)
					end
				end

				local selected_duel_char: any = LocalPlayer:GetAttribute("SELECTED_DUEL_CHAR")

				if typeof(selected_duel_char) ~= "string" or selected_duel_char == "" then
					return
				end

				if not u5 then
					return
				end

				local characterSpecial = u5:FindFirstChild("CharacterSpecial")
				local v85 = characterSpecial and characterSpecial:FindFirstChild(selected_duel_char)

				if not v85 then
					return
				end

				if object[v85] then
					return
				end

				object[v85] = true
				task.spawn(function()
					local v91 = collectPreloadables(v85)

					if #v91 > 0 then
						preloadAssetListBatched(v91, v85:GetFullName())

						return
					end
				end)
			end)
		end
	end)
end

LocalPlayer.ChildAdded:Connect(function(child: Instance)
	if child:IsA("PlayerGui") then
		u5 = child
		child.ChildAdded:Connect(function(p10: Instance)
			if p10.Name == "CharacterSpecial" then
				task.defer(function()
					local selectedCharacter: any = LocalPlayer:GetAttribute("SelectedCharacter")

					if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and u5 then
						local characterSpecial = u5:FindFirstChild("CharacterSpecial")
						local v82 = characterSpecial and characterSpecial:FindFirstChild(selectedCharacter)

						if v82 and not object[v82] then
							object[v82] = true
							task.spawn(function()
								local v90 = collectPreloadables(v82)

								if #v90 > 0 then
									preloadAssetListBatched(v90, v82:GetFullName())

									return
								end
							end)
						end
					end

					local selected_duel_char: any = LocalPlayer:GetAttribute("SELECTED_DUEL_CHAR")

					if typeof(selected_duel_char) ~= "string" or selected_duel_char == "" then
						return
					end

					if not u5 then
						return
					end

					local characterSpecial = u5:FindFirstChild("CharacterSpecial")
					local v85 = characterSpecial and characterSpecial:FindFirstChild(selected_duel_char)

					if not v85 then
						return
					end

					if object[v85] then
						return
					end

					object[v85] = true
					task.spawn(function()
						local v91 = collectPreloadables(v85)

						if #v91 > 0 then
							preloadAssetListBatched(v91, v85:GetFullName())

							return
						end
					end)
				end)
			end
		end)
	end
end)

local function preloadSelectedCharacterSpecial()
	local selectedCharacter: any = LocalPlayer:GetAttribute("SelectedCharacter")
	local selected_duel_char: any = LocalPlayer:GetAttribute("SELECTED_DUEL_CHAR")

	if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and not t1[selectedCharacter] then
		local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")
		local v63: Instance = uiAssets

		if v63 then
			v63 = uiAssets:FindFirstChild("CharacterSpecialAssets")
		end

		local v64: Instance = v63 and v63:FindFirstChild(selectedCharacter)

		if v64 then
			t1[selectedCharacter] = true

			if v64 and not object[v64] then
				object[v64] = true
				task.spawn(function()
					local v86 = collectPreloadables(v64)

					if #v86 > 0 then
						preloadAssetListBatched(v86, v64:GetFullName())

						return
					end
				end)
			end
		end
	end

	if typeof(selected_duel_char) == "string" and selected_duel_char ~= "" and not t1[selected_duel_char] then
		local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")
		local v66: Instance = uiAssets

		if v66 then
			v66 = uiAssets:FindFirstChild("CharacterSpecialAssets")
		end

		local v67: Instance = v66 and v66:FindFirstChild(selected_duel_char)

		if v67 then
			t1[selected_duel_char] = true

			if v67 and not object[v67] then
				object[v67] = true
				task.spawn(function()
					local v87 = collectPreloadables(v67)

					if #v87 > 0 then
						preloadAssetListBatched(v87, v67:GetFullName())

						return
					end
				end)
			end
		end
	end

	if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and u5 then
		local characterSpecial = u5:FindFirstChild("CharacterSpecial")
		local v69 = characterSpecial and characterSpecial:FindFirstChild(selectedCharacter)

		if v69 and not object[v69] then
			object[v69] = true
			task.spawn(function()
				local v88 = collectPreloadables(v69)

				if #v88 > 0 then
					preloadAssetListBatched(v88, v69:GetFullName())

					return
				end
			end)
		end
	end

	if typeof(selected_duel_char) ~= "string" or selected_duel_char == "" then
		return
	end

	if not u5 then
		return
	end

	local characterSpecial = u5:FindFirstChild("CharacterSpecial")
	local v71 = characterSpecial and characterSpecial:FindFirstChild(selected_duel_char)

	if not v71 then
		return
	end

	if object[v71] then
		return
	end

	object[v71] = true
	task.spawn(function()
		local v89 = collectPreloadables(v71)

		if #v89 > 0 then
			preloadAssetListBatched(v89, v71:GetFullName())

			return
		end
	end)
end

local selectedCharacter: any = LocalPlayer:GetAttribute("SelectedCharacter")
local selected_duel_char: any = LocalPlayer:GetAttribute("SELECTED_DUEL_CHAR")

if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and not t1[selectedCharacter] then
	local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")
	local v22: Instance = uiAssets

	if v22 then
		v22 = uiAssets:FindFirstChild("CharacterSpecialAssets")
	end

	local v23: Instance = v22 and v22:FindFirstChild(selectedCharacter)

	if v23 then
		t1[selectedCharacter] = true

		if v23 and not object[v23] then
			object[v23] = true
			task.spawn(function()
				local v72 = collectPreloadables(v23)

				if #v72 > 0 then
					preloadAssetListBatched(v72, v23:GetFullName())

					return
				end
			end)
		end
	end
end

if typeof(selected_duel_char) == "string" and selected_duel_char ~= "" and not t1[selected_duel_char] then
	local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")
	local v25: Instance = uiAssets

	if v25 then
		v25 = uiAssets:FindFirstChild("CharacterSpecialAssets")
	end

	local v26: Instance = v25 and v25:FindFirstChild(selected_duel_char)

	if v26 then
		t1[selected_duel_char] = true

		if v26 and not object[v26] then
			object[v26] = true
			task.spawn(function()
				local v73 = collectPreloadables(v26)

				if #v73 > 0 then
					preloadAssetListBatched(v73, v26:GetFullName())

					return
				end
			end)
		end
	end
end

if typeof(selectedCharacter) == "string" and selectedCharacter ~= "" and u5 then
	local characterSpecial = u5:FindFirstChild("CharacterSpecial")
	local v28 = characterSpecial and characterSpecial:FindFirstChild(selectedCharacter)

	if v28 and not object[v28] then
		object[v28] = true
		task.spawn(function()
			local v74 = collectPreloadables(v28)

			if #v74 > 0 then
				preloadAssetListBatched(v74, v28:GetFullName())

				return
			end
		end)
	end
end

if typeof(selected_duel_char) == "string" and selected_duel_char ~= "" and u5 then
	local characterSpecial = u5:FindFirstChild("CharacterSpecial")
	local v30 = characterSpecial and characterSpecial:FindFirstChild(selected_duel_char)

	if v30 and not object[v30] then
		object[v30] = true
		task.spawn(function()
			local v75 = collectPreloadables(v30)

			if #v75 > 0 then
				preloadAssetListBatched(v75, v30:GetFullName())

				return
			end
		end)
	end
end

LocalPlayer:GetAttributeChangedSignal("SelectedCharacter"):Connect(preloadSelectedCharacterSpecial)
LocalPlayer:GetAttributeChangedSignal("SELECTED_DUEL_CHAR"):Connect(preloadSelectedCharacterSpecial)
