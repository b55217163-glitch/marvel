-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local soundService: SoundService = game:GetService("SoundService")
local players: Players = game:GetService("Players")
local system: Instance = replicatedStorage:WaitForChild("System")
local lazySound = require(system:WaitForChild("LazySound"))
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })

local function getSoundLogInfo(p1)
	local ok, result = pcall(function()
		return p1:GetFullName()
	end)

	local lazySoundId = p1:GetAttribute("LazySoundId")
	local originalSoundId = p1:GetAttribute("OriginalSoundId")
	local stringFormat = string.format
	local v34 = ok and result or p1.Name
	local text: string = tostring(p1.SoundId)
	local text2: string = tostring(lazySoundId)
	local text3: string = tostring(originalSoundId)

	return stringFormat("%s | SoundId=%s | LazySoundId=%s | OriginalSoundId=%s", v34, text, text2, text3)
end
local function isInsideMenuPreview(p2)
	local v39 = p2

	while v39 and v39 ~= game do
		if v39:GetAttribute("MenuCharacterPreview") == true then
			return true
		end

		local lowerText = v39.Name:lower()

		if lowerText:find("fakechars", 1, true) or lowerText:find("preview_", 1, true) then
			return true
		end

		v39 = v39.Parent
	end

	return false
end
local function cleanupSound(p3)
	local v42 = object2[p3]

	if v42 then
		for i = 1, #v42 do
			local v44 = v42[i]

			if v44 and v44.Connected then
				v44:Disconnect()
			end
		end
	end

	object2[p3] = nil
	object[p3] = nil

	if p3 and not p3:IsDescendantOf(game) then
		pcall(function()
			p3:Destroy()
		end)
	end
end
local function shouldBind(p4)
	local v46
	local v47
	local lazySoundId
	local originalSoundId
	local typeName
	local u51
	local typeName2

	v46 = p4:IsA("Sound")

	if v46 and object[p4] ~= true then
		v47 = isInsideMenuPreview(p4)

		if v47 then
			return false
		else
			lazySoundId = p4:GetAttribute("LazySoundId")
			originalSoundId = p4:GetAttribute("OriginalSoundId")
			typeName = typeof(lazySoundId)

			if typeName == "string" then
				u51 = true

				if lazySoundId == "" then
					u51 = false
					typeName2 = typeof(originalSoundId)

					if typeName2 == "string" then
						u51 = originalSoundId ~= ""
					end
				end
			else
				u51 = false
				typeName2 = typeof(originalSoundId)

				if typeName2 == "string" then
					u51 = originalSoundId ~= ""
				end
			end

			return u51
		end
	else
		return false
	end
end
local function bindSound(p5)
	if not shouldBind(p5) then
		return
	end

	object[p5] = true
	p5:SetAttribute("LazySoundClientBound", nil)

	local t1: {[any]: any} = {}

	object2[p5] = t1

	if p5.Playing then
		lazySound.Restore(p5)
		pcall(function()
			p5.TimePosition = 0
		end)
		p5:Play()
	end

	local v55 = p5:GetPropertyChangedSignal("Playing")

	table.insert(t1, v55:Connect(function()
		if not p5.Parent or not p5.Playing then
		elseif p5.SoundId == "" then
			if p5:GetAttribute("LazySoundReplaying") == true then
				return
			end

			p5:SetAttribute("LazySoundReplaying", true)

			if lazySound.Restore(p5) and p5.Parent then
				pcall(function()
					p5.TimePosition = 0
				end)
				p5:Play()
			end

			p5:SetAttribute("LazySoundReplaying", false)

			return
		end
	end))
	table.insert(t1, p5.Ended:Connect(function()
		if p5.Parent and p5:GetAttribute("LazyClearAfterPlay") == true then
			task.delay(0.25, function()
				if p5.Parent and not p5.Playing then
					lazySound.Clear(p5)
				end
			end)
		end
	end))
	table.insert(t1, p5.AncestryChanged:Connect(function()
		if p5:IsDescendantOf(game) then
			return
		end

		task.delay(1, function()
			if not p5:IsDescendantOf(game) then
				cleanupSound(p5)
			end
		end)
	end))
	table.insert(t1, p5.Destroying:Connect(function()
		cleanupSound(p5)
	end))
end
local function bindAddedInstance(p6)
	if p6:IsA("Sound") then
		bindSound(p6)
	end
end
local function scanBatched(p7)
	if not p7 then
		return
	end

	if p7:IsA("Sound") then
		bindSound(p7)

		return
	end

	task.spawn(function()
		local t9: {[any]: any} = { p7 }
		local n1: number = 0

		while #t9 > 0 do
			local v105 = table.remove(t9)

			if v105:IsA("Sound") then
				bindSound(v105)
			end

			local children = v105:GetChildren()

			for i = 1, #children do
				t9[#t9 + 1] = children[i]
			end

			n1 += 1

			if n1 >= 200 then
				n1 = 0
				task.wait()
			end
		end
	end)
end
local function v15(p8)
	if not p8 then
		return
	end

	if p8:IsA("Sound") then
		bindSound(p8)

		return
	end

	task.spawn(function()
		local t10: {[any]: any} = { p8 }
		local n1: number = 0

		while #t10 > 0 do
			local v110 = table.remove(t10)

			if v110:IsA("Sound") then
				bindSound(v110)
			end

			local children = v110:GetChildren()

			for i = 1, #children do
				t10[#t10 + 1] = children[i]
			end

			n1 += 1

			if n1 >= 200 then
				n1 = 0
				task.wait()
			end
		end
	end)
end

local object3 = setmetatable({}, { __mode = "k" })

local function watchPlayerContainer(p9)
	if p9 and not object3[p9] then
		object3[p9] = true

		if p9 then
			if p9:IsA("Sound") then
				bindSound(p9)
			else
				task.spawn(function()
					local t11: {[any]: any} = { p9 }
					local n1: number = 0

					while #t11 > 0 do
						local v115 = table.remove(t11)

						if v115:IsA("Sound") then
							bindSound(v115)
						end

						local children = v115:GetChildren()

						for i = 1, #children do
							t11[#t11 + 1] = children[i]
						end

						n1 += 1

						if n1 >= 200 then
							n1 = 0
							task.wait()
						end
					end
				end)
			end
		end

		p9.DescendantAdded:Connect(bindAddedInstance)

		return
	end
end

local v18 = workspace

if v18 then
	if v18:IsA("Sound") then
		bindSound(v18)
	else
		task.spawn(function()
			local t2: {[any]: any} = { v18 }
			local n1: number = 0

			while #t2 > 0 do
				local v62 = table.remove(t2)

				if v62:IsA("Sound") then
					bindSound(v62)
				end

				local children = v62:GetChildren()

				for i = 1, #children do
					t2[#t2 + 1] = children[i]
				end

				n1 += 1

				if n1 >= 200 then
					n1 = 0
					task.wait()
				end
			end
		end)
	end
end

if soundService then
	if soundService:IsA("Sound") then
		bindSound(soundService)
	else
		task.spawn(function()
			local t3: {[any]: any} = { soundService }
			local n1: number = 0

			while #t3 > 0 do
				local v67 = table.remove(t3)

				if v67:IsA("Sound") then
					bindSound(v67)
				end

				local children = v67:GetChildren()

				for i = 1, #children do
					t3[#t3 + 1] = children[i]
				end

				n1 += 1

				if n1 >= 200 then
					n1 = 0
					task.wait()
				end
			end
		end)
	end
end

local scriptParent: Instance = script.Parent

if scriptParent then
	if scriptParent:IsA("Sound") then
		bindSound(scriptParent)
	else
		task.spawn(function()
			local t4: {[any]: any} = { scriptParent }
			local n1: number = 0

			while #t4 > 0 do
				local v72 = table.remove(t4)

				if v72:IsA("Sound") then
					bindSound(v72)
				end

				local children = v72:GetChildren()

				for i = 1, #children do
					t4[#t4 + 1] = children[i]
				end

				n1 += 1

				if n1 >= 200 then
					n1 = 0
					task.wait()
				end
			end
		end)
	end
end

replicatedStorage.DescendantAdded:Connect(bindAddedInstance)
workspace.DescendantAdded:Connect(bindAddedInstance)
soundService.DescendantAdded:Connect(bindAddedInstance)

local LocalPlayer: Player = players.LocalPlayer

local function bindPlayerGui()
	local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

	if not playerGui then
		return
	end

	if object3[playerGui] then
		return
	end

	object3[playerGui] = true

	if playerGui then
		if playerGui:IsA("Sound") then
			bindSound(playerGui)
		else
			task.spawn(function()
				local t12: {[any]: any} = { playerGui }
				local n1: number = 0

				while #t12 > 0 do
					local v120 = table.remove(t12)

					if v120:IsA("Sound") then
						bindSound(v120)
					end

					local children = v120:GetChildren()

					for i = 1, #children do
						t12[#t12 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	playerGui.DescendantAdded:Connect(bindAddedInstance)
end
local function bindPlayerScripts()
	local playerScripts: Instance = LocalPlayer:FindFirstChild("PlayerScripts")

	if not playerScripts then
		return
	end

	if object3[playerScripts] then
		return
	end

	object3[playerScripts] = true

	if playerScripts then
		if playerScripts:IsA("Sound") then
			bindSound(playerScripts)
		else
			task.spawn(function()
				local t13: {[any]: any} = { playerScripts }
				local n1: number = 0

				while #t13 > 0 do
					local v125 = table.remove(t13)

					if v125:IsA("Sound") then
						bindSound(v125)
					end

					local children = v125:GetChildren()

					for i = 1, #children do
						t13[#t13 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	playerScripts.DescendantAdded:Connect(bindAddedInstance)
end
local function bindBackpack()
	local backpack: Instance = LocalPlayer:FindFirstChildOfClass("Backpack")

	if not backpack then
		return
	end

	if object3[backpack] then
		return
	end

	object3[backpack] = true

	if backpack then
		if backpack:IsA("Sound") then
			bindSound(backpack)
		else
			task.spawn(function()
				local t14: {[any]: any} = { backpack }
				local n1: number = 0

				while #t14 > 0 do
					local v130 = table.remove(t14)

					if v130:IsA("Sound") then
						bindSound(v130)
					end

					local children = v130:GetChildren()

					for i = 1, #children do
						t14[#t14 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	backpack.DescendantAdded:Connect(bindAddedInstance)
end

local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

if playerGui and not object3[playerGui] then
	object3[playerGui] = true

	if playerGui then
		if playerGui:IsA("Sound") then
			bindSound(playerGui)
		else
			task.spawn(function()
				local t5: {[any]: any} = { playerGui }
				local n1: number = 0

				while #t5 > 0 do
					local v80 = table.remove(t5)

					if v80:IsA("Sound") then
						bindSound(v80)
					end

					local children = v80:GetChildren()

					for i = 1, #children do
						t5[#t5 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	playerGui.DescendantAdded:Connect(bindAddedInstance)
end

local playerScripts: Instance = LocalPlayer:FindFirstChild("PlayerScripts")

if playerScripts and not object3[playerScripts] then
	object3[playerScripts] = true

	if playerScripts then
		if playerScripts:IsA("Sound") then
			bindSound(playerScripts)
		else
			task.spawn(function()
				local t6: {[any]: any} = { playerScripts }
				local n1: number = 0

				while #t6 > 0 do
					local v85 = table.remove(t6)

					if v85:IsA("Sound") then
						bindSound(v85)
					end

					local children = v85:GetChildren()

					for i = 1, #children do
						t6[#t6 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	playerScripts.DescendantAdded:Connect(bindAddedInstance)
end

local backpack: Instance = LocalPlayer:FindFirstChildOfClass("Backpack")

if backpack and not object3[backpack] then
	object3[backpack] = true

	if backpack then
		if backpack:IsA("Sound") then
			bindSound(backpack)
		else
			task.spawn(function()
				local t7: {[any]: any} = { backpack }
				local n1: number = 0

				while #t7 > 0 do
					local v90 = table.remove(t7)

					if v90:IsA("Sound") then
						bindSound(v90)
					end

					local children = v90:GetChildren()

					for i = 1, #children do
						t7[#t7 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	backpack.DescendantAdded:Connect(bindAddedInstance)
end

local Character: Model = LocalPlayer.Character

if Character and not object3[Character] then
	object3[Character] = true

	if Character then
		if Character:IsA("Sound") then
			bindSound(Character)
		else
			task.spawn(function()
				local t8: {[any]: any} = { Character }
				local n1: number = 0

				while #t8 > 0 do
					local v95 = table.remove(t8)

					if v95:IsA("Sound") then
						bindSound(v95)
					end

					local children = v95:GetChildren()

					for i = 1, #children do
						t8[#t8 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	Character.DescendantAdded:Connect(bindAddedInstance)
end

LocalPlayer.CharacterAdded:Connect(function(character: Model)
	if not character then
		return
	end

	if object3[character] then
		return
	end

	object3[character] = true

	if character then
		if character:IsA("Sound") then
			bindSound(character)
		else
			task.spawn(function()
				local t15: {[any]: any} = { character }
				local n1: number = 0

				while #t15 > 0 do
					local v135 = table.remove(t15)

					if v135:IsA("Sound") then
						bindSound(v135)
					end

					local children = v135:GetChildren()

					for i = 1, #children do
						t15[#t15 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	character.DescendantAdded:Connect(bindAddedInstance)
end)
LocalPlayer.ChildAdded:Connect(function(child: Instance)
	if child:IsA("PlayerGui") then
		local playerGui2: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

		if playerGui2 then
			if object3[playerGui2] then
				return
			end

			object3[playerGui2] = true

			if playerGui2 then
				if playerGui2:IsA("Sound") then
					bindSound(playerGui2)
				else
					task.spawn(function()
						local t16: {[any]: any} = { playerGui2 }
						local n1: number = 0

						while #t16 > 0 do
							local v140 = table.remove(t16)

							if v140:IsA("Sound") then
								bindSound(v140)
							end

							local children = v140:GetChildren()

							for i = 1, #children do
								t16[#t16 + 1] = children[i]
							end

							n1 += 1

							if n1 >= 200 then
								n1 = 0
								task.wait()
							end
						end
					end)
				end
			end

			playerGui2.DescendantAdded:Connect(bindAddedInstance)

			return
		end
	elseif child.Name == "PlayerScripts" then
		local playerScripts2: Instance = LocalPlayer:FindFirstChild("PlayerScripts")

		if playerScripts2 then
			if object3[playerScripts2] then
				return
			end

			object3[playerScripts2] = true

			if playerScripts2 then
				if playerScripts2:IsA("Sound") then
					bindSound(playerScripts2)
				else
					task.spawn(function()
						local t17: {[any]: any} = { playerScripts2 }
						local n1: number = 0

						while #t17 > 0 do
							local v145 = table.remove(t17)

							if v145:IsA("Sound") then
								bindSound(v145)
							end

							local children = v145:GetChildren()

							for i = 1, #children do
								t17[#t17 + 1] = children[i]
							end

							n1 += 1

							if n1 >= 200 then
								n1 = 0
								task.wait()
							end
						end
					end)
				end
			end

			playerScripts2.DescendantAdded:Connect(bindAddedInstance)

			return
		end
	else
		local backpack = child:IsA("Backpack") and LocalPlayer:FindFirstChildOfClass("Backpack")

		if backpack then
			if object3[backpack] then
				return
			end

			object3[backpack] = true

			if backpack then
				if backpack:IsA("Sound") then
					bindSound(backpack)
				else
					task.spawn(function()
						local t18: {[any]: any} = { backpack }
						local n1: number = 0

						while #t18 > 0 do
							local v150 = table.remove(t18)

							if v150:IsA("Sound") then
								bindSound(v150)
							end

							local children = v150:GetChildren()

							for i = 1, #children do
								t18[#t18 + 1] = children[i]
							end

							n1 += 1

							if n1 >= 200 then
								n1 = 0
								task.wait()
							end
						end
					end)
				end
			end

			backpack.DescendantAdded:Connect(bindAddedInstance)
		end
	end
end)
