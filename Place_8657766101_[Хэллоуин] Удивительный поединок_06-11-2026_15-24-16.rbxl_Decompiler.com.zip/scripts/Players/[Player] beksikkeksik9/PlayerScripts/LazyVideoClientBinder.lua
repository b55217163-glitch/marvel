-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local contentProvider: ContentProvider = game:GetService("ContentProvider")
local LocalPlayer: Player = players.LocalPlayer
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })
local t1: {[any]: any} = {}

local function cleanupVideo(p1)
	local v16 = object2[p1]

	if v16 then
		for i = 1, #v16 do
			local v18 = v16[i]

			if v18 and v18.Connected then
				v18:Disconnect()
			end
		end
	end

	object2[p1] = nil
	object[p1] = nil
end
local function assignAndPreload(p2)
	local lazyVideoId = p2:GetAttribute("LazyVideoId")

	if typeof(lazyVideoId) == "string" and lazyVideoId ~= "" then
		if lazyVideoId ~= p2.Video then
			p2.Video = lazyVideoId
		end

		if t1[lazyVideoId] then
			return
		end

		t1[lazyVideoId] = true
		task.spawn(function()
			pcall(function()
				contentProvider:PreloadAsync({ p2 })
			end)
		end)

		return
	end
end
local function restoreAndPlay(p3)
	if p3:GetAttribute("LazyVideoReplaying") == true then
		return
	end

	local lazyVideoId = p3:GetAttribute("LazyVideoId")

	if typeof(lazyVideoId) == "string" and lazyVideoId ~= "" then
		if lazyVideoId ~= p3.Video then
			p3.Video = lazyVideoId
		end

		p3:SetAttribute("LazyVideoReplaying", true)
		assignAndPreload(p3)
		pcall(function()
			p3.TimePosition = 0
		end)
		p3:Play()
		p3:SetAttribute("LazyVideoReplaying", false)

		return
	end
end
local function bindVideo(p4)
	if object[p4] then
	elseif typeof(p4:GetAttribute("LazyVideoId")) == "string" and p4:GetAttribute("LazyVideoId") ~= "" then
		object[p4] = true
		p4:SetAttribute("LazyVideoClientBound", true)

		local t2: {[any]: any} = {}

		object2[p4] = t2

		local v25 = p4:GetAttributeChangedSignal("LazyVideoId")

		table.insert(t2, v25:Connect(function()
			if p4.Playing then
				assignAndPreload(p4)
			end
		end))
		v25 = p4:GetPropertyChangedSignal("Playing")
		table.insert(t2, v25:Connect(function()
			if p4.Playing and p4.Video == "" then
				restoreAndPlay(p4)
			end
		end))
		table.insert(t2, p4.Destroying:Connect(function()
			cleanupVideo(p4)
		end))

		return
	end
end

local object3 = setmetatable({}, { __mode = "k" })

local function scan(p5)
	if not p5 then
		return
	end

	if p5:IsA("VideoFrame") then
		bindVideo(p5)

		return
	end

	task.spawn(function()
		local t4: {[any]: any} = { p5 }
		local n1: number = 0

		while #t4 > 0 do
			local v37 = table.remove(t4)

			if v37:IsA("VideoFrame") then
				bindVideo(v37)
			end

			local children = v37:GetChildren()

			for i = 1, #children do
				t4[#t4 + 1] = children[i]
			end

			n1 += 1

			if n1 >= 200 then
				n1 = 0
				task.wait()
			end
		end
	end)
end
local function watch(p6)
	if p6 and not object3[p6] then
		object3[p6] = true

		if p6 then
			if p6:IsA("VideoFrame") then
				bindVideo(p6)
			else
				task.spawn(function()
					local t5: {[any]: any} = { p6 }
					local n1: number = 0

					while #t5 > 0 do
						local v42 = table.remove(t5)

						if v42:IsA("VideoFrame") then
							bindVideo(v42)
						end

						local children = v42:GetChildren()

						for i = 1, #children do
							t5[#t5 + 1] = children[i]
						end

						n1 += 1

						if n1 >= 200 then
							n1 = 0
							task.wait()
						end
					end
				end)
			end
		end

		p6.DescendantAdded:Connect(function(p7: Instance)
			if p7:IsA("VideoFrame") then
				bindVideo(p7)
			end
		end)

		return
	end
end

local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

if playerGui and not object3[playerGui] then
	object3[playerGui] = true

	if playerGui then
		if playerGui:IsA("VideoFrame") then
			bindVideo(playerGui)
		else
			task.spawn(function()
				local t3: {[any]: any} = { playerGui }
				local n1: number = 0

				while #t3 > 0 do
					local v30 = table.remove(t3)

					if v30:IsA("VideoFrame") then
						bindVideo(v30)
					end

					local children = v30:GetChildren()

					for i = 1, #children do
						t3[#t3 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	playerGui.DescendantAdded:Connect(function(p8: Instance)
		if p8:IsA("VideoFrame") then
			bindVideo(p8)
		end
	end)
end

LocalPlayer.ChildAdded:Connect(function(child: Instance)
	if not child:IsA("PlayerGui") or not child then
		return
	end

	if object3[child] then
		return
	end

	object3[child] = true

	if child then
		if child:IsA("VideoFrame") then
			bindVideo(child)
		else
			task.spawn(function()
				local t6: {[any]: any} = { child }
				local n1: number = 0

				while #t6 > 0 do
					local v48 = table.remove(t6)

					if v48:IsA("VideoFrame") then
						bindVideo(v48)
					end

					local children = v48:GetChildren()

					for i = 1, #children do
						t6[#t6 + 1] = children[i]
					end

					n1 += 1

					if n1 >= 200 then
						n1 = 0
						task.wait()
					end
				end
			end)
		end
	end

	child.DescendantAdded:Connect(function(p7: Instance)
		if p7:IsA("VideoFrame") then
			bindVideo(p7)
		end
	end)
end)
