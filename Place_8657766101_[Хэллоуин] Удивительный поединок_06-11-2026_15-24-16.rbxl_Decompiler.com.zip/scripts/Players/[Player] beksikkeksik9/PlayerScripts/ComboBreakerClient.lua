-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local contextActionService: ContextActionService = game:GetService("ContextActionService")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local userInputService: UserInputService = game:GetService("UserInputService")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local combat: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat")
local remotes: Instance = combat:WaitForChild("Remotes")
local comboBreakerConfig = require(combat:WaitForChild("ComboBreakerConfig"))
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local comboBreakerRemote: Instance = remotes:WaitForChild("ComboBreakerRemote")
local comboBreakerResetRemote: Instance = remotes:WaitForChild("ComboBreakerResetRemote")
local comboBreakerResetBindable = replicatedStorage:FindFirstChild("ComboBreakerResetBindable")

if not comboBreakerResetBindable then
	comboBreakerResetBindable = Instance.new("BindableEvent")
	comboBreakerResetBindable.Name = "ComboBreakerResetBindable"
	comboBreakerResetBindable.Parent = replicatedStorage
end

local u16: boolean = false
local u17 = nil
local u18 = false
local u19 = false
local u20 = nil
local u21: boolean = false
local n1 = 0
local n2 = 0
local u24 = nil
local u25: boolean = false
local u26 = false
local u27 = nil
local u28 = nil
local comboBreakerPromptGui: ScreenGui = Instance.new("ScreenGui")

comboBreakerPromptGui.Name = "ComboBreakerPromptGui"
comboBreakerPromptGui.ResetOnSpawn = false
comboBreakerPromptGui.IgnoreGuiInset = true
comboBreakerPromptGui.Enabled = false
comboBreakerPromptGui.DisplayOrder = 65
comboBreakerPromptGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

local comboBreakerMeterGui: ScreenGui = Instance.new("ScreenGui")

comboBreakerMeterGui.Name = "ComboBreakerMeterGui"
comboBreakerMeterGui.ResetOnSpawn = false
comboBreakerMeterGui.IgnoreGuiInset = true
comboBreakerMeterGui.Enabled = false
comboBreakerMeterGui.DisplayOrder = comboBreakerConfig.MeterDisplayOrder or -5
comboBreakerMeterGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
comboBreakerMeterGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

local v31 = comboBreakerConfig.MeterPosition or UDim2.new(0.035, 0, 0.5, 0)
local uDim2 = UDim2.new(0, -40, v31.Y.Scale, v31.Y.Offset)
local root: CanvasGroup = Instance.new("CanvasGroup")

root.Name = "Root"
root.AnchorPoint = Vector2.new(0.5, 0.5)
root.Position = uDim2
root.Size = comboBreakerConfig.MeterSize or UDim2.new(0.018, 0, 0.26, 0)
root.BackgroundColor3 = comboBreakerConfig.MeterBackgroundColor or Color3.fromRGB(0, 0, 0)
root.BackgroundTransparency = 0.18
root.BorderSizePixel = 0
root.GroupTransparency = 0
root.Parent = comboBreakerMeterGui

local uiSizeConstraint: UISizeConstraint = Instance.new("UISizeConstraint")

uiSizeConstraint.MinSize = Vector2.new(comboBreakerConfig.MeterMinWidth or 18, comboBreakerConfig.MeterMinHeight or 140)
uiSizeConstraint.MaxSize = Vector2.new(comboBreakerConfig.MeterMaxWidth or 26, comboBreakerConfig.MeterMaxHeight or 210)
uiSizeConstraint.Parent = root

local uiStroke: UIStroke = Instance.new("UIStroke")

uiStroke.Color = comboBreakerConfig.MeterStrokeColor or Color3.fromRGB(0, 0, 0)
uiStroke.Thickness = 3
uiStroke.Transparency = 0
uiStroke.Parent = root

local fillClip: Frame = Instance.new("Frame")

fillClip.Name = "FillClip"
fillClip.AnchorPoint = Vector2.new(0.5, 1)
fillClip.Position = UDim2.new(0.5, 0, 1, -3)
fillClip.Size = UDim2.new(1, -6, 0, 0)
fillClip.BackgroundTransparency = 1
fillClip.ClipsDescendants = true
fillClip.Parent = root

local pixelMask: Frame = Instance.new("Frame")

pixelMask.Name = "PixelMask"
pixelMask.BackgroundTransparency = 1
pixelMask.Size = UDim2.new(1, 0, 1, 0)
pixelMask.ZIndex = 3
pixelMask.Parent = root

local v38 = comboBreakerConfig.MeterPixelSegments or 12

for i = 1, v38 - 1 do
	local frame: Frame = Instance.new("Frame")

	frame.Name = "PixelDivider" .. tostring(i)
	frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	frame.BorderSizePixel = 0
	frame.Position = UDim2.new(0, 0, i / v38, -1)
	frame.Size = UDim2.new(1, 0, 0, 2)
	frame.ZIndex = 3
	frame.Parent = pixelMask
end

local fill: Frame = Instance.new("Frame")

fill.Name = "Fill"
fill.AnchorPoint = Vector2.new(0.5, 1)
fill.Position = UDim2.new(0.5, 0, 1, 0)
fill.Size = UDim2.new(1, 0, 1, 0)
fill.BackgroundColor3 = comboBreakerConfig.MeterFillColor or Color3.fromRGB(0, 170, 255)
fill.BorderSizePixel = 0
fill.Parent = fillClip

local uiGradient: UIGradient = Instance.new("UIGradient")

uiGradient.Rotation = 90

local colorSequenceNew = ColorSequence.new
local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, Color3.fromRGB(120, 235, 255))
local colorSequenceKeypointNew = ColorSequenceKeypoint.new
local v46 = comboBreakerConfig.MeterFillColor or Color3.fromRGB(0, 170, 255)
local v47 = colorSequenceKeypointNew(0.55, v46)

uiGradient.Color = colorSequenceNew({
	colorSequenceKeypoint,
	v47,
	ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 85, 210))
})
uiGradient.Parent = fill

local readyFlash: Frame = Instance.new("Frame")

readyFlash.Name = "ReadyFlash"
readyFlash.AnchorPoint = Vector2.new(0.5, 0.5)
readyFlash.Position = UDim2.new(0.5, 0, 0.5, 0)
readyFlash.Size = UDim2.new(1, 0, 1, 0)
readyFlash.BackgroundColor3 = Color3.fromRGB(80, 220, 255)
readyFlash.BackgroundTransparency = 1
readyFlash.BorderSizePixel = 0
readyFlash.Parent = root

local readyText: TextLabel = Instance.new("TextLabel")

readyText.Name = "ReadyText"
readyText.AnchorPoint = Vector2.new(0.5, 0.5)
readyText.Position = UDim2.new(0.5, 0, 0, -20)
readyText.Size = UDim2.new(0, 82, 0, 20)
readyText.BackgroundTransparency = 1
readyText.Font = Enum.Font.Arcade
readyText.Text = "READY"
readyText.TextColor3 = Color3.fromRGB(80, 220, 255)
readyText.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
readyText.TextStrokeTransparency = 0
readyText.TextScaled = true
readyText.Visible = false
readyText.ZIndex = 4
readyText.Parent = root

local canvasGroup: CanvasGroup = Instance.new("CanvasGroup")

canvasGroup.Name = "Root"
canvasGroup.AnchorPoint = Vector2.new(0.5, 0.5)
canvasGroup.Position = UDim2.new(0.5, 0, 0.31, 0)
canvasGroup.Size = UDim2.new(0, 470, 0, 92)
canvasGroup.BackgroundTransparency = 1
canvasGroup.GroupTransparency = 1
canvasGroup.Parent = comboBreakerPromptGui

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 1
uiScale.Parent = canvasGroup

local panel: TextButton = Instance.new("TextButton")

panel.Name = "Panel"
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.new(0.5, 0, 0.5, 0)
panel.Size = UDim2.new(1, 0, 1, 0)
panel.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
panel.BackgroundTransparency = 0.45
panel.BorderSizePixel = 0
panel.AutoButtonColor = true
panel.Text = ""
panel.Selectable = true
panel.Active = true
panel.Parent = canvasGroup

local uiCorner: UICorner = Instance.new("UICorner")

uiCorner.CornerRadius = UDim.new(0, 12)
uiCorner.Parent = panel

local uiStroke2: UIStroke = Instance.new("UIStroke")

uiStroke2.Color = Color3.fromRGB(80, 220, 255)
uiStroke2.Thickness = 2
uiStroke2.Transparency = 0.15
uiStroke2.Parent = panel

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.new(0.04, 0, 0.08, 0)
title.Size = UDim2.new(0.92, 0, 0.36, 0)
title.Font = Enum.Font.Arcade
title.Text = comboBreakerConfig.PromptTitle or "COMBO BREAKER READY"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextStrokeTransparency = 0.45
title.TextScaled = true
title.Parent = panel

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.new(0.04, 0, 0.51, 0)
subtitle.Size = UDim2.new(0.92, 0, 0.32, 0)
subtitle.Font = Enum.Font.Arcade
subtitle.Text = "TAP X TO BREAK COMBO"
subtitle.TextColor3 = Color3.fromRGB(80, 220, 255)
subtitle.TextStrokeTransparency = 0.55
subtitle.TextScaled = true
subtitle.Parent = panel

local function formatBinding(p1)
	if not p1 or p1 == "" then
		return nil
	end

	if p1 == "MouseButton1" then
		return "M1"
	end

	if p1 == "MouseButton2" then
		return "M2"
	end

	if p1 == "MouseButton3" then
		return "M3"
	end

	if p1 == "ButtonA" then
		return "A"
	end

	if p1 == "ButtonB" then
		return "B"
	end

	if p1 == "ButtonX" then
		return "X"
	end

	if p1 == "ButtonY" then
		return "Y"
	end

	if string.sub(p1, 1, 6) == "Button" then
		return (string.sub(p1, 7))
	end

	if string.sub(p1, 1, 4) == "DPad" then
		return string.gsub(p1, "DPad", "D-")
	end

	return p1
end
local function getPromptText()
	if userInputService.TouchEnabled and not userInputService.KeyboardEnabled then
		return comboBreakerConfig.PromptTouchText or "TAP BREAKER TO BREAK COMBO"
	end

	local v93 = userInputService.KeyboardEnabled and formatBinding(controlsRuntime.GetBinding(LocalPlayer, comboBreakerConfig.ActionName, "Keyboard"))

	if v93 then
		return "TAP " .. v93 .. " TO BREAK COMBO"
	end

	v93 = formatBinding(controlsRuntime.GetBinding(LocalPlayer, comboBreakerConfig.ActionName, "Controller"))

	if v93 then
		return "TAP " .. v93 .. " TO BREAK COMBO"
	end

	return "TAP BREAKER TO BREAK COMBO"
end
local function hasIframe(p2)
	local v95 = p2

	if v95 then
		v95 = p2:FindFirstChild("Iframe") ~= nil
	end

	return v95
end

hasIframe = function()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local u97: boolean = false

	if menu ~= nil then
		u97 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	return u97
end

local function isCharacterActiveForComboBreaker(character)
	if not character or not character.Parent then
		return false
	end

	local menu: Instance = playerGui:FindFirstChild("Menu")
	local u100: boolean = false

	if menu ~= nil then
		u100 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	if u100 then
	elseif character:FindFirstChildOfClass("Humanoid") and not (character:FindFirstChildOfClass("Humanoid").Health <= 0) then
		return true
	end

	return false
end
local function hasComboBreakerIgnore(p4)
	if not p4 then
		return false
	end

	if p4:GetAttribute("ComboBreakerIgnore") == true then
		return true
	end

	local comboBreakerIgnoreUntil = p4:GetAttribute("ComboBreakerIgnoreUntil")

	if typeof(comboBreakerIgnoreUntil) == "number" and comboBreakerIgnoreUntil > os.clock() then
		return true
	end

	local children = p4:GetChildren()

	for i = 1, #children do
		local v105 = children[i]

		if v105.Name == "ComboBreakerIgnore" or v105:GetAttribute("ComboBreakerIgnore") == true or v105:GetAttribute("SelfStun") == true then
			return true
		end
	end

	return false
end
local function isSelfComboBreakerStatus(p5)
	local u107: boolean = false

	if p5 ~= nil then
		u107 = true

		if p5:GetAttribute("SelfStun") ~= true then
			u107 = true

			if p5:GetAttribute("ComboBreakerIgnore") ~= true then
				u107 = p5:GetAttribute("SelfApplied") == true
			end
		end
	end

	return u107
end
local function hasActivationStatus(p6)
	if not p6 then
		return false
	end

	local comboBreakerConfigActivationStatusNames = comboBreakerConfig.ActivationStatusNames

	for i = 1, #comboBreakerConfigActivationStatusNames do
		local foundChild = p6:FindFirstChild(comboBreakerConfigActivationStatusNames[i])

		if foundChild then
			local u112: boolean = false

			if foundChild ~= nil then
				u112 = true

				if foundChild:GetAttribute("SelfStun") ~= true then
					u112 = true

					if foundChild:GetAttribute("ComboBreakerIgnore") ~= true then
						u112 = foundChild:GetAttribute("SelfApplied") == true
					end
				end
			end

			if u112 then
				continue
			end

			return true
		end
	end

	return false
end
local function u64()
	return false
end
local function usedForCurrentCharacter()
	return u17 ~= nil and u17:GetAttribute("ComboBreakerUsed") == true
end
local function getMeterProgress()
	if comboBreakerConfig.Enabled == true and comboBreakerConfig.MeterEnabled == true then
		local character = u17
		local u115

		if not character or not character.Parent then
			u115 = false
		else
			local menu: Instance = playerGui:FindFirstChild("Menu")
			local u116: boolean = false

			if menu ~= nil then
				u116 = menu:IsA("ScreenGui") and menu.Enabled == true
			end

			if u116 then
				u115 = false
			else
				local humanoid = character:FindFirstChildOfClass("Humanoid")

				u115 = if humanoid and not (humanoid.Health <= 0) then true else false
			end
		end

		if not u115 then
		elseif not u64() then
			if (u17 == nil or u17:GetAttribute("ComboBreakerUsed") ~= true) and not hasComboBreakerIgnore(character) then
				if character:GetAttribute("ComboBreakerWindowOpen") == true then
					return 0
				end

				local humanoid = character:FindFirstChildOfClass("Humanoid")

				if humanoid and not (humanoid.MaxHealth <= 0) then
					local comboBreakerDamage = character:GetAttribute("ComboBreakerDamage")

					if typeof(comboBreakerDamage) == "number" and not (comboBreakerDamage <= 0) then
						local n1 = humanoid.MaxHealth * (comboBreakerConfig.DamageThresholdMaxHealthFraction or 0.5)

						if n1 <= 0 then
							return 0
						end

						return (math.clamp(comboBreakerDamage / n1, 0, 1))
					end

					return 0
				end

				return 0
			end

			return 0
		end

		return 0
	end

	return 0
end
local function playMeterReadyPulse()
	readyText.Visible = true
	readyText.TextTransparency = 0
	readyText.TextStrokeTransparency = 0
	readyFlash.BackgroundTransparency = 0.25

	local v121 = comboBreakerConfig.MeterSize or UDim2.new(0, 22, 0, 190)

	root.Size = UDim2.new(v121.X.Scale, v121.X.Offset + 8, v121.Y.Scale, v121.Y.Offset + 8)

	local tweenInfo = TweenInfo.new(0.16, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	tweenService:Create(root, tweenInfo, { Size = v121 }):Play()

	local tweenInfo2 = TweenInfo.new(0.32, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

	tweenService:Create(readyFlash, tweenInfo2, { BackgroundTransparency = 1 }):Play()
	task.delay(0.75, function()
		if not u21 then
			return
		end

		local tweenInfo3 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v236: Tween = tweenService:Create(readyText, tweenInfo3, { TextTransparency = 1, TextStrokeTransparency = 1 })

		v236:Play()
		v236.Completed:Connect(function()
			if readyText.TextTransparency >= 1 then
				readyText.Visible = false
			end
		end)
	end)
end
local function setMeterVisible(p7, _)
	if p7 == u19 then
		return
	end

	u19 = p7

	if u28 then
		u28:Cancel()
		u28 = nil
	end

	if p7 then
		comboBreakerMeterGui.Enabled = true

		local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

		u28 = tweenService:Create(root, tweenInfo, { Position = v31 })
		u28:Play()

		return
	end

	local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

	u28 = tweenService:Create(root, tweenInfo, { Position = uDim2 })
	u28:Play()
	u28.Completed:Connect(function()
		if not u19 then
			comboBreakerMeterGui.Enabled = false
		end
	end)
end
local function scheduleMeterNoUpdateHide(p9)
	local t2: {[any]: any} = {}

	u24 = t2
	task.delay(p9, function()
		if u24 ~= t2 then
			return
		end

		if getMeterProgress() <= 0.01 then
			return
		end

		if os.clock() - n1 >= p9 then
			u24 = nil
			setMeterVisible(false, "Left")
		end
	end)
end
local function forceHideMeter()
	u20 = nil
	u24 = nil
	u25 = false
	u21 = false
	readyText.Visible = false
	readyFlash.BackgroundTransparency = 1
	u19 = false

	if u28 then
		u28:Cancel()
		u28 = nil
	end

	root.Position = uDim2
	comboBreakerMeterGui.Enabled = false
end
local function hideMeterAfterDelay(p10, p11, p12)
	local t3: {[any]: any} = {}

	u20 = t3
	task.delay(p10, function()
		if u20 ~= t3 then
			return
		end

		local v237 = getMeterProgress()
		local v238 = u17
		local u239

		if v238 then
			u239 = true

			if v238:GetAttribute("ComboBreakerWindowOpen") ~= true then
				u239 = v237 >= 1
			end
		else
			u239 = v237 >= 1
		end

		if p11 == nil or u239 == p11 then
			u20 = nil
			u25 = false

			if v237 <= 0.01 or u239 then
				u21 = false
				setMeterVisible(false, p12)
			end

			return
		end
	end)
end
local function swipeMeterRightEmpty()
	u20 = nil
	u25 = false
	u21 = false
	readyText.Visible = false
	readyFlash.BackgroundTransparency = 1
	setMeterVisible(false, "Left")
end
local function refreshMeter()
	if u26 then
		return
	end

	local v134 = getMeterProgress()
	local v135 = v134

	if v134 > 0 then
		local v136 = math.max(comboBreakerConfig.MeterPixelSegments or 12, 1)

		v135 = math.ceil(v134 * v136) / v136
	end

	local v137 = u17
	local v138 = v137

	if v138 then
		v138 = v137:GetAttribute("ComboBreakerWindowOpen") == true
	end

	if v138 then
		readyText.Visible = false
		readyFlash.BackgroundTransparency = 1
		u21 = true
		fillClip.Size = UDim2.new(1, -6, 1, -6)

		if u19 ~= true then
			u19 = true

			if u28 then
				u28:Cancel()
				u28 = nil
			end

			comboBreakerMeterGui.Enabled = true

			local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

			u28 = tweenService:Create(root, tweenInfo, { Position = v31 })
			u28:Play()
		end

		if not u25 then
			u25 = true

			local t4: {[any]: any} = {}

			u20 = t4

			local u141: boolean = true
			local s1: string = "Left"

			task.delay(comboBreakerConfig.MeterReadyHoldTime or 3, function()
				if u20 ~= t4 then
					return
				end

				local v240 = getMeterProgress()
				local v241 = u17
				local u242

				if v241 then
					u242 = true

					if v241:GetAttribute("ComboBreakerWindowOpen") ~= true then
						u242 = v240 >= 1
					end
				else
					u242 = v240 >= 1
				end

				if u141 == nil or u242 == u141 then
					u20 = nil
					u25 = false

					if v240 <= 0.01 or u242 then
						u21 = false
						setMeterVisible(false, s1)
					end

					return
				end
			end)
		end

		return
	end

	if v134 >= 1 then
		readyText.Visible = false
		readyFlash.BackgroundTransparency = 1
		u21 = false
		u25 = false
		fillClip.Size = UDim2.new(1, -6, 1, -6)

		local v143 = os.clock()

		if math.abs(v134 - n2) > 0.001 then
			n2 = v134
			n1 = v143
		elseif n1 <= 0 then
			n1 = v143
		end

		local v144 = comboBreakerConfig.MeterHideAfterNoUpdate or 3

		if v144 <= 0 or v144 > v143 - n1 then
			if u19 ~= true then
				u19 = true

				if u28 then
					u28:Cancel()
					u28 = nil
				end

				comboBreakerMeterGui.Enabled = true

				local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

				u28 = tweenService:Create(root, tweenInfo, { Position = v31 })
				u28:Play()
			end

			if not u24 then
				local t5: {[any]: any} = {}

				u24 = t5
				task.delay(v144, function()
					if u24 ~= t5 then
						return
					end

					if getMeterProgress() <= 0.01 then
						return
					end

					if os.clock() - n1 >= v144 then
						u24 = nil
						setMeterVisible(false, "Left")
					end
				end)

				return
			end
		else
			setMeterVisible(false, "Left")
		end

		return
	end

	u21 = false
	u25 = false
	fillClip.Size = UDim2.new(1, -6, v135, -6 * v135)

	if v134 > 0.01 then
		local v147 = os.clock()
		local u148: boolean = math.abs(v134 - n2) > 0.001

		if u148 then
			n2 = v134
			n1 = v147
		elseif n1 <= 0 then
			n1 = v147
		end

		local v149 = comboBreakerConfig.MeterHideAfterNoUpdate or 3

		if v149 <= 0 or v149 > v147 - n1 then
			if u19 ~= true then
				u19 = true

				if u28 then
					u28:Cancel()
					u28 = nil
				end

				comboBreakerMeterGui.Enabled = true

				local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

				u28 = tweenService:Create(root, tweenInfo, { Position = v31 })
				u28:Play()
			end

			if not not u148 or not u24 then
				local t6: {[any]: any} = {}

				u24 = t6
				task.delay(v149, function()
					if u24 ~= t6 then
						return
					end

					if getMeterProgress() <= 0.01 then
						return
					end

					if os.clock() - n1 >= v149 then
						u24 = nil
						setMeterVisible(false, "Left")
					end
				end)

				return
			end
		else
			setMeterVisible(false, "Left")
		end

		return
	end

	readyText.Visible = false
	readyFlash.BackgroundTransparency = 1
	u21 = false

	if u19 and not u20 then
		local t7: {[any]: any} = {}

		u20 = t7

		local u153: boolean = false
		local s2: string = "Left"

		task.delay(comboBreakerConfig.MeterLingerAfterEmpty or 0, function()
			if u20 ~= t7 then
				return
			end

			local v243 = getMeterProgress()
			local v244 = u17
			local u245

			if v244 then
				u245 = true

				if v244:GetAttribute("ComboBreakerWindowOpen") ~= true then
					u245 = v243 >= 1
				end
			else
				u245 = v243 >= 1
			end

			if u153 == nil or u245 == u153 then
				u20 = nil
				u25 = false

				if v243 <= 0.01 or u245 then
					u21 = false
					setMeterVisible(false, s2)
				end

				return
			end
		end)
	elseif not u19 then
		setMeterVisible(false)
	end
end
local function getCharacterCooldownKey(p13)
	if not p13 then
		return nil
	end

	local characterCHOSENVALUE = p13:FindFirstChild("CharacterCHOSENVALUE")

	if characterCHOSENVALUE and characterCHOSENVALUE:IsA("StringValue") and characterCHOSENVALUE.Value ~= "" then
		return characterCHOSENVALUE.Value
	end

	return p13.Name
end

u64 = function()
	local v157 = u17
	local comboBreakerCooldownCharacter: any = LocalPlayer:GetAttribute("ComboBreakerCooldownCharacter")
	local v159

	if not v157 then
		v159 = nil
	else
		local characterCHOSENVALUE = v157:FindFirstChild("CharacterCHOSENVALUE")

		v159 = if characterCHOSENVALUE and characterCHOSENVALUE:IsA("StringValue") and characterCHOSENVALUE.Value ~= "" then characterCHOSENVALUE.Value else v157.Name
	end

	if comboBreakerCooldownCharacter ~= v159 then
		return false
	end

	local comboBreakerCooldownUntil: any = LocalPlayer:GetAttribute("ComboBreakerCooldownUntil")
	local u162: boolean = false

	if typeof(comboBreakerCooldownUntil) == "number" then
		local v163 = os.clock()

		u162 = comboBreakerCooldownUntil > v163
	end

	return u162
end

local function storedMeterCanActivate(p14)
	if getMeterProgress() < 1 then
		return false
	end

	local comboBreakerRecentDamageUntil = p14:GetAttribute("ComboBreakerRecentDamageUntil")

	if typeof(comboBreakerRecentDamageUntil) == "number" then
		local v166: number = workspace:GetServerTimeNow()

		return comboBreakerRecentDamageUntil >= v166
	end

	return false
end
local function shouldShowPrompt()
	if comboBreakerConfig.Enabled == true and comboBreakerConfig.InputEnabled == true and comboBreakerConfig.PromptEnabled == true then
		local character = u17
		local u169

		if not character or not character.Parent then
			u169 = false
		else
			local menu: Instance = playerGui:FindFirstChild("Menu")
			local u170: boolean = false

			if menu ~= nil then
				u170 = menu:IsA("ScreenGui") and menu.Enabled == true
			end

			if u170 then
				u169 = false
			else
				local humanoid = character:FindFirstChildOfClass("Humanoid")

				u169 = if humanoid and not (humanoid.Health <= 0) then true else false
			end
		end

		if not u169 then
			return false
		end

		if u17 ~= nil and u17:GetAttribute("ComboBreakerUsed") == true or not not u64() or not not hasComboBreakerIgnore(character) or not hasActivationStatus(character) then
			return false
		end

		local u172: boolean = true

		if character:GetAttribute("ComboBreakerWindowOpen") == true then
			return u172
		end

		if getMeterProgress() < 1 then
			return false
		end

		local comboBreakerRecentDamageUntil = character:GetAttribute("ComboBreakerRecentDamageUntil")

		if typeof(comboBreakerRecentDamageUntil) == "number" then
			local v174: number = workspace:GetServerTimeNow()

			u172 = comboBreakerRecentDamageUntil >= v174

			return u172
		end

		return false
	end

	return false
end
local function setPromptVisible(p15)
	if p15 then
		if u17 and (not not u17:FindFirstChild("Iframe") or not not hasComboBreakerIgnore(u17)) then
			subtitle.Text = "IFRAME ACTIVE - WAIT"
		else
			subtitle.Text = getPromptText()
		end
	end

	if p15 == u18 then
		return
	end

	u18 = p15

	if u27 then
		u27:Cancel()
		u27 = nil
	end

	if p15 then
		comboBreakerPromptGui.Enabled = true
		canvasGroup.GroupTransparency = 1
		uiScale.Scale = 0.92

		local tweenInfo = TweenInfo.new(0.14, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

		u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 0 })

		local tweenInfo4 = TweenInfo.new(0.14, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local v178: Tween = tweenService:Create(uiScale, tweenInfo4, { Scale = 1 })

		u27:Play()
		v178:Play()

		return
	end

	local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

	u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
	u27:Play()
	u27.Completed:Connect(function()
		if not u18 then
			comboBreakerPromptGui.Enabled = false
		end
	end)
end
local function refreshPrompt()
	local v180 = shouldShowPrompt()

	setPromptVisible(v180)
	refreshMeter()
end
local function resetLocalComboBreakerMeter()
	local v181 = u17 or LocalPlayer.Character
	local v182 = getMeterProgress()
	local v183 = math.clamp(fillClip.Size.Y.Scale, 0, 1)
	local v184 = math.max(v182, v183)

	if v184 > 0 then
		local v185 = math.max(comboBreakerConfig.MeterPixelSegments or 12, 1)

		v184 = math.ceil(v184 * v185) / v185
	end

	if v181 then
		v181:SetAttribute("ComboBreakerWindowOpen", nil)
		v181:SetAttribute("ComboBreakerWindowExpiresAt", nil)
		v181:SetAttribute("ComboBreakerDamage", nil)
		v181:SetAttribute("ComboBreakerRecentDamageUntil", nil)
	end

	n1 = 0
	n2 = 0

	if u18 ~= false then
		u18 = false

		if u27 then
			u27:Cancel()
			u27 = nil
		end

		local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

		u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
		u27:Play()
		u27.Completed:Connect(function()
			if not u18 then
				comboBreakerPromptGui.Enabled = false
			end
		end)
	end

	v181 = comboBreakerMeterGui.Enabled or u19 or v184 > 0.01
	u20 = nil
	u24 = nil
	u25 = false
	u21 = false
	readyText.Visible = false
	readyFlash.BackgroundTransparency = 1
	u26 = v181

	if v181 then
		comboBreakerMeterGui.Enabled = true
		fillClip.Size = UDim2.new(1, -6, v184, v184 * -6)

		if u19 ~= true then
			u19 = true

			if u28 then
				u28:Cancel()
				u28 = nil
			end

			comboBreakerMeterGui.Enabled = true

			local tweenInfo = TweenInfo.new(comboBreakerConfig.MeterSlideTweenTime or 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

			u28 = tweenService:Create(root, tweenInfo, { Position = v31 })
			u28:Play()
		end

		local v188 = math.clamp(v184 * 0.75 + 0.45, 0.45, 1.2)

		task.delay(0.12, function()
			if not u26 then
				return
			end

			local tweenInfo = TweenInfo.new(v188, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v247: Tween = tweenService:Create(fillClip, tweenInfo, { Size = UDim2.new(1, -6, 0, 0) })

			v247:Play()
			v247.Completed:Connect(function()
				setMeterVisible(false, "Left")
				task.delay((comboBreakerConfig.MeterSlideTweenTime or 0.22) + 0.08, function()
					u26 = false
					u20 = nil
					u24 = nil
					u25 = false
					u21 = false
					readyText.Visible = false
					readyFlash.BackgroundTransparency = 1
					u19 = false

					if u28 then
						u28:Cancel()
						u28 = nil
					end

					root.Position = uDim2
					comboBreakerMeterGui.Enabled = false

					local v258 = shouldShowPrompt()

					setPromptVisible(v258)
					refreshMeter()
				end)
			end)
		end)
	else
		u26 = false
		u20 = nil
		u24 = nil
		u25 = false
		u21 = false
		readyText.Visible = false
		readyFlash.BackgroundTransparency = 1
		u19 = false

		if u28 then
			u28:Cancel()
			u28 = nil
		end

		root.Position = uDim2
		comboBreakerMeterGui.Enabled = false
	end

	task.delay(1.7, function()
		u26 = false

		local v248 = shouldShowPrompt()

		setPromptVisible(v248)
		refreshMeter()
	end)
end
local function requestComboBreakerMeterReset()
	resetLocalComboBreakerMeter()
	comboBreakerResetRemote:FireServer()
end
local function submitComboBreaker()
	if comboBreakerConfig.Enabled == true and comboBreakerConfig.InputEnabled == true then
		if not shouldShowPrompt() then
			if u18 ~= false then
				u18 = false

				if u27 then
					u27:Cancel()
					u27 = nil
				end

				local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
				u27:Play()
				u27.Completed:Connect(function()
					if not u18 then
						comboBreakerPromptGui.Enabled = false
					end
				end)
			end

			return false
		end

		if u17 and u17:FindFirstChild("Iframe") then
			if u18 ~= false then
				u18 = false

				if u27 then
					u27:Cancel()
					u27 = nil
				end

				local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
				u27:Play()
				u27.Completed:Connect(function()
					if not u18 then
						comboBreakerPromptGui.Enabled = false
					end
				end)
			end

			return false
		end

		if u16 then
			return false
		end

		u16 = true
		comboBreakerRemote:FireServer()
		task.delay(comboBreakerConfig.RemoteRateLimit, function()
			u16 = false
		end)

		return true
	end

	return false
end
local function isTouchActivationInput(input)
	return input ~= nil and input.UserInputType == Enum.UserInputType.Touch
end
local function formatBindingForLetter(p20)
	if typeof(p20) == "string" and p20 ~= "" then
		local t8: {[any]: any} = {
			MouseButton1 = "M1",
			MouseButton2 = "M2",
			MouseButton3 = "M3",
			LeftShift = "Shift",
			RightShift = "Shift",
			LeftControl = "Ctrl",
			RightControl = "Ctrl",
			LeftAlt = "Alt",
			RightAlt = "Alt",
			ButtonA = "A",
			ButtonB = "B",
			ButtonX = "X",
			ButtonY = "Y",
			ButtonL1 = "L1",
			ButtonR1 = "R1",
			ButtonL2 = "L2",
			ButtonR2 = "R2",
			ButtonL3 = "L3",
			ButtonR3 = "R3",
			DPadUp = "↑",
			DPadDown = "↓",
			DPadLeft = "←",
			DPadRight = "→"
		}

		return t8[p20] or p20
	end

	return nil
end
local function updateBreakerLetterFromCustomBinding()
	local v194 = controlsRuntime.GetBinding(LocalPlayer, comboBreakerConfig.ActionName, "Keyboard")
	local v195 = controlsRuntime.GetBinding(LocalPlayer, comboBreakerConfig.ActionName, "Controller")
	local v196 = nil

	if v194 and v194 ~= "" then
		v196 = v194
	elseif v195 and v195 ~= "" then
		v196 = v195
	end

	v195 = formatBindingForLetter(v196)

	if not v195 then
		return
	end

	local moveset: Instance = playerGui:FindFirstChild("Moveset")

	v194 = moveset

	if v194 then
		v194 = moveset:FindFirstChild("Frame")
	end

	local hold = v194 and v194:FindFirstChild("Hold")

	v194 = hold

	if v194 then
		v194 = hold:FindFirstChild("BreakerLetter")
	end

	if v194 and v194:IsA("TextLabel") then
		v194.Text = v195
	end
end
local function connectCustomBreakerButton()
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local frame: Instance = moveset and moveset:FindFirstChild("Frame")
	local v201: Instance = frame

	if v201 then
		v201 = frame:FindFirstChild("Hold")
	end

	local breakerButton: Instance = v201 and v201:FindFirstChild("BreakerButton")

	if not breakerButton or not breakerButton:IsA("GuiButton") then
		return
	end

	updateBreakerLetterFromCustomBinding()

	if breakerButton:GetAttribute("ComboBreakerConnected") == true then
		return
	end

	breakerButton:SetAttribute("ComboBreakerConnected", true)
	breakerButton.Active = true
	breakerButton.Activated:Connect(function()
		if shouldShowPrompt() then
			submitComboBreaker()
		end
	end)
	breakerButton.InputBegan:Connect(function(input)
		if (input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1) and shouldShowPrompt() then
			submitComboBreaker()
		end
	end)
end

panel.Activated:Connect(function(inputObject: InputObject)
	if u18 and shouldShowPrompt() then
		submitComboBreaker()
	end
end)
panel.InputBegan:Connect(function(input: InputObject)
	if (input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1) and u18 and shouldShowPrompt() then
		submitComboBreaker()
	end
end)
contextActionService:BindAction(comboBreakerConfig.ActionName, function(p17, p18, input)
	if p17 ~= comboBreakerConfig.ActionName then
		return Enum.ContextActionResult.Pass
	end

	if (input == nil or input.UserInputType ~= Enum.UserInputType.Touch) and not controlsRuntime.InputMatches(LocalPlayer, input, comboBreakerConfig.ActionName) then
		return Enum.ContextActionResult.Pass
	end

	if p18 ~= Enum.UserInputState.Begin then
		return shouldShowPrompt() and Enum.ContextActionResult.Sink or Enum.ContextActionResult.Pass
	end

	if submitComboBreaker() then
		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end, false, Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three, Enum.KeyCode.Four, Enum.KeyCode.Five, Enum.KeyCode.Six, Enum.KeyCode.Seven, Enum.KeyCode.Eight, Enum.KeyCode.Nine, Enum.KeyCode.Zero, Enum.KeyCode.Q, Enum.KeyCode.E, Enum.KeyCode.R, Enum.KeyCode.T, Enum.KeyCode.Y, Enum.KeyCode.U, Enum.KeyCode.F, Enum.KeyCode.G, Enum.KeyCode.H, Enum.KeyCode.J, Enum.KeyCode.K, Enum.KeyCode.Z, Enum.KeyCode.X, Enum.KeyCode.C, Enum.KeyCode.V, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonX, Enum.KeyCode.ButtonY, Enum.KeyCode.ButtonR1, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR2, Enum.KeyCode.ButtonL2, Enum.KeyCode.ButtonR3, Enum.KeyCode.ButtonL3, Enum.KeyCode.DPadUp, Enum.KeyCode.DPadDown, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight, Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2, Enum.UserInputType.MouseButton3)
playerGui.ChildAdded:Connect(function(p24: Instance)
	if p24.Name == "Moveset" then
		task.delay(0.3, function()
			updateBreakerLetterFromCustomBinding()
			connectCustomBreakerButton()
		end)
	end
end)
updateBreakerLetterFromCustomBinding()
connectCustomBreakerButton()

local t1: {[any]: any} = {}

local function disconnectCharacterConnections()
	for i = 1, #t1 do
		t1[i]:Disconnect()
	end

	t1 = {}
end
local function watchCharacter(character)
	disconnectCharacterConnections()
	u17 = character
	n1 = 0
	n2 = 0
	u24 = nil

	local v211 = shouldShowPrompt()

	setPromptVisible(v211)
	refreshMeter()
	v211 = t1

	local v212 = character:GetAttributeChangedSignal("ComboBreakerWindowOpen")

	table.insert(v211, v212:Connect(refreshPrompt))
	v211 = t1
	v212 = character:GetAttributeChangedSignal("ComboBreakerWindowExpiresAt")
	table.insert(v211, v212:Connect(refreshPrompt))
	v211 = t1
	v212 = character:GetAttributeChangedSignal("ComboBreakerDamage")
	table.insert(v211, v212:Connect(refreshPrompt))
	v211 = t1
	v212 = character:GetAttributeChangedSignal("ComboBreakerRecentDamageUntil")
	table.insert(v211, v212:Connect(refreshPrompt))
	v211 = t1
	v212 = character:GetAttributeChangedSignal("ComboBreakerUsed")
	table.insert(v211, v212:Connect(refreshPrompt))

	local humanoid = character:FindFirstChildOfClass("Humanoid")

	if humanoid then
		table.insert(t1, humanoid.HealthChanged:Connect(function(p26)
			if p26 <= 0 then
				if u18 ~= false then
					u18 = false

					if u27 then
						u27:Cancel()
						u27 = nil
					end

					local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
					u27:Play()
					u27.Completed:Connect(function()
						if not u18 then
							comboBreakerPromptGui.Enabled = false
						end
					end)
				end

				u20 = nil
				u24 = nil
				u25 = false
				u21 = false
				readyText.Visible = false
				readyFlash.BackgroundTransparency = 1
				u19 = false

				if u28 then
					u28:Cancel()
					u28 = nil
				end

				root.Position = uDim2
				comboBreakerMeterGui.Enabled = false

				return
			end

			local v252 = shouldShowPrompt()

			setPromptVisible(v252)
			refreshMeter()
		end))
		table.insert(t1, humanoid.Died:Connect(function()
			if u18 ~= false then
				u18 = false

				if u27 then
					u27:Cancel()
					u27 = nil
				end

				local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
				u27:Play()
				u27.Completed:Connect(function()
					if not u18 then
						comboBreakerPromptGui.Enabled = false
					end
				end)
			end

			u20 = nil
			u24 = nil
			u25 = false
			u21 = false
			readyText.Visible = false
			readyFlash.BackgroundTransparency = 1
			u19 = false

			if u28 then
				u28:Cancel()
				u28 = nil
			end

			root.Position = uDim2
			comboBreakerMeterGui.Enabled = false
		end))

		local v214: {[any]: any} = t1
		local v215 = humanoid:GetPropertyChangedSignal("MaxHealth")

		table.insert(v214, v215:Connect(refreshPrompt))
	end

	table.insert(t1, character.ChildAdded:Connect(function(p27)
		if p27.Name == "Iframe" or table.find(comboBreakerConfig.ActivationStatusNames, p27.Name) then
			local v255 = shouldShowPrompt()

			setPromptVisible(v255)
			refreshMeter()
		end
	end))
	table.insert(t1, character.ChildRemoved:Connect(function(p28)
		if p28.Name == "Iframe" or table.find(comboBreakerConfig.ActivationStatusNames, p28.Name) then
			local v257 = shouldShowPrompt()

			setPromptVisible(v257)
			refreshMeter()
		end
	end))
end

if LocalPlayer.Character then
	watchCharacter(LocalPlayer.Character)
end

LocalPlayer.CharacterAdded:Connect(watchCharacter)
LocalPlayer:GetAttributeChangedSignal("ComboBreakerCooldownUntil"):Connect(refreshPrompt)
LocalPlayer:GetAttributeChangedSignal("ComboBreakerCooldownCharacter"):Connect(refreshPrompt)

local function refreshForMenuState()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local u217: boolean = false

	if menu ~= nil then
		u217 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	if u217 then
		if u18 ~= false then
			u18 = false

			if u27 then
				u27:Cancel()
				u27 = nil
			end

			local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
			u27:Play()
			u27.Completed:Connect(function()
				if not u18 then
					comboBreakerPromptGui.Enabled = false
				end
			end)
		end

		u20 = nil
		u24 = nil
		u25 = false
		u21 = false
		readyText.Visible = false
		readyFlash.BackgroundTransparency = 1
		u19 = false

		if u28 then
			u28:Cancel()
			u28 = nil
		end

		root.Position = uDim2
		comboBreakerMeterGui.Enabled = false

		return
	end

	local v219 = shouldShowPrompt()

	setPromptVisible(v219)
	refreshMeter()
end

local menu: Instance = playerGui:FindFirstChild("Menu")

if menu and menu:IsA("ScreenGui") then
	menu:GetPropertyChangedSignal("Enabled"):Connect(refreshForMenuState)
end

playerGui.ChildAdded:Connect(function(p29: Instance)
	if p29.Name == "Menu" and p29:IsA("ScreenGui") then
		p29:GetPropertyChangedSignal("Enabled"):Connect(refreshForMenuState)

		local menu2: Instance = playerGui:FindFirstChild("Menu")
		local u222: boolean = false

		if menu2 ~= nil then
			u222 = menu2:IsA("ScreenGui") and menu2.Enabled == true
		end

		if u222 then
			if u18 ~= false then
				u18 = false

				if u27 then
					u27:Cancel()
					u27 = nil
				end

				local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
				u27:Play()
				u27.Completed:Connect(function()
					if not u18 then
						comboBreakerPromptGui.Enabled = false
					end
				end)
			end

			u20 = nil
			u24 = nil
			u25 = false
			u21 = false
			readyText.Visible = false
			readyFlash.BackgroundTransparency = 1
			u19 = false

			if u28 then
				u28:Cancel()
				u28 = nil
			end

			root.Position = uDim2
			comboBreakerMeterGui.Enabled = false

			return
		end

		local v224 = shouldShowPrompt()

		setPromptVisible(v224)
		refreshMeter()

		return
	end
end)
userInputService.LastInputTypeChanged:Connect(function()
	local v225 = shouldShowPrompt()

	setPromptVisible(v225)
	refreshMeter()
end)

local function playPromptPulse()
	uiStroke2.Transparency = 0

	local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

	tweenService:Create(uiStroke2, tweenInfo, { Transparency = 0.15 }):Play()

	local uiScaleScale: number = uiScale.Scale

	uiScale.Scale = 1.06

	local tweenInfo5 = TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	tweenService:Create(uiScale, tweenInfo5, { Scale = uiScaleScale }):Play()
end

comboBreakerResetRemote.OnClientEvent:Connect(function(p30)
	if p30 == "Reset" and not u26 then
		resetLocalComboBreakerMeter()
	end
end)
comboBreakerResetBindable.Event:Connect(requestComboBreakerMeterReset)
_G.ResetComboBreakerMeter = requestComboBreakerMeterReset
comboBreakerRemote.OnClientEvent:Connect(function(p31, _)
	if p31 == "Ready" then
		local v232 = shouldShowPrompt()

		setPromptVisible(v232)
		refreshMeter()
		playPromptPulse()
	elseif p31 == "Activated" then
		playPromptPulse()

		if u18 ~= false then
			u18 = false

			if u27 then
				u27:Cancel()
				u27 = nil
			end

			local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			u27 = tweenService:Create(canvasGroup, tweenInfo, { GroupTransparency = 1 })
			u27:Play()
			u27.Completed:Connect(function()
				if not u18 then
					comboBreakerPromptGui.Enabled = false
				end
			end)
		end

		u20 = nil
		u25 = false
		u21 = false
		readyText.Visible = false
		readyFlash.BackgroundTransparency = 1
		setMeterVisible(false, "Left")
	end
end)
task.spawn(function()
	while true do
		local v234 = shouldShowPrompt()

		setPromptVisible(v234)
		refreshMeter()
		task.wait(0.15)
	end
end)
