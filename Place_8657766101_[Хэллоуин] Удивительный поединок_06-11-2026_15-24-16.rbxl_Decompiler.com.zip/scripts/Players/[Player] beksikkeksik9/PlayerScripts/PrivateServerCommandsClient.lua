-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local userInputService: UserInputService = game:GetService("UserInputService")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local privateServerCommandsList: Instance = replicatedStorage:WaitForChild("PrivateServerCommandsList")
local uDim2 = UDim2.new(0, 560, 0, 430)
local uDim22 = UDim2.new(0, 520, 0, 390)
local u12 = nil
local n1 = 0

local function getAccessInfo()
	if u12 and os.clock() - n1 < 10 then
		return u12
	end

	local ok, result = pcall(function()
		return privateServerCommandsList:InvokeServer()
	end)

	if ok and typeof(result) == "table" then
		u12 = result
	else
		u12 = {
			CanOpen = false,
			Role = "NONE",
			Commands = {}
		}
	end

	n1 = os.clock()

	return u12
end

local privateServerCommandsGui: ScreenGui = Instance.new("ScreenGui")

privateServerCommandsGui.Name = "PrivateServerCommandsGui"
privateServerCommandsGui.ResetOnSpawn = false
privateServerCommandsGui.IgnoreGuiInset = true
privateServerCommandsGui.DisplayOrder = 74
privateServerCommandsGui.Enabled = false
privateServerCommandsGui.Parent = playerGui

local dim: Frame = Instance.new("Frame")

dim.Name = "Dim"
dim.Size = UDim2.new(1, 0, 1, 0)
dim.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
dim.BackgroundTransparency = 0.45
dim.BorderSizePixel = 0
dim.Parent = privateServerCommandsGui

local main: Frame = Instance.new("Frame")

main.Name = "Main"
main.AnchorPoint = Vector2.new(0.5, 0.5)
main.Position = UDim2.new(0.5, 0, 0.5, 0)
main.Size = uDim22
main.BackgroundColor3 = Color3.fromRGB(18, 18, 24)
main.BorderSizePixel = 0
main.Parent = dim

local uiCorner: UICorner = Instance.new("UICorner")

uiCorner.CornerRadius = UDim.new(0, 12)
uiCorner.Parent = main

local uiStroke: UIStroke = Instance.new("UIStroke")

uiStroke.Color = Color3.fromRGB(120, 100, 255)
uiStroke.Thickness = 2
uiStroke.Transparency = 0.18
uiStroke.Parent = main

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.new(0, 18, 0, 10)
title.Size = UDim2.new(1, -70, 0, 40)
title.Font = Enum.Font.Arcade
title.Text = "PRIVATE SERVER COMMANDS"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextScaled = true
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = main

local closeButton: TextButton = Instance.new("TextButton")

closeButton.Name = "CloseButton"
closeButton.AnchorPoint = Vector2.new(1, 0)
closeButton.Position = UDim2.new(1, -12, 0, 12)
closeButton.Size = UDim2.new(0, 38, 0, 34)
closeButton.BackgroundColor3 = Color3.fromRGB(50, 35, 60)
closeButton.BorderSizePixel = 0
closeButton.Font = Enum.Font.Arcade
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 210, 210)
closeButton.TextScaled = true
closeButton.Parent = main

local uiCorner2: UICorner = Instance.new("UICorner")

uiCorner2.CornerRadius = UDim.new(0, 8)
uiCorner2.Parent = closeButton

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.new(0, 18, 0, 52)
subtitle.Size = UDim2.new(1, -36, 0, 26)
subtitle.Font = Enum.Font.GothamBold
subtitle.Text = "Commands you can use in this server"
subtitle.TextColor3 = Color3.fromRGB(190, 190, 215)
subtitle.TextSize = 16
subtitle.TextXAlignment = Enum.TextXAlignment.Left
subtitle.Parent = main

local commandList: ScrollingFrame = Instance.new("ScrollingFrame")

commandList.Name = "CommandList"
commandList.Position = UDim2.new(0, 18, 0, 88)
commandList.Size = UDim2.new(1, -36, 1, -106)
commandList.BackgroundColor3 = Color3.fromRGB(10, 10, 14)
commandList.BackgroundTransparency = 0.15
commandList.BorderSizePixel = 0
commandList.ScrollBarThickness = 6
commandList.CanvasSize = UDim2.new(0, 0, 0, 0)
commandList.AutomaticCanvasSize = Enum.AutomaticSize.Y
commandList.Parent = main

local uiCorner3: UICorner = Instance.new("UICorner")

uiCorner3.CornerRadius = UDim.new(0, 8)
uiCorner3.Parent = commandList

local uiListLayout: UIListLayout = Instance.new("UIListLayout")

uiListLayout.Padding = UDim.new(0, 8)
uiListLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiListLayout.Parent = commandList

local uiPadding: UIPadding = Instance.new("UIPadding")

uiPadding.PaddingTop = UDim.new(0, 10)
uiPadding.PaddingBottom = UDim.new(0, 10)
uiPadding.PaddingLeft = UDim.new(0, 10)
uiPadding.PaddingRight = UDim.new(0, 10)
uiPadding.Parent = commandList

local function clearList()
	local children = commandList:GetChildren()

	for i = 1, #children do
		local v39 = children[i]

		if v39:IsA("Frame") or v39:IsA("TextLabel") then
			v39.Parent = nil
		end
	end
end
local function addMessage(text, p2)
	local message: TextLabel = Instance.new("TextLabel")

	message.Name = "Message"
	message.BackgroundTransparency = 1
	message.Size = UDim2.new(1, -6, 0, 70)
	message.Font = Enum.Font.GothamBold
	message.Text = text
	message.TextColor3 = p2 or Color3.fromRGB(230, 230, 240)
	message.TextSize = 18
	message.TextWrapped = true
	message.TextXAlignment = Enum.TextXAlignment.Center
	message.TextYAlignment = Enum.TextYAlignment.Center
	message.Parent = commandList
end
local function addCommandRow(p3, layoutOrder)
	local commandRow: Frame = Instance.new("Frame")

	commandRow.Name = "CommandRow"
	commandRow.BackgroundColor3 = layoutOrder % 2 == 0 and Color3.fromRGB(30, 30, 40) or Color3.fromRGB(25, 25, 34)
	commandRow.BorderSizePixel = 0
	commandRow.Size = UDim2.new(1, -6, 0, 68)
	commandRow.LayoutOrder = layoutOrder
	commandRow.Parent = commandList

	local uiCorner4: UICorner = Instance.new("UICorner")

	uiCorner4.CornerRadius = UDim.new(0, 8)
	uiCorner4.Parent = commandRow

	local commandName: TextLabel = Instance.new("TextLabel")

	commandName.Name = "CommandName"
	commandName.BackgroundTransparency = 1
	commandName.Position = UDim2.new(0, 12, 0, 7)
	commandName.Size = UDim2.new(1, -24, 0, 24)
	commandName.Font = Enum.Font.Arcade
	commandName.Text = tostring(p3.Name or "")
	commandName.TextColor3 = Color3.fromRGB(135, 210, 255)
	commandName.TextSize = 20
	commandName.TextXAlignment = Enum.TextXAlignment.Left
	commandName.Parent = commandRow

	local description: TextLabel = Instance.new("TextLabel")

	description.Name = "Description"
	description.BackgroundTransparency = 1
	description.Position = UDim2.new(0, 12, 0, 34)
	description.Size = UDim2.new(1, -24, 0, 26)
	description.Font = Enum.Font.Gotham
	description.Text = tostring(p3.Description or "")
	description.TextColor3 = Color3.fromRGB(220, 220, 230)
	description.TextSize = 14
	description.TextWrapped = true
	description.TextXAlignment = Enum.TextXAlignment.Left
	description.TextYAlignment = Enum.TextYAlignment.Top
	description.Parent = commandRow
end
local function getBindingName()
	local v49 = controlsRuntime.GetBinding(LocalPlayer, "PrivateServerCommands", "Keyboard")

	if v49 and v49 ~= "" then
		return v49
	end

	return "P"
end
local function loadCommands()
	clearList()
	subtitle.Text = "Loading commands..."
	addMessage("Loading commands...", Color3.fromRGB(210, 210, 230))
	u12 = nil

	local v50 = getAccessInfo()

	clearList()

	if typeof(v50) ~= "table" then
		subtitle.Text = "Could not load commands"
		addMessage("Could not load the private server command list.", Color3.fromRGB(255, 150, 150))

		return
	end

	if v50.CanOpen == true then
		local commands = v50.Commands

		if typeof(commands) == "table" and #commands ~= 0 then
			local v52 = controlsRuntime.GetBinding(LocalPlayer, "PrivateServerCommands", "Keyboard")

			subtitle.Text = tostring(v50.Role or "") .. " commands - Press " .. (if v52 and v52 ~= "" then v52 else "P") .. " to close"

			for i = 1, #commands do
				addCommandRow(commands[i], i)
			end

			return
		end

		subtitle.Text = "No commands available"
		addMessage("No commands are available for your current role.", Color3.fromRGB(255, 210, 150))

		return
	end

	subtitle.Text = "No private commands available"
	addMessage("You do not have private server commands in this server.", Color3.fromRGB(255, 210, 150))
end
local function openGui()
	privateServerCommandsGui.Enabled = true
	main.Size = uDim22

	local tweenInfo = TweenInfo.new(0.14, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	tweenService:Create(main, tweenInfo, { Size = uDim2 }):Play()
	loadCommands()
end
local function toggleGui()
	if privateServerCommandsGui.Enabled then
		privateServerCommandsGui.Enabled = false

		return
	end

	openGui()
end

closeButton.Activated:Connect(function()
	privateServerCommandsGui.Enabled = false
end)
dim.InputBegan:Connect(function(input: InputObject)
	if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) and (input.Position.X < main.AbsolutePosition.X or input.Position.X > main.AbsolutePosition.X + main.AbsoluteSize.X or input.Position.Y < main.AbsolutePosition.Y or input.Position.Y > main.AbsolutePosition.Y + main.AbsoluteSize.Y) then
		privateServerCommandsGui.Enabled = false
	end
end)
userInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if input.KeyCode == Enum.KeyCode.Escape and privateServerCommandsGui.Enabled then
		privateServerCommandsGui.Enabled = false

		return
	end

	if gameProcessedEvent then
		return
	end

	local v58 = getAccessInfo()
	local v59 = v58 and v58.Role or "NONE"

	v58 = false

	if v59 == "OWNER" or v59 == "PS_OWNER" then
		v58 = controlsRuntime.InputMatches(LocalPlayer, input, "PrivateServerCommands")
	end

	if not v58 then
		return
	end

	if privateServerCommandsGui.Enabled then
		privateServerCommandsGui.Enabled = false

		return
	end

	openGui()
end)
