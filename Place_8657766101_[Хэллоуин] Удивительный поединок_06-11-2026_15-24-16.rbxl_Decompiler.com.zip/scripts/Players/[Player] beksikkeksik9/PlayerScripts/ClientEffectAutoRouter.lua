-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local clientEffectModules: Instance = game:GetService("ReplicatedStorage"):WaitForChild("System"):WaitForChild("ClientEffectModules")
local t1: {[any]: any} = {}

local function getRelativePath(p1)
	return p1:GetFullName():gsub("^ReplicatedStorage%.System%.ClientEffectModules%.", "")
end
local function getModuleByPath(p2)
	local v8: Instance = clientEffectModules

	for iterValue in string.gmatch(p2, "[^%.]+") do
		v8 = v8 and v8:FindFirstChild(iterValue)
	end

	if v8 and v8:IsA("ModuleScript") then
		return v8
	end

	return nil
end

local t2: {[any]: any} = { ["OmniMan.Counter"] = true }

getModuleByPath = function(p3)
	if t1[p3] then
		return
	end

	local replacedText = p3:GetFullName():gsub("^ReplicatedStorage%.System%.ClientEffectModules%.", "")

	if t2[replacedText] then
		t1[p3] = true

		return
	end

	t1[p3] = true

	local ok, result = pcall(require, p3)

	if not ok then
		warn("[ClientEffectAutoRouter] Legacy module load failed:", replacedText, result)
	end
end
task.spawn(function()
	local t3: {[any]: any} = {}

	for iterFirst, iterSecond in clientEffectModules:GetDescendants() do
		if iterSecond:IsA("ModuleScript") then
			table.insert(t3, iterSecond)
		end
	end

	table.sort(t3, function(p4, p5)
		local replacedText = p4:GetFullName():gsub("^ReplicatedStorage%.System%.ClientEffectModules%.", "")
		local replacedText2 = p5:GetFullName():gsub("^ReplicatedStorage%.System%.ClientEffectModules%.", "")

		return replacedText < replacedText2
	end)

	for i = 1, #t3 do
		local v18 = t3[i]

		if not t1[v18] then
			local replacedText = v18:GetFullName():gsub("^ReplicatedStorage%.System%.ClientEffectModules%.", "")

			if t2[replacedText] then
				t1[v18] = true
			else
				t1[v18] = true

				local ok, result = pcall(require, v18)

				if not ok then
					warn("[ClientEffectAutoRouter] Legacy module load failed:", replacedText, result)
				end
			end
		end

		if i % 20 == 0 then
			task.wait()
		end
	end
end)

return nil
