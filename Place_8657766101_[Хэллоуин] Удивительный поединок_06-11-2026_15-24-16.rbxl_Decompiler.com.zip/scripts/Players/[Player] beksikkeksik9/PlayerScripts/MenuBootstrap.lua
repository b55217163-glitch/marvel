-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local menuRemotes = replicatedStorage:FindFirstChild("MenuRemotes")

if menuRemotes then
	menuRemotes = replicatedStorage.MenuRemotes:FindFirstChild("MenuProtectionState")
end

local object = setmetatable({}, { __mode = "k" })
local connection = nil
local connection2 = nil
local connection3 = nil

local function isInActiveDuelMode()
	local u23: boolean = true

	if workspace:GetAttribute("DUEL_MODE") ~= true then
		u23 = LocalPlayer:GetAttribute("IN_DUEL") == true
	end

	return u23
end
local function getCharacterParts(p1)
	local t1: {[any]: any} = {}

	for _, v in ipairs(p1:GetDescendants()) do
		if v:IsA("BasePart") then
			table.insert(t1, v)
		end
	end

	return t1
end

local u12 = nil

local function freezeCharacterForMenu(p2)
	if menuRemotes and menuRemotes:IsA("RemoteEvent") then
		menuRemotes:FireServer(true)
	end

	if not p2 then
		return
	end

	local humanoidRootPart = p2:FindFirstChild("HumanoidRootPart")

	if not humanoidRootPart or not humanoidRootPart:IsA("BasePart") then
		return
	end

	if object[p2] then
		humanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)

		return
	end

	local t2: {[any]: any} = {
		AnchoredParts = setmetatable({}, { __mode = "k" })
	}
	local v31 = getCharacterParts(p2)

	for _, v in ipairs(v31) do
		t2.AnchoredParts[v] = v.Anchored
		v.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	end

	humanoidRootPart.Anchored = true
	humanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	u12()
	object[p2] = t2
end

u12 = function()
	for k, v in pairs(object) do
		if not k or not k:IsDescendantOf(game) then
			object[k] = nil
		elseif v and v.AnchoredParts then
			for iterKey in pairs(v.AnchoredParts) do
				if not iterKey or not iterKey:IsDescendantOf(game) then
					v.AnchoredParts[iterKey] = nil
				end
			end
		end
	end
end

local function unfreezeCharacterFromMenu(p3)
	if menuRemotes and menuRemotes:IsA("RemoteEvent") then
		menuRemotes:FireServer(false)
	end

	if not p3 then
		u12()

		return
	end

	local v38 = object[p3]

	if not v38 then
		return
	end

	for k, v in pairs(v38.AnchoredParts) do
		if k and k.Parent then
			k.Anchored = v
		end
	end

	object[p3] = nil
end
local function isMenuActuallyOpen(p4)
	if not p4 or not p4.Enabled then
		return false
	end

	local frame = p4:FindFirstChild("Frame")

	if frame and frame:IsA("GuiObject") and frame.Visible == false then
		return false
	end

	return true
end
local function updateMenuFreeze(p5)
	u12()

	local Character: Model = LocalPlayer.Character
	local u45

	if not p5 or not p5.Enabled then
		u45 = false
	else
		local frame = p5:FindFirstChild("Frame")

		u45 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
	end

	if u45 then
		local u47: boolean = true

		if workspace:GetAttribute("DUEL_MODE") ~= true then
			u47 = LocalPlayer:GetAttribute("IN_DUEL") == true
		end

		if not u47 then
			freezeCharacterForMenu(Character)

			return
		end

		unfreezeCharacterFromMenu(Character)

		return
	end

	unfreezeCharacterFromMenu(Character)
end
local function watchMenuEnabled(p6)
	if connection then
		connection:Disconnect()
		connection = nil
	end

	if connection2 then
		connection2:Disconnect()
		connection2 = nil
	end

	if connection3 then
		connection3:Disconnect()
		connection3 = nil
	end

	if not p6 then
		return
	end

	connection = p6:GetPropertyChangedSignal("Enabled"):Connect(function()
		local v88 = p6

		u12()

		local Character: Model = LocalPlayer.Character
		local u90

		if not v88 or not v88.Enabled then
			u90 = false
		else
			local frame = v88:FindFirstChild("Frame")

			u90 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
		end

		if u90 then
			local u92: boolean = true

			if workspace:GetAttribute("DUEL_MODE") ~= true then
				u92 = LocalPlayer:GetAttribute("IN_DUEL") == true
			end

			if not u92 then
				freezeCharacterForMenu(Character)

				return
			end

			unfreezeCharacterFromMenu(Character)

			return
		end

		unfreezeCharacterFromMenu(Character)
	end)
	connection2 = LocalPlayer:GetAttributeChangedSignal("IN_DUEL"):Connect(function()
		local v93 = p6

		u12()

		local Character: Model = LocalPlayer.Character
		local u95

		if not v93 or not v93.Enabled then
			u95 = false
		else
			local frame = v93:FindFirstChild("Frame")

			u95 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
		end

		if u95 then
			local u97: boolean = true

			if workspace:GetAttribute("DUEL_MODE") ~= true then
				u97 = LocalPlayer:GetAttribute("IN_DUEL") == true
			end

			if not u97 then
				freezeCharacterForMenu(Character)

				return
			end

			unfreezeCharacterFromMenu(Character)

			return
		end

		unfreezeCharacterFromMenu(Character)
	end)
	connection3 = workspace:GetAttributeChangedSignal("DUEL_MODE"):Connect(function()
		local v98 = p6

		u12()

		local Character: Model = LocalPlayer.Character
		local u100

		if not v98 or not v98.Enabled then
			u100 = false
		else
			local frame = v98:FindFirstChild("Frame")

			u100 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
		end

		if u100 then
			local u102: boolean = true

			if workspace:GetAttribute("DUEL_MODE") ~= true then
				u102 = LocalPlayer:GetAttribute("IN_DUEL") == true
			end

			if not u102 then
				freezeCharacterForMenu(Character)

				return
			end

			unfreezeCharacterFromMenu(Character)

			return
		end

		unfreezeCharacterFromMenu(Character)
	end)
	u12()

	local Character: Model = LocalPlayer.Character
	local u50

	if not p6 or not p6.Enabled then
		u50 = false
	else
		local frame = p6:FindFirstChild("Frame")

		u50 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
	end

	if u50 then
		local u52: boolean = true

		if workspace:GetAttribute("DUEL_MODE") ~= true then
			u52 = LocalPlayer:GetAttribute("IN_DUEL") == true
		end

		if not u52 then
			freezeCharacterForMenu(Character)

			return
		end

		unfreezeCharacterFromMenu(Character)

		return
	end

	unfreezeCharacterFromMenu(Character)
end
local function ensureMenu()
	local playerGui

	repeat
		task.wait()
		playerGui = LocalPlayer:FindFirstChild("PlayerGui")
	until playerGui

	local menu = playerGui:FindFirstChild("Menu")

	if not menu then
		for _ = 1, 20 do
			task.wait(0.1)
			menu = playerGui:FindFirstChild("Menu")

			if menu then
				break
			end
		end
	end

	if menu then
		if not menu:FindFirstChild("UsingSkin") then
			local usingSkin: BoolValue = Instance.new("BoolValue")

			usingSkin.Name = "UsingSkin"
			usingSkin.Value = false
			usingSkin.Parent = menu
		end

		if not menu:FindFirstChild("Changing") then
			local changing: BoolValue = Instance.new("BoolValue")

			changing.Name = "Changing"
			changing.Value = false
			changing.Parent = menu
		end
	end

	return menu
end
local function getGlobalPivot()
	local fakeChars: Instance = workspace:FindFirstChild("FakeChars")
	local fakeHumanoidRootPart: Instance = fakeChars and fakeChars:FindFirstChild("FakeHumanoidRootPart")

	if fakeHumanoidRootPart and fakeHumanoidRootPart:IsA("BasePart") then
		return fakeHumanoidRootPart
	end

	local parent = workspace:FindFirstChild("FakeChars") or Instance.new("Folder", workspace)

	parent.Name = "FakeChars"

	local v61 = parent:FindFirstChild("FakeHumanoidRootPart") or Instance.new("Part")

	v61.Name = "FakeHumanoidRootPart"
	v61.Anchored = true
	v61.CanCollide = false
	v61.CanQuery = false
	v61.Transparency = 1
	v61.Size = Vector3.new(2, 2, 2)
	v61.CFrame = CFrame.new(0, 4, 0)
	v61.Parent = parent

	return v61
end
local function openMenu(p7)
	local Character
	local u64
	local frame
	local v66
	local u67
	local duel_mode
	local in_duel
	local v70
	local CurrentCamera
	local cFrame
	local menuMusic
	local v74
	local v75
	local tweenInfo
	local t3
	local v78

	if not p7 then
	else
		p7.Enabled = true
		watchMenuEnabled(p7)
		u12()
		Character = LocalPlayer.Character

		if not p7 or not p7.Enabled then
			u64 = false
		else
			frame = p7:FindFirstChild("Frame")
			v66 = frame and frame:IsA("GuiObject")
			u64 = if v66 and frame.Visible == false then false else true
		end

		if u64 then
			u67 = true
			duel_mode = workspace:GetAttribute("DUEL_MODE")

			if duel_mode == true then
			else
				in_duel = LocalPlayer:GetAttribute("IN_DUEL")
				u67 = in_duel == true
			end

			if not u67 then
				freezeCharacterForMenu(Character)
			else
				unfreezeCharacterFromMenu(Character)
			end
		else
			unfreezeCharacterFromMenu(Character)
		end

		v70 = getGlobalPivot()
		CurrentCamera = workspace.CurrentCamera
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		cFrame = CFrame.new(v70.Position + Vector3.new(0, 2, 8), v70.Position)
		CurrentCamera.CFrame = cFrame
		menuMusic = p7:FindFirstChild("MenuMusic")

		if menuMusic then
			v74 = p7.MenuMusic
			v74:Stop()
			v74.Volume = 0
			v74:Play()
			v75 = tweenService
			tweenInfo = TweenInfo.new(1)
			t3 = { Volume = 0.5 }
			v78 = v75:Create(v74, tweenInfo, t3)
			v78:Play()
		end
	end
end
local function characterAlreadySelected(p8)
	if not p8 then
		return false
	end

	return p8:FindFirstChild("Values") ~= nil
end
local function onSpawn()
	for iterKey in pairs(object) do
		if iterKey ~= LocalPlayer.Character then
			unfreezeCharacterFromMenu(iterKey)
			object[iterKey] = nil
		end
	end

	u12()
	task.wait(0.15)

	local v81 = ensureMenu()
	local Character: Model = LocalPlayer.Character

	if if not Character then false else Character:FindFirstChild("Values") ~= nil then
		if v81 then
			v81.Enabled = false

			local frame = v81:FindFirstChild("Frame")

			if frame and frame:IsA("GuiObject") then
				frame.Visible = false
			end
		end

		u12()

		local Character2: Model = LocalPlayer.Character
		local u85

		if not v81 or not v81.Enabled then
			u85 = false
		else
			local frame = v81:FindFirstChild("Frame")

			u85 = if frame and frame:IsA("GuiObject") and frame.Visible == false then false else true
		end

		if u85 then
			local u87: boolean = true

			if workspace:GetAttribute("DUEL_MODE") ~= true then
				u87 = LocalPlayer:GetAttribute("IN_DUEL") == true
			end

			if not u87 then
				freezeCharacterForMenu(Character2)

				return
			end

			unfreezeCharacterFromMenu(Character2)

			return
		end

		unfreezeCharacterFromMenu(Character2)

		return
	end

	openMenu(v81)
end

onSpawn()
LocalPlayer.CharacterAdded:Connect(onSpawn)
