-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local soundService: SoundService = game:GetService("SoundService")
local atomicBinding = require(script:WaitForChild("AtomicBinding"))

local function loadFlag(p1)
	local ok, result = pcall(function()
		return UserSettings():IsUserFeatureEnabled(p1)
	end)

	return ok and result
end

local s1: string = "UserSoundsUseRelativeVelocity2"

local ok, result = pcall(function()
	return UserSettings():IsUserFeatureEnabled(s1)
end)

local v9 = ok and result
local s2: string = "UserNewCharacterSoundsApi3"

local ok2, result2 = pcall(function()
	return UserSettings():IsUserFeatureEnabled(s2)
end)

local v13 = ok2 and result2
local s3: string = "UserFixCharSoundsEmitters"

local ok3, result3 = pcall(function()
	return UserSettings():IsUserFeatureEnabled(s3)
end)

local v17 = ok3 and result3

local function map(p2, p3, p4, p5, p6)
	return (p2 - p3) * (p6 - p5) / (p4 - p3) + p5
end
local function getRelativeVelocity(p7, p8)
	if not p7 or not p7.ActiveController then
		return p8
	end

	local activeController = p7.ActiveController
	local GroundSensor = nil

	if typeof(activeController) == "Instance" then
		if activeController:IsA("GroundController") and p7.GroundSensor then
			GroundSensor = p7.GroundSensor
		elseif activeController:IsA("ClimbController") and p7.ClimbSensor then
			GroundSensor = p7.ClimbSensor
		end
	end

	local v46 = GroundSensor and GroundSensor.SensedPart and p7.RootPart

	if v46 and v46:IsA("BasePart") then
		local v47 = GroundSensor.SensedPart:GetVelocityAtPosition(v46.Position)

		return p8 - v47
	end

	return p8
end
local function playSound(p9, p10)
	if not p9 then
		return
	end

	if not p10 then
		p9.TimePosition = 0
	end

	if v13 and p9:IsA("AudioPlayer") then
		p9:Play()

		return
	end

	p9.Playing = true
end
local function stopSound(p11)
	if not p11 then
		return
	end

	if v13 and p11:IsA("AudioPlayer") then
		p11:Stop()

		return
	end

	p11.Playing = false
end
local function playSoundIf(p12, playing)
	if not p12 then
		return
	end

	if v13 and p12:IsA("AudioPlayer") then
		if p12.IsPlaying and not playing then
			p12:Stop()

			return
		end

		if not p12.IsPlaying and playing then
			p12:Play()

			return
		end
	else
		p12.Playing = playing
	end
end
local function setSoundLooped(p14, p15)
	if not p14 then
		return
	end

	if v13 and p14:IsA("AudioPlayer") then
		p14.Looping = p15

		return
	end

	p14.Looped = p15
end
local function shallowCopy(p16)
	local t4: {[any]: any} = {}

	for k, v in pairs(p16) do
		t4[k] = v
	end

	return t4
end

local t1: {[any]: any} = {
	Climbing = {
		SoundId = "rbxasset://sounds/action_footsteps_plastic.mp3",
		Looped = true
	},
	Died = { SoundId = "rbxasset://sounds/uuhhh.mp3" },
	FreeFalling = { SoundId = "rbxasset://sounds/action_falling.ogg", Looped = true },
	GettingUp = { SoundId = "rbxasset://sounds/action_get_up.mp3" },
	Jumping = { SoundId = "rbxasset://sounds/action_jump.mp3" },
	Landing = { SoundId = "rbxasset://sounds/action_jump_land.mp3" },
	Splash = { SoundId = "rbxasset://sounds/impact_water.mp3" },
	Swimming = {
		SoundId = "rbxasset://sounds/action_swim.mp3",
		Looped = true,
		Pitch = 1.6
	}
}
local t2: {[any]: any} = {
	Climbing = {
		AssetId = "rbxasset://sounds/action_footsteps_plastic.mp3",
		Looping = true
	},
	Died = { AssetId = "rbxasset://sounds/uuhhh.mp3" },
	FreeFalling = { AssetId = "rbxasset://sounds/action_falling.ogg", Looping = true },
	GettingUp = { AssetId = "rbxasset://sounds/action_get_up.mp3" },
	Jumping = { AssetId = "rbxasset://sounds/action_jump.mp3" },
	Landing = { AssetId = "rbxasset://sounds/action_jump_land.mp3" },
	Splash = { AssetId = "rbxasset://sounds/impact_water.mp3" },
	Swimming = {
		AssetId = "rbxasset://sounds/action_swim.mp3",
		Looping = true,
		PlaybackSpeed = 1.6
	}
}

local v27 = atomicBinding.new({ Humanoid = "Humanoid", rootPart = "HumanoidRootPart" }, function(p17)
	local Humanoid = p17.Humanoid
	local rootPart = p17.rootPart
	local controllerManager = nil

	if v9 and Humanoid.Parent then
		controllerManager = Humanoid.Parent:FindFirstChild("ControllerManager")
	end

	local t5: {[any]: any} = {}

	if v13 and soundService.CharacterSoundsUseNewApi == Enum.RolloutState.Enabled then
		local humanoidParent = Humanoid.Parent
		local humanoidRootPart = Humanoid.RootPart
		local t6: {[any]: any} = {}
		local n1: number = 5

		while n1 < 150 do
			t6[n1] = 5 / n1
			n1 *= 1.25
		end

		t6[150] = 0

		local audioEmitter

		if v17 and humanoidRootPart then
			audioEmitter = Instance.new("AudioEmitter")
			audioEmitter.Name = "RbxCharacterSoundsEmitter"
			audioEmitter.Parent = humanoidRootPart
		else
			audioEmitter = Instance.new("AudioEmitter")
			audioEmitter.Name = "RbxCharacterSoundsEmitter"
			audioEmitter.Parent = humanoidParent
		end

		audioEmitter:SetDistanceAttenuation(t6)

		for k, v in pairs(t2) do
			local audioPlayer: AudioPlayer = Instance.new("AudioPlayer")

			audioPlayer.Name = k
			audioPlayer.Archivable = false
			audioPlayer.Volume = 0.65

			for k2, iterValue in pairs(v) do
				audioPlayer[k2] = iterValue
			end

			audioPlayer.Parent = rootPart

			local wire: Wire = Instance.new("Wire")

			wire.Name = k .. "Wire"
			wire.Parent = audioPlayer
			wire.SourceInstance = audioPlayer
			wire.TargetInstance = audioEmitter
			t5[k] = audioPlayer
		end
	else
		for k, v in pairs(t1) do
			local sound: Sound = Instance.new("Sound")

			sound.Name = k
			sound.Archivable = false
			sound.RollOffMinDistance = 5
			sound.RollOffMaxDistance = 150
			sound.Volume = 0.65

			for k3, iterValue2 in pairs(v) do
				sound[k3] = iterValue2
			end

			sound.Parent = rootPart
			t5[k] = sound
		end
	end

	local t7: {[any]: any} = {}

	local function stopPlayingLoopedSounds(p18)
		local t12: {[any]: any} = {}

		for k, v in pairs(t7) do
			t12[k] = v
		end

		for iterKey in pairs(t12) do
			if iterKey ~= p18 then
				if iterKey then
					if v13 and iterKey:IsA("AudioPlayer") then
						iterKey:Stop()
					else
						iterKey.Playing = false
					end
				end

				t7[iterKey] = nil
			end
		end
	end

	local t8: {[any]: any} = {
		[Enum.HumanoidStateType.FallingDown] = function()
			stopPlayingLoopedSounds()
		end,
		[Enum.HumanoidStateType.GettingUp] = function()
			stopPlayingLoopedSounds()

			local gettingUp = t5.GettingUp

			if not gettingUp then
				return
			end

			gettingUp.TimePosition = 0

			if v13 and gettingUp:IsA("AudioPlayer") then
				gettingUp:Play()

				return
			end

			gettingUp.Playing = true
		end,
		[Enum.HumanoidStateType.Jumping] = function()
			stopPlayingLoopedSounds()

			local jumping = t5.Jumping

			if not jumping then
				return
			end

			jumping.TimePosition = 0

			if v13 and jumping:IsA("AudioPlayer") then
				jumping:Play()

				return
			end

			jumping.Playing = true
		end,
		[Enum.HumanoidStateType.Swimming] = function()
			local absoluteValue = math.abs(rootPart.AssemblyLinearVelocity.Y)

			if t5.Splash and absoluteValue > 0.1 then
				t5.Splash.Volume = math.clamp((absoluteValue - 100) * 0.72 / 250 + 0.28, 0, 1)

				local splash = t5.Splash

				if splash then
					splash.TimePosition = 0

					if v13 and splash:IsA("AudioPlayer") then
						splash:Play()
					else
						splash.Playing = true
					end
				end
			end

			stopPlayingLoopedSounds(t5.Swimming)

			if t5.Swimming then
				local swimming = t5.Swimming

				if swimming then
					if v13 and swimming:IsA("AudioPlayer") then
						swimming:Play()
					else
						swimming.Playing = true
					end
				end

				t7[t5.Swimming] = true
			end
		end,
		[Enum.HumanoidStateType.Freefall] = function()
			if t5.FreeFalling then
				t5.FreeFalling.Volume = 0
				stopPlayingLoopedSounds(t5.FreeFalling)

				local freeFalling = t5.FreeFalling

				if freeFalling then
					if v13 and freeFalling:IsA("AudioPlayer") then
						freeFalling.Looping = true
					else
						freeFalling.Looped = true
					end
				end

				if t5.FreeFalling:IsA("Sound") then
					t5.FreeFalling.PlaybackRegionsEnabled = true
					t5.FreeFalling.LoopRegion = NumberRange.new(2, 9)
				end

				local v112 = t5.FreeFalling

				if v112 then
					v112.TimePosition = 0

					if v13 and v112:IsA("AudioPlayer") then
						v112:Play()
					else
						v112.Playing = true
					end
				end

				t7[t5.FreeFalling] = true

				return
			end

			stopPlayingLoopedSounds()
		end,
		[Enum.HumanoidStateType.Landed] = function()
			stopPlayingLoopedSounds()

			local absoluteValue = math.abs(rootPart.AssemblyLinearVelocity.Y)

			if t5.Landing and absoluteValue > 75 then
				t5.Landing.Volume = math.clamp((absoluteValue - 50) * 1 / 50 + 0, 0, 1)

				local landing = t5.Landing

				if not landing then
					return
				end

				landing.TimePosition = 0

				if v13 and landing:IsA("AudioPlayer") then
					landing:Play()

					return
				end

				landing.Playing = true

				return
			end
		end,
		[Enum.HumanoidStateType.Running] = function()
			stopPlayingLoopedSounds()
		end,
		[Enum.HumanoidStateType.Climbing] = function()
			local climbing = t5.Climbing
			local rootPartAssemblyLinearVelocity = rootPart.AssemblyLinearVelocity
			local v117 = v9 and getRelativeVelocity(controllerManager, rootPartAssemblyLinearVelocity) or rootPartAssemblyLinearVelocity

			if climbing then
				if math.abs(v117.Y) > 0.1 then
					if climbing then
						if v13 and climbing:IsA("AudioPlayer") then
							climbing:Play()
						else
							climbing.Playing = true
						end
					end

					stopPlayingLoopedSounds(climbing)
				else
					stopPlayingLoopedSounds()
				end

				t7[climbing] = true

				return
			end

			stopPlayingLoopedSounds()
		end,
		[Enum.HumanoidStateType.Seated] = function()
			stopPlayingLoopedSounds()
		end,
		[Enum.HumanoidStateType.Dead] = function()
			stopPlayingLoopedSounds()

			local died = t5.Died

			if not died then
				return
			end

			died.TimePosition = 0

			if v13 and died:IsA("AudioPlayer") then
				died:Play()

				return
			end

			died.Playing = true
		end
	}

	local t9: {[any]: any} = {}

	if t5.Climbing then
		t9[t5.Climbing] = function(_, p20, p21)
			local playing: boolean = (v9 and getRelativeVelocity(controllerManager, p21) or p21).Magnitude > 0.1

			if not p20 then
				return
			end

			if v13 and p20:IsA("AudioPlayer") then
				if p20.IsPlaying and not playing then
					p20:Stop()

					return
				end

				if not p20.IsPlaying and playing then
					p20:Play()

					return
				end
			else
				p20.Playing = playing
			end
		end
	end

	if t5.FreeFalling then
		t9[t5.FreeFalling] = function(p22, p23, p24)
			if p24.Magnitude > 75 then
				p23.Volume = math.clamp(p23.Volume + p22 * 0.9, 0, 1)

				return
			end

			p23.Volume = 0
		end
	end

	local runningNoPhysics = Enum.HumanoidStateType.RunningNoPhysics
	local running = Enum.HumanoidStateType.Running
	local v86 = Humanoid:GetState()
	local t10: {[any]: any} = { [runningNoPhysics] = running }
	local u88 = t10[v86] or Humanoid:GetState()

	v86 = function(p25)
		local v127 = t8[p25]

		if v127 then
			v127()
		end

		u88 = p25
	end

	local v89 = u88
	local v90 = t8[v89]

	if v90 then
		v90()
	end

	u88 = v89

	local connection = Humanoid.StateChanged:Connect(function(_, p27)
		local v130 = t10[p27] or p27

		if v130 ~= u88 then
			local v131 = t8[v130]

			if v131 then
				v131()
			end

			u88 = v130
		end
	end)

	local connection2 = runService.Stepped:Connect(function(time: number, deltaTime: number)
		for iterKey in pairs(t7) do
			local v135 = t9[iterKey]

			if v135 then
				v135(deltaTime, iterKey, rootPart.AssemblyLinearVelocity)
			end
		end
	end)

	return function()
		connection:Disconnect()
		connection2:Disconnect()

		for _, v in pairs(t5) do
			if v and v.Destroy then
				v:Destroy()
			end
		end

		table.clear(t5)
	end
end)

local t3: {[any]: any} = {}

local function characterAdded(p30)
	v27:bindRoot(p30)
end
local function characterRemoving(p31)
	v27:unbindRoot(p31)
end
local function playerAdded(player)
	local t11 = t3[player]

	if not t11 then
		t11 = {}
		t3[player] = t11
	end

	if player.Character then
		v27:bindRoot(player.Character)
	end

	table.insert(t11, player.CharacterAdded:Connect(characterAdded))
	table.insert(t11, player.CharacterRemoving:Connect(characterRemoving))
end

for _, v in ipairs(players:GetPlayers()) do
	task.spawn(playerAdded, v)
end

players.PlayerAdded:Connect(playerAdded)
players.PlayerRemoving:Connect(function(player: Player)
	local v98 = t3[player]

	if v98 then
		for _, v in ipairs(v98) do
			v:Disconnect()
		end

		t3[player] = nil
	end

	if player.Character then
		v27:unbindRoot(player.Character)
	end
end)
