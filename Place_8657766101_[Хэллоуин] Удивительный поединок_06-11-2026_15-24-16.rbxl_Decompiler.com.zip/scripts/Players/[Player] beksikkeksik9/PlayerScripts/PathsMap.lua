-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")

require(replicatedStorage.System:WaitForChild("CooldownUI"))

local pathsAnnouncement = replicatedStorage.Remotes:WaitForChild("PathsAnnouncement")
local rbxSystem: Instance = game:GetService("TextChatService"):WaitForChild("TextChannels"):WaitForChild("RBXSystem")

pathsAnnouncement.OnClientEvent:Connect(function(p1)
	if type(p1) == "string" then
		local ok, result = pcall(function()
			rbxSystem:DisplaySystemMessage("<font color=\"rgb(107, 144, 180)\">" .. p1 .. "</font>")
		end)

		if not ok then
			warn(result)
		end

		return
	end
end)
