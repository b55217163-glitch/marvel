-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local starterGui: StarterGui = game:GetService("StarterGui")
local LocalPlayer: Player = game:GetService("Players").LocalPlayer

local function notify(p1)
	pcall(function()
		starterGui:SetCore("SendNotification", {
			Title = "Owner Command",
			Duration = 3,
			Text = if p1 then "No cooldowns enabled." else "No cooldowns disabled."
		})
	end)
end

LocalPlayer:GetAttributeChangedSignal("NoCooldown"):Connect(function()
	local u5: boolean = LocalPlayer:GetAttribute("NoCooldown") == true

	pcall(function()
		starterGui:SetCore("SendNotification", {
			Title = "Owner Command",
			Duration = 3,
			Text = if u5 then "No cooldowns enabled." else "No cooldowns disabled."
		})
	end)
end)
