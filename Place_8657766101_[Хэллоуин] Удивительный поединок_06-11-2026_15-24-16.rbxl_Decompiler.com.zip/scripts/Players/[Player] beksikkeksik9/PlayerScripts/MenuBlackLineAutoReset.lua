-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

if not playerGui then
	playerGui = LocalPlayer:WaitForChild("PlayerGui")
end

local uDim2 = UDim2.new(0, 0, -0.2, 0)
local uDim22 = UDim2.new(0, 0, 1, 0)

local function isMenuOpen()
	local menu: Instance = playerGui:FindFirstChild("Menu")

	return menu and menu:IsA("ScreenGui") and menu.Enabled == true
end
local function sendLineBack(p1)
	if not p1 or not p1:IsA("GuiObject") then
		return
	end

	local v13 = p1.Name == "BlackLineUp" and uDim2 or uDim22

	p1.Visible = true
	p1.BackgroundTransparency = 0
	pcall(function()
		local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(p1, tweenInfo, { Position = v13 }):Play()
	end)
	task.delay(0.15, function()
		if p1 and p1.Parent then
			local menu: Instance = playerGui:FindFirstChild("Menu")
			local v28 = menu

			if v28 then
				v28 = menu:IsA("ScreenGui") and menu.Enabled == true
			end

			if v28 then
				p1.Position = v13
				p1.Visible = false
			end
		end
	end)
end
local function resetAllBlackLinesForMenu()
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local v15 = menu

	if v15 then
		v15 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	if not v15 then
		return
	end

	for iterFirst, iterSecond in playerGui:GetDescendants() do
		if iterSecond:IsA("GuiObject") and (iterSecond.Name == "BlackLineUp" or iterSecond.Name == "BlackLineDown") then
			sendLineBack(iterSecond)

			local v18 = iterSecond:FindFirstAncestorWhichIsA("ScreenGui")

			if v18 and v18.Name ~= "Menu" then
				task.delay(0.16, function()
					if v18 and v18.Parent then
						local menu2: Instance = playerGui:FindFirstChild("Menu")
						local v30 = menu2

						if v30 then
							v30 = menu2:IsA("ScreenGui") and menu2.Enabled == true
						end

						if v30 then
							v18.Enabled = false
						end
					end
				end)
			end
		end
	end
end
local function hookMenu(p2)
	if not p2 or not p2:IsA("ScreenGui") then
		return
	end

	p2:GetPropertyChangedSignal("Enabled"):Connect(function()
		if p2.Enabled then
			resetAllBlackLinesForMenu()
		end
	end)

	if p2.Enabled then
		resetAllBlackLinesForMenu()
	end
end

hookMenu(playerGui:FindFirstChild("Menu"))
playerGui.ChildAdded:Connect(function(p3: Instance)
	if p3.Name == "Menu" then
		hookMenu(p3)

		return
	end

	local menu: Instance = playerGui:FindFirstChild("Menu")
	local v22 = menu

	if v22 then
		v22 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	if v22 then
		task.defer(resetAllBlackLinesForMenu)
	end
end)
playerGui.DescendantAdded:Connect(function(p4: Instance)
	local menu: Instance = playerGui:FindFirstChild("Menu")
	local v25 = menu

	if v25 then
		v25 = menu:IsA("ScreenGui") and menu.Enabled == true
	end

	if v25 and p4:IsA("GuiObject") and (p4.Name == "BlackLineUp" or p4.Name == "BlackLineDown") then
		task.defer(resetAllBlackLinesForMenu)
	end
end)
