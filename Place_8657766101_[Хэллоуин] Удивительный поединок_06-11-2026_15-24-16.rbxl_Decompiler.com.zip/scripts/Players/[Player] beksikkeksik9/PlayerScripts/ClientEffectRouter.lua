-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local remotes: Instance = replicatedStorage:WaitForChild("Remotes")
local characters: Instance = replicatedStorage:WaitForChild("Characters")
local clientEffectModules: Instance = replicatedStorage:WaitForChild("System"):WaitForChild("ClientEffectModules")
local t1: {[any]: any} = {}

local function findModuleScript(p1)
	local v18: Instance = clientEffectModules

	for iterValue in string.gmatch(p1, "[^%.]+") do
		v18 = v18 and v18:FindFirstChild(iterValue)
	end

	if v18 and v18:IsA("ModuleScript") then
		return v18
	end

	return nil
end
local function getModule(p2)
	local v21 = t1[p2]

	if v21 then
		return v21
	end

	v21 = findModuleScript(p2)

	if not v21 then
		warn("[ClientEffectRouter] Missing effect module:", p2)

		return nil
	end

	local ok, result = pcall(require, v21)

	if not ok then
		warn("[ClientEffectRouter] Failed to load effect module:", p2, result)

		return nil
	end

	t1[p2] = result

	return result
end
local function playModule(p3, ...)
	local v25 = getModule(p3)

	if not v25 then
		return
	end

	local v26 = type(v25) == "table" and v25.Play or nil

	if typeof(v26) == "function" then
		local v27 = table.pack(...)

		task.spawn(function()
			local ok, result = pcall(function()
				v26(table.unpack(v27, 1, v27.n))
			end)

			if not ok then
				warn("[ClientEffectRouter] Effect failed:", p3, result)
			end
		end)

		return
	end
end

for iterFirst, value in {
	"RagdollDeathVisual",
	"Mohawk.MoveOne",
	"Mohawk.MoveFour",
	"Invincible.ComboPunches",
	"Invincible.Counters",
	"Invincible.UpKick",
	"OmniMan.Flight",
	"Hal.MoveOne",
	"Hal.MoveTwo",
	"Hal.MoveThree",
	"Hal.Finisher"
}, nil, nil do
	getModule(value)
end

remotes:WaitForChild("ImpactFrame").OnClientEvent:Connect(function(p4, p5)
	playModule("ImpactFrame", p4, p5)
end)

local combatRemotes: Instance = characters:WaitForChild("Combat"):WaitForChild("Remotes")

combatRemotes:WaitForChild("Blocking").OnClientEvent:Connect(function(p6)
	playModule("Blocking", p6)
end)
combatRemotes:WaitForChild("HitEffect").OnClientEvent:Connect(function(p7, p8, p9)
	playModule("ComboEffects", p7, p8, p9)
end)
getModule("Combat.Knockback")
getModule("Combat.WallHit")

for iterFirst2, value2 in {
	"Zoom.MoveFourChoke",
	"Zoom.Counter",
	"Joe.ChokeSlam",
	"Joe.Counter",
	"Joe.Finisher",
	"Joe.Death"
}, nil, nil do
	getModule(value2)
end

local localHitEffect = combatRemotes:FindFirstChild("LocalHitEffect")

if not localHitEffect then
	localHitEffect = Instance.new("BindableEvent")
	localHitEffect.Name = "LocalHitEffect"
	localHitEffect.Parent = combatRemotes
end

if localHitEffect:IsA("BindableEvent") then
	localHitEffect.Event:Connect(function(p10, p11, p12)
		local v37 = getModule("ComboEffects")

		if type(v37) == "table" and typeof(v37.PlayPredicted) == "function" then
			local v38 = table.pack(p10, p11, p12)

			task.spawn(function()
				local ok, result = pcall(function()
					v37.PlayPredicted(table.unpack(v38, 1, v38.n))
				end)

				if not ok then
					warn("[ClientEffectRouter] Predicted effect failed: ComboEffects", result)
				end
			end)
		end
	end)
end

characters:WaitForChild("Hal"):WaitForChild("Remotes"):WaitForChild("MoveTwo").OnClientEvent:Connect(function(p13, p14, ...)
	playModule("Hal.MoveTwo", p13, p14, ...)
end)

local moonKnightRemotes: Instance = characters:WaitForChild("MoonKnight"):WaitForChild("Remotes")

moonKnightRemotes:WaitForChild("GunShot").OnClientEvent:Connect(function(p15)
	playModule("MoonKnight.GunShoot", p15)
end)
moonKnightRemotes:WaitForChild("MoonKnightTransformation").OnClientEvent:Connect(function(p16)
	playModule("MoonKnight.MoonKnightTransform", p16)
end)
moonKnightRemotes:WaitForChild("MoonKnightMenuTransformation").Event:Connect(function(p17)
	local v44 = getModule("MoonKnight.MoonKnightTransform")

	if type(v44) == "table" and typeof(v44.PlayMenu) == "function" then
		task.spawn(function()
			local ok, result = pcall(function()
				v44.PlayMenu(p17)
			end)

			if not ok then
				warn("[ClientEffectRouter] Effect failed: MoonKnight.MoonKnightTransform menu", result)
			end
		end)
	end
end)
moonKnightRemotes:WaitForChild("Skydive").OnClientEvent:Connect(function(p18)
	playModule("MoonKnight.Glide", p18)
end)
moonKnightRemotes:WaitForChild("GunShots").OnClientEvent:Connect(function(p19, p20)
	playModule("MoonKnight.HitBullet", p19, p20)
end)
moonKnightRemotes:WaitForChild("KnockoutPunch").OnClientEvent:Connect(function(p21, p22, p23)
	playModule("MoonKnight.MrKnightCounter", p21, p22, p23)
end)
moonKnightRemotes:WaitForChild("MoonKick").OnClientEvent:Connect(function(p24, p25, p26)
	playModule("MoonKnight.MKOneSlam", p24, p25, p26)
end)
moonKnightRemotes:WaitForChild("Death").OnClientEvent:Connect(function(p27)
	playModule("MoonKnight.Death", p27)
end)
moonKnightRemotes:WaitForChild("BatonProjectile").OnClientEvent:Connect(function(p28, p29, p30, p31, p32)
	playModule("MoonKnight.MrKnightBaton", p28, p29, p30, p31, p32)
end)
moonKnightRemotes:WaitForChild("KhonshuSlam").OnClientEvent:Connect(function(p33, p34)
	playModule("MoonKnight.KhonshuSlam", p33, p34)
end)
moonKnightRemotes:WaitForChild("RandomKhonshuLine").OnClientEvent:Connect(function()
	playModule("MoonKnight.KhonshuAppear")
end)
moonKnightRemotes:WaitForChild("DismissRandomKhonshu").OnClientEvent:Connect(function()
	local v62 = getModule("MoonKnight.KhonshuAppear")

	if type(v62) == "table" and typeof(v62.Dismiss) == "function" then
		task.spawn(function()
			local ok, result = pcall(function()
				v62.Dismiss()
			end)

			if not ok then
				warn("[ClientEffectRouter] Effect failed: MoonKnight.KhonshuAppear dismiss", result)
			end
		end)
	end
end)
characters:WaitForChild("DoctorStrange"):WaitForChild("Remotes"):WaitForChild("PortalBullets").OnClientEvent:Connect(function(p35, p36, p37)
	playModule("DoctorStrange.Hit", p35, p36, p37)
end)

local invincible: Instance = characters:WaitForChild("Invincible")

invincible:WaitForChild("Remotes"):WaitForChild("ComboPunch").OnClientEvent:Connect(function(p38)
	playModule("Invincible.ComboPunches", p38)
end)
invincible:WaitForChild("Remotes"):WaitForChild("Counters").OnClientEvent:Connect(function(p39)
	playModule("Invincible.Counters", p39)
end)
invincible:WaitForChild("Remotes"):WaitForChild("HeavyPunch").OnClientEvent:Connect(function(p40)
	playModule("Invincible.HeavyPunch", p40)
end)
invincible:WaitForChild("Remotes"):WaitForChild("UpKick").OnClientEvent:Connect(function(p41)
	playModule("Invincible.UpKick", p41)
end)

return nil
