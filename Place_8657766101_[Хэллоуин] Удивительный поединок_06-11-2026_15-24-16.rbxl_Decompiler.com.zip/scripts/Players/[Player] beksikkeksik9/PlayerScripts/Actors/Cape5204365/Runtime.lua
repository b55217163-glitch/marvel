-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
if not script.Parent:IsA("Actor") then
	return
end

local event = script.Parent.Event
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local v5 = nil

for _, v in pairs({ replicatedStorage, players.LocalPlayer:WaitForChild("PlayerScripts") }) do
	local foundChild = v:FindFirstChild("SmartBone", true)

	if foundChild and foundChild:IsA("ModuleScript") then
		v5 = foundChild

		break
	end
end

if not v5 then
	warn("SmartBone was not found!")

	return
end

local dependencies = v5:WaitForChild("Dependencies")
local config = require(dependencies:WaitForChild("Config"))
local v11 = require(v5)
local cameraUtil = require(dependencies:WaitForChild("CameraUtil"))
local configDebug = config.Debug
local osClock = os.clock
local v15 = osClock()
local n1 = 60
local t1: {[any]: any} = {}

local function roundNumber(p1)
	return math.floor(p1 * 1000 + 0.5) / 1000
end
local function smoothDelta()
	local v22 = osClock()

	for i = #t1, 1, -1 do
		t1[i + 1] = t1[i] >= v22 - 1 and t1[i] or nil
	end

	t1[1] = v22

	local n2 = osClock() - v15 >= 1 and #t1

	if not n2 then
		local v25 = osClock()

		n2 = #t1 / (v25 - v15)
	end

	n1 = math.floor(n2)

	return math.floor((n1 * (1 / n1) ^ 2 + 0.001) * 1000 + 0.5) / 1000
end
local function Initialize(p2, p3)
	local v28 = v11.new(p2, p3)
	local n1 = 0

	v28.SimulationConnection = runService.Heartbeat:ConnectParallel(function(_)
		local v35 = smoothDelta()

		n1 += v35

		local magnitude = (workspace.CurrentCamera.CFrame.Position - v28.RootPart.Position).Magnitude
		local activationDistance = v28.Settings.ActivationDistance
		local v38 = math.clamp(magnitude - v28.Settings.ThrottleDistance, 0, activationDistance)

		v38 = math.clamp(v38 / activationDistance, 0, 1)

		local v39 = math.clamp((1 - v38) * v28.Settings.UpdateRate, 1, v28.Settings.UpdateRate)
		local floored = math.floor(v39)

		v38 = cameraUtil.WithinViewport(v28.RootPart)

		if not (n1 >= 1 / floored) then
		elseif activationDistance > magnitude and v38 then
			local v41 = n1

			n1 = 0
			debug.profilebegin("SmartBone")

			if v28.InRange == false then
				v28.InRange = true
			end

			v28:UpdateBones(v41, floored)
			debug.profileend()
			task.synchronize()
			debug.profilebegin("SmartBoneTransform")

			for iterFirst, iterSecond in v28.ParticleTrees, nil, nil do
				v28:TransformBones(iterSecond, v41)

				if configDebug then
					v28:DEBUG(iterSecond, v41)
				end
			end

			debug.profileend()
			task.desynchronize()
		elseif v28.InRange == true then
			v28.InRange = false

			for iterFirst2, iterSecond2 in v28.ParticleTrees, nil, nil do
				v28:ResetParticles(iterSecond2)
			end

			task.synchronize()

			for iterFirst3, iterSecond3 in v28.ParticleTrees, nil, nil do
				v28:ResetTransforms(iterSecond3, v35)
			end

			task.desynchronize()
		end
	end)

	return v28
end
function event.OnInvoke(p5, p6)
	local v32 = v11.new(p5, p6)
	local n1 = 0

	v32.SimulationConnection = runService.Heartbeat:ConnectParallel(function(_)
		local v49 = smoothDelta()

		n1 += v49

		local magnitude = (workspace.CurrentCamera.CFrame.Position - v32.RootPart.Position).Magnitude
		local activationDistance = v32.Settings.ActivationDistance
		local v52 = math.clamp(magnitude - v32.Settings.ThrottleDistance, 0, activationDistance)

		v52 = math.clamp(v52 / activationDistance, 0, 1)

		local v53 = math.clamp((1 - v52) * v32.Settings.UpdateRate, 1, v32.Settings.UpdateRate)
		local floored = math.floor(v53)

		v52 = cameraUtil.WithinViewport(v32.RootPart)

		if not (n1 >= 1 / floored) then
		elseif activationDistance > magnitude and v52 then
			local v55 = n1

			n1 = 0
			debug.profilebegin("SmartBone")

			if v32.InRange == false then
				v32.InRange = true
			end

			v32:UpdateBones(v55, floored)
			debug.profileend()
			task.synchronize()
			debug.profilebegin("SmartBoneTransform")

			for iterFirst, iterSecond in v32.ParticleTrees, nil, nil do
				v32:TransformBones(iterSecond, v55)

				if configDebug then
					v32:DEBUG(iterSecond, v55)
				end
			end

			debug.profileend()
			task.desynchronize()
		elseif v32.InRange == true then
			v32.InRange = false

			for iterFirst2, iterSecond2 in v32.ParticleTrees, nil, nil do
				v32:ResetParticles(iterSecond2)
			end

			task.synchronize()

			for iterFirst3, iterSecond3 in v32.ParticleTrees, nil, nil do
				v32:ResetTransforms(iterSecond3, v49)
			end

			task.desynchronize()
		end
	end)

	return v32
end
