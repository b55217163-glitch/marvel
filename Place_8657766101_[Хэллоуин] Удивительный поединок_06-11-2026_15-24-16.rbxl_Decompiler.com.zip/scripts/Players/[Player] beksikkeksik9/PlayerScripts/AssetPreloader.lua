-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local sharedAssetPreloadQueue = require(script.Parent:WaitForChild("SharedAssetPreloadQueue"))

replicatedStorage:WaitForChild("SelectACharacter"):WaitForChild("PreloadCharacterAnimations").OnClientEvent:Connect(function(p1, p2)
	if type(p1) == "string" and type(p2) == "table" then
		sharedAssetPreloadQueue.EnqueueAnimationIds(p2, sharedAssetPreloadQueue.Priority.SelectedCharacter, "AssetPreloader:" .. p1, { skipDefaultAnimations = false })

		return
	end
end)
