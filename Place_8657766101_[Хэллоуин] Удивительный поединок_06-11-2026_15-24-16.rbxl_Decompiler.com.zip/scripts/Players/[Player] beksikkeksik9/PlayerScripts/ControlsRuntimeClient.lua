-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local LocalPlayer: Player = game:GetService("Players").LocalPlayer
local system: Instance = game:GetService("ReplicatedStorage"):WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))

local function applyShiftLock()
	controlsRuntime.ApplyShiftLockBinding(LocalPlayer)
end
local function connectBindingsFolder(p1)
	for _, v in ipairs(p1:GetChildren()) do
		if v.Name == "ShiftLock" then
			v.ChildAdded:Connect(applyShiftLock)
			v.ChildRemoved:Connect(applyShiftLock)

			for _, iterValue in ipairs(v:GetChildren()) do
				if iterValue:IsA("StringValue") then
					iterValue.Changed:Connect(applyShiftLock)
				end
			end
		end
	end

	p1.ChildAdded:Connect(function(p2)
		if p2.Name == "ShiftLock" then
			controlsRuntime.ApplyShiftLockBinding(LocalPlayer)
			connectBindingsFolder(p1)
		end
	end)
end

task.defer(function()
	local playerScripts: Instance = LocalPlayer:WaitForChild("PlayerScripts", 10)

	if playerScripts then
		playerScripts:WaitForChild("PlayerModule", 10)
	end

	local controlsBindings: Instance = LocalPlayer:WaitForChild("ControlsBindings", 10)

	if controlsBindings then
		connectBindingsFolder(controlsBindings)
	end

	controlsRuntime.ApplyShiftLockBinding(LocalPlayer)
end)
