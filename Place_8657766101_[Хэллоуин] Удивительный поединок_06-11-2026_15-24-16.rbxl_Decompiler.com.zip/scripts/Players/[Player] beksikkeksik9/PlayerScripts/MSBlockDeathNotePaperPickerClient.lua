-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local userInputService: UserInputService = game:GetService("UserInputService")
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local msBlockDeathNotePaperPicker: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockDeathNotePaperPicker")
local msBlockDeathNoteRyukPrompt: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockDeathNoteRyukPrompt")
local msBlockDeathNoteRyukRigRequest: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockDeathNoteRyukRigRequest")
local msBlockDeathNotePaperPickerGui: ScreenGui = Instance.new("ScreenGui")

msBlockDeathNotePaperPickerGui.Name = "MSBlockDeathNotePaperPickerGui"
msBlockDeathNotePaperPickerGui.ResetOnSpawn = false
msBlockDeathNotePaperPickerGui.IgnoreGuiInset = true
msBlockDeathNotePaperPickerGui.Enabled = false
msBlockDeathNotePaperPickerGui.DisplayOrder = 75
msBlockDeathNotePaperPickerGui.Parent = playerGui

local root: CanvasGroup = Instance.new("CanvasGroup")

root.Name = "Root"
root.AnchorPoint = Vector2.new(0.5, 0.5)
root.Position = UDim2.fromScale(0.5, 0.36)
root.Size = UDim2.fromOffset(880, 450)
root.BackgroundTransparency = 1
root.GroupTransparency = 1
root.Parent = msBlockDeathNotePaperPickerGui

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 0.9
uiScale.Parent = root

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.fromOffset(0, 0)
title.Size = UDim2.new(1, 0, 0, 46)
title.Font = Enum.Font.Arcade
title.Text = "DEATH NOTE PAPER"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
title.TextStrokeTransparency = 0.2
title.TextScaled = true
title.Parent = root

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.fromOffset(0, 46)
subtitle.Size = UDim2.new(1, 0, 0, 30)
subtitle.Font = Enum.Font.Arcade
subtitle.Text = "Choose one name — press 1-0, tap, or use controller"
subtitle.TextColor3 = Color3.fromRGB(235, 235, 235)
subtitle.TextStrokeTransparency = 0.6
subtitle.TextScaled = true
subtitle.Parent = root

local players: Frame = Instance.new("Frame")

players.Name = "Players"
players.BackgroundTransparency = 1
players.Position = UDim2.fromOffset(0, 92)
players.Size = UDim2.new(1, 0, 0, 340)
players.Parent = root

local uiGridLayout: UIGridLayout = Instance.new("UIGridLayout")

uiGridLayout.CellSize = UDim2.fromOffset(160, 68)
uiGridLayout.CellPadding = UDim2.fromOffset(10, 10)
uiGridLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
uiGridLayout.VerticalAlignment = Enum.VerticalAlignment.Top
uiGridLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiGridLayout.Parent = players

local u19: boolean = false
local n1: number = 0
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local n2 = 1
local t3: {[any]: any} = {
	"PhantomScareOne",
	"PhantomScareTwo",
	"PhantomScareThree",
	"PhantomScareFour"
}
local t4: {[any]: any} = {
	"One",
	"Two",
	"Three",
	"Four",
	"Five",
	"Six",
	"Seven",
	"Eight",
	"Nine",
	"Zero"
}
local t5: {[any]: any} = {
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"0"
}

local function playRandomShinigamiLine(p1)
	local rootPart = p1 and p1:FindFirstChild("RootPart")

	if not rootPart then
		return
	end

	local t6: {[any]: any} = {}

	for iterFirst, iterSecond in rootPart:GetChildren() do
		if iterSecond:IsA("Sound") and string.match(iterSecond.Name, "^Sfx%d+$") then
			t6[#t6 + 1] = iterSecond
		end
	end

	if #t6 <= 0 then
		return
	end

	local randomNumber = math.random(1, #t6)
	local v44 = t6[randomNumber]

	v44.TimePosition = 0
	v44:Play()
end
local function revealLocalRyuk()
	local Character: Model = LocalPlayer.Character

	if not Character then
		return
	end

	local ryuk: Instance = Character:FindFirstChild("Ryuk")
	local v47 = os.clock()

	while not ryuk and os.clock() - v47 < 2 do
		task.wait(0.05)

		local Character2: Model = LocalPlayer.Character

		if not Character2 then
			return
		end

		ryuk = Character2:FindFirstChild("Ryuk")
	end

	if not ryuk then
		return
	end

	playRandomShinigamiLine(ryuk)

	for iterFirst, iterSecond in ryuk:GetChildren() do
		if (iterSecond:IsA("BasePart") or iterSecond:IsA("MeshPart")) and iterSecond.Name ~= "RootPart" then
			local v51 = iterSecond.Size

			iterSecond.Size = Vector3.new(0, 0, 0)
			iterSecond.Transparency = 1
			tweenService:Create(iterSecond, TweenInfo.new(1), { Transparency = 0, Size = v51 }):Play()
		end
	end
end

msBlockDeathNoteRyukPrompt.OnClientEvent:Connect(function(p2)
	if p2 == "RequestRig" then
		msBlockDeathNoteRyukRigRequest:FireServer()
	elseif p2 == "Reveal" then
		revealLocalRyuk()
	end
end)

local function formatBinding(p3)
	if p3 and p3 ~= "" then
		if p3 == "MouseButton1" then
			return "M1"
		end

		if p3 == "MouseButton2" then
			return "M2"
		end

		if p3 == "ButtonA" then
			return "A"
		end

		if p3 == "ButtonB" then
			return "B"
		end

		if p3 == "ButtonX" then
			return "X"
		end

		if p3 == "ButtonY" then
			return "Y"
		end

		if string.sub(p3, 1, 6) == "Button" then
			return (string.sub(p3, 7))
		end

		if string.sub(p3, 1, 4) == "DPad" then
			return string.gsub(p3, "DPad", "D-")
		end

		return p3
	end

	return "?"
end
local function getActionText(p4)
	local t7: {[any]: any} = {}
	local v56 = t5[p4]

	if v56 then
		t7[#t7 + 1] = v56
	end

	v56 = t3[p4]

	if v56 then
		local v57 = controlsRuntime.GetBinding(LocalPlayer, v56, "Keyboard")
		local v58 = controlsRuntime.GetBinding(LocalPlayer, v56, "Controller")

		if v57 and v57 ~= "" and v57 ~= t4[p4] then
			t7[#t7 + 1] = formatBinding(v57)
		end

		if v58 and v58 ~= "" then
			t7[#t7 + 1] = formatBinding(v58)
		end
	end

	if #t7 <= 0 then
		return "TAP"
	end

	return table.concat(t7, " / ")
end
local function inputMatchesAction(input, p6)
	local v61 = controlsRuntime.GetBinding(LocalPlayer, p6, "Keyboard")
	local v62 = controlsRuntime.GetBinding(LocalPlayer, p6, "Controller")

	if v61 and v61 ~= "" then
		if input.KeyCode and v61 == input.KeyCode.Name then
			return true
		end

		if input.UserInputType and v61 == input.UserInputType.Name then
			return true
		end
	end

	if v62 and v62 ~= "" and input.KeyCode and v62 == input.KeyCode.Name then
		return true
	end

	return false
end
local function clearButtons()
	local children = players:GetChildren()

	for i = 1, #children do
		local v65 = children[i]

		if v65:IsA("GuiButton") then
			v65:Destroy()
		end
	end

	t2 = {}
	n2 = 1
end
local function updateSelection()
	for key, value in t2 do
		if value and value.Parent then
			local u68: boolean = key == n2

			value.BackgroundTransparency = if u68 then 0.1 else 0.25

			local uiStroke = value:FindFirstChildOfClass("UIStroke")

			if uiStroke then
				uiStroke.Thickness = if u68 then 3 else 1
				uiStroke.Transparency = if u68 then 0 else 0.22
				uiStroke.Color = u68 and Color3.fromRGB(255, 219, 92) or Color3.fromRGB(245, 235, 210)
			end
		end
	end
end
local function moveSelection(p7)
	local n1: number = #t1

	if n1 <= 0 then
		return
	end

	n2 = (n2 - 1 + p7) % n1 + 1
	updateSelection()
end
local function closePicker()
	u19 = false
	n1 += 1

	local v72: Tween = tweenService:Create(root, TweenInfo.new(0.15), { GroupTransparency = 1 })

	v72:Play()
	v72.Completed:Wait()
	msBlockDeathNotePaperPickerGui.Enabled = false
	t1 = {}
	clearButtons()
end
local function chooseTarget(p8)
	if not u19 then
		return
	end

	u19 = false
	msBlockDeathNotePaperPicker:FireServer(p8)
	closePicker()
end
local function createPlayerButton(player, layoutOrder)
	local v76 = getActionText(layoutOrder)
	local textButton: TextButton = Instance.new("TextButton")

	t2[layoutOrder] = textButton
	textButton.Name = "Name_" .. tostring(player.UserId)
	textButton.LayoutOrder = layoutOrder
	textButton.Size = UDim2.fromOffset(160, 68)
	textButton.BackgroundColor3 = player.IsSelf and Color3.fromRGB(60, 35, 35) or Color3.fromRGB(10, 8, 6)
	textButton.BackgroundTransparency = 0.25
	textButton.BorderSizePixel = 0
	textButton.AutoButtonColor = true
	textButton.Text = ""
	textButton.Parent = players

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 8)
	uiCorner.Parent = textButton

	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = player.IsSelf and Color3.fromRGB(255, 120, 120) or Color3.fromRGB(245, 235, 210)
	uiStroke.Transparency = 0.22
	uiStroke.Thickness = if player.IsSelf then 2 else 1
	uiStroke.Parent = textButton

	local textLabel: TextLabel = Instance.new("TextLabel")

	textLabel.BackgroundTransparency = 1
	textLabel.Position = UDim2.fromScale(0.06, 0.08)
	textLabel.Size = UDim2.fromScale(0.88, 0.48)
	textLabel.Font = Enum.Font.Arcade
	textLabel.Text = player.DisplayName or player.Name or "Player"
	textLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	textLabel.TextStrokeTransparency = 0.55
	textLabel.TextScaled = true
	textLabel.Parent = textButton

	local textLabel2: TextLabel = Instance.new("TextLabel")

	textLabel2.BackgroundTransparency = 1
	textLabel2.Position = UDim2.fromScale(0.06, 0.58)
	textLabel2.Size = UDim2.fromScale(0.88, 0.32)
	textLabel2.Font = Enum.Font.Arcade
	textLabel2.Text = "[" .. v76 .. "] WRITE NAME"
	textLabel2.TextColor3 = player.IsSelf and Color3.fromRGB(255, 170, 170) or Color3.fromRGB(255, 219, 92)
	textLabel2.TextStrokeTransparency = 0.65
	textLabel2.TextScaled = true
	textLabel2.Parent = textButton
	textButton.Activated:Connect(function()
		local userId = player.UserId

		if not u19 then
			return
		end

		u19 = false
		msBlockDeathNotePaperPicker:FireServer(userId)
		closePicker()
	end)
end

userInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if not u19 then
		return
	end

	for i = 1, #t1 do
		if input.KeyCode and input.KeyCode.Name == t4[i] then
			local userId = t1[i].UserId

			if not u19 then
				return
			end

			u19 = false
			msBlockDeathNotePaperPicker:FireServer(userId)
			closePicker()

			return
		end
	end

	for i = 1, math.min(#t1, 4) do
		local v87 = t3[i]

		if v87 and inputMatchesAction(input, v87) then
			local v88 = t1[i].UserId

			if not u19 then
				return
			end

			u19 = false
			msBlockDeathNotePaperPicker:FireServer(v88)
			closePicker()

			return
		end
	end

	if input.KeyCode == Enum.KeyCode.DPadRight or input.KeyCode == Enum.KeyCode.DPadDown or input.KeyCode == Enum.KeyCode.Thumbstick1Right or input.KeyCode == Enum.KeyCode.Thumbstick1Down then
		local n1: number = #t1

		if n1 <= 0 then
			return
		end

		n2 = (n2 - 1 + 1) % n1 + 1
		updateSelection()
	elseif input.KeyCode == Enum.KeyCode.DPadLeft or input.KeyCode == Enum.KeyCode.DPadUp or input.KeyCode == Enum.KeyCode.Thumbstick1Left or input.KeyCode == Enum.KeyCode.Thumbstick1Up then
		local n3: number = #t1

		if n3 <= 0 then
			return
		end

		n2 = (n2 - 1 + -1) % n3 + 1
		updateSelection()
	elseif input.KeyCode == Enum.KeyCode.ButtonA or input.KeyCode == Enum.KeyCode.Return then
		local player = t1[n2]

		if player then
			local playerUserId = player.UserId

			if not u19 then
				return
			end

			u19 = false
			msBlockDeathNotePaperPicker:FireServer(playerUserId)
			closePicker()

			return
		end
	elseif input.KeyCode == Enum.KeyCode.ButtonB or input.KeyCode == Enum.KeyCode.Escape then
		closePicker()
	end
end)
msBlockDeathNotePaperPicker.OnClientEvent:Connect(function(p13, p14)
	if typeof(p13) == "table" then
		n1 += 1

		local v95: number = n1

		u19 = true
		clearButtons()
		t1 = {}

		for i = 1, math.min(#p13, 10) do
			t1[i] = p13[i]
			createPlayerButton(p13[i], i)
		end

		msBlockDeathNotePaperPickerGui.Enabled = true
		root.GroupTransparency = 1
		uiScale.Scale = 0.9
		tweenService:Create(root, TweenInfo.new(0.18), { GroupTransparency = 0 }):Play()

		local tweenInfo = TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

		tweenService:Create(uiScale, tweenInfo, { Scale = 1 }):Play()
		n2 = 1
		updateSelection()

		local taskDelay = task.delay
		local numberValue: number? = tonumber(p14)

		taskDelay(numberValue or 15, function()
			if u19 and v95 == n1 then
				closePicker()
			end
		end)

		return
	end
end)
