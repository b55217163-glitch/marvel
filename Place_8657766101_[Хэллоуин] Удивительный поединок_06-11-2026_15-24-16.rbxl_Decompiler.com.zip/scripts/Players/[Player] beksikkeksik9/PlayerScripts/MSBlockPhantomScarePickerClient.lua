-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local userInputService: UserInputService = game:GetService("UserInputService")
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local msBlockPhantomScarePicker: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockPhantomScarePicker")
local msBlockPhantomScarePickerGui: ScreenGui = Instance.new("ScreenGui")

msBlockPhantomScarePickerGui.Name = "MSBlockPhantomScarePickerGui"
msBlockPhantomScarePickerGui.ResetOnSpawn = false
msBlockPhantomScarePickerGui.IgnoreGuiInset = true
msBlockPhantomScarePickerGui.Enabled = false
msBlockPhantomScarePickerGui.DisplayOrder = 70
msBlockPhantomScarePickerGui.Parent = playerGui

local root: CanvasGroup = Instance.new("CanvasGroup")

root.Name = "Root"
root.AnchorPoint = Vector2.new(0.5, 0.5)
root.Position = UDim2.fromScale(0.5, 0.36)
root.Size = UDim2.fromOffset(860, 430)
root.BackgroundTransparency = 1
root.GroupTransparency = 1
root.Parent = msBlockPhantomScarePickerGui

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 0.9
uiScale.Parent = root

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.fromOffset(0, 0)
title.Size = UDim2.new(1, 0, 0, 42)
title.Font = Enum.Font.Arcade
title.Text = "SEND PHANTOM SCARE"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextStrokeTransparency = 0.35
title.TextScaled = true
title.Parent = root

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.fromOffset(0, 42)
subtitle.Size = UDim2.new(1, 0, 0, 28)
subtitle.Font = Enum.Font.Arcade
subtitle.Text = "Choose a player — press 1-0, tap, or use controller"
subtitle.TextColor3 = Color3.fromRGB(220, 220, 220)
subtitle.TextStrokeTransparency = 0.65
subtitle.TextScaled = true
subtitle.Parent = root

local players: Frame = Instance.new("Frame")

players.Name = "Players"
players.BackgroundTransparency = 1
players.Position = UDim2.fromOffset(0, 82)
players.Size = UDim2.new(1, 0, 0, 330)
players.Parent = root

local uiGridLayout: UIGridLayout = Instance.new("UIGridLayout")

uiGridLayout.CellSize = UDim2.fromOffset(155, 64)
uiGridLayout.CellPadding = UDim2.fromOffset(10, 10)
uiGridLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
uiGridLayout.VerticalAlignment = Enum.VerticalAlignment.Top
uiGridLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiGridLayout.Parent = players

local u17: boolean = false
local n1: number = 0
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local n2 = 1
local t3: {[any]: any} = {
	"PhantomScareOne",
	"PhantomScareTwo",
	"PhantomScareThree",
	"PhantomScareFour"
}
local t4: {[any]: any} = {
	"One",
	"Two",
	"Three",
	"Four",
	"Five",
	"Six",
	"Seven",
	"Eight",
	"Nine",
	"Zero"
}
local t5: {[any]: any} = {
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"0"
}

local function formatBinding(p1)
	if p1 and p1 ~= "" then
		if p1 == "MouseButton1" then
			return "M1"
		end

		if p1 == "MouseButton2" then
			return "M2"
		end

		if p1 == "ButtonA" then
			return "A"
		end

		if p1 == "ButtonB" then
			return "B"
		end

		if p1 == "ButtonX" then
			return "X"
		end

		if p1 == "ButtonY" then
			return "Y"
		end

		if string.sub(p1, 1, 6) == "Button" then
			return (string.sub(p1, 7))
		end

		if string.sub(p1, 1, 4) == "DPad" then
			return string.gsub(p1, "DPad", "D-")
		end

		return p1
	end

	return "?"
end
local function getActionText(p2)
	local t6: {[any]: any} = {}
	local v37 = t5[p2]

	if v37 then
		t6[#t6 + 1] = v37
	end

	v37 = t3[p2]

	if v37 then
		local v38 = controlsRuntime.GetBinding(LocalPlayer, v37, "Keyboard")
		local v39 = controlsRuntime.GetBinding(LocalPlayer, v37, "Controller")

		if v38 and v38 ~= "" and v38 ~= t4[p2] then
			t6[#t6 + 1] = formatBinding(v38)
		end

		if v39 and v39 ~= "" then
			t6[#t6 + 1] = formatBinding(v39)
		end
	end

	if #t6 <= 0 then
		return "TAP"
	end

	return table.concat(t6, " / ")
end
local function inputMatchesAction(input, p4)
	local v42 = controlsRuntime.GetBinding(LocalPlayer, p4, "Keyboard")
	local v43 = controlsRuntime.GetBinding(LocalPlayer, p4, "Controller")

	if v42 and v42 ~= "" then
		if input.KeyCode and v42 == input.KeyCode.Name then
			return true
		end

		if input.UserInputType and v42 == input.UserInputType.Name then
			return true
		end
	end

	if v43 and v43 ~= "" and input.KeyCode and v43 == input.KeyCode.Name then
		return true
	end

	return false
end
local function clearButtons()
	local children = players:GetChildren()

	for i = 1, #children do
		local v46 = children[i]

		if v46:IsA("GuiButton") then
			v46:Destroy()
		end
	end

	t2 = {}
	n2 = 1
end
local function updateSelection()
	for key, value in t2 do
		if value and value.Parent then
			local u49: boolean = key == n2

			value.BackgroundTransparency = if u49 then 0.12 else 0.35

			local uiStroke = value:FindFirstChildOfClass("UIStroke")

			if uiStroke then
				uiStroke.Thickness = if u49 then 3 else 1
				uiStroke.Transparency = if u49 then 0 else 0.35
				uiStroke.Color = u49 and Color3.fromRGB(255, 219, 92) or Color3.fromRGB(255, 255, 255)
			end
		end
	end
end
local function moveSelection(p5)
	local n1: number = #t1

	if n1 <= 0 then
		return
	end

	n2 = (n2 - 1 + p5) % n1 + 1
	updateSelection()
end
local function closePicker()
	u17 = false
	n1 += 1

	local v53: Tween = tweenService:Create(root, TweenInfo.new(0.15), { GroupTransparency = 1 })

	v53:Play()
	v53.Completed:Wait()
	msBlockPhantomScarePickerGui.Enabled = false
	t1 = {}
	clearButtons()
end
local function chooseTarget(p6)
	if not u17 then
		return
	end

	u17 = false
	msBlockPhantomScarePicker:FireServer(p6)
	closePicker()
end
local function createPlayerButton(player, layoutOrder)
	local v57 = getActionText(layoutOrder)
	local textButton: TextButton = Instance.new("TextButton")

	t2[layoutOrder] = textButton
	textButton.Name = "Player_" .. tostring(player.UserId)
	textButton.LayoutOrder = layoutOrder
	textButton.Size = UDim2.fromOffset(155, 64)
	textButton.BackgroundColor3 = player.IsSelf and Color3.fromRGB(45, 25, 70) or Color3.fromRGB(0, 0, 0)
	textButton.BackgroundTransparency = 0.35
	textButton.BorderSizePixel = 0
	textButton.AutoButtonColor = true
	textButton.Text = ""
	textButton.Parent = players

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 10)
	uiCorner.Parent = textButton

	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = player.IsSelf and Color3.fromRGB(180, 120, 255) or Color3.fromRGB(255, 255, 255)
	uiStroke.Transparency = 0.35
	uiStroke.Thickness = if player.IsSelf then 2 else 1
	uiStroke.Parent = textButton

	local textLabel: TextLabel = Instance.new("TextLabel")

	textLabel.BackgroundTransparency = 1
	textLabel.Position = UDim2.fromScale(0.06, 0.08)
	textLabel.Size = UDim2.fromScale(0.88, 0.48)
	textLabel.Font = Enum.Font.Arcade
	textLabel.Text = player.DisplayName or player.Name or "Player"
	textLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	textLabel.TextStrokeTransparency = 0.6
	textLabel.TextScaled = true
	textLabel.Parent = textButton

	local textLabel2: TextLabel = Instance.new("TextLabel")

	textLabel2.BackgroundTransparency = 1
	textLabel2.Position = UDim2.fromScale(0.06, 0.58)
	textLabel2.Size = UDim2.fromScale(0.88, 0.32)
	textLabel2.Font = Enum.Font.Arcade
	textLabel2.Text = "[" .. v57 .. "] " .. (if player.IsSelf then "YOURSELF" else "SEND SCARE")
	textLabel2.TextColor3 = player.IsSelf and Color3.fromRGB(230, 190, 255) or Color3.fromRGB(255, 219, 92)
	textLabel2.TextStrokeTransparency = 0.7
	textLabel2.TextScaled = true
	textLabel2.Parent = textButton
	textButton.Activated:Connect(function()
		local userId = player.UserId

		if not u17 then
			return
		end

		u17 = false
		msBlockPhantomScarePicker:FireServer(userId)
		closePicker()
	end)
end

userInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if not u17 then
		return
	end

	for i = 1, #t1 do
		if input.KeyCode and input.KeyCode.Name == t4[i] then
			local userId = t1[i].UserId

			if not u17 then
				return
			end

			u17 = false
			msBlockPhantomScarePicker:FireServer(userId)
			closePicker()

			return
		end
	end

	for i = 1, math.min(#t1, 4) do
		local v68 = t3[i]

		if v68 and inputMatchesAction(input, v68) then
			local v69 = t1[i].UserId

			if not u17 then
				return
			end

			u17 = false
			msBlockPhantomScarePicker:FireServer(v69)
			closePicker()

			return
		end
	end

	if input.KeyCode == Enum.KeyCode.DPadRight or input.KeyCode == Enum.KeyCode.DPadDown or input.KeyCode == Enum.KeyCode.Thumbstick1Right or input.KeyCode == Enum.KeyCode.Thumbstick1Down then
		local n1: number = #t1

		if n1 <= 0 then
			return
		end

		n2 = (n2 - 1 + 1) % n1 + 1
		updateSelection()
	elseif input.KeyCode == Enum.KeyCode.DPadLeft or input.KeyCode == Enum.KeyCode.DPadUp or input.KeyCode == Enum.KeyCode.Thumbstick1Left or input.KeyCode == Enum.KeyCode.Thumbstick1Up then
		local n3: number = #t1

		if n3 <= 0 then
			return
		end

		n2 = (n2 - 1 + -1) % n3 + 1
		updateSelection()
	elseif input.KeyCode == Enum.KeyCode.ButtonA or input.KeyCode == Enum.KeyCode.Return then
		local player = t1[n2]

		if player then
			local playerUserId = player.UserId

			if not u17 then
				return
			end

			u17 = false
			msBlockPhantomScarePicker:FireServer(playerUserId)
			closePicker()

			return
		end
	elseif input.KeyCode == Enum.KeyCode.ButtonB or input.KeyCode == Enum.KeyCode.Escape then
		closePicker()
	end
end)
msBlockPhantomScarePicker.OnClientEvent:Connect(function(p11, p12)
	if typeof(p11) == "table" then
		n1 += 1

		local v76: number = n1

		u17 = true
		clearButtons()
		t1 = {}

		for i = 1, math.min(#p11, 10) do
			t1[i] = p11[i]
			createPlayerButton(p11[i], i)
		end

		msBlockPhantomScarePickerGui.Enabled = true
		root.GroupTransparency = 1
		uiScale.Scale = 0.9
		tweenService:Create(root, TweenInfo.new(0.18), { GroupTransparency = 0 }):Play()

		local tweenInfo = TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

		tweenService:Create(uiScale, tweenInfo, { Scale = 1 }):Play()
		n2 = 1
		updateSelection()

		local taskDelay = task.delay
		local numberValue: number? = tonumber(p12)

		taskDelay(numberValue or 15, function()
			if u17 and v76 == n1 then
				closePicker()
			end
		end)

		return
	end
end)
