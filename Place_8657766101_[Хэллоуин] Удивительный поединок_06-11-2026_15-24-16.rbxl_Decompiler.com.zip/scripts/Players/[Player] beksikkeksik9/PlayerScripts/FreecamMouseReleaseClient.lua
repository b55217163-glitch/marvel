-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local userInputService: UserInputService = game:GetService("UserInputService")
local LocalPlayer: Player = players.LocalPlayer

local function freecamIsEnabled()
	local Character: Model = LocalPlayer.Character

	return Character ~= nil and Character:FindFirstChild("FREECAMCOMMAND") ~= nil
end

runService.RenderStepped:Connect(function()
	local Character: Model = LocalPlayer.Character

	if Character ~= nil and Character:FindFirstChild("FREECAMCOMMAND") ~= nil then
		if not userInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
			userInputService.MouseBehavior = Enum.MouseBehavior.Default
		end

		userInputService.MouseIconEnabled = true
	end
end)
