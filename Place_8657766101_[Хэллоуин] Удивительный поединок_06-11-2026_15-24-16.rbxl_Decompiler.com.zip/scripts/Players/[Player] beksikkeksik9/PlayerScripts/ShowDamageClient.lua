-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")
local LocalPlayer: Player = players.LocalPlayer
local combatRemotes: Instance = replicatedStorage:FindFirstChild("CombatRemotes")
local v7: Instance = combatRemotes

if v7 then
	v7 = combatRemotes:FindFirstChild("DamageFeedback")
end

local random = Random.new()
local t1: {[any]: any} = {}
local arcade = Enum.Font.Arcade

local function showDamageEnabled()
	return LocalPlayer:FindFirstChild("ShowDamage") ~= nil
end
local function cleanupStack(p1)
	t1[p1] = math.max((t1[p1] or 1) - 1, 0)

	if t1[p1] <= 0 then
		t1[p1] = nil
	end
end
local function createDamagePopup(adornee, p3, p4)
	if LocalPlayer:FindFirstChild("ShowDamage") == nil then
		return
	end

	if not adornee or not adornee:IsA("BasePart") or not adornee:IsDescendantOf(workspace) then
		return
	end

	local v18 = t1[adornee] or 0

	t1[adornee] = math.min(v18 + 1, 5)

	local v19 = random:NextNumber(-0.75, 0.75)
	local v20 = math.min(v18, 5)

	v18 = Vector3.new(0, 2.9, 0) + Vector3.new(v19, v20 * 0.28, 0)

	local vector3 = Vector3.new(v19 * 0.25, 1.9, 0)
	local pixelDamagePopup: BillboardGui = Instance.new("BillboardGui")

	pixelDamagePopup.Name = "PixelDamagePopup"
	pixelDamagePopup.Adornee = adornee
	pixelDamagePopup.AlwaysOnTop = true
	pixelDamagePopup.LightInfluence = 0
	pixelDamagePopup.MaxDistance = 350
	pixelDamagePopup.Size = UDim2.fromOffset(105, 42)
	pixelDamagePopup.StudsOffset = v18
	pixelDamagePopup.Parent = LocalPlayer:FindFirstChild("PlayerGui") or adornee

	local damageText: TextLabel = Instance.new("TextLabel")

	damageText.Name = "DamageText"
	damageText.BackgroundTransparency = 1
	damageText.Size = UDim2.fromScale(1, 1)
	damageText.AnchorPoint = Vector2.new(0.5, 0.5)
	damageText.Position = UDim2.fromScale(0.5, 0.5)
	damageText.Font = arcade
	v20 = p4 == "Heal"

	local text: string = tostring(p3)

	damageText.Text = (if v20 then "+" else "-") .. text

	if v20 then
		damageText.TextColor3 = Color3.fromRGB(80, 255, 105)
		damageText.TextStrokeColor3 = Color3.fromRGB(0, 45, 8)
	else
		damageText.TextColor3 = Color3.fromRGB(255, 64, 64)
		damageText.TextStrokeColor3 = Color3.fromRGB(35, 0, 0)
	end

	damageText.TextStrokeTransparency = 0
	damageText.TextScaled = true
	damageText.ZIndex = 10
	damageText.Parent = pixelDamagePopup

	local tweenInfo = TweenInfo.new(0.08, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	local v26 = UDim2.fromScale(1.18, 1.18)

	v20 = tweenService:Create(damageText, tweenInfo, { Size = v26 })

	local tweenInfo2 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v28 = UDim2.fromScale(1, 1)
	local v29: Tween = tweenService:Create(damageText, tweenInfo2, { Size = v28 })
	local tweenInfo3 = TweenInfo.new(0.75, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v31: Tween = tweenService:Create(pixelDamagePopup, tweenInfo3, { StudsOffset = v18 + vector3 })
	local tweenInfo4 = TweenInfo.new(0.75, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	local v33: Tween = tweenService:Create(damageText, tweenInfo4, { TextTransparency = 1, TextStrokeTransparency = 1 })

	v20:Play()
	v20.Completed:Connect(function()
		v29:Play()
	end)
	v31:Play()
	v33:Play()
	task.delay(0.75, function()
		local v34 = adornee

		t1[v34] = math.max((t1[v34] or 1) - 1, 0)

		if t1[v34] <= 0 then
			t1[v34] = nil
		end
	end)
	debris:AddItem(pixelDamagePopup, 0.9)
end

if v7 then
	v7.OnClientEvent:Connect(createDamagePopup)
end
