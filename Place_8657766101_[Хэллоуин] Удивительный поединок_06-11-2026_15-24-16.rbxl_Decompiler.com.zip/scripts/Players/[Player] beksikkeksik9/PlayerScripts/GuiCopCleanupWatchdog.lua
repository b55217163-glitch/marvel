-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local u1
local brk0: boolean = false
local players: Players = game:GetService("Players")
local userInputService: UserInputService = game:GetService("UserInputService")
local tweenService: TweenService = game:GetService("TweenService")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local lightingEffects = require(replicatedStorage:WaitForChild("LightingEffects"))
local u7 = nil
local system: Instance = replicatedStorage:FindFirstChild("System")
local v9: Instance = system

if v9 then
	v9 = system:FindFirstChild("GuiCopRunner")
end

if v9 and v9:IsA("ModuleScript") then
	local ok, result = pcall(require, v9)

	if ok then
		u7 = result
	end
end

local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

if not playerGui then
	playerGui = LocalPlayer:WaitForChild("PlayerGui")
end

local u14 = nil

if system then
	local percentageGuiUtility: Instance = system:FindFirstChild("PercentageGuiUtility")

	if percentageGuiUtility and percentageGuiUtility:IsA("ModuleScript") then
		local ok, result = pcall(require, percentageGuiUtility)

		if ok then
			u14 = result
		end
	end
end

local uDim2 = UDim2.new(0, 0, -0.2, 0)
local uDim22 = UDim2.new(0, 0, 1, 0)
local u20 = nil
local u21 = nil
local s1 = ""
local u23 = nil
local u24 = nil
local u25 = nil
local u26 = nil

local function getActiveRunnerCount()
	local guiCopActiveRuns: any = playerGui:GetAttribute("GuiCopActiveRuns")

	if typeof(guiCopActiveRuns) == "number" then
		return (math.max(0, guiCopActiveRuns))
	end

	return 0
end
local function hasActiveRunnerCutscene()
	local guiCopActiveRuns: any = playerGui:GetAttribute("GuiCopActiveRuns")

	return (if typeof(guiCopActiveRuns) == "number" then math.max(0, guiCopActiveRuns) else 0) > 0
end
local function runnerRecentlyEnded(p1)
	local guiCopLastRunEndedAt: any = playerGui:GetAttribute("GuiCopLastRunEndedAt")
	local u84: boolean = false

	if typeof(guiCopLastRunEndedAt) == "number" then
		u84 = p1 - guiCopLastRunEndedAt < 1.25
	end

	return u84
end
local function activeRunnerIsStale(p2)
	local guiCopActiveRuns: any = playerGui:GetAttribute("GuiCopActiveRuns")

	if (if typeof(guiCopActiveRuns) == "number" then math.max(0, guiCopActiveRuns) else 0) <= 0 then
		return false
	end

	local guiCopRunDeadlineAt: any = playerGui:GetAttribute("GuiCopRunDeadlineAt")

	if typeof(guiCopRunDeadlineAt) == "number" and p2 >= guiCopRunDeadlineAt then
		return true
	end

	local guiCopLastRunStartedAt: any = playerGui:GetAttribute("GuiCopLastRunStartedAt")

	if typeof(guiCopLastRunStartedAt) == "number" then
		return p2 - guiCopLastRunStartedAt >= 30
	end

	return true
end
local function clearStaleRunnerAttributes(p3)
	playerGui:SetAttribute("GuiCopActiveRuns", 0)
	playerGui:SetAttribute("GuiCopRunDeadlineAt", nil)
	playerGui:SetAttribute("GuiCopLastRunEndedAt", p3)
end
local function characterHasValues()
	local Character: Model = LocalPlayer.Character

	if not Character or not Character:FindFirstChild("Values") then
		return false
	end

	if LocalPlayer:GetAttribute("DUEL_SOUL") == true then
		return false
	end

	local characterCHOSENVALUE: Instance = Character:FindFirstChild("CharacterCHOSENVALUE")

	if characterCHOSENVALUE and characterCHOSENVALUE:IsA("StringValue") and characterCHOSENVALUE.Value == "Soul" then
		return false
	end

	return true
end
local function isTeamBattleSoulLocked()
	local u92: boolean = false

	if LocalPlayer:GetAttribute("DUEL_MODE_TYPE") == "TEAM_BATTLE" then
		u92 = true

		if LocalPlayer:GetAttribute("DUEL_SOUL") ~= true then
			u92 = LocalPlayer:GetAttribute("DUEL_ELIMINATED") == true
		end
	end

	return u92
end
local function hideMenuForTeamBattleSoul()
	local u93: boolean = false

	if LocalPlayer:GetAttribute("DUEL_MODE_TYPE") == "TEAM_BATTLE" then
		u93 = true

		if LocalPlayer:GetAttribute("DUEL_SOUL") ~= true then
			u93 = LocalPlayer:GetAttribute("DUEL_ELIMINATED") == true
		end
	end

	if not u93 then
		return
	end

	local menu: Instance = playerGui:FindFirstChild("Menu")

	if menu and menu:IsA("ScreenGui") then
		menu.Enabled = false

		local frame: Instance = menu:FindFirstChild("Frame")

		if frame and frame:IsA("GuiObject") then
			frame.Visible = false
		end

		local camForce: Instance = menu:FindFirstChild("CamForce")

		if camForce and camForce:IsA("LocalScript") then
			camForce.Enabled = false
		end

		local menuMusic: Instance = menu:FindFirstChild("MenuMusic")

		if menuMusic and menuMusic:IsA("Sound") then
			menuMusic:Stop()
		end
	end
end
local function setScreenGuiEnabled(p4, enabled)
	local foundChild: Instance = playerGui:FindFirstChild(p4)

	if foundChild and foundChild:IsA("ScreenGui") then
		foundChild.Enabled = enabled
	end
end
local function restoreCamera()
	local CurrentCamera: Camera = workspace.CurrentCamera
	local Character: Model = LocalPlayer.Character
	local humanoid = Character and Character:FindFirstChildOfClass("Humanoid")

	if CurrentCamera then
		CurrentCamera.CameraType = Enum.CameraType.Custom

		if humanoid then
			CurrentCamera.CameraSubject = humanoid
		end
	end
end
local function tweenBlackLine(p6, p7)
	if not p6 or not p6:IsA("GuiObject") then
		return
	end

	local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

	tweenService:Create(p6, tweenInfo, { Position = p7 }):Play()
end
local function hideAndRemoveBlackLineGui(p8, p9)
	local blackLineUp = p8:FindFirstChild("BlackLineUp")
	local blackLineDown = p8:FindFirstChild("BlackLineDown")

	tweenBlackLine(blackLineUp, uDim2)
	tweenBlackLine(blackLineDown, uDim22)

	if p8.Name ~= "CinLines" then
		task.delay(0.44999999999999996, function()
			if p8 and p8.Parent and (p9 == true or not u24()) then
				p8.Enabled = false
				p8.Parent = nil
			end
		end)
	end
end
local function getActiveGuiCopSignature()
	local t4: {[any]: any} = {}
	local guiCopActiveRuns: any = playerGui:GetAttribute("GuiCopActiveRuns")
	local v113 = if typeof(guiCopActiveRuns) == "number" then math.max(0, guiCopActiveRuns) else 0

	if v113 > 0 then
		local text: string = tostring(v113)

		table.insert(t4, "GuiCopRunnerActive:" .. text)
	end

	local Character: Model = LocalPlayer.Character

	if Character then
		for iterFirst, iterSecond in Character:GetDescendants() do
			if iterSecond:IsA("LocalScript") and (string.find(iterSecond.Name:lower(), "guicop", 1, true) or string.find(iterSecond.Name:lower(), "gui cop", 1, true)) then
				table.insert(t4, iterSecond:GetFullName())
			end
		end

		if #t4 <= 0 then
			return false, ""
		end

		table.sort(t4)

		return true, table.concat(t4, "|")
	end

	if #t4 > 0 then
		return true, table.concat(t4, "|")
	end

	return false, ""
end

u24 = function()
	return getActiveGuiCopSignature() == true
end

local function isTemporaryGuiCopBlackLines(p10)
	if not p10 or not p10:IsA("ScreenGui") then
		return false
	end

	if p10:GetAttribute("BlackLineCinematicActive") == true then
		return false
	end

	if p10.Name == "CinLines" or p10.Name == "GuiCopBlackLines" then
		return false
	end

	local u119: boolean = false

	if p10:FindFirstChild("BlackLineUp") ~= nil then
		u119 = p10:FindFirstChild("BlackLineDown") ~= nil
	end

	return u119
end

local t1: {[any]: any} = {
	"guicop",
	"gui cop",
	"finisher",
	"counter",
	"blackout",
	"blink",
	"scare",
	"jumpscare",
	"riddlerbomb",
	"facetape",
	"livestream",
	"localhit",
	"localblue",
	"impactframe"
}
local t2: {[any]: any} = {
	AdminPanel = true,
	CharacterGui = true,
	CharacterSpecial = true,
	CinLines = true,
	ClashTimingGui = true,
	Duel = true,
	DuelBlackScreen = true,
	DuelLoadingGui = true,
	DuelRoundTimerGui = true,
	Freecam = true,
	GameGuis = true,
	GuiCopBlackLines = true,
	ImpactFrameGui = true,
	LightScreen = true,
	MapChange = true,
	MapRoundResultsGui = true,
	MapTimerGui = true,
	MapVoteGui = true,
	Menu = true,
	MobileMovesetLayoutEditor = true,
	MoonKnightGui = true,
	Moveset = true,
	MSBlockDeathNotePaperPickerGui = true,
	MSBlockPhantomScarePickerGui = true,
	MSBlockPopupGui = true,
	PrivateDuelGui = true,
	RandomEvents = true,
	Ranked1v1Gui = true,
	RedScreen = true,
	RegionCheck = true,
	Transition = true,
	["UI thing"] = true,
	VecnaBossHealthBarGui = true,
	VideoGui = true,
	Vig = true
}
local t3: {[any]: any} = { RageScreenOverlay = true, BlackViewportOverlay = true }

local function looksLikeTemporaryEffectGui(p11)
	if not p11 or not p11:IsA("ScreenGui") then
		return false
	end

	if t2[p11.Name] then
		return false
	end

	if t3[p11.Name] then
		return not characterHasValues()
	end

	if p11:FindFirstChild("BlackLineDown", true) then
		return false
	end

	if isTemporaryGuiCopBlackLines(p11) then
		return true
	end

	local lowerText = p11.Name:lower()

	for key, value in t1 do
		if string.find(lowerText, value, 1, true) then
			return true
		end
	end

	for iterFirst, iterSecond in p11:GetDescendants() do
		local lowerText2 = iterSecond.Name:lower()

		for key2, value2 in t1 do
			if string.find(lowerText2, value2, 1, true) then
				return true
			end
		end
	end

	return false
end
local function cleanupTemporaryEffectGuisAfterRespawn()
	for iterFirst, iterSecond in playerGui:GetChildren() do
		if looksLikeTemporaryEffectGui(iterSecond) then
			iterSecond.Enabled = false
			iterSecond.Parent = nil
		end
	end
end
local function isVisibleCinematicBlackLine(p12)
	if not p12 or not p12:IsA("GuiObject") then
		return false
	end

	if p12.Name ~= "BlackLineUp" and p12.Name ~= "BlackLineDown" then
		return false
	end

	if not p12.Visible then
		return false
	end

	local v132 = p12:FindFirstAncestorWhichIsA("ScreenGui")

	if v132 and v132.Name == "Menu" then
		return false
	end

	if v132 and v132:GetAttribute("BlackLineCinematicActive") == true then
		return true
	end

	if v132 and v132.Enabled == false then
		return false
	end

	local scale = p12.Position.Y.Scale

	if p12.Name == "BlackLineUp" then
		return scale > -0.15
	end

	return scale < 0.98
end
local function hasVisibleCinematicBlackLines()
	for iterFirst, iterSecond in playerGui:GetDescendants() do
		if isVisibleCinematicBlackLine(iterSecond) then
			return true
		end
	end

	return false
end
local function hasGuiCopBlackLines()
	for iterFirst, iterSecond in playerGui:GetChildren() do
		if not not u25() or not not u24() then
			break
		end

		if isTemporaryGuiCopBlackLines(iterSecond) then
			return true
		end
	end

	return false
end
local function isCutsceneStateStillApplied()
	local CurrentCamera: Camera = workspace.CurrentCamera
	local moveset: Instance = playerGui:FindFirstChild("Moveset")
	local characterGui: Instance = playerGui:FindFirstChild("CharacterGui")
	local foundChild: Instance = playerGui:FindFirstChild("UI thing")
	local vig: Instance = playerGui:FindFirstChild("Vig")
	local v143 = hasGuiCopBlackLines()
	local v144, v145, v146 = playerGui:GetDescendants()
	local v147: boolean = false
	local u148

	for iterFirst, iterSecond in v144, v145, v146 do
		if isVisibleCinematicBlackLine(iterSecond) then
			u148 = true
			v147 = true

			break
		end
	end

	if not v147 then
		u148 = false
	end

	if not v143 and not u148 then
		if not u21 then
			return false
		end

		if CurrentCamera and CurrentCamera.CameraType == Enum.CameraType.Scriptable then
			return true
		end

		if moveset and moveset:IsA("ScreenGui") and not moveset.Enabled then
			return true
		end

		if characterGui and characterGui:IsA("ScreenGui") and not characterGui.Enabled then
			return true
		end

		if foundChild and foundChild:IsA("ScreenGui") and not foundChild.Enabled then
			return true
		end

		if vig and vig:IsA("ScreenGui") and not vig.Enabled then
			return true
		end

		return false
	end

	return true
end
local function forceRemoveBlackLineGui(p13)
	if not p13 or not p13.Parent then
		return
	end

	local foundChild = p13:FindFirstChild("BlackLineUp", true)
	local foundChild2 = p13:FindFirstChild("BlackLineDown", true)

	if foundChild and foundChild:IsA("GuiObject") then
		foundChild.Position = uDim2
		foundChild.Visible = false
	end

	if foundChild2 and foundChild2:IsA("GuiObject") then
		foundChild2.Position = uDim22
		foundChild2.Visible = false
	end

	if p13.Name == "CinLines" or p13.Name == "GuiCopBlackLines" then
		p13.Enabled = false

		return
	end

	p13.Enabled = false
	p13.Parent = nil
end
local function resetGuiCopBlackLines()
	local guiCopBlackLines: Instance = playerGui:FindFirstChild("GuiCopBlackLines")

	if not guiCopBlackLines or not guiCopBlackLines:IsA("ScreenGui") then
		return
	end

	local foundChild: Instance = guiCopBlackLines:FindFirstChild("BlackLineUp", true)
	local foundChild3: Instance = guiCopBlackLines:FindFirstChild("BlackLineDown", true)

	if foundChild and foundChild:IsA("GuiObject") then
		foundChild.Position = uDim2
		foundChild.Visible = false
		foundChild.BackgroundTransparency = 1
	end

	if foundChild3 and foundChild3:IsA("GuiObject") then
		foundChild3.Position = uDim22
		foundChild3.Visible = false
		foundChild3.BackgroundTransparency = 1
	end

	guiCopBlackLines.Enabled = false
end
local function resetCinLinesIfSafe(p14)
	local cinLines: Instance = playerGui:FindFirstChild("CinLines")

	if cinLines and cinLines:IsA("ScreenGui") and (workspace:GetAttribute("MapSwitching") ~= true or p14 == true) then
		local u159: boolean = p14 ~= true
		local foundChild: Instance = cinLines:FindFirstChild("BlackLineUp", true)
		local foundChild4: Instance = cinLines:FindFirstChild("BlackLineDown", true)

		if foundChild and foundChild:IsA("GuiObject") then
			foundChild.Position = uDim2
			foundChild.Visible = u159
			foundChild.BackgroundTransparency = u159 and foundChild.BackgroundTransparency or 1
		end

		if foundChild4 and foundChild4:IsA("GuiObject") then
			foundChild4.Position = uDim22
			foundChild4.Visible = u159
			foundChild4.BackgroundTransparency = u159 and foundChild4.BackgroundTransparency or 1
		end

		cinLines.Enabled = u159
	end

	resetGuiCopBlackLines()
end
local function isMenuOpen()
	local menu: Instance = playerGui:FindFirstChild("Menu")

	if menu and menu:IsA("ScreenGui") and menu.Enabled == true then
		local frame: Instance = menu:FindFirstChild("Frame")

		if frame and frame:IsA("GuiObject") and frame.Visible == false then
			return false
		end

		return true
	end

	return false
end
local function forceHideMenuBlackLineObject(p15)
	if not p15 or not p15:IsA("GuiObject") then
		return
	end

	p15.Visible = false
	p15.BackgroundTransparency = 1
	p15.Position = p15.Name == "BlackLineUp" and UDim2.new(0, 0, -1, 0) or UDim2.new(0, 0, 2, 0)

	local v165 = p15:FindFirstAncestorWhichIsA("ScreenGui")

	if v165 and v165.Name ~= "Menu" then
		v165.Enabled = false

		if v165.Name ~= "CinLines" and v165.Name ~= "GuiCopBlackLines" then
			v165.Parent = nil
		end
	end
end
local function cleanupMenuBlackBars()
	if not isMenuOpen() then
		return
	end

	cleanupTemporaryEffectGuisAfterRespawn()

	for iterFirst, iterSecond in playerGui:GetDescendants() do
		if iterSecond.Name == "BlackLineUp" or iterSecond.Name == "BlackLineDown" then
			forceHideMenuBlackLineObject(iterSecond)
		end
	end

	resetCinLinesIfSafe(true)
end

u26 = function()
	for iterFirst, iterSecond in playerGui:GetChildren() do
		if isTemporaryGuiCopBlackLines(iterSecond) then
			forceRemoveBlackLineGui(iterSecond)
		end
	end
end

local function tweenGuiObjectOut(p19, p20)
	local v172 = p20 or 0.35

	if not p19:IsA("ImageLabel") and not p19:IsA("ImageButton") then
		if not p19:IsA("TextLabel") and not p19:IsA("TextButton") and not p19:IsA("TextBox") then
			if p19:IsA("Frame") or p19:IsA("ScrollingFrame") or p19:IsA("ViewportFrame") then
				local tweenInfo = TweenInfo.new(v172, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

				tweenService:Create(p19, tweenInfo, { BackgroundTransparency = 1 }):Play()
			end

			return
		end

		local tweenInfo = TweenInfo.new(v172, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(p19, tweenInfo, { TextTransparency = 1, BackgroundTransparency = 1 }):Play()

		return
	end

	local tweenInfo = TweenInfo.new(v172, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

	tweenService:Create(p19, tweenInfo, { ImageTransparency = 1 }):Play()
end
local function resetCinematicOverlays(p21)
	for iterFirst, iterSecond in playerGui:GetDescendants() do
		if iterSecond:IsA("GuiObject") then
			local lowerText = string.lower(iterSecond.Name)
			local u180: boolean = false

			if string.find(lowerText, "vign", 1, true) or string.find(lowerText, "vignette", 1, true) or string.find(lowerText, "darthvader", 1, true) or string.find(lowerText, "cinematic", 1, true) then
				u180 = true
			end

			if u180 then
				tweenGuiObjectOut(iterSecond, p21 or 0.35)
			end
		end
	end
end
local function resetCinematicEffects(p22)
	pcall(function()
		lightingEffects.ResetDefault({
			ColorDuration = p22 or 0.35,
			BlurDuration = p22 or 0.35,
			DepthDuration = p22 or 0.35,
			BloomDuration = p22 or 0.5,
			LightingDuration = p22 or 0.5,
			SunRaysDuration = p22 or 0.5
		})

		local lighting: Lighting = game:GetService("Lighting")
		local tweenInfo = TweenInfo.new(p22 or 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(lighting, tweenInfo, { ExposureCompensation = 0 }):Play()
	end)
	resetCinematicOverlays(p22 or 0.35)
end
local function forceRunnerCleanup()
	if u7 and typeof(u7.ForceCleanup) == "function" then
		pcall(function()
			u7.ForceCleanup()
		end)

		return
	end

	local v182 = os.clock()

	playerGui:SetAttribute("GuiCopActiveRuns", 0)
	playerGui:SetAttribute("GuiCopRunDeadlineAt", nil)
	playerGui:SetAttribute("GuiCopLastRunEndedAt", v182)
end

u25 = function()
	local CurrentCamera: Camera = workspace.CurrentCamera

	if CurrentCamera and CurrentCamera.CameraType == Enum.CameraType.Scriptable then
		return true
	end

	local Character: Model = LocalPlayer.Character
	local camForce = Character and Character:FindFirstChild("CamForce")

	if camForce and camForce:IsA("LocalScript") and camForce.Disabled == false then
		return true
	end

	local characterGui: Instance = playerGui:FindFirstChild("CharacterGui")

	if characterGui and characterGui:IsA("ScreenGui") and characterGui.Enabled == false then
		return true
	end

	local foundChild: Instance = playerGui:FindFirstChild("UI thing")

	if foundChild and foundChild:IsA("ScreenGui") and foundChild.Enabled == false then
		return true
	end

	local vig: Instance = playerGui:FindFirstChild("Vig")

	if vig and vig:IsA("ScreenGui") and vig.Enabled == false then
		return true
	end

	return false
end

local function cleanupStaleGuiCopState()
	forceRunnerCleanup()

	local characterGui: Instance = playerGui:FindFirstChild("CharacterGui")

	if characterGui and characterGui:IsA("ScreenGui") then
		characterGui.Enabled = true
	end

	local foundChild: Instance = playerGui:FindFirstChild("UI thing")

	if foundChild and foundChild:IsA("ScreenGui") then
		foundChild.Enabled = true
	end

	local vig: Instance = playerGui:FindFirstChild("Vig")

	if vig and vig:IsA("ScreenGui") then
		vig.Enabled = true
	end

	local enabled = characterHasValues()
	local moveset: Instance = playerGui:FindFirstChild("Moveset")

	if moveset and moveset:IsA("ScreenGui") then
		moveset.Enabled = enabled
	end

	userInputService.MouseIconEnabled = true

	if u14 then
		pcall(function()
			if u14.ForceRestore then
				u14.ForceRestore(50)
			elseif u14.SetEnabled then
				u14.SetEnabled(true, 50)
			end
		end)
	end

	for iterFirst, iterSecond in playerGui:GetChildren() do
		if isTemporaryGuiCopBlackLines(iterSecond) then
			hideAndRemoveBlackLineGui(iterSecond, true)
		elseif iterSecond:IsA("ScreenGui") and (not not iterSecond:FindFirstChild("BlackLineUp", true) or not not iterSecond:FindFirstChild("BlackLineDown", true)) then
			forceRemoveBlackLineGui(iterSecond)
		end
	end

	resetGuiCopBlackLines()
	resetCinLinesIfSafe(true)
	u23 = nil

	local CurrentCamera: Camera = workspace.CurrentCamera
	local Character: Model = LocalPlayer.Character
	local humanoid = Character and Character:FindFirstChildOfClass("Humanoid")

	if CurrentCamera then
		CurrentCamera.CameraType = Enum.CameraType.Custom

		if humanoid then
			CurrentCamera.CameraSubject = humanoid
		end
	end

	local n1: number = 0.5

	pcall(function()
		lightingEffects.ResetDefault({
			ColorDuration = n1 or 0.35,
			BlurDuration = n1 or 0.35,
			DepthDuration = n1 or 0.35,
			BloomDuration = n1 or 0.5,
			LightingDuration = n1 or 0.5,
			SunRaysDuration = n1 or 0.5
		})

		local lighting: Lighting = game:GetService("Lighting")
		local tweenInfo = TweenInfo.new(n1 or 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(lighting, tweenInfo, { ExposureCompensation = 0 }):Play()
	end)
	resetCinematicOverlays(0.5)
end
local function cleanupAfterDeathOrRespawn()
	u20 = nil
	u21 = nil
	s1 = ""
	u26()
	cleanupTemporaryEffectGuisAfterRespawn()
	resetCinLinesIfSafe(false)
	cleanupStaleGuiCopState()

	for _, v in ipairs({ 0.15, 0.4, 0.8, 1.5, 2.5 }) do
		task.delay(v, function()
			u26()
			cleanupTemporaryEffectGuisAfterRespawn()
			resetCinLinesIfSafe()
		end)
	end
end
local function cleanupForCharacterReplacement()
	u20 = nil
	u21 = nil
	s1 = ""
	u26()
	cleanupTemporaryEffectGuisAfterRespawn()
	resetCinLinesIfSafe(false)
	forceRunnerCleanup()

	for _, v in ipairs({ 0.05, 0.15, 0.35, 0.75, 1.25, 2 }) do
		task.delay(v, function()
			u26()
			cleanupTemporaryEffectGuisAfterRespawn()
			resetCinLinesIfSafe(false)
		end)
	end
end
local function hookHumanoidDeath(character)
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")

	if not humanoid then
		return
	end

	humanoid.Died:Connect(function()
		cleanupAfterDeathOrRespawn()
	end)
end

LocalPlayer.CharacterRemoving:Connect(function()
	cleanupForCharacterReplacement()
end)
LocalPlayer.CharacterAdded:Connect(function(character: Model)
	cleanupAfterDeathOrRespawn()

	local humanoid = character and character:FindFirstChildOfClass("Humanoid")

	if humanoid then
		humanoid.Died:Connect(function()
			cleanupAfterDeathOrRespawn()
		end)
	end

	task.delay(1, function()
		if hasGuiCopBlackLines() and not u24() then
			cleanupStaleGuiCopState()
		end
	end)
end);
(function()
	local function attach(p16)
		if not p16 or not p16:IsA("ScreenGui") then
			return
		end

		p16:GetPropertyChangedSignal("Enabled"):Connect(function()
			if p16.Enabled then
				cleanupMenuBlackBars()
			end
		end)

		if p16.Enabled then
			cleanupMenuBlackBars()
		end
	end

	attach(playerGui:FindFirstChild("Menu"))
	playerGui.ChildAdded:Connect(function(p17: Instance)
		if p17.Name == "Menu" then
			attach(p17)

			return
		end

		if p17:IsA("ScreenGui") then
			task.defer(cleanupMenuBlackBars)
			task.delay(0.1, cleanupMenuBlackBars)
			task.delay(0.35, cleanupMenuBlackBars)
		end
	end)
	playerGui.DescendantAdded:Connect(function(p18: Instance)
		if isMenuOpen() and (p18.Name == "BlackLineUp" or p18.Name == "BlackLineDown") then
			task.defer(function()
				forceHideMenuBlackLineObject(p18)
			end)
		end
	end)
end)()

if LocalPlayer.Character then
	local Character: Model = LocalPlayer.Character
	local v65 = Character

	if v65 then
		v65 = Character:FindFirstChildOfClass("Humanoid")
	end

	if v65 then
		v65.Died:Connect(function()
			cleanupAfterDeathOrRespawn()
		end)
	end
end

LocalPlayer:GetAttributeChangedSignal("DUEL_SOUL"):Connect(hideMenuForTeamBattleSoul)
LocalPlayer:GetAttributeChangedSignal("DUEL_ELIMINATED"):Connect(hideMenuForTeamBattleSoul)
LocalPlayer:GetAttributeChangedSignal("DUEL_MODE_TYPE"):Connect(hideMenuForTeamBattleSoul)
task.defer(hideMenuForTeamBattleSoul)

while true do
	brk0 = false

	local v66 = os.clock()
	local v67, v68 = getActiveGuiCopSignature()

	for iterFirst, iterSecond in playerGui:GetDescendants() do
		if isVisibleCinematicBlackLine(iterSecond) then
			local u1 = true
			local v71 = isCutsceneStateStillApplied()
			local u72: boolean = false

			if LocalPlayer:GetAttribute("DUEL_MODE_TYPE") == "TEAM_BATTLE" then
				u72 = true

				if LocalPlayer:GetAttribute("DUEL_SOUL") ~= true then
					u72 = LocalPlayer:GetAttribute("DUEL_ELIMINATED") == true
				end
			end

			if u72 then
				hideMenuForTeamBattleSoul()
				cleanupTemporaryEffectGuisAfterRespawn()
				resetCinLinesIfSafe()
				task.wait(0.25)
			elseif isMenuOpen() then
				cleanupMenuBlackBars()
				cleanupTemporaryEffectGuisAfterRespawn()
				task.wait(0.03)
			elseif (if typeof((playerGui:GetAttribute("GuiCopActiveRuns"))) == "number" then math.max(0, (playerGui:GetAttribute("GuiCopActiveRuns"))) else 0) > 0 then
				local guiCopActiveRuns: any = playerGui:GetAttribute("GuiCopActiveRuns")
				local u74

				if (if typeof(guiCopActiveRuns) == "number" then math.max(0, guiCopActiveRuns) else 0) <= 0 then
					u74 = false
				elseif typeof((playerGui:GetAttribute("GuiCopRunDeadlineAt"))) == "number" and v66 >= playerGui:GetAttribute("GuiCopRunDeadlineAt") then
					u74 = true
				else
					local guiCopLastRunStartedAt: any = playerGui:GetAttribute("GuiCopLastRunStartedAt")

					u74 = if typeof(guiCopLastRunStartedAt) == "number" then v66 - guiCopLastRunStartedAt >= 30 else true
				end

				if u74 then
					playerGui:SetAttribute("GuiCopActiveRuns", 0)
					playerGui:SetAttribute("GuiCopRunDeadlineAt", nil)
					playerGui:SetAttribute("GuiCopLastRunEndedAt", v66)
					cleanupStaleGuiCopState()
					u20 = nil
					u21 = nil
					s1 = ""
				else
					u21 = v66
					u20 = u20 or v66
				end

				u23 = nil
				task.wait(0.25)
			else
				local guiCopLastRunEndedAt: any = playerGui:GetAttribute("GuiCopLastRunEndedAt")
				local u77: boolean = false

				if typeof(guiCopLastRunEndedAt) == "number" then
					u77 = v66 - guiCopLastRunEndedAt < 1.25
				end

				if u77 then
				else
					u23 = if u1 then u23 or v66 else nil

					if u1 and not v67 and not ((if typeof((playerGui:GetAttribute("GuiCopActiveRuns"))) == "number" then math.max(0, (playerGui:GetAttribute("GuiCopActiveRuns"))) else 0) > 0) and not u25() and u23 and v66 - u23 >= 1.25 then
						cleanupStaleGuiCopState()
						u20 = nil
						u21 = nil
						s1 = ""
						u23 = nil
						task.wait(0.25)
						brk0 = true

						break
					end

					if v67 then
						u21 = v66

						if v68 ~= s1 then
							s1 = v68
							u20 = v66
						elseif not u20 then
							u20 = v66
						elseif v66 - u20 >= 30 and v71 then
							cleanupStaleGuiCopState()
							u20 = nil
							u21 = nil
							s1 = ""
						end
					elseif not v71 then
						u20 = nil
						u21 = nil
						s1 = ""
					else
						local v78 = u21 and v66 - u21 >= 1.25
						local u79 = not u21 and hasGuiCopBlackLines() and u20

						if u79 then
							u79 = false

							if v66 - u20 >= 1.25 then
								u79 = not u25()
							end
						end

						if not u20 then
							u20 = v66
						elseif v78 or u79 or u20 and v66 - u20 >= 30 then
							cleanupStaleGuiCopState()
							u20 = nil
							u21 = nil
							s1 = ""
						end
					end

					if u23 and u1 and v66 - u23 >= 12 and (not v67 or not not u20 and v66 - u20 >= 12) then
						cleanupStaleGuiCopState()
						u20 = nil
						u21 = nil
						s1 = ""
						u23 = nil
					end
				end

				task.wait(0.25)
			end

			brk0 = true

			break
		end
	end

	if brk0 then
		continue
	end

	u1 = false
end
