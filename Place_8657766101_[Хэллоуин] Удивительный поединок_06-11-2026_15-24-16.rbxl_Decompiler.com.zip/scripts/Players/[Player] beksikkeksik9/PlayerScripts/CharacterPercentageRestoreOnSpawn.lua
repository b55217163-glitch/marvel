-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
local percentageGuiUtility = nil

pcall(function()
	local system: Instance = replicatedStorage:WaitForChild("System")

	percentageGuiUtility = require(system:WaitForChild("PercentageGuiUtility"))
end)

local function enableCharacterPercentages(p1)
	if not p1 then
		return
	end

	for _, v in ipairs(p1:GetDescendants()) do
		if v.Name == "Percentage" and v:IsA("BillboardGui") then
			v.Enabled = true

			if v.MaxDistance <= 0 then
				v.MaxDistance = 50
			end
		end
	end
end
local function restoreForSpawnedCharacter()
	playerGui:SetAttribute("GuiCopActiveRuns", 0)
	playerGui:SetAttribute("GuiCopRunDeadlineAt", nil)
	playerGui:SetAttribute("GuiCopLastRunStartedAt", nil)
	playerGui:SetAttribute("GuiCopLastRunEndedAt", os.clock())
	workspace:SetAttribute("PercentageBillboardsSuppressed", false)

	if percentageGuiUtility then
		pcall(function()
			if percentageGuiUtility.ForceRestore then
				percentageGuiUtility.ForceRestore(50)
			elseif percentageGuiUtility.SetEnabled then
				percentageGuiUtility.SetEnabled(true, 50)
			end
		end)
	end

	enableCharacterPercentages(LocalPlayer.Character)
end
local function scheduleRestore()
	restoreForSpawnedCharacter()

	for _, v in ipairs({ 0.1, 0.35, 0.75, 1.5, 2.5 }) do
		task.delay(v, function()
			restoreForSpawnedCharacter()
		end)
	end
end

LocalPlayer:GetAttributeChangedSignal("ForceRestoreBillboardsTick"):Connect(scheduleRestore)
LocalPlayer.CharacterAdded:Connect(scheduleRestore)
scheduleRestore()
