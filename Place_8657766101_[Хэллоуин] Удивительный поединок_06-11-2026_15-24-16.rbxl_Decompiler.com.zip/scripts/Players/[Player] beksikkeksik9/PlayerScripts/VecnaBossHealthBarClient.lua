-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local playerGui: Instance = LocalPlayer:FindFirstChildOfClass("PlayerGui")

if not playerGui then
	playerGui = LocalPlayer:FindFirstChild("PlayerGui")
end

if not playerGui then
	return
end

local vecnaBossHealthBarGui: ScreenGui = Instance.new("ScreenGui")

vecnaBossHealthBarGui.Name = "VecnaBossHealthBarGui"
vecnaBossHealthBarGui.ResetOnSpawn = false
vecnaBossHealthBarGui.IgnoreGuiInset = true
vecnaBossHealthBarGui.Enabled = false
vecnaBossHealthBarGui.Parent = playerGui

local container: Frame = Instance.new("Frame")

container.Name = "Container"
container.AnchorPoint = Vector2.new(0.5, 0)
container.Position = UDim2.fromScale(0.5, 0.06)
container.Size = UDim2.fromScale(0.5, 0.028)
container.BackgroundTransparency = 1
container.Parent = vecnaBossHealthBarGui

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.fromScale(0, -0.95)
title.Size = UDim2.fromScale(1, 0.75)
title.Font = Enum.Font.Arcade
title.Text = "BOSS"
title.TextColor3 = Color3.fromRGB(215, 190, 255)
title.TextStrokeTransparency = 0.35
title.TextScaled = true
title.Parent = container

local back: Frame = Instance.new("Frame")

back.Name = "Back"
back.Size = UDim2.fromScale(1, 1)
back.BackgroundColor3 = Color3.fromRGB(18, 10, 28)
back.BorderSizePixel = 0
back.Parent = container

local uiCorner: UICorner = Instance.new("UICorner")

uiCorner.CornerRadius = UDim.new(0, 5)
uiCorner.Parent = back

local uiStroke: UIStroke = Instance.new("UIStroke")

uiStroke.Color = Color3.fromRGB(135, 75, 210)
uiStroke.Thickness = 2
uiStroke.Transparency = 0.08
uiStroke.Parent = back

local fill: Frame = Instance.new("Frame")

fill.Name = "Fill"
fill.Size = UDim2.fromScale(1, 1)
fill.BackgroundColor3 = Color3.fromRGB(125, 38, 210)
fill.BorderSizePixel = 0
fill.Parent = back

local uiCorner2: UICorner = Instance.new("UICorner")

uiCorner2.CornerRadius = UDim.new(0, 5)
uiCorner2.Parent = fill

local glow: Frame = Instance.new("Frame")

glow.Name = "Glow"
glow.BackgroundColor3 = Color3.fromRGB(210, 120, 255)
glow.BackgroundTransparency = 0.45
glow.BorderSizePixel = 0
glow.Size = UDim2.fromScale(1, 0.22)
glow.Parent = fill

local healthText: TextLabel = Instance.new("TextLabel")

healthText.Name = "HealthText"
healthText.BackgroundTransparency = 1
healthText.Size = UDim2.fromScale(1, 1)
healthText.Font = Enum.Font.Arcade
healthText.TextColor3 = Color3.fromRGB(245, 235, 255)
healthText.TextStrokeTransparency = 0.4
healthText.TextScaled = true
healthText.Parent = back

local n1 = 1
local u17 = nil

local function getLocalRoot()
	local Character: Model = LocalPlayer.Character
	local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")

	if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
		return humanoidRootPart
	end

	return nil
end
local function getBoss()
	local v22 = nil
	local v23 = nil
	local v24 = nil
	local Character: Model = LocalPlayer.Character
	local characterHumanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
	local v27 = if characterHumanoidRootPart and characterHumanoidRootPart:IsA("BasePart") then characterHumanoidRootPart else nil
	local n1 = math.huge

	for iterFirst, value in { "VecnaBoss", "Vecna" }, nil, nil do
		local value: Instance = workspace:FindFirstChild(value)

		if value and value:IsA("Model") then
			local humanoid: Instance = value:FindFirstChildOfClass("Humanoid")
			local humanoidRootPart: Instance = value:FindFirstChild("HumanoidRootPart")

			if humanoid and humanoid.Health > 0 and humanoidRootPart and humanoidRootPart:IsA("BasePart") then
				local v34 = v27 and (humanoidRootPart.Position - v27.Position).Magnitude or 0

				if n1 > v34 then
					v22 = value
					v23 = humanoid
					v24 = humanoidRootPart
					n1 = v34
				end
			end
		end
	end

	return v22, v23, v24
end

runService.RenderStepped:Connect(function()
	local v35, v36, v37 = getBoss()
	local Character: Model = LocalPlayer.Character
	local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
	local v40 = if humanoidRootPart and humanoidRootPart:IsA("BasePart") then humanoidRootPart else nil

	if not v36 or not v37 or not v40 or v36.Health <= 0 then
		vecnaBossHealthBarGui.Enabled = false

		return
	end

	if (v37.Position - v40.Position).Magnitude > 260 then
		vecnaBossHealthBarGui.Enabled = false

		return
	end

	vecnaBossHealthBarGui.Enabled = true

	local v41 = v35:GetAttribute("BossDisplayName") or string.upper(v35.Name)

	title.Text = tostring(v41)

	local health = v36.Health

	v41 = math.max(v36.MaxHealth, 1)

	local v43 = math.clamp(health / v41, 0, 1)
	local stringFormat = string.format
	local roundedUp = math.ceil(v36.Health)
	local roundedUp2 = math.ceil(v36.MaxHealth)

	healthText.Text = stringFormat("%d / %d", roundedUp, roundedUp2)

	if math.abs(v43 - n1) > 0.005 then
		n1 = v43

		if u17 then
			u17:Cancel()
		end

		local tweenInfo = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v48 = UDim2.fromScale(v43, 1)

		u17 = tweenService:Create(fill, tweenInfo, { Size = v48 })
		u17:Play()
	end
end)
