-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local LocalPlayer: Player = game:GetService("Players").LocalPlayer
local system: Instance = game:GetService("ReplicatedStorage"):WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local t1: {[any]: any} = {
	MoveOne = "Oneletter",
	MoveTwo = "TwoLetter",
	MoveThree = "ThirdLetter",
	MoveFour = "FourLetter",
	MoveFive = "FiveLetter",
	SpecialMove = "ELetter",
	Combat = "M1Letter",
	Guard = "FLetter",
	MoonKnightForm = "EightLetter",
	MrKnightForm = "NineLetter"
}
local t2: {[any]: any} = {
	MouseButton1 = "M1",
	MouseButton2 = "M2",
	MouseBackButton = "M4",
	MouseNoButton = "Mouse",
	MouseLeftButton = "M1",
	MouseRightButton = "M2",
	MouseMiddleButton = "M3",
	LeftShift = "Shift",
	RightShift = "RShift",
	LeftControl = "Ctrl",
	RightControl = "RCtrl",
	LeftAlt = "Alt",
	RightAlt = "RAlt",
	One = "1",
	Two = "2",
	Three = "3",
	Four = "4",
	Five = "5",
	Six = "6",
	Seven = "7",
	Eight = "8",
	Nine = "9",
	Zero = "0",
	KeypadZero = "0",
	KeypadOne = "1",
	KeypadTwo = "2",
	KeypadThree = "3",
	KeypadFour = "4",
	KeypadFive = "5",
	KeypadSix = "6",
	KeypadSeven = "7",
	KeypadEight = "8",
	KeypadNine = "9"
}

local function formatBinding(p1)
	if p1 and p1 ~= "" then
		return t2[p1] or p1
	end

	return "-"
end
local function getHoldFrame()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")
	local moveset: Instance = playerGui and playerGui:FindFirstChild("Moveset")
	local v14: Instance = moveset

	if v14 then
		v14 = moveset:FindFirstChild("Frame")
	end

	return v14 and v14:FindFirstChild("Hold")
end
local function updateMoveLetters()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")
	local moveset: Instance = playerGui and playerGui:FindFirstChild("Moveset")
	local v17: Instance = moveset

	if v17 then
		v17 = moveset:FindFirstChild("Frame")
	end

	local v18: Instance = v17

	if v18 then
		v18 = v17:FindFirstChild("Hold")
	end

	if not v18 then
		return
	end

	for k, v in pairs(t1) do
		local v: Instance = v18:FindFirstChild(v)

		if v and v:IsA("TextLabel") then
			local v22 = controlsRuntime.GetBinding(LocalPlayer, k, "Keyboard")

			v.Text = if v22 and v22 ~= "" then t2[v22] or v22 else "-"
		end
	end
end
local function connectBindingsFolder(p2)
	p2.DescendantAdded:Connect(function(p3)
		if p3:IsA("StringValue") then
			p3.Changed:Connect(updateMoveLetters)
			updateMoveLetters()
		end
	end)
	p2.DescendantRemoving:Connect(updateMoveLetters)

	for _, v in ipairs(p2:GetDescendants()) do
		if v:IsA("StringValue") then
			v.Changed:Connect(updateMoveLetters)
		end
	end
end

LocalPlayer.CharacterAdded:Connect(function()
	task.wait(1)
	updateMoveLetters()
end)
LocalPlayer:WaitForChild("PlayerGui").ChildAdded:Connect(function(p4: Instance)
	if p4.Name == "Moveset" then
		task.wait(0.2)
		updateMoveLetters()
	end
end)

local controlsBindings: Instance = LocalPlayer:WaitForChild("ControlsBindings", 10)

if controlsBindings then
	connectBindingsFolder(controlsBindings)
end

updateMoveLetters()
