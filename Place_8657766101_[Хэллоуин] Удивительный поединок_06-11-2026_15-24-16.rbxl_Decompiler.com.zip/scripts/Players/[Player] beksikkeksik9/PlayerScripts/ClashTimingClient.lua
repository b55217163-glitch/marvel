-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local runService: RunService = game:GetService("RunService")
local contextActionService: ContextActionService = game:GetService("ContextActionService")
local userInputService: UserInputService = game:GetService("UserInputService")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local clashTiming = replicatedStorage.Remotes:WaitForChild("ClashTiming")
local clashTimingStart = clashTiming.Start
local clashTimingPress = clashTiming.Press
local clashTimingFeedback = clashTiming.Feedback
local clashTimingFinish = clashTiming.Finish
local u13 = nil
local connection = nil
local connection2 = nil
local screenGui = nil
local u17 = nil
local color3 = Color3.fromRGB(8, 8, 10)

Color3.fromRGB(3, 3, 4)

local color32 = Color3.fromRGB(255, 70, 70)
local color33 = Color3.fromRGB(255, 180, 70)
local color34 = Color3.fromRGB(245, 245, 245)
local color35 = Color3.fromRGB(255, 170, 60)
local color36 = Color3.fromRGB(255, 90, 90)
local color37 = Color3.fromRGB(180, 40, 40)
local color38 = Color3.fromRGB(255, 210, 90)
local color39 = Color3.fromRGB(120, 120, 120)

local function cleanup()
	contextActionService:UnbindAction("ClashTimingPress")

	if u17 then
		u17:Cancel()
		u17 = nil
	end

	if connection then
		connection:Disconnect()
		connection = nil
	end

	if connection2 then
		connection2:Disconnect()
		connection2 = nil
	end

	if screenGui then
		screenGui:Destroy()
		screenGui = nil
	end

	u13 = nil
end
local function markerAt(p1)
	local n1 = (u13.MarkerStart + u13.Direction * u13.BarSpeed * (p1 - u13.StartTime)) % 2

	if n1 <= 1 then
		return n1
	end

	return 2 - n1
end
local function makeStroke(parent, p3, p4, p5)
	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = p3
	uiStroke.Thickness = p4 or 1
	uiStroke.Transparency = p5 or 0
	uiStroke.Parent = parent

	return uiStroke
end
local function makeCorner(parent, p7)
	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = p7 or UDim.new(0, 0)
	uiCorner.Parent = parent

	return uiCorner
end
local function makeGradient(parent, p9, p10, p11)
	local uiGradient: UIGradient = Instance.new("UIGradient")
	local colorSequenceNew = ColorSequence.new
	local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, p9)

	uiGradient.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, p10) })
	uiGradient.Rotation = p11 or 0
	uiGradient.Parent = parent

	return uiGradient
end
local function createGui(p12)
	screenGui = Instance.new("ScreenGui")
	screenGui.Name = "ClashTimingGui"
	screenGui.ResetOnSpawn = false
	screenGui.IgnoreGuiInset = true
	screenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

	local main: Frame = Instance.new("Frame")

	main.Name = "Main"
	main.AnchorPoint = Vector2.new(0.5, 0.5)
	main.Position = UDim2.fromScale(0.5, 0.58)
	main.Size = UDim2.fromScale(0.5, 0.19)
	main.BackgroundColor3 = color3
	main.BackgroundTransparency = 0.5
	main.BorderSizePixel = 0
	main.Parent = screenGui

	local color310 = Color3.fromRGB(255, 255, 255)
	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = color310
	uiStroke.Thickness = 1.5
	uiStroke.Transparency = 0.35
	uiStroke.Parent = main

	local title: TextLabel = Instance.new("TextLabel")

	title.Name = "Title"
	title.BackgroundTransparency = 1
	title.Position = UDim2.fromScale(0.16, 0.05)
	title.Size = UDim2.fromScale(0.68, 0.16)
	title.Text = "CLASH"
	title.TextScaled = true
	title.Font = Enum.Font.Arcade
	title.TextColor3 = color34
	title.Parent = main

	local sub: TextLabel = Instance.new("TextLabel")

	sub.Name = "Sub"
	sub.BackgroundTransparency = 1
	sub.Position = UDim2.fromScale(0.08, 0.2)
	sub.Size = UDim2.fromScale(0.84, 0.11)
	sub.Text = "AGAINST " .. string.upper(p12)
	sub.TextScaled = true
	sub.Font = Enum.Font.Arcade
	sub.TextColor3 = color34
	sub.Parent = main

	local score: TextLabel = Instance.new("TextLabel")

	score.Name = "Score"
	score.BackgroundTransparency = 1
	score.Position = UDim2.fromScale(0.07, 0.33)
	score.Size = UDim2.fromScale(0.86, 0.1)
	score.Text = "HITS 0   MISSES 0"
	score.TextScaled = true
	score.Font = Enum.Font.Arcade
	score.TextColor3 = color34
	score.Parent = main

	local bar: Frame = Instance.new("Frame")

	bar.Name = "Bar"
	bar.AnchorPoint = Vector2.new(0.5, 0.5)
	bar.Position = UDim2.fromScale(0.5, 0.57)
	bar.Size = UDim2.fromScale(0.86, 0.17)
	bar.BackgroundColor3 = Color3.fromRGB(15, 15, 18)
	bar.BorderSizePixel = 0
	bar.Parent = main

	local color311 = Color3.fromRGB(255, 255, 255)
	local uiStroke2: UIStroke = Instance.new("UIStroke")

	uiStroke2.Color = color311
	uiStroke2.Thickness = 1
	uiStroke2.Transparency = 0.5
	uiStroke2.Parent = bar

	local green: Frame = Instance.new("Frame")

	green.Name = "Green"
	green.Position = UDim2.fromScale(u13.GreenMin, 0)
	green.Size = UDim2.fromScale(u13.GreenMax - u13.GreenMin, 1)
	green.BackgroundColor3 = color35
	green.BorderSizePixel = 0
	green.Parent = bar

	local uiStroke3: UIStroke = Instance.new("UIStroke")

	uiStroke3.Color = color34
	uiStroke3.Thickness = 1
	uiStroke3.Transparency = 0.35
	uiStroke3.Parent = green
	makeGradient(green, color35, color36, 0)

	local glow: Frame = Instance.new("Frame")

	glow.Name = "Glow"
	glow.AnchorPoint = Vector2.new(0.5, 0.5)
	glow.Position = UDim2.fromScale(0.5, 0.5)
	glow.Size = UDim2.fromScale(1.12, 1.25)
	glow.BackgroundColor3 = color35
	glow.BackgroundTransparency = 0.7
	glow.BorderSizePixel = 0
	glow.ZIndex = green.ZIndex - 1
	glow.Parent = green

	local center: Frame = Instance.new("Frame")

	center.Name = "Center"
	center.AnchorPoint = Vector2.new(0.5, 0.5)
	center.Position = UDim2.fromScale(0.5, 0.5)
	center.Size = UDim2.fromScale(0.08, 1.1)
	center.BackgroundColor3 = color34
	center.BorderSizePixel = 0
	center.Parent = green

	local marker: Frame = Instance.new("Frame")

	marker.Name = "Marker"
	marker.AnchorPoint = Vector2.new(0.5, 0.5)
	marker.Position = UDim2.fromScale(u13.MarkerStart, 0.5)
	marker.Size = UDim2.fromScale(0.018, 1.9)
	marker.BackgroundColor3 = color34
	marker.BorderSizePixel = 0
	marker.Parent = bar

	local color312 = Color3.fromRGB(0, 0, 0)
	local uiStroke4: UIStroke = Instance.new("UIStroke")

	uiStroke4.Color = color312
	uiStroke4.Thickness = 1
	uiStroke4.Transparency = 0
	uiStroke4.Parent = marker

	local markerGlow: Frame = Instance.new("Frame")

	markerGlow.Name = "MarkerGlow"
	markerGlow.AnchorPoint = Vector2.new(0.5, 0.5)
	markerGlow.Position = UDim2.fromScale(0.5, 0.5)
	markerGlow.Size = UDim2.fromScale(2.2, 1.2)
	markerGlow.BackgroundColor3 = color34
	markerGlow.BackgroundTransparency = 0.8
	markerGlow.BorderSizePixel = 0
	markerGlow.ZIndex = marker.ZIndex - 1
	markerGlow.Parent = marker

	local timerBack: Frame = Instance.new("Frame")

	timerBack.Name = "TimerBack"
	timerBack.AnchorPoint = Vector2.new(0.5, 0.5)
	timerBack.Position = UDim2.fromScale(0.5, 0.79)
	timerBack.Size = UDim2.fromScale(0.86, 0.045)
	timerBack.BackgroundColor3 = Color3.fromRGB(18, 18, 22)
	timerBack.BorderSizePixel = 0
	timerBack.Parent = main

	local color313 = Color3.fromRGB(255, 255, 255)
	local uiStroke5: UIStroke = Instance.new("UIStroke")

	uiStroke5.Color = color313
	uiStroke5.Thickness = 1
	uiStroke5.Transparency = 0.55
	uiStroke5.Parent = timerBack

	local timer: Frame = Instance.new("Frame")

	timer.Name = "Timer"
	timer.Size = UDim2.fromScale(1, 1)
	timer.BackgroundColor3 = color32
	timer.BorderSizePixel = 0
	timer.Parent = timerBack
	makeGradient(timer, color32, color33, 0)

	local hint: TextLabel = Instance.new("TextLabel")

	hint.Name = "Hint"
	hint.BackgroundTransparency = 1
	hint.Position = UDim2.fromScale(0.05, 0.86)
	hint.Size = UDim2.fromScale(0.9, 0.1)

	if userInputService.TouchEnabled then
		hint.Text = "TAP IN THE HIT ZONE"
	elseif userInputService.GamepadEnabled then
		hint.Text = "PRESS A IN THE HIT ZONE"
	else
		hint.Text = "PRESS SPACE IN THE HIT ZONE"
	end

	hint.TextScaled = true
	hint.Font = Enum.Font.Arcade
	hint.TextColor3 = color34
	hint.Parent = main

	local tap: TextButton = Instance.new("TextButton")

	tap.Name = "Tap"
	tap.AnchorPoint = Vector2.new(0.5, 0.5)
	tap.Position = UDim2.fromScale(0.5, 1.05)
	tap.Size = UDim2.fromScale(0.36, 0.24)
	tap.BackgroundColor3 = color3
	tap.BackgroundTransparency = 0.35
	tap.TextColor3 = color34
	tap.Text = "TAP"
	tap.TextScaled = true
	tap.Font = Enum.Font.Arcade
	tap.Visible = userInputService.TouchEnabled
	tap.Parent = main

	local color314 = Color3.fromRGB(255, 255, 255)
	local uiStroke6: UIStroke = Instance.new("UIStroke")

	uiStroke6.Color = color314
	uiStroke6.Thickness = 1
	uiStroke6.Transparency = 0.4
	uiStroke6.Parent = tap

	if userInputService.TouchEnabled then
		tap.Size = UDim2.fromScale(0.6, 0.32)
		tap.Position = UDim2.fromScale(0.5, 1.02)
	end

	local tweenInfo = TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
	local v79 = UDim2.fromScale(1.04, 1.12)

	u17 = tweenService:Create(glow, tweenInfo, { BackgroundTransparency = 0.84, Size = v79 })
	u17:Play()

	local tweenInfo2 = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	v79 = UDim2.fromScale(0.5, 0.19)

	local v81 = UDim2.fromScale(0.5, 0.58)
	local v82: Tween = tweenService:Create(main, tweenInfo2, { Size = v79, Position = v81 })

	main.Size = UDim2.fromScale(0.46, 0.16)
	main.Position = UDim2.fromScale(0.5, 0.61)
	v82:Play()

	return main, title, score, marker, timer, tap
end
local function attemptPress()
	if u13 and not u13.Finished then
		local lastPress: number = workspace:GetServerTimeNow()

		if lastPress < u13.StartTime then
			return
		end

		if lastPress > u13.EndTime then
			return
		end

		if lastPress - u13.LastPress < 0.12 then
			return
		end

		u13.LastPress = lastPress
		clashTimingPress:FireServer(u13.Id, lastPress)

		return
	end
end
local function inputAction(_, p14)
	if p14 == Enum.UserInputState.Begin and u13 and not u13.Finished then
		local lastPress: number = workspace:GetServerTimeNow()

		if not (lastPress < u13.StartTime) and not (lastPress > u13.EndTime) and not (lastPress - u13.LastPress < 0.12) then
			u13.LastPress = lastPress
			clashTimingPress:FireServer(u13.Id, lastPress)
		end
	end

	return Enum.ContextActionResult.Sink
end

clashTimingStart.OnClientEvent:Connect(function(p15, p16, p17, p18, p19, p20, p21, p22, p23)
	cleanup()
	u13 = {
		LastPress = 0,
		Finished = false,
		Id = p15,
		StartTime = p16,
		EndTime = p17,
		MarkerStart = p18,
		Direction = p19,
		GreenMin = p20,
		GreenMax = p21,
		BarSpeed = p22
	}
	local v96, v97, v98, v99, v100, v101 = createGui(p23)

	contextActionService:BindAction("ClashTimingPress", inputAction, false, Enum.KeyCode.Space, Enum.KeyCode.ButtonA)

	if userInputService.TouchEnabled then
		connection2 = userInputService.TouchTap:Connect(function()
			if not u13 then
				return
			end

			if u13.Finished then
				return
			end

			local lastPress: number = workspace:GetServerTimeNow()

			if lastPress < u13.StartTime then
				return
			end

			if lastPress > u13.EndTime then
				return
			end

			if lastPress - u13.LastPress < 0.12 then
				return
			end

			u13.LastPress = lastPress
			clashTimingPress:FireServer(u13.Id, lastPress)
		end)
	else
		connection2 = v101.MouseButton1Click:Connect(attemptPress)
	end

	connection = runService.RenderStepped:Connect(function()
		if not u13 then
			return
		end

		local v115: number = workspace:GetServerTimeNow()

		if v115 < u13.StartTime then
			v97.Text = "GET READY..."
			v99.Position = UDim2.fromScale(u13.MarkerStart, 0.5)

			return
		end

		local v116 = math.clamp((u13.EndTime - v115) / (u13.EndTime - u13.StartTime), 0, 1)

		v100.Size = UDim2.fromScale(v116, 1)

		if v115 <= u13.EndTime then
			v97.Text = "CLASH"

			local n1 = (u13.MarkerStart + u13.Direction * u13.BarSpeed * (v115 - u13.StartTime)) % 2

			v99.Position = UDim2.fromScale(if n1 <= 1 then n1 else 2 - n1, 0.5)
		end
	end)
end)
clashTimingFeedback.OnClientEvent:Connect(function(p24, p25, p26, p27)
	if u13 and p24 == u13.Id then
		local main = screenGui and screenGui:FindFirstChild("Main")

		if not main then
			return
		end

		main.Score.Text = "HITS " .. p26 .. "   MISSES " .. p27

		if p25 then
			main.BackgroundColor3 = color38
			main.Title.TextColor3 = color3
			main.Score.TextColor3 = color3
			task.delay(0.08, function()
				if main and main.Parent and u13 then
					main.BackgroundColor3 = color3
					main.Title.TextColor3 = color34
					main.Score.TextColor3 = color34
				end
			end)

			return
		end

		main.BackgroundColor3 = color37
		task.delay(0.08, function()
			if main and main.Parent and u13 then
				main.BackgroundColor3 = color3
			end
		end)

		return
	end
end)
clashTimingFinish.OnClientEvent:Connect(function(p28, p29, p30, p31, _, _)
	if u13 and p28 == u13.Id then
		u13.Finished = true
		contextActionService:UnbindAction("ClashTimingPress")

		local main = screenGui and screenGui:FindFirstChild("Main")

		if not main then
			cleanup()

			return
		end

		if p29 == 1 then
			main.Title.Text = "CLASH WON!"
			main.BackgroundColor3 = color38
			main.Title.TextColor3 = color3
		elseif p29 == -1 then
			main.Title.Text = "CLASH LOST!"
			main.BackgroundColor3 = color37
			main.Title.TextColor3 = color34
		else
			main.Title.Text = "CLASH DRAW!"
			main.BackgroundColor3 = color39
			main.Title.TextColor3 = color34
		end

		main.Score.Text = "YOU " .. p30 .. "  -  " .. p31 .. " THEM"
		task.delay(0.8, function()
			if u13 and u13.Id == p28 then
				local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.In)
				local v119 = UDim2.fromScale(0.5, 1.25)
				local v120: Tween = tweenService:Create(main, tweenInfo, { Position = v119 })

				v120:Play()
				v120.Completed:Once(cleanup)
			end
		end)

		return
	end
end)
