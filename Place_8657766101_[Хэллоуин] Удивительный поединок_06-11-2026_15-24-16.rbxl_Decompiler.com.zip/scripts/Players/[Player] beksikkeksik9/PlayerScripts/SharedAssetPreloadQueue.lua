-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local contentProvider: ContentProvider = game:GetService("ContentProvider")
local module: {[any]: any} = {
	Priority = {
		OwnCharacter = 100,
		SelectedCharacter = 90,
		NearbyOpponent = 70,
		Default = 40,
		Background = 10
	}
}
local default = module.Priority.Default
local t2: {[any]: any} = {}
local t3: {[any]: any} = {}
local t4: {[any]: any} = {}
local n1: number = 0
local u8: boolean = false
local t5: {[any]: any} = {}
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })
local u12: boolean = false

local function numericId(p1)
	if typeof(p1) == "string" then
		return p1:match("%d+")
	end

	return nil
end
local function isDefaultRobloxAnimation(p2)
	local numberValue: number? = tonumber(numericId(p2))

	return numberValue ~= nil and numberValue >= 507765000 and numberValue <= 507790000
end
local function hasValue(p3)
	local u30: boolean = false

	if typeof(p3) == "string" then
		u30 = p3 ~= ""
	end

	return u30
end
local function getSoundPreloadId(p4)
	local soundId = p4.SoundId
	local u33: boolean = false

	if typeof(soundId) == "string" then
		u33 = soundId ~= ""
	end

	if u33 then
		return soundId
	end

	local lazySoundId = p4:GetAttribute("LazySoundId")

	u33 = false

	if typeof(lazySoundId) == "string" then
		u33 = lazySoundId ~= ""
	end

	if u33 then
		p4.SoundId = lazySoundId

		return lazySoundId
	end

	local originalSoundId = p4:GetAttribute("OriginalSoundId")

	u33 = false

	if typeof(originalSoundId) == "string" then
		u33 = originalSoundId ~= ""
	end

	if u33 then
		p4.SoundId = originalSoundId

		return originalSoundId
	end

	return nil
end
local function getVideoPreloadId(p5)
	local video = p5.Video
	local u38: boolean = false

	if typeof(video) == "string" then
		u38 = video ~= ""
	end

	if u38 then
		return video
	end

	local lazyVideoId = p5:GetAttribute("LazyVideoId")

	u38 = false

	if typeof(lazyVideoId) == "string" then
		u38 = lazyVideoId ~= ""
	end

	if u38 then
		p5.Video = lazyVideoId

		return lazyVideoId
	end

	return nil
end
local function addPart(p6, p7)
	local u42: boolean = false

	if typeof(p7) == "string" then
		u42 = p7 ~= ""
	end

	if u42 then
		p6[#p6 + 1] = p7
	end
end
local function getPreloadKey(p8)
	if not p8 then
		return nil
	end

	if p8:IsA("Animation") then
		local animationId = p8.AnimationId
		local u45: boolean = false

		if typeof(animationId) == "string" then
			u45 = animationId ~= ""
		end

		if not u45 then
			return nil
		end

		return "Animation:" .. p8.AnimationId
	end

	if p8:IsA("Sound") then
		local v46 = getSoundPreloadId(p8)

		return v46 and "Sound:" .. v46 or nil
	end

	if p8:IsA("VideoFrame") then
		local video = p8.Video
		local u48: boolean = false

		if typeof(video) == "string" then
			u48 = video ~= ""
		end

		local v50

		if u48 then
			v50 = video
		else
			local lazyVideoId = p8:GetAttribute("LazyVideoId")
			local u51: boolean = false

			if typeof(lazyVideoId) == "string" then
				u51 = lazyVideoId ~= ""
			end

			if u51 then
				p8.Video = lazyVideoId
				v50 = lazyVideoId
			else
				v50 = nil
			end
		end

		return v50 and "Video:" .. v50 or nil
	end

	if p8:IsA("MeshPart") then
		local t6: {[any]: any} = {}
		local meshId = p8.MeshId
		local u54: boolean = false

		if typeof(meshId) == "string" then
			u54 = meshId ~= ""
		end

		if u54 then
			t6[#t6 + 1] = meshId
		end

		local textureID = p8.TextureID

		u54 = false

		if typeof(textureID) == "string" then
			u54 = textureID ~= ""
		end

		if u54 then
			t6[#t6 + 1] = textureID
		end

		return #t6 > 0 and "MeshPart:" .. table.concat(t6, "|") or p8
	end

	if p8:IsA("SpecialMesh") then
		local t7: {[any]: any} = {}
		local v57 = p8.MeshId
		local u58: boolean = false

		if typeof(v57) == "string" then
			u58 = v57 ~= ""
		end

		if u58 then
			t7[#t7 + 1] = v57
		end

		local textureId = p8.TextureId

		u58 = false

		if typeof(textureId) == "string" then
			u58 = textureId ~= ""
		end

		if u58 then
			t7[#t7 + 1] = textureId
		end

		return #t7 > 0 and "SpecialMesh:" .. table.concat(t7, "|") or p8
	end

	if p8:IsA("Decal") then
		local texture = p8.Texture
		local u61: boolean = false

		if typeof(texture) == "string" then
			u61 = texture ~= ""
		end

		return u61 and "Decal:" .. p8.Texture or p8
	end

	if p8:IsA("Texture") then
		local v62 = p8.Texture
		local u63: boolean = false

		if typeof(v62) == "string" then
			u63 = v62 ~= ""
		end

		return u63 and "Texture:" .. p8.Texture or p8
	end

	if p8:IsA("SurfaceAppearance") then
		return p8
	end

	if p8:IsA("Shirt") then
		local shirtTemplate = p8.ShirtTemplate
		local u65: boolean = false

		if typeof(shirtTemplate) == "string" then
			u65 = shirtTemplate ~= ""
		end

		return u65 and "Shirt:" .. p8.ShirtTemplate or p8
	end

	if p8:IsA("Pants") then
		local pantsTemplate = p8.PantsTemplate
		local u67: boolean = false

		if typeof(pantsTemplate) == "string" then
			u67 = pantsTemplate ~= ""
		end

		return u67 and "Pants:" .. p8.PantsTemplate or p8
	end

	if p8:IsA("ShirtGraphic") then
		local graphic = p8.Graphic
		local u69: boolean = false

		if typeof(graphic) == "string" then
			u69 = graphic ~= ""
		end

		return u69 and "ShirtGraphic:" .. p8.Graphic or p8
	end

	return nil
end
local function isSupportedAsset(p9)
	return p9:IsA("Animation") or p9:IsA("Sound") or p9:IsA("VideoFrame") or p9:IsA("MeshPart") or p9:IsA("SpecialMesh") or p9:IsA("Decal") or p9:IsA("Texture") or p9:IsA("SurfaceAppearance") or p9:IsA("Shirt") or p9:IsA("Pants") or p9:IsA("ShirtGraphic")
end
local function forceSilentVideoStop(p10)
	pcall(function()
		p10.Volume = 0
		p10:Pause()
		p10.TimePosition = 0
	end)
end
local function processWarmQueue()
	if u12 then
		return
	end

	u12 = true
	task.spawn(function()
		while #t5 > 0 do
			local v133 = table.remove(t5, 1)

			object[v133] = nil

			if v133 and v133:IsA("VideoFrame") and not object2[v133] then
				object2[v133] = true

				local visible = v133.Visible
				local backgroundTransparency = v133.BackgroundTransparency
				local volume = v133.Volume
				local timePosition = v133.TimePosition

				pcall(function()
					v133:SetAttribute("PreloadWarmMuted", true)
					v133.Volume = 0
					v133.BackgroundTransparency = 1
					v133.Visible = true
					v133.TimePosition = 0
					v133:Play()
				end)
				task.wait(0.2)
				pcall(function()
					v133:Pause()
					v133.TimePosition = timePosition or 0
					v133.BackgroundTransparency = backgroundTransparency
					v133.Visible = visible
					v133:SetAttribute("PreloadWarmMuted", nil)

					if v133.Visible then
						v133.Volume = volume

						return
					end

					v133.Volume = 0
				end)
				task.wait(0.1)
			end
		end

		u12 = false
	end)
end
local function warmVideo(p11)
	if not p11 or not p11:IsA("VideoFrame") then
	elseif not object2[p11] and not object[p11] then
		object[p11] = true
		t5[#t5 + 1] = p11

		if u12 then
			return
		end

		u12 = true
		task.spawn(function()
			while #t5 > 0 do
				local v138 = table.remove(t5, 1)

				object[v138] = nil

				if v138 and v138:IsA("VideoFrame") and not object2[v138] then
					object2[v138] = true

					local visible = v138.Visible
					local backgroundTransparency = v138.BackgroundTransparency
					local volume = v138.Volume
					local timePosition = v138.TimePosition

					pcall(function()
						v138:SetAttribute("PreloadWarmMuted", true)
						v138.Volume = 0
						v138.BackgroundTransparency = 1
						v138.Visible = true
						v138.TimePosition = 0
						v138:Play()
					end)
					task.wait(0.2)
					pcall(function()
						v138:Pause()
						v138.TimePosition = timePosition or 0
						v138.BackgroundTransparency = backgroundTransparency
						v138.Visible = visible
						v138:SetAttribute("PreloadWarmMuted", nil)

						if v138.Visible then
							v138.Volume = volume

							return
						end

						v138.Volume = 0
					end)
					task.wait(0.1)
				end
			end

			u12 = false
		end)

		return
	end
end
local function cleanupTemporary(p12, p13)
	if p13 and p12 and p12.Parent == nil and (not not p12:IsA("Animation") or not not p12:IsA("VideoFrame")) then
		p12:Destroy()
	end
end
local function processQueue()
	if u8 then
		return
	end

	u8 = true
	task.spawn(function()
		while #t2 > 0 do
			table.sort(t2, function(p14, p15)
				if p14.priority == p15.priority then
					return p14.order < p15.order
				end

				return p14.priority > p15.priority
			end)

			local t12: {[any]: any} = {}
			local t13: {[any]: any} = {}

			while #t12 < 35 and #t2 > 0 do
				local v145 = table.remove(t2, 1)

				t3[v145.key] = nil

				if not t4[v145.key] then
					t12[#t12 + 1] = v145.asset
					t13[#t13 + 1] = v145
				else
					local asset = v145.asset

					if v145.temporary and asset and asset.Parent == nil and (not not asset:IsA("Animation") or not not asset:IsA("VideoFrame")) then
						asset:Destroy()
					end

					if v145.asset and v145.asset:IsA("VideoFrame") then
						local v147 = v145.asset

						if v147 and v147:IsA("VideoFrame") and not object2[v147] and not object[v147] then
							object[v147] = true
							t5[#t5 + 1] = v147

							if not u12 then
								u12 = true
								task.spawn(function()
									while #t5 > 0 do
										local v179 = table.remove(t5, 1)

										object[v179] = nil

										if v179 and v179:IsA("VideoFrame") and not object2[v179] then
											object2[v179] = true

											local visible = v179.Visible
											local backgroundTransparency = v179.BackgroundTransparency
											local volume = v179.Volume
											local timePosition = v179.TimePosition

											pcall(function()
												v179:SetAttribute("PreloadWarmMuted", true)
												v179.Volume = 0
												v179.BackgroundTransparency = 1
												v179.Visible = true
												v179.TimePosition = 0
												v179:Play()
											end)
											task.wait(0.2)
											pcall(function()
												v179:Pause()
												v179.TimePosition = timePosition or 0
												v179.BackgroundTransparency = backgroundTransparency
												v179.Visible = visible
												v179:SetAttribute("PreloadWarmMuted", nil)

												if v179.Visible then
													v179.Volume = volume

													return
												end

												v179.Volume = 0
											end)
											task.wait(0.1)
										end
									end

									u12 = false
								end)
							end
						end
					end
				end
			end

			if #t12 > 0 then
				local ok, result = pcall(function()
					contentProvider:PreloadAsync(t12)
				end)

				if not ok then
					warn("[SharedAssetPreloadQueue] Batch failed", result)
				end

				for i = 1, #t13 do
					local v151 = t13[i]

					if ok then
						t4[v151.key] = true
					end

					if v151.asset and v151.asset:IsA("VideoFrame") then
						local v152 = v151.asset

						if v152 and v152:IsA("VideoFrame") and not object2[v152] and not object[v152] then
							object[v152] = true
							t5[#t5 + 1] = v152

							if not u12 then
								u12 = true
								task.spawn(function()
									while #t5 > 0 do
										local v179 = table.remove(t5, 1)

										object[v179] = nil

										if v179 and v179:IsA("VideoFrame") and not object2[v179] then
											object2[v179] = true

											local visible = v179.Visible
											local backgroundTransparency = v179.BackgroundTransparency
											local volume = v179.Volume
											local timePosition = v179.TimePosition

											pcall(function()
												v179:SetAttribute("PreloadWarmMuted", true)
												v179.Volume = 0
												v179.BackgroundTransparency = 1
												v179.Visible = true
												v179.TimePosition = 0
												v179:Play()
											end)
											task.wait(0.2)
											pcall(function()
												v179:Pause()
												v179.TimePosition = timePosition or 0
												v179.BackgroundTransparency = backgroundTransparency
												v179.Visible = visible
												v179:SetAttribute("PreloadWarmMuted", nil)

												if v179.Visible then
													v179.Volume = volume

													return
												end

												v179.Volume = 0
											end)
											task.wait(0.1)
										end
									end

									u12 = false
								end)
							end
						end

						if not v151.asset.Visible then
							local v153 = v151.asset

							pcall(function()
								v153.Volume = 0
								v153:Pause()
								v153.TimePosition = 0
							end)
						end
					end

					local v154 = v151.asset

					if v151.temporary and v154 and v154.Parent == nil and (v154:IsA("Animation") or v154:IsA("VideoFrame")) then
						v154:Destroy()
					end
				end
			end

			task.wait()
		end

		u8 = false
	end)
end
function module.EnqueueAsset(p16, p17, p18, p19)
	if not p16 or not isSupportedAsset(p16) then
		return false
	end

	local v79 = p17 or default
	local v80 = getPreloadKey(p16)

	if not v80 then
		if p19 and p16 and p16.Parent == nil and (not not p16:IsA("Animation") or not not p16:IsA("VideoFrame")) then
			p16:Destroy()
		end

		return false
	end

	if t4[v80] then
		if p16:IsA("VideoFrame") and p16 and p16:IsA("VideoFrame") and not object2[p16] and not object[p16] then
			object[p16] = true
			t5[#t5 + 1] = p16

			if not u12 then
				u12 = true
				task.spawn(function()
					while #t5 > 0 do
						local v155 = table.remove(t5, 1)

						object[v155] = nil

						if v155 and v155:IsA("VideoFrame") and not object2[v155] then
							object2[v155] = true

							local visible = v155.Visible
							local backgroundTransparency = v155.BackgroundTransparency
							local volume = v155.Volume
							local timePosition = v155.TimePosition

							pcall(function()
								v155:SetAttribute("PreloadWarmMuted", true)
								v155.Volume = 0
								v155.BackgroundTransparency = 1
								v155.Visible = true
								v155.TimePosition = 0
								v155:Play()
							end)
							task.wait(0.2)
							pcall(function()
								v155:Pause()
								v155.TimePosition = timePosition or 0
								v155.BackgroundTransparency = backgroundTransparency
								v155.Visible = visible
								v155:SetAttribute("PreloadWarmMuted", nil)

								if v155.Visible then
									v155.Volume = volume

									return
								end

								v155.Volume = 0
							end)
							task.wait(0.1)
						end
					end

					u12 = false
				end)
			end
		end

		if p19 and p16 and p16.Parent == nil and (not not p16:IsA("Animation") or not not p16:IsA("VideoFrame")) then
			p16:Destroy()
		end

		return false
	end

	local v81 = t3[v80]

	if v81 then
		if v79 > v81.priority then
			v81.priority = v79
			v81.contextName = p18 or v81.contextName
		end

		if p16:IsA("VideoFrame") and p16 and p16:IsA("VideoFrame") and not object2[p16] and not object[p16] then
			object[p16] = true
			t5[#t5 + 1] = p16

			if not u12 then
				u12 = true
				task.spawn(function()
					while #t5 > 0 do
						local v155 = table.remove(t5, 1)

						object[v155] = nil

						if v155 and v155:IsA("VideoFrame") and not object2[v155] then
							object2[v155] = true

							local visible = v155.Visible
							local backgroundTransparency = v155.BackgroundTransparency
							local volume = v155.Volume
							local timePosition = v155.TimePosition

							pcall(function()
								v155:SetAttribute("PreloadWarmMuted", true)
								v155.Volume = 0
								v155.BackgroundTransparency = 1
								v155.Visible = true
								v155.TimePosition = 0
								v155:Play()
							end)
							task.wait(0.2)
							pcall(function()
								v155:Pause()
								v155.TimePosition = timePosition or 0
								v155.BackgroundTransparency = backgroundTransparency
								v155.Visible = visible
								v155:SetAttribute("PreloadWarmMuted", nil)

								if v155.Visible then
									v155.Volume = volume

									return
								end

								v155.Volume = 0
							end)
							task.wait(0.1)
						end
					end

					u12 = false
				end)
			end
		end

		if p19 and p16 and p16.Parent == nil and (not not p16:IsA("Animation") or not not p16:IsA("VideoFrame")) then
			p16:Destroy()
		end

		return false
	end

	n1 += 1
	v81 = {
		asset = p16,
		key = v80,
		priority = v79,
		contextName = p18,
		temporary = if p19 == true then true else false,
		order = n1
	}
	t3[v80] = v81
	t2[#t2 + 1] = v81

	if not u8 then
		u8 = true
		task.spawn(function()
			while #t2 > 0 do
				table.sort(t2, function(p14, p15)
					if p14.priority == p15.priority then
						return p14.order < p15.order
					end

					return p14.priority > p15.priority
				end)

				local t14: {[any]: any} = {}
				local t15: {[any]: any} = {}

				while #t14 < 35 and #t2 > 0 do
					local v162 = table.remove(t2, 1)

					t3[v162.key] = nil

					if not t4[v162.key] then
						t14[#t14 + 1] = v162.asset
						t15[#t15 + 1] = v162
					else
						local asset = v162.asset

						if v162.temporary and asset and asset.Parent == nil and (not not asset:IsA("Animation") or not not asset:IsA("VideoFrame")) then
							asset:Destroy()
						end

						if v162.asset and v162.asset:IsA("VideoFrame") then
							local v164 = v162.asset

							if v164 and v164:IsA("VideoFrame") and not object2[v164] and not object[v164] then
								object[v164] = true
								t5[#t5 + 1] = v164

								if not u12 then
									u12 = true
									task.spawn(function()
										while #t5 > 0 do
											local v179 = table.remove(t5, 1)

											object[v179] = nil

											if v179 and v179:IsA("VideoFrame") and not object2[v179] then
												object2[v179] = true

												local visible = v179.Visible
												local backgroundTransparency = v179.BackgroundTransparency
												local volume = v179.Volume
												local timePosition = v179.TimePosition

												pcall(function()
													v179:SetAttribute("PreloadWarmMuted", true)
													v179.Volume = 0
													v179.BackgroundTransparency = 1
													v179.Visible = true
													v179.TimePosition = 0
													v179:Play()
												end)
												task.wait(0.2)
												pcall(function()
													v179:Pause()
													v179.TimePosition = timePosition or 0
													v179.BackgroundTransparency = backgroundTransparency
													v179.Visible = visible
													v179:SetAttribute("PreloadWarmMuted", nil)

													if v179.Visible then
														v179.Volume = volume

														return
													end

													v179.Volume = 0
												end)
												task.wait(0.1)
											end
										end

										u12 = false
									end)
								end
							end
						end
					end
				end

				if #t14 > 0 then
					local ok, result = pcall(function()
						contentProvider:PreloadAsync(t14)
					end)

					if not ok then
						warn("[SharedAssetPreloadQueue] Batch failed", result)
					end

					for i = 1, #t15 do
						local v168 = t15[i]

						if ok then
							t4[v168.key] = true
						end

						if v168.asset and v168.asset:IsA("VideoFrame") then
							local v169 = v168.asset

							if v169 and v169:IsA("VideoFrame") and not object2[v169] and not object[v169] then
								object[v169] = true
								t5[#t5 + 1] = v169

								if not u12 then
									u12 = true
									task.spawn(function()
										while #t5 > 0 do
											local v179 = table.remove(t5, 1)

											object[v179] = nil

											if v179 and v179:IsA("VideoFrame") and not object2[v179] then
												object2[v179] = true

												local visible = v179.Visible
												local backgroundTransparency = v179.BackgroundTransparency
												local volume = v179.Volume
												local timePosition = v179.TimePosition

												pcall(function()
													v179:SetAttribute("PreloadWarmMuted", true)
													v179.Volume = 0
													v179.BackgroundTransparency = 1
													v179.Visible = true
													v179.TimePosition = 0
													v179:Play()
												end)
												task.wait(0.2)
												pcall(function()
													v179:Pause()
													v179.TimePosition = timePosition or 0
													v179.BackgroundTransparency = backgroundTransparency
													v179.Visible = visible
													v179:SetAttribute("PreloadWarmMuted", nil)

													if v179.Visible then
														v179.Volume = volume

														return
													end

													v179.Volume = 0
												end)
												task.wait(0.1)
											end
										end

										u12 = false
									end)
								end
							end

							if not v168.asset.Visible then
								local v170 = v168.asset

								pcall(function()
									v170.Volume = 0
									v170:Pause()
									v170.TimePosition = 0
								end)
							end
						end

						local v171 = v168.asset

						if v168.temporary and v171 and v171.Parent == nil and (v171:IsA("Animation") or v171:IsA("VideoFrame")) then
							v171:Destroy()
						end
					end
				end

				task.wait()
			end

			u8 = false
		end)
	end

	return true
end
function module.EnqueueInstances(p20, p21, p22, p23)
	if type(p20) == "table" then
		local n1: number = 0

		for i = 1, #p20 do
			if module.EnqueueAsset(p20[i], p21, p22, p23) then
				n1 += 1
			end
		end

		return n1
	end

	return 0
end
function module.EnqueueAnimationIds(p24, p25, p26, p27)
	if type(p24) == "table" then
		local t8 = p27 or {}
		local n1: number = 0

		for i = 1, #p24 do
			local animationId = p24[i]
			local u96: boolean = false

			if typeof(animationId) == "string" then
				u96 = animationId ~= ""
			end

			if u96 then
				local u97: boolean = false
				local skipDefaultAnimations = t8.skipDefaultAnimations

				if skipDefaultAnimations then
					local numberValue: number? = tonumber(numericId(animationId))

					u97 = false

					if numberValue ~= nil then
						u97 = false

						if numberValue >= 507765000 then
							u97 = numberValue <= 507790000
						end
					end
				end

				if (not skipDefaultAnimations or not u97) and not t4["Animation:" .. animationId] and not t3["Animation:" .. animationId] then
					local animation: Animation = Instance.new("Animation")

					animation.AnimationId = animationId

					if module.EnqueueAsset(animation, p25, p26, true) then
						n1 += 1
					end
				end
			end
		end

		return n1
	end

	return 0
end
function module.EnqueueVideoIds(p28, p29, p30)
	if type(p28) == "table" then
		local n1: number = 0

		for i = 1, #p28 do
			local video = p28[i]
			local u107: boolean = false

			if typeof(video) == "string" then
				u107 = video ~= ""
			end

			if u107 then
				local s1: string = "Video:" .. video

				if not not t4[s1] or not not t3[s1] then
					continue
				end

				local preloadVideo: VideoFrame = Instance.new("VideoFrame")

				preloadVideo.Name = "PreloadVideo"
				preloadVideo.BackgroundTransparency = 1
				preloadVideo.Transparency = 1
				preloadVideo.Visible = false
				preloadVideo.Size = UDim2.fromOffset(1, 1)
				preloadVideo.Video = video

				if not module.EnqueueAsset(preloadVideo, p29, p30, true) then
					continue
				end

				n1 += 1
			end
		end

		return n1
	end

	return 0
end
function module.EnqueueRootAssets(p31, p32, p33, p34)
	local t9
	local t10
	local n1
	local t11
	local n2
	local v119
	local v120
	local v121
	local numberValue
	local u123
	local v124
	local v125

	if not p31 then
		return 0
	else
		t9 = p34 or {}
		t10 = t9
		n1 = 0
		t11 = { p31 }
		n2 = 0

		while true do
			if #t11 > 0 then
				v119 = table.remove(t11)
				v120 = isSupportedAsset(v119)

				if v120 then
					v121 = v119:IsA("Animation")

					if v121 and t10.skipDefaultAnimations then
						numberValue = tonumber(numericId(v119.AnimationId))
						u123 = false

						if numberValue == nil then
						else
							u123 = false

							if numberValue >= 507765000 then
								u123 = numberValue <= 507790000
							end
						end

						if not u123 then
							v124 = module.EnqueueAsset(v119, p32, p33, false)

							if v124 then
								n1 += 1
							end
						end
					else
						v124 = module.EnqueueAsset(v119, p32, p33, false)

						if v124 then
							n1 += 1
						end
					end
				end

				v125 = v119:GetChildren()

				for i = 1, #v125 do
					t11[#t11 + 1] = v125[i]
				end

				n2 += 1

				if n2 >= 300 then
					n2 = 0
					task.wait()
				end

				continue
			else
				break
			end
		end

		return n1
	end
end
function module.WarmVideoFrame(p35, p36, p37)
	if not p35 or not p35:IsA("VideoFrame") then
		return false
	end

	module.EnqueueAsset(p35, p36 or default, p37, false)

	if p35 and p35:IsA("VideoFrame") and not object2[p35] and not object[p35] then
		object[p35] = true
		t5[#t5 + 1] = p35

		if not u12 then
			u12 = true
			task.spawn(function()
				while #t5 > 0 do
					local v172 = table.remove(t5, 1)

					object[v172] = nil

					if v172 and v172:IsA("VideoFrame") and not object2[v172] then
						object2[v172] = true

						local visible = v172.Visible
						local backgroundTransparency = v172.BackgroundTransparency
						local volume = v172.Volume
						local timePosition = v172.TimePosition

						pcall(function()
							v172:SetAttribute("PreloadWarmMuted", true)
							v172.Volume = 0
							v172.BackgroundTransparency = 1
							v172.Visible = true
							v172.TimePosition = 0
							v172:Play()
						end)
						task.wait(0.2)
						pcall(function()
							v172:Pause()
							v172.TimePosition = timePosition or 0
							v172.BackgroundTransparency = backgroundTransparency
							v172.Visible = visible
							v172:SetAttribute("PreloadWarmMuted", nil)

							if v172.Visible then
								v172.Volume = volume

								return
							end

							v172.Volume = 0
						end)
						task.wait(0.1)
					end
				end

				u12 = false
			end)
		end
	end

	return true
end
function module.IsQueuedOrPreloaded(p38)
	local v131 = p38

	if typeof(p38) == "Instance" then
		v131 = getPreloadKey(p38)
	end

	local u132: boolean = false

	if v131 ~= nil then
		u132 = true

		if t4[v131] ~= true then
			u132 = t3[v131] ~= nil
		end
	end

	return u132
end

return module
