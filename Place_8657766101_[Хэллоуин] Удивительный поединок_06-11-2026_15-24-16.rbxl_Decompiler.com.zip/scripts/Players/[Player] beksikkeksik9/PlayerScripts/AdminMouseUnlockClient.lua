-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local userInputService: UserInputService = game:GetService("UserInputService")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local players: Players = game:GetService("Players")
local v4: Instance = replicatedStorage:FindFirstChild("Remotes") or replicatedStorage:WaitForChild("Remotes", 10)

if not v4 then
	return
end

local adminMouseUnlockToggle: Instance = v4:FindFirstChild("AdminMouseUnlockToggle")

if not adminMouseUnlockToggle then
	adminMouseUnlockToggle = v4:WaitForChild("AdminMouseUnlockToggle", 10)
end

if not adminMouseUnlockToggle or not adminMouseUnlockToggle:IsA("RemoteEvent") then
	return
end

local u6: boolean = false
local LocalPlayer: Player = players.LocalPlayer

local function adminPanelExists()
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

	return playerGui ~= nil and playerGui:FindFirstChild("AdminPanel") ~= nil
end

userInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if gameProcessedEvent then
		return
	end

	if input.KeyCode ~= Enum.KeyCode.B then
		return
	end

	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

	if playerGui ~= nil and playerGui:FindFirstChild("AdminPanel") ~= nil then
		return
	end

	if u6 then
		return
	end

	u6 = true
	adminMouseUnlockToggle:FireServer()
	task.delay(0.25, function()
		u6 = false
	end)
end)
