-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local LocalPlayer: Player = players.LocalPlayer
local n1: number = 0
local u5 = nil
local u6: boolean = false
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local t3: {[any]: any} = {}
local t4: {[any]: any} = {}
local t5: {[any]: any} = {}
local t6: {[any]: any} = {}
local t7: {[any]: any} = {}
local t8: {[any]: any} = {}

local function digits(p1)
	if type(p1) == "string" then
		return p1:match("%d+")
	end

	return nil
end
local function targetOf(p2)
	if not p2:IsA("BasePart") and not p2:IsA("Decal") and not p2:IsA("Texture") then
		return p2.Parent
	end

	return p2
end
local function setTransparency(p3, transparency)
	if p3 and (not not p3:IsA("BasePart") or not not p3:IsA("Decal") or not not p3:IsA("Texture")) then
		p3.Transparency = transparency
	end
end
local function setEnabled(p5, enabled)
	if p5 and (not not p5:IsA("ParticleEmitter") or not not p5:IsA("Trail") or not not p5:IsA("Beam") or not not p5:IsA("PointLight") or not not p5:IsA("SpotLight") or not not p5:IsA("SurfaceLight") or not not p5:IsA("BillboardGui") or not not p5:IsA("SurfaceGui") or not not p5:IsA("UIStroke")) then
		p5.Enabled = enabled
	end
end
local function collectVisualTargets(p7)
	local t9: {[any]: any} = {}

	if not p7 then
		return t9
	end

	table.insert(t9, p7)

	if p7:IsA("Model") or p7:IsA("Folder") then
		for _, v in ipairs(p7:GetDescendants()) do
			table.insert(t9, v)
		end
	end

	return t9
end
local function clearCache()
	u5 = nil
	u6 = false
	t1 = {}
	t2 = {}
	t3 = {}
	t4 = {}
	t5 = {}
	t6 = {}
	t7 = {}
	t8 = {}
end
local function addVisualItem(p8, p9)
	if p9 then
		local v41 = collectVisualTargets(p9)

		table.insert(p8, v41)
	end
end
local function buildCache(p10)
	clearCache()
	u5 = p10

	if not p10 then
		return
	end

	local animate = p10:FindFirstChild("Animate")

	if animate then
		for _, v in ipairs({ "dance", "dance2", "dance3" }) do
			local numberValue: number? = tonumber(v:match("%d+"))
			local v = animate:FindFirstChild(v)

			if v then
				for _, iterValue in ipairs(v:GetChildren()) do
					if iterValue:IsA("Animation") then
						local animationId = iterValue.AnimationId
						local v51 = if type(animationId) == "string" then animationId:match("%d+") else nil

						if v51 then
							t1[v51] = numberValue or 1
						end
					end
				end
			end
		end
	end

	for _, v in ipairs(p10:GetDescendants()) do
		local v54 = if not v:IsA("BasePart") and not v:IsA("Decal") and not v:IsA("Texture") then v.Parent else v

		if v54 then
			if v.Name == "EmoteItem" then
				local v55: {[any]: any} = t2

				if v54 then
					local v56 = collectVisualTargets(v54)

					table.insert(v55, v56)
				end
			elseif v.Name == "EmoteItemNum" and v:IsA("NumberValue") then
				local v57: {[any]: any} = t3
				local v58 = collectVisualTargets(v54)

				table.insert(v57, { Targets = v58, ValueObject = v })
			elseif v.Name == "EmoteSize" and v:IsA("Vector3Value") and v54:IsA("BasePart") then
				table.insert(t4, { Target = v54, ValueObject = v })
			elseif v.Name == "HideItemEmote" then
				local v59: {[any]: any} = t5

				if v54 then
					local v60 = collectVisualTargets(v54)

					table.insert(v59, v60)
				end
			elseif v.Name == "DisableItemEmote" then
				local v61: {[any]: any} = t6

				if v54 then
					local v62 = collectVisualTargets(v54)

					table.insert(v61, v62)
				end
			elseif v.Name == "EnableItemEmote" then
				local v63: {[any]: any} = t7

				if v54 then
					local v64 = collectVisualTargets(v54)

					table.insert(v63, v64)
				end
			end
		end
	end

	local head = p10:FindFirstChild("Head")

	if head then
		for i = 1, 3 do
			local text: string = tostring(i)
			local text2: string = tostring(i)

			for _, v in ipairs({
				"Emote" .. text .. "Sfx",
				"Dance" .. text2 .. "Sound",
				if i == 1 then "Emote1Sfx" else nil
			}) do
				if v then
					local v = head:FindFirstChild(v)

					if v and v:IsA("Sound") then
						t8[i] = t8[i] or v
					end
				end
			end
		end
	end
end
local function getPlayingEmoteIndex(character)
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")

	if not humanoid then
		return nil
	end

	for _, v in ipairs(humanoid:GetPlayingAnimationTracks()) do
		local v76 = v.Animation

		if v76 then
			local animationId = v.Animation.AnimationId

			v76 = if type(animationId) == "string" then animationId:match("%d+") else nil
		end

		if v.IsPlaying and v.WeightCurrent > 0 and v76 and t1[v76] then
			return t1[v76]
		end
	end

	return nil
end
local function setTargetListTransparency(p12, transparency)
	for _, v in ipairs(p12) do
		for _, iterValue in ipairs(v) do
			if iterValue and (not not iterValue:IsA("BasePart") or not not iterValue:IsA("Decal") or not not iterValue:IsA("Texture")) then
				iterValue.Transparency = transparency
			end
		end
	end
end
local function setTargetListEnabled(p14, p15)
	for _, v in ipairs(p14) do
		for _, iterValue in ipairs(v) do
			setEnabled(iterValue, p15)
		end
	end
end
local function showThings(p16)
	setTargetListTransparency(t2, 0)
	setTargetListTransparency(t5, 1)
	setTargetListEnabled(t6, false)
	setTargetListEnabled(t7, true)

	for _, v in ipairs(t3) do
		local transparency = v.ValueObject and v.ValueObject.Value or 0

		for _, iterValue in ipairs(v.Targets) do
			if iterValue and (not not iterValue:IsA("BasePart") or not not iterValue:IsA("Decal") or not not iterValue:IsA("Texture")) then
				iterValue.Transparency = transparency
			end
		end
	end

	for _, v in ipairs(t4) do
		if v.Target and v.Target.Parent and v.ValueObject and v.ValueObject.Parent then
			v.Target.Size = v.ValueObject.Value
		end
	end

	local v98 = t8[p16] or t8[1]

	if v98 and not v98.IsPlaying then
		v98.Volume = 1
		v98:Play()
	end
end
local function hideThings()
	setTargetListTransparency(t2, 1)
	setTargetListTransparency(t5, 0)
	setTargetListEnabled(t6, true)
	setTargetListEnabled(t7, false)

	for _, v in ipairs(t3) do
		for _, iterValue in ipairs(v.Targets) do
			if iterValue and (not not iterValue:IsA("BasePart") or not not iterValue:IsA("Decal") or not not iterValue:IsA("Texture")) then
				iterValue.Transparency = 1
			end
		end
	end

	for _, v in ipairs(t4) do
		if v.Target and v.Target.Parent then
			v.Target.Size = Vector3.new(0.001, 0.001, 0.001)
		end
	end

	for _, v in pairs(t8) do
		if v and v:IsA("Sound") then
			v:Stop()
			v.Volume = 1
		end
	end
end
local function sync()
	local Character: Model = LocalPlayer.Character

	if Character ~= u5 then
		buildCache(Character)
	end

	if not Character then
		return
	end

	local v108 = getPlayingEmoteIndex(Character)

	if v108 then
		if not u6 then
			u6 = true
		end

		showThings(v108)
	elseif u6 then
		u6 = false
		hideThings()
	end
end

runService.RenderStepped:Connect(function(deltaTime: number)
	n1 += deltaTime

	if n1 < 0.05 then
		return
	end

	n1 = 0

	local Character: Model = LocalPlayer.Character

	if Character ~= u5 then
		buildCache(Character)
	end

	if not Character then
		return
	end

	local v111 = getPlayingEmoteIndex(Character)

	if v111 then
		if not u6 then
			u6 = true
		end

		showThings(v111)
	elseif u6 then
		u6 = false
		hideThings()
	end
end)
LocalPlayer.CharacterAdded:Connect(function(character: Model)
	buildCache(character)
end)

if LocalPlayer.Character then
	buildCache(LocalPlayer.Character)
end
