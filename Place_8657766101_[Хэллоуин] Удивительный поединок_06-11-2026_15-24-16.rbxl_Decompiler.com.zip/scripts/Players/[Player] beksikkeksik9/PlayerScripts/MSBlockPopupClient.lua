-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local playerGui: Instance = players.LocalPlayer:WaitForChild("PlayerGui")
local msBlockPopup: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockPopup")
local msBlockPopupGui: ScreenGui = Instance.new("ScreenGui")

msBlockPopupGui.Name = "MSBlockPopupGui"
msBlockPopupGui.IgnoreGuiInset = true
msBlockPopupGui.ResetOnSpawn = false
msBlockPopupGui.DisplayOrder = 50
msBlockPopupGui.Parent = playerGui

local popupContainer: Frame = Instance.new("Frame")

popupContainer.Name = "PopupContainer"
popupContainer.AnchorPoint = Vector2.new(0.5, 0.5)
popupContainer.Position = UDim2.fromScale(0.5, 0.42)
popupContainer.Size = UDim2.fromOffset(700, 170)
popupContainer.BackgroundTransparency = 1
popupContainer.Visible = false
popupContainer.Parent = msBlockPopupGui

local background: ImageLabel = Instance.new("ImageLabel")

background.Name = "Background"
background.AnchorPoint = Vector2.new(0.5, 0.5)
background.Position = UDim2.fromScale(0.5, 0.5)
background.Size = UDim2.fromOffset(620, 160)
background.BackgroundTransparency = 1
background.Image = "rbxassetid://7948615545"
background.ImageColor3 = Color3.new(0, 0, 0)
background.ImageTransparency = 1
background.ScaleType = Enum.ScaleType.Stretch
background.ZIndex = 9
background.Parent = popupContainer

local powerPopup: TextLabel = Instance.new("TextLabel")

powerPopup.Name = "PowerPopup"
powerPopup.AnchorPoint = Vector2.new(0.5, 0.5)
powerPopup.Position = UDim2.fromScale(0.5, 0.5)
powerPopup.Size = UDim2.fromOffset(560, 100)
powerPopup.BackgroundTransparency = 1
powerPopup.Text = ""
powerPopup.TextColor3 = Color3.new(1, 1, 1)
powerPopup.TextStrokeColor3 = Color3.new(0, 0, 0)
powerPopup.TextStrokeTransparency = 1
powerPopup.TextScaled = true
powerPopup.TextTransparency = 1
powerPopup.TextWrapped = true
powerPopup.ZIndex = 10
powerPopup.Font = Enum.Font.Arcade
powerPopup.Parent = popupContainer

local uiTextSizeConstraint: UITextSizeConstraint = Instance.new("UITextSizeConstraint")

uiTextSizeConstraint.MinTextSize = 16
uiTextSizeConstraint.MaxTextSize = 46
uiTextSizeConstraint.Parent = powerPopup

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 0.65
uiScale.Parent = popupContainer

local n1: number = 0

local function showPopup(p1)
	n1 += 1

	local v15: number = n1

	popupContainer.Visible = true
	powerPopup.Text = tostring(p1)
	powerPopup.TextTransparency = 1
	powerPopup.TextStrokeTransparency = 1
	background.ImageTransparency = 1
	uiScale.Scale = 0.65

	local tweenInfo = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	local v17: Tween = tweenService:Create(uiScale, tweenInfo, { Scale = 1.12 })
	local tweenInfo2 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v19: Tween = tweenService:Create(powerPopup, tweenInfo2, { TextTransparency = 0, TextStrokeTransparency = 0 })
	local tweenInfo3 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v21: Tween = tweenService:Create(background, tweenInfo3, { ImageTransparency = 0.15 })

	v17:Play()
	v19:Play()
	v21:Play()
	v17.Completed:Wait()

	if v15 ~= n1 then
		return
	end

	local tweenInfo4 = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

	v21 = tweenService:Create(uiScale, tweenInfo4, { Scale = 1 })
	v21:Play()
	v21.Completed:Wait()
	task.wait(2.5)

	if v15 ~= n1 then
		return
	end

	local tweenInfo5 = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In)

	v21 = tweenService:Create(uiScale, tweenInfo5, { Scale = 0.7 })

	local tweenInfo6 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

	v19 = tweenService:Create(powerPopup, tweenInfo6, { TextTransparency = 1, TextStrokeTransparency = 1 })

	local tweenInfo7 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	local v26: Tween = tweenService:Create(background, tweenInfo7, { ImageTransparency = 1 })

	v21:Play()
	v19:Play()
	v26:Play()
	v19.Completed:Wait()

	if v15 ~= n1 then
		return
	end

	popupContainer.Visible = false
	powerPopup.Text = ""
end

msBlockPopup.OnClientEvent:Connect(function(p2)
	task.spawn(showPopup, p2)
end)
