-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local lighting: Lighting = game:GetService("Lighting")
local soundService: SoundService = game:GetService("SoundService")
local system: Instance = replicatedStorage:WaitForChild("System")
local lazySound = require(system:WaitForChild("LazySound"))
local LocalPlayer: Player = players.LocalPlayer
local msBlockXRay: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MSBlockXRay")
local xRaySfx: Instance = replicatedStorage:WaitForChild("Extras"):WaitForChild("ItemFolder"):WaitForChild("XRaySfx")
local skullBillboardGui: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Peacemaker"):WaitForChild("Fx"):WaitForChild("SkullBillboardGui")
local clone = nil
local folder = nil
local connection = nil
local u15 = nil
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local n1: number = 0

local function hasSoul(p1)
	local v30 = p1

	if v30 then
		v30 = p1:FindFirstChild("Soul", true) ~= nil
	end

	return v30
end
local function removeSkullBillboard(p2)
	local v32 = t2[p2]

	if v32 then
		t2[p2] = nil

		if v32.Parent then
			v32:Destroy()
		end
	end
end
local function addSkullBillboard(p3)
	if skullBillboardGui and p3 and not t2[p3] then
		local head = p3:FindFirstChild("Head")

		if not head or not head:IsA("BasePart") then
			return
		end

		local msBlockSkullBillboardGui = head:FindFirstChild("MSBlockSkullBillboardGui")

		if msBlockSkullBillboardGui then
			msBlockSkullBillboardGui:Destroy()
		end

		local clone: Instance = skullBillboardGui:Clone()

		clone.Name = "MSBlockSkullBillboardGui"
		clone.Enabled = true
		clone.Parent = head
		t2[p3] = clone

		return
	end
end
local function addHighlight(character)
	if folder and folder.Parent and character and character:IsA("Model") then
		local v38 = character

		if v38 then
			v38 = character:FindFirstChild("Soul", true) ~= nil
		end

		if not v38 and not t1[character] then
			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if humanoid and not (humanoid.Health <= 0) then
				local xRayHighlight: Highlight = Instance.new("Highlight")

				xRayHighlight.Name = "XRayHighlight"
				xRayHighlight.Adornee = character
				xRayHighlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
				xRayHighlight.FillColor = Color3.fromRGB(255, 55, 55)
				xRayHighlight.FillTransparency = 0.45
				xRayHighlight.OutlineColor = Color3.fromRGB(255, 255, 255)
				xRayHighlight.OutlineTransparency = 0
				xRayHighlight.Parent = folder
				t1[character] = xRayHighlight
				addSkullBillboard(character)
				character.Destroying:Once(function()
					t1[character] = nil

					local v61 = character
					local v62 = t2[v61]

					if v62 then
						t2[v61] = nil

						if v62.Parent then
							v62:Destroy()
						end
					end
				end)

				return
			end

			return
		end

		return
	end
end
local function scanHumanoids()
	for iterFirst, iterSecond in workspace:GetDescendants() do
		if iterSecond:IsA("Humanoid") then
			addHighlight(iterSecond.Parent)
		end
	end
end
local function createBlackAndWhiteEffect()
	if u15 then
		u15:Destroy()
	end

	local msBlockXRayColor: Instance = lighting:FindFirstChild("MSBlockXRayColor")

	if msBlockXRayColor then
		msBlockXRayColor:Destroy()
	end

	local msBlockXRayColor: ColorCorrectionEffect = Instance.new("ColorCorrectionEffect")

	game.Debris:AddItem(msBlockXRayColor, 14)
	msBlockXRayColor.Name = "MSBlockXRayColor"
	msBlockXRayColor.Enabled = true
	msBlockXRayColor.TintColor = Color3.new(1, 1, 1)
	msBlockXRayColor.Brightness = 0
	msBlockXRayColor.Contrast = 0
	msBlockXRayColor.Saturation = 0
	msBlockXRayColor.Parent = lighting
	u15 = msBlockXRayColor

	local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

	tweenService:Create(msBlockXRayColor, tweenInfo, { Saturation = -2.5, Contrast = 0.2, Brightness = -0.03 }):Play()
end
local function removeBlackAndWhiteEffect(p5)
	local v47 = u15

	if not v47 or not v47.Parent then
		u15 = nil

		return
	end

	u15 = nil

	if p5 then
		v47:Destroy()

		return
	end

	local tweenInfo = TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v49: Tween = tweenService:Create(v47, tweenInfo, {
		Brightness = 0,
		Contrast = 0,
		Saturation = 0,
		TintColor = Color3.new(1, 1, 1)
	})

	v49:Play()
	v49.Completed:Once(function()
		if v47.Parent then
			v47:Destroy()
		end
	end)
end
local function playXRaySound()
	if clone then
		clone:Destroy()
		clone = nil
	end

	clone = xRaySfx:Clone()
	clone.Name = "LocalXRaySfx"
	clone.Volume = xRaySfx.Volume
	clone.Looped = false
	clone.Parent = soundService
	clone.TimePosition = 0
	lazySound.Play(clone, false)
end
local function stopXRaySound(p6)
	local v51 = clone

	if not v51 then
		return
	end

	clone = nil

	if not not p6 or not v51.IsPlaying then
		v51:Destroy()

		return
	end

	local tweenInfo = TweenInfo.new(0.6, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
	local v53: Tween = tweenService:Create(v51, tweenInfo, { Volume = 0 })

	v53:Play()
	v53.Completed:Once(function()
		if v51.Parent then
			v51:Destroy()
		end
	end)
end
local function stopXRay(p7)
	if connection then
		connection:Disconnect()
		connection = nil
	end

	if folder then
		folder:Destroy()
		folder = nil
	end

	table.clear(t1)

	for iterValue in t2 do
		local v56 = t2[iterValue]

		if v56 then
			t2[iterValue] = nil

			if v56.Parent then
				v56:Destroy()
			end
		end
	end

	table.clear(t2)
	removeBlackAndWhiteEffect(p7)
	stopXRaySound(p7)
end

msBlockXRay.OnClientEvent:Connect(function(p8)
	local numberValue: number? = tonumber(p8)
	local v59 = math.max(0, numberValue or 10)

	n1 += 1

	local v60: number = n1

	stopXRay(true)
	folder = Instance.new("Folder")
	folder.Name = "MSBlockXRay"
	folder.Parent = LocalPlayer:WaitForChild("PlayerGui")
	createBlackAndWhiteEffect()

	if clone then
		clone:Destroy()
		clone = nil
	end

	clone = xRaySfx:Clone()
	clone.Name = "LocalXRaySfx"
	clone.Volume = xRaySfx.Volume
	clone.Looped = false
	clone.Parent = soundService
	clone.TimePosition = 0
	lazySound.Play(clone, false)
	scanHumanoids()
	connection = workspace.DescendantAdded:Connect(function(descendant: Instance)
		if descendant:IsA("Humanoid") then
			task.defer(addHighlight, descendant.Parent)
		end
	end)
	task.delay(v59, function()
		if n1 ~= v60 then
			return
		end

		stopXRay(false)
	end)
end)
