-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local debris: Debris = game:GetService("Debris")
local LocalPlayer: Player = players.LocalPlayer
local humanoid = nil
local humanoidRootPart = nil
local u7: boolean = false
local connection = nil
local connection2 = nil

local function getHorizontalLook(p1)
	local lookVector = p1.LookVector
	local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)

	if vector3.Magnitude < 0.01 then
		local rightVector = p1.RightVector

		vector3 = Vector3.new(rightVector.X, 0, rightVector.Z)
	end

	if vector3.Magnitude < 0.01 then
		return Vector3.new(0, 0, -1)
	end

	return vector3.Unit
end
local function destroyOldUpright(p2)
	local stunUprightAlign = p2:FindFirstChild("StunUprightAlign")

	if stunUprightAlign then
		stunUprightAlign:Destroy()
	end
end
local function startUprightAlign(p3)
	if not p3 or not humanoid or not humanoidRootPart then
		return
	end

	if humanoid.Health <= 0 then
		return
	end

	if humanoidRootPart.CFrame.UpVector.Y > 0.8 then
		return
	end

	local stunUprightAttachment = humanoidRootPart:FindFirstChild("StunUprightAttachment")

	if not stunUprightAttachment then
		stunUprightAttachment = Instance.new("Attachment")
		stunUprightAttachment.Name = "StunUprightAttachment"
		stunUprightAttachment.Parent = humanoidRootPart
	end

	local stunUprightAlign = humanoidRootPart:FindFirstChild("StunUprightAlign")

	if stunUprightAlign then
		stunUprightAlign:Destroy()
	end

	local humanoidRootPartCFrame = humanoidRootPart.CFrame
	local humanoidRootPartCFrameLookVector = humanoidRootPartCFrame.LookVector
	local vector3 = Vector3.new(humanoidRootPartCFrameLookVector.X, 0, humanoidRootPartCFrameLookVector.Z)

	if vector3.Magnitude < 0.01 then
		local humanoidRootPartCFrameRightVector = humanoidRootPartCFrame.RightVector

		vector3 = Vector3.new(humanoidRootPartCFrameRightVector.X, 0, humanoidRootPartCFrameRightVector.Z)
	end

	local cFrame = CFrame.lookAt(Vector3.new(0, 0, 0), if vector3.Magnitude < 0.01 then Vector3.new(0, 0, -1) else vector3.Unit, Vector3.new(0, 1, 0))

	humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)

	local stunUprightAlign: AlignOrientation = Instance.new("AlignOrientation")

	stunUprightAlign.Name = "StunUprightAlign"
	stunUprightAlign.Attachment0 = stunUprightAttachment
	stunUprightAlign.Mode = Enum.OrientationAlignmentMode.OneAttachment
	stunUprightAlign.Responsiveness = 80
	stunUprightAlign.MaxAngularVelocity = math.huge
	stunUprightAlign.CFrame = cFrame
	stunUprightAlign.RigidityEnabled = false
	stunUprightAlign.Parent = humanoidRootPart
	debris:AddItem(stunUprightAlign, 0.35)
end
local function scheduleUprightFix(p4)
	task.defer(function()
		if p4 and p4.Parent and humanoid and humanoidRootPart then
			startUprightAlign(p4)
		end
	end)
	task.delay(0.06, function()
		if p4 and p4.Parent and humanoid and humanoidRootPart then
			startUprightAlign(p4)
		end
	end)
	task.delay(0.16, function()
		if p4 and p4.Parent and humanoid and humanoidRootPart then
			startUprightAlign(p4)
		end
	end)
end

local t1: {[any]: any} = {
	Enum.HumanoidStateType.RunningNoPhysics,
	Enum.HumanoidStateType.Jumping,
	Enum.HumanoidStateType.Climbing,
	Enum.HumanoidStateType.Swimming
}

local function setMovementLocked(p5)
	if not humanoid then
		return
	end

	for _, v in ipairs(t1) do
		humanoid:SetStateEnabled(v, not p5)
	end

	if p5 then
		humanoid:Move(Vector3.new(0, 0, 0), true)
	end
end
local function fullyRecover(p6)
	if not p6 or not humanoid or not humanoidRootPart then
		return
	end

	if humanoid.Health <= 0 then
		return
	end

	humanoid.AutoRotate = true
	humanoid.PlatformStand = false
	scheduleUprightFix(p6)

	local v40 = humanoid:GetState()

	if v40 == Enum.HumanoidStateType.Ragdoll or v40 == Enum.HumanoidStateType.FallingDown or v40 == Enum.HumanoidStateType.Physics or v40 == Enum.HumanoidStateType.GettingUp then
		humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)

		return
	end

	humanoid:ChangeState(Enum.HumanoidStateType.Running)
end
local function hasCantAttack(p7)
	for iterFirst, value in { "CantAttack", "Cantattack" }, nil, nil do
		local value = p7:FindFirstChild(value)

		if value and value:GetAttribute("MenuProtection") ~= true then
			return true
		end
	end

	return false
end
local function disconnectCharacterConns()
	if connection then
		connection:Disconnect()
		connection = nil
	end

	if connection2 then
		connection2:Disconnect()
		connection2 = nil
	end
end
local function bindCharacter(character)
	if connection then
		connection:Disconnect()
		connection = nil
	end

	if connection2 then
		connection2:Disconnect()
		connection2 = nil
	end

	humanoid = nil
	humanoidRootPart = nil
	u7 = false

	if not character then
		return
	end

	humanoid = character:FindFirstChildOfClass("Humanoid")
	humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

	if not humanoid or not humanoidRootPart then
		return
	end

	connection = humanoid.StateChanged:Connect(function(_, p10)
		if p10 == Enum.HumanoidStateType.Physics or p10 == Enum.HumanoidStateType.Ragdoll or p10 == Enum.HumanoidStateType.FallingDown then
			scheduleUprightFix(character)
		end
	end)
	connection2 = humanoidRootPart:GetPropertyChangedSignal("Anchored"):Connect(function()
		scheduleUprightFix(character)
	end)
end

bindCharacter(LocalPlayer.Character)
LocalPlayer.CharacterAdded:Connect(function(character: Model)
	character:WaitForChild("Humanoid", 10)
	character:WaitForChild("HumanoidRootPart", 10)
	task.wait()
	bindCharacter(character)
end)
runService.RenderStepped:Connect(function()
	local Character: Model = LocalPlayer.Character

	if not Character then
		return
	end

	if not humanoid or not humanoidRootPart or Character ~= humanoid.Parent or Character ~= humanoidRootPart.Parent then
		bindCharacter(Character)

		if not humanoid or not humanoidRootPart then
			return
		end
	end

	local v48 = hasCantAttack(Character)

	if v48 and not u7 then
		u7 = true
		setMovementLocked(true)
	elseif not v48 and u7 then
		u7 = false

		if humanoid then
			for _, v in ipairs(t1) do
				humanoid:SetStateEnabled(v, true)
			end
		end

		fullyRecover(Character)
	end

	if u7 then
		humanoid:Move(Vector3.new(0, 0, 0), true)

		if humanoidRootPart.CFrame.UpVector.Y <= 0.8 then
			scheduleUprightFix(Character)

			return
		end
	elseif humanoidRootPart.CFrame.UpVector.Y <= 0.8 then
		fullyRecover(Character)
	end
end)
