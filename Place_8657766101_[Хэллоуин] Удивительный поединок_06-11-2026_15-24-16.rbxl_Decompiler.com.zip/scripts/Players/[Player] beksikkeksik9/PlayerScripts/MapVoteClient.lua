-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local userInputService: UserInputService = game:GetService("UserInputService")
local guiService: GuiService = game:GetService("GuiService")
local tweenService: TweenService = game:GetService("TweenService")
local LocalPlayer: Player = players.LocalPlayer
local mapVote: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("MapVote")
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsRuntime = require(system:WaitForChild("ControlsRuntime"))
local t1: {[any]: any} = { "MapVoteOne", "MapVoteTwo", "MapVoteThree" }
local u11: boolean = false
local u12: boolean = false
local t2 = {}
local t3 = {}
local u15 = nil
local n1 = 0
local u17 = nil
local mapVoteGui: ScreenGui = Instance.new("ScreenGui")

mapVoteGui.Name = "MapVoteGui"
mapVoteGui.ResetOnSpawn = false
mapVoteGui.IgnoreGuiInset = true
mapVoteGui.Enabled = false
mapVoteGui.DisplayOrder = 60
mapVoteGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

local root: CanvasGroup = Instance.new("CanvasGroup")

root.Name = "Root"
root.AnchorPoint = Vector2.new(0.5, 0.5)
root.Position = UDim2.new(0.5, 0, 0.24, 0)
root.Size = UDim2.new(0, 620, 0, 185)
root.BackgroundTransparency = 1
root.Parent = mapVoteGui

local uiScale: UIScale = Instance.new("UIScale")

uiScale.Scale = 1
uiScale.Parent = root

local n2 = 1
local n3: number = 1

local function applyScale()
	uiScale.Scale = n2 * n3
end
local function updateResponsiveScale()
	local CurrentCamera: Camera = workspace.CurrentCamera
	local v51 = CurrentCamera and CurrentCamera.ViewportSize or Vector2.new(1280, 720)
	local v52 = math.min(v51.X * 0.88 / 620, v51.Y * 0.3 / 185)

	n2 = math.clamp(v52, 0.42, 1)
	uiScale.Scale = n2 * n3
end
local function watchCamera(p1)
	if not p1 then
		return
	end

	local CurrentCamera: Camera = workspace.CurrentCamera
	local v55 = CurrentCamera and CurrentCamera.ViewportSize or Vector2.new(1280, 720)
	local v56 = math.min(v55.X * 0.88 / 620, v55.Y * 0.3 / 185)

	n2 = math.clamp(v56, 0.42, 1)
	uiScale.Scale = n2 * n3
	p1:GetPropertyChangedSignal("ViewportSize"):Connect(updateResponsiveScale)
end

local CurrentCamera: Camera = workspace.CurrentCamera

if CurrentCamera then
	local CurrentCamera2: Camera = workspace.CurrentCamera
	local v28 = CurrentCamera2 and CurrentCamera2.ViewportSize or Vector2.new(1280, 720)
	local v29 = math.min(v28.X * 0.88 / 620, v28.Y * 0.3 / 185)

	n2 = math.clamp(v29, 0.42, 1)
	uiScale.Scale = n2 * n3
	CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(updateResponsiveScale)
end

workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
	local CurrentCamera3: Camera = workspace.CurrentCamera

	if not CurrentCamera3 then
		return
	end

	local CurrentCamera4: Camera = workspace.CurrentCamera
	local v59 = CurrentCamera4 and CurrentCamera4.ViewportSize or Vector2.new(1280, 720)
	local v60 = math.min(v59.X * 0.88 / 620, v59.Y * 0.3 / 185)

	n2 = math.clamp(v60, 0.42, 1)
	uiScale.Scale = n2 * n3
	CurrentCamera3:GetPropertyChangedSignal("ViewportSize"):Connect(updateResponsiveScale)
end)

local title: TextLabel = Instance.new("TextLabel")

title.Name = "Title"
title.BackgroundTransparency = 1
title.Position = UDim2.new(0, 0, 0, 0)
title.Size = UDim2.new(1, 0, 0, 34)
title.Font = Enum.Font.Arcade
title.Text = "VOTE NEXT MAP"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextStrokeTransparency = 0.45
title.TextScaled = true
title.Parent = root

local subtitle: TextLabel = Instance.new("TextLabel")

subtitle.Name = "Subtitle"
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.new(0, 0, 0, 34)
subtitle.Size = UDim2.new(1, 0, 0, 22)
subtitle.Font = Enum.Font.Arcade
subtitle.Text = ""
subtitle.TextColor3 = Color3.fromRGB(220, 220, 220)
subtitle.TextStrokeTransparency = 0.65
subtitle.TextScaled = true
subtitle.Parent = root

local options: Frame = Instance.new("Frame")

options.Name = "Options"
options.BackgroundTransparency = 1
options.Position = UDim2.new(0, 0, 0, 63)
options.Size = UDim2.new(1, 0, 0, 118)
options.Parent = root

local uiListLayout: UIListLayout = Instance.new("UIListLayout")

uiListLayout.FillDirection = Enum.FillDirection.Horizontal
uiListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
uiListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
uiListLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiListLayout.Padding = UDim.new(0, 14)
uiListLayout.Parent = options

local t4: {[any]: any} = {}
local t5: {[any]: any} = {}
local t6: {[any]: any} = {}
local t7: {[any]: any} = {}
local t8: {[any]: any} = {}

local function formatBinding(p2)
	if not p2 or p2 == "" then
		return "?"
	end

	if p2 == "MouseButton1" then
		return "M1"
	end

	if p2 == "MouseButton2" then
		return "M2"
	end

	if p2 == "MouseButton3" then
		return "M3"
	end

	if p2 == "ButtonA" then
		return "A"
	end

	if p2 == "ButtonB" then
		return "B"
	end

	if p2 == "ButtonX" then
		return "X"
	end

	if p2 == "ButtonY" then
		return "Y"
	end

	if string.sub(p2, 1, 6) == "Button" then
		return (string.sub(p2, 7))
	end

	if string.sub(p2, 1, 4) == "DPad" then
		return string.gsub(p2, "DPad", "D-")
	end

	return p2
end
local function getActionText(p3)
	local v63 = t1[p3]
	local v64 = controlsRuntime.GetBinding(LocalPlayer, v63, "Keyboard")
	local v65 = controlsRuntime.GetBinding(LocalPlayer, v63, "Controller")
	v63 = {}

	if v64 and v64 ~= "" then
		table.insert(v63, formatBinding(v64))
	end

	if v65 and v65 ~= "" then
		table.insert(v63, formatBinding(v65))
	end

	if #v63 <= 0 then
		return "TAP / SELECT"
	end

	return table.concat(v63, " / ")
end
local function makeButton(layoutOrder)
	local textButton: TextButton = Instance.new("TextButton")

	textButton.Name = "Option" .. layoutOrder
	textButton.LayoutOrder = layoutOrder
	textButton.Size = UDim2.new(0, 190, 0, 112)
	textButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	textButton.BackgroundTransparency = 0.55
	textButton.BorderSizePixel = 0
	textButton.AutoButtonColor = true
	textButton.Text = ""
	textButton.Selectable = true
	textButton.Parent = options

	local uiCorner: UICorner = Instance.new("UICorner")

	uiCorner.CornerRadius = UDim.new(0, 10)
	uiCorner.Parent = textButton

	local uiStroke: UIStroke = Instance.new("UIStroke")

	uiStroke.Color = Color3.fromRGB(255, 255, 255)
	uiStroke.Thickness = 1
	uiStroke.Transparency = 0.7
	uiStroke.Parent = textButton
	t8[layoutOrder] = uiStroke

	local key: TextLabel = Instance.new("TextLabel")

	key.Name = "Key"
	key.BackgroundTransparency = 1
	key.Position = UDim2.new(0.08, 0, 0.05, 0)
	key.Size = UDim2.new(0.84, 0, 0, 20)
	key.Font = Enum.Font.Arcade
	key.Text = ""
	key.TextColor3 = Color3.fromRGB(255, 219, 92)
	key.TextStrokeTransparency = 0.65
	key.TextScaled = true
	key.Parent = textButton
	t7[layoutOrder] = key

	local mapName: TextLabel = Instance.new("TextLabel")

	mapName.Name = "MapName"
	mapName.BackgroundTransparency = 1
	mapName.Position = UDim2.new(0.06, 0, 0.28, 0)
	mapName.Size = UDim2.new(0.88, 0, 0, 36)
	mapName.Font = Enum.Font.Arcade
	mapName.Text = "MAP"
	mapName.TextColor3 = Color3.fromRGB(255, 255, 255)
	mapName.TextStrokeTransparency = 0.5
	mapName.TextScaled = true
	mapName.Parent = textButton
	t5[layoutOrder] = mapName

	local votes: TextLabel = Instance.new("TextLabel")

	votes.Name = "Votes"
	votes.BackgroundTransparency = 1
	votes.Position = UDim2.new(0.08, 0, 0.68, 0)
	votes.Size = UDim2.new(0.84, 0, 0, 28)
	votes.Font = Enum.Font.Arcade
	votes.Text = "0 VOTES"
	votes.TextColor3 = Color3.fromRGB(210, 210, 210)
	votes.TextStrokeTransparency = 0.65
	votes.TextScaled = true
	votes.Parent = textButton
	t6[layoutOrder] = votes
	textButton.Activated:Connect(function(p5: InputObject)
		if p5 and p5.UserInputType == Enum.UserInputType.MouseButton1 then
		elseif u11 then
			u17(layoutOrder)
		end
	end)
	t4[layoutOrder] = textButton
end

for i = 1, 3 do
	makeButton(i)
end

makeButton = function()
	local n1 = -1
	local v74 = nil

	for i = 1, #t2 do
		local v76 = t3[i] or 0

		if n1 < v76 then
			n1 = v76
			v74 = i
		end
	end

	if n1 <= 0 then
		return nil
	end

	return v74
end

local function updateVisuals()
	local n1 = -1
	local v78 = nil

	for i = 1, #t2 do
		local v80 = t3[i] or 0

		if n1 < v80 then
			n1 = v80
			v78 = i
		end
	end

	for i = 1, 3 do
		local v82 = t4[i]
		local v83 = t2[i]
		local v84 = t3[i] or 0

		v82.Visible = v83 ~= nil
		t5[i].Text = string.upper(v83 or "")
		t6[i].Text = tostring(v84) .. (if v84 == 1 then " VOTE" else " VOTES")
		t7[i].Text = getActionText(i)

		local color3 = Color3.fromRGB(255, 255, 255)

		v83 = 0.7

		local n2: number = 0.55

		if i == u15 then
			color3 = Color3.fromRGB(255, 219, 92)
			v83 = 0.1
			n2 = 0.42
		elseif (if n1 <= 0 then nil else v78) == i then
			color3 = Color3.fromRGB(90, 255, 130)
			v83 = 0.18
			n2 = 0.48
		end

		v82.BackgroundTransparency = n2
		t8[i].Color = color3
		t8[i].Transparency = v83
		t6[i].TextColor3 = color3
	end
end
local function showGui()
	mapVoteGui.Enabled = true
	root.Visible = true

	local CurrentCamera5: Camera = workspace.CurrentCamera
	local v88 = CurrentCamera5 and CurrentCamera5.ViewportSize or Vector2.new(1280, 720)
	local v89 = math.min(v88.X * 0.88 / 620, v88.Y * 0.3 / 185)

	n2 = math.clamp(v89, 0.42, 1)
	uiScale.Scale = n2 * n3
	root.Position = UDim2.new(0.5, 0, 0.205, -16)
	root.GroupTransparency = 1
	n3 = 0.94
	uiScale.Scale = n2 * n3

	local tweenInfo = TweenInfo.new(0.38, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)

	tweenService:Create(root, tweenInfo, { GroupTransparency = 0, Position = UDim2.new(0.5, 0, 0.24, 0) }):Play()

	local numberValue: NumberValue = Instance.new("NumberValue")

	numberValue.Value = n3

	local tweenInfo2 = TweenInfo.new(0.38, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

	v88 = tweenService:Create(numberValue, tweenInfo2, { Value = 1 })
	numberValue:GetPropertyChangedSignal("Value"):Connect(function()
		n3 = numberValue.Value
		uiScale.Scale = n2 * n3
	end)
	v88.Completed:Connect(function()
		numberValue.Parent = nil
	end)
	v88:Play()

	if userInputService.GamepadEnabled and t4[1] and t4[1].Visible then
		pcall(function()
			guiService.SelectedObject = t4[1]
		end)
	end
end
local function hideGui()
	if not mapVoteGui.Enabled then
		return
	end

	local tweenInfo = TweenInfo.new(0.55, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut)
	local v94: Tween = tweenService:Create(root, tweenInfo, { GroupTransparency = 1, Position = UDim2.new(0.5, 0, 0.17, -34) })
	local numberValue: NumberValue = Instance.new("NumberValue")

	numberValue.Value = n3

	local tweenInfo3 = TweenInfo.new(0.55, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut)
	local v97: Tween = tweenService:Create(numberValue, tweenInfo3, { Value = 0.88 })

	numberValue:GetPropertyChangedSignal("Value"):Connect(function()
		n3 = numberValue.Value
		uiScale.Scale = n2 * n3
	end)
	v97.Completed:Connect(function()
		numberValue.Parent = nil
	end)
	v97:Play()
	v94:Play()
	v94.Completed:Connect(function()
		if not u11 then
			mapVoteGui.Enabled = false
		end
	end)
end

u17 = function(p6)
	if not u11 then
		return
	end

	if p6 == u15 then
		return
	end

	u12 = true
	u15 = p6
	title.Text = "VOTE UPDATED"
	subtitle.Text = "YOU CAN CHANGE UNTIL TIME RUNS OUT"
	updateVisuals()
	mapVote:FireServer("Vote", p6)
end

local n4: number = 0

local function startCountdownLoop()
	n4 += 1

	local v99: number = n4

	task.spawn(function()
		while v99 == n4 and u11 and mapVoteGui.Enabled do
			if u12 and u15 and t2[u15] then
				local stringUpper = string.upper
				local text: string = tostring(t2[u15])

				subtitle.Text = "CURRENT: " .. stringUpper(text) .. " - CLICK ANOTHER TO CHANGE"
			else
				subtitle.Text = "CHOOSE A MAP"
			end

			task.wait(0.2)
		end
	end)
end
local function startVote(p7, p8, p9)
	u11 = true
	u12 = false
	u15 = nil
	t2 = p7 or {}
	t3 = p8 or {}

	local v103 = os.clock()
	local numberValue: number? = tonumber(p9)

	n1 = v103 + (numberValue or 10)
	title.Text = "VOTE NEXT MAP"
	subtitle.Text = "CHOOSE A MAP"
	updateVisuals()
	showGui()
	n4 += 1

	local v105: number = n4

	task.spawn(function()
		while v105 == n4 and u11 and mapVoteGui.Enabled do
			if u12 and u15 and t2[u15] then
				local stringUpper = string.upper
				local text: string = tostring(t2[u15])

				subtitle.Text = "CURRENT: " .. stringUpper(text) .. " - CLICK ANOTHER TO CHANGE"
			else
				subtitle.Text = "CHOOSE A MAP"
			end

			task.wait(0.2)
		end
	end)
end
local function lockVote(p10, p11, p12)
	u15 = p10
	u12 = true
	t3 = p12 or t3
	title.Text = "VOTE SELECTED"

	local stringUpper = string.upper
	local text: string = tostring(p11 or "")

	subtitle.Text = "CURRENT: " .. stringUpper(text) .. " - CLICK ANOTHER TO CHANGE"
	updateVisuals()
end

mapVote.OnClientEvent:Connect(function(p13, ...)
	if p13 == "Start" then
		startVote(...)
	elseif p13 == "Update" then
		t3 = ...
		updateVisuals()
	elseif p13 == "Locked" then
		local v112, v113, v114 = ...

		u15 = v112
		u12 = true
		t3 = v114 or t3
		title.Text = "VOTE SELECTED"

		local stringUpper = string.upper
		local text: string = tostring(v113 or "")

		subtitle.Text = "CURRENT: " .. stringUpper(text) .. " - CLICK ANOTHER TO CHANGE"
		updateVisuals()
	elseif p13 == "End" then
		u11 = false
		n4 += 1

		local v117, v118, v119 = ...

		t3 = v119 or t3
		u15 = v117
		title.Text = "WINNER"

		local v120 = string.upper
		local text: string = tostring(v118 or "")

		subtitle.Text = v120(text)
		updateVisuals()
		task.delay(0.8, hideGui)
	elseif p13 == "Cancel" then
		u11 = false
		n4 += 1
		title.Text = "VOTE CANCELLED"
		subtitle.Text = tostring(... or "")
		task.delay(0.45, hideGui)
	end
end)
userInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if not u11 then
		return
	end

	if userInputService:GetFocusedTextBox() then
		return
	end

	for i = 1, 3 do
		local v125 = t1[i]

		if v125 and controlsRuntime.InputMatches(LocalPlayer, input, v125) then
			u17(i)

			return
		end
	end
end)
