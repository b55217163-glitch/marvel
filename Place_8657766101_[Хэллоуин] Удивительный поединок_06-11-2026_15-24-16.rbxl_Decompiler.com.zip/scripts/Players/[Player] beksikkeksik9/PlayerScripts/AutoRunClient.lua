-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local runService: RunService = game:GetService("RunService")
local LocalPlayer: Player = players.LocalPlayer
local u4 = nil
local humanoid = nil
local n1 = 0

local function hasAutoRun()
	return LocalPlayer:FindFirstChild("AutoRun") ~= nil
end
local function hasMovementLockout(p1)
	if not p1 then
		return true
	end

	local u12: boolean = true

	if p1:FindFirstChild("CantAttack") == nil then
		u12 = true

		if p1:FindFirstChild("Cantattack") == nil then
			u12 = true

			if p1:FindFirstChild("Disabled") == nil then
				u12 = p1:FindFirstChild("Blocking") ~= nil
			end
		end
	end

	return u12
end

if LocalPlayer.Character then
	local Character: Model = LocalPlayer.Character

	u4 = Character
	humanoid = nil

	if Character then
		humanoid = Character:FindFirstChildOfClass("Humanoid")

		if not humanoid then
			local connection = nil

			connection = Character.ChildAdded:Connect(function(child: Instance)
				local v14: boolean = child:IsA("Humanoid")

				if v14 then
					humanoid = child
				end

				if v14 and connection then
					connection:Disconnect()
				end
			end)
		end
	end
end

LocalPlayer.CharacterAdded:Connect(function(character: Model)
	u4 = character
	humanoid = nil

	if character then
		humanoid = character:FindFirstChildOfClass("Humanoid")

		if not humanoid then
			local connection = nil

			connection = character.ChildAdded:Connect(function(p3: Instance)
				local v21: boolean = p3:IsA("Humanoid")

				if v21 then
					humanoid = p3
				end

				if v21 and connection then
					connection:Disconnect()
				end
			end)
		end
	end
end)
runService.Heartbeat:Connect(function()
	if LocalPlayer:FindFirstChild("AutoRun") == nil then
		return
	end

	local v17 = u4
	local v18 = humanoid

	if v17 and v18 and not (v18.Health <= 0) then
		if hasMovementLockout(v17) then
		elseif v18.MoveDirection.Magnitude <= 0.05 then
		elseif v18.Sit then
		elseif v18.WalkSpeed > 0 and v18.WalkSpeed < 25 then
			local v19 = os.clock()

			if v19 - n1 >= 0.05 then
				n1 = v19
				v18.WalkSpeed = 25
			end
		end

		return
	end
end)
