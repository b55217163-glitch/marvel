-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local lighting: Lighting = game:GetService("Lighting")
local collectionService: CollectionService = game:GetService("CollectionService")

if not game:GetService("RunService"):IsClient() then
	warn("Attempted to initialize SmartBone on Server.")

	return nil
end

local dependencies: Instance = script:WaitForChild("Dependencies", 5)
local v4: string = script:GetFullName()

assert(dependencies, "Dependencies folder missing under " .. v4)

local components: Instance = script:WaitForChild("Components", 5)
local v6: string = script:GetFullName()

assert(components, "Components folder missing under " .. v6)

local config = require(dependencies.Config)
local unitConversion = require(dependencies.UnitConversion)
local defaultSettings = require(dependencies.DefaultSettings)
local particleTree = require(components.ParticleTree)
local particle = require(components.Particle)
local settingsMath = require(dependencies.SettingsMath)
local utilities = require(dependencies.Utilities)
local random = Random.new(12098135901304)
local v15 = collectionService:GetTagged("SmartBone")
local configDebug = config.Debug
local model = nil

if configDebug then
	model = Instance.new("Model")
	model.Name = "SMARTBONE_DEBUGFOLDER"
	model.Parent = workspace

	local highlight: Highlight = Instance.new("Highlight")

	highlight.FillColor = Color3.fromRGB(255, 0, 0)
	highlight.OutlineTransparency = 1
	highlight.FillTransparency = 0
	highlight.Parent = model
	highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	highlight.Enabled = true
end

local t1: {[any]: any} = {}
local module: {[any]: any} = {}

module.__index = module

function module.new(rootPart, p2)
	local v24 = random:NextInteger(1, 10000000)
	local unitConversionConvert = unitConversion.Convert
	local absoluteValue = math.abs(rootPart.Size.X)
	local v27 = unitConversionConvert(absoluteValue, "Millimeter")
	local bindableEvent: BindableEvent = Instance.new("BindableEvent")
	local object = setmetatable({
		Time = 0,
		WindPreviousPosition = Vector3.new(0, 0, 0),
		Removed = false,
		InRange = false,
		ID = v24,
		RootPart = rootPart,
		ParticleTrees = {},
		Connections = {},
		RootList = p2,
		ObjectScale = v27,
		RemovedEvent = bindableEvent,
		Settings = {}
	}, module)

	for iterFirst, iterSecond in defaultSettings do
		object.Settings[iterFirst] = rootPart:GetAttribute(iterFirst) or iterSecond
	end

	object.Settings.BlendWeight = 1
	object.Settings.UpdateRate = math.floor(object.Settings.UpdateRate + 0.1)
	object:Init()
	object:UpdateParameters(object.Settings)

	return object
end
function module.Init(p3)
	local rootPart = p3.RootPart

	t1[p3.ID] = p3
	p3.Connections.AttributeChanged = rootPart.AttributeChanged:ConnectParallel(function(p4)
		if p3.Settings[p4] == nil then
			return
		end

		p3:UpdateParameters(p4, rootPart:GetAttribute(p4))
	end)
	p3.Connections.LightingAttributeChanged = lighting.AttributeChanged:ConnectParallel(function(p5)
		if p3.Settings[p5] == nil then
			return
		end

		p3:UpdateParameters(p5, lighting:GetAttribute(p5))
	end)

	for iterFirst, iterSecond in rootPart:GetDescendants() do
		if iterSecond:IsA("Bone") and iterSecond.Parent:IsA("Bone") and #iterSecond:GetChildren() == 0 then
			local worldCFrame = iterSecond.WorldCFrame + iterSecond.WorldCFrame.UpVector.Unit * (iterSecond.WorldPosition - iterSecond.Parent.WorldPosition).Magnitude
			local bone: Bone = Instance.new("Bone")

			bone.Parent = iterSecond
			bone.Name = iterSecond.Name .. "_Tail"
			bone.WorldCFrame = worldCFrame
		end
	end

	for iterFirst2, iterSecond2 in p3.RootList, nil, nil do
		p3:AppendParticleTree(iterSecond2)
	end

	for iterFirst3, iterSecond3 in p3.ParticleTrees, nil, nil do
		p3:AppendParticles(iterSecond3, iterSecond3.Root, 0, 0)
	end
end
function module.AppendParticleTree(p6, p7)
	table.insert(p6.ParticleTrees, particleTree.new(p7, p6.RootPart, p6.Settings.Gravity))
end
function module.AppendParticles(p8, p9, p10, parentIndex, p12)
	local settings = p8.Settings
	local v50 = particle.new(p10, p9.Root, p8.RootPart, settings)
	local worldPosition = p10.WorldPosition

	v50.Position = p10.WorldPosition
	v50.LastPosition = worldPosition
	v50.ParentIndex = parentIndex
	v50.BoneLength = p12
	v50.HeirarchyLength = 0

	if configDebug == true then
		v50.DebugPart = Instance.new("Part")
		v50.DebugPart.Size = Vector3.new(0.1, 0.1, 0.1)
		v50.DebugPart.Anchored = true
		v50.DebugPart.CanCollide = false
		v50.DebugPart.CastShadow = false
		v50.DebugPart.CanTouch = false
		v50.DebugPart.CanQuery = false
		v50.DebugPart.Color = Color3.fromRGB(255, 0, 0)
		v50.DebugPart.Parent = model
	end

	if parentIndex >= 1 then
		p12 = (p9.Particles[parentIndex].Bone.WorldPosition - v50.Position).Magnitude
		v50.BoneLength = p12
		v50.Weight = p12 * 0.7
		v50.HeirarchyLength = utilities.GetHierarchyLength(p10, p9.Root)
	end

	if v50.HeirarchyLength <= settings.AnchorDepth then
		v50.Anchored = true
	end

	table.insert(p9.Particles, v50)
	v50 = #p9.Particles

	local children = p10:GetChildren()

	for i = 1, #children do
		local v54 = children[i]

		if v54:IsA("Bone") then
			p8:AppendParticles(p9, v54, v50, p12)
		end
	end
end
function module.UpdateParameters(p13, p14, p15)
	if typeof(p14) == "table" then
		for k, v in pairs(p14) do
			if p13.Settings[k] ~= nil then
				p13.Settings[k] = if settingsMath[k] then settingsMath[k](v) else v
			end
		end

		return
	end

	if typeof(p14) ~= "string" then
		return
	end

	if p13.Settings[p14] == nil then
		return
	end

	p13.Settings[p14] = if settingsMath[p14] then settingsMath[p14](p15) else p15
end
function module.PreUpdate(_, p17)
	local rootPart = p17.RootPart
	local root = p17.Root

	p17.ObjectMove = rootPart.Position - p17.ObjectPreviousPosition
	p17.ObjectPreviousPosition = rootPart.Position
	p17.RestGravity = root.CFrame:PointToWorldSpace(p17.LocalGravity)

	for iterFirst, iterSecond in p17.Particles, nil, nil do
		iterSecond.LastTransformOffset = iterSecond.TransformOffset

		if iterSecond.Bone == iterSecond.Root then
			iterSecond.TransformOffset = rootPart.CFrame * iterSecond.RootTransform
		else
			iterSecond.TransformOffset = root.WorldCFrame * iterSecond.Transform
		end

		iterSecond.LocalTransformOffset = root.CFrame * iterSecond.LocalTransform
	end
end
function module.UpdateParticles(p18, p19, p20, p21)
	local settings = p18.Settings
	local settingsDamping = settings.Damping
	local settingsGravity = settings.Gravity
	local unit = settings.Gravity.Unit
	local v74 = p19.RestGravity:Dot(unit)
	local v75 = math.max(v74, 0)
	local n1 = (settingsGravity - unit * v75 + settings.Force) * (p18.ObjectScale * p20)
	local v77 = p21 == 0 and p19.ObjectMove or Vector3.new(0, 0, 0)

	for iterFirst, iterSecond in p19.Particles, nil, nil do
		if iterSecond.ParentIndex >= 1 and iterSecond.Anchored == false then
			local vectorValue = Vector3.new(0, 0, 0)

			if settings.WindInfluence > 0 then
				local windOffset = p19.WindOffset
				local v82 = os.clock()
				local n2 = windOffset + (v82 - iterSecond.HeirarchyLength / 5) + (iterSecond.TransformOffset.Position - p19.Root.WorldPosition).Magnitude / 5 * settings.WindInfluence
				local x = settings.WindDirection.X
				local v85 = settings.WindDirection.X
				local sine = math.sin(n2 * settings.WindSpeed)
				local y = settings.WindDirection.Y
				local sine2 = math.sin(n2 * settings.WindSpeed)
				local z = settings.WindDirection.Z
				local v90 = settings.WindDirection.X
				local sine3 = math.sin(n2 * settings.WindSpeed)
				local n3 = Vector3.new(x + v85 * sine, y + sine2 * 0.05, z + v90 * sine3) / iterSecond.BoneLength * settings.WindInfluence
				local n4 = settings.WindStrength / 100

				v82 = math.clamp(iterSecond.HeirarchyLength, 1, 10)
				vectorValue = n3 * (n4 * (v82 / 10)) * iterSecond.Weight
				p18.WindPreviousPosition = vectorValue
			end

			local n5 = iterSecond.Position - iterSecond.LastPosition
			local n6 = v77 * settings.Inertia

			iterSecond.LastPosition = iterSecond.Position + n6
			iterSecond.Position = iterSecond.Position + (n5 * (1 - settingsDamping) + n1 + n6 + vectorValue)
		else
			iterSecond.LastPosition = iterSecond.TransformOffset.Position
			iterSecond.Position = iterSecond.TransformOffset.Position
		end
	end
end
function module.CorrectParticles(p22, p23, p24)
	local settings = p22.Settings
	local settingsStiffness = settings.Stiffness

	for iterFirst, iterSecond in p23.Particles, nil, nil do
		local v103 = p23.Particles[iterSecond.ParentIndex]

		if v103 and iterSecond.ParentIndex >= 1 and iterSecond.Anchored == false then
			local magnitude = (v103.TransformOffset.Position - iterSecond.TransformOffset.Position).Magnitude

			if settingsStiffness > 0 or settings.Elasticity > 0 then
				local n1 = CFrame.new(v103.Position) * v103.TransformOffset.Rotation
				local cFrame = CFrame.new(iterSecond.LocalTransformOffset.Position)
				local v107 = (n1 * cFrame).Position

				iterSecond.Position = iterSecond.Position + (v107 - iterSecond.Position) * (settings.Elasticity * p24)

				if settingsStiffness > 0 then
					local n2 = v107 - iterSecond.Position
					local v109 = n2.Magnitude
					local n3 = magnitude * (1 - settingsStiffness) * 2

					if v109 > n3 then
						iterSecond.Position = iterSecond.Position + n2 * ((v109 - n3) / v109)
					end
				end
			end

			local n4 = v103.Position - iterSecond.Position
			local v112 = n4.Magnitude

			if v112 > 0 then
				iterSecond.Position = iterSecond.Position + n4 * ((v112 - magnitude) / v112)
			end
		end
	end
end
function module.SkipUpdateParticles(p25, p26)
	for iterFirst, iterSecond in p26.Particles, nil, nil do
		if iterSecond.ParentIndex >= 1 and not iterSecond.Anchored then
			iterSecond.LastPosition = iterSecond.LastPosition + p26.ObjectMove
			iterSecond.Position = iterSecond.Position + p26.ObjectMove

			local v117 = p26.Particles[iterSecond.ParentIndex]
			local magnitude = (v117.TransformOffset.Position - iterSecond.TransformOffset.Position).Magnitude
			local stiffness = p25.Settings.Stiffness

			if stiffness > 0 then
				local v120 = v117.Position
				local v121 = CFrame.lookAt(v117.Position, iterSecond.Position)
				local n1 = v120 + v121.LookVector.Unit * (v117.Position - iterSecond.Position).Magnitude - iterSecond.Position
				local v123 = n1.Magnitude
				local n2 = magnitude * (1 - stiffness) * 2

				if v123 > n2 then
					iterSecond.Position = iterSecond.Position + n1 * ((v123 - n2) / v123)
				end
			end

			local n3 = v117.Position - iterSecond.Position
			local v126 = n3.Magnitude

			if magnitude < v126 then
				iterSecond.Position = iterSecond.Position + n3 * ((v126 - magnitude) / v126)
			end
		else
			iterSecond.LastPosition = iterSecond.TransformOffset.Position
			iterSecond.Position = iterSecond.TransformOffset.Position
		end
	end
end
function module.CalculateTransforms(p27, p28, p29)
	if p27.InRange then
		for iterFirst, iterSecond in p28.Particles, nil, nil do
			if iterSecond.ParentIndex >= 1 and iterSecond.Anchored == false then
				local v132 = p28.Particles[iterSecond.ParentIndex]
				local bone = v132.Bone

				if v132 and bone and bone:IsA("Bone") and bone ~= p28.Root then
					local transformOffset = v132.TransformOffset
					local v135 = transformOffset:PointToObjectSpace(v132.LocalTransformOffset.Position)
					local n1 = utilities.GetRotationBetween(transformOffset.UpVector, iterSecond.Position - v132.Position, v135).Rotation * transformOffset.Rotation
					local boneWorldCFrame = bone.WorldCFrame
					local cFrame = CFrame.new(v132.Position)

					v132.CalculatedWorldCFrame = boneWorldCFrame:Lerp(cFrame * n1, 1 - 0.00001 ^ p29)
				end
			end
		end
	end
end
function module.TransformBones(p30, p31)
	if p30.InRange then
		for iterFirst, iterSecond in p31.Particles, nil, nil do
			if iterSecond.ParentIndex >= 1 and iterSecond.Anchored == false then
				local v143 = p31.Particles[iterSecond.ParentIndex]
				local bone = v143.Bone

				if v143 and bone and bone:IsA("Bone") and bone ~= p31.Root then
					if v143.Anchored and p30.Settings.AnchorsRotate == false then
						bone.WorldCFrame = v143.TransformOffset
					else
						bone.WorldCFrame = v143.CalculatedWorldCFrame
					end
				end
			end
		end
	end
end
function module.DEBUG(_, p33)
	for iterFirst, iterSecond in p33.Particles, nil, nil do
		local debugPart = iterSecond and iterSecond.DebugPart

		if debugPart then
			debugPart.CFrame = CFrame.new(iterSecond.Position)
		end
	end
end
function module.RunLoop(p34, p35, p36, p37)
	local u154: boolean = true
	local n1 = p36 * 10

	if p37 > 0 then
		p34.Time = p34.Time + p36
		u154 = false

		if 1 / p37 <= p34.Time then
			u154 = true
			p34.Time = 0
		end
	end

	if u154 then
		p34:UpdateParticles(p35, n1, 0)
		p34:CorrectParticles(p35, n1)

		return
	end

	p34:SkipUpdateParticles(p35)
end
function module.ResetParticles(_, p39)
	for iterFirst, iterSecond in p39.Particles, nil, nil do
		iterSecond.LastPosition = iterSecond.TransformOffset.Position
		iterSecond.Position = iterSecond.TransformOffset.Position
	end
end
function module.ResetTransforms(_, p41)
	for iterFirst, iterSecond in p41.Particles, nil, nil do
		iterSecond.Bone.WorldCFrame = if iterSecond.Bone == iterSecond.Root then p41.RootPart.CFrame * iterSecond.RootTransform else p41.Root.WorldCFrame * iterSecond.Transform
	end
end
function module.UpdateBones(p42, p43, p44)
	for iterFirst, iterSecond in p42.ParticleTrees, nil, nil do
		p42:PreUpdate(iterSecond)
		p42:RunLoop(iterSecond, p43, p44)
		p42:CalculateTransforms(iterSecond, p43)
	end
end

local u21: boolean = false

function module.Start()
	if u21 then
		return
	end

	u21 = true

	local LocalPlayer = game.Players.LocalPlayer
	local actors: Folder = Instance.new("Folder")

	actors.Name = "Actors"

	local playerScripts = LocalPlayer:WaitForChild("PlayerScripts", 5)

	assert(playerScripts, "PlayerScripts missing for " .. LocalPlayer.Name)
	actors.Parent = playerScripts

	local function DebugPrint(p45)
		if configDebug then
			warn(p45)
		end
	end

	local t3: {[any]: any} = {}
	local t4: {[any]: any} = {}

	local function registerSmartBoneObject(p46)
		if p46:IsA("BasePart") and utilities.WaitForChildOfClass(p46, "Bone", 3) and game.Workspace:IsAncestorOf(p46) then
			local t5: {[any]: any} = {}

			if p46:GetAttribute("Roots") and p46:GetAttribute("Roots") ~= nil and typeof(p46:GetAttribute("Roots")) == "string" then
				local stringSplit = string.split
				local roots = p46:GetAttribute("Roots")
				local v185 = stringSplit(roots, ",")

				for _, v in ipairs(v185) do
					local foundChild = p46:FindFirstChild(v, true)

					if foundChild and foundChild:IsA("Bone") then
						table.insert(t5, foundChild)
					end
				end
			end

			local connection

			if #t5 > 0 then
				local actor: Actor = Instance.new("Actor")
				local event: BindableFunction = Instance.new("BindableFunction")

				event.Name = "Event"
				event.Parent = actor

				local actorScript: Instance = dependencies:WaitForChild("ActorScript", 5)
				local v194 = actorScript and actorScript:IsA("Script")

				assert(v194, "Dependencies.ActorScript missing or not a Script")

				local clone: Instance = actorScript:Clone()

				clone.Name = "Runtime"
				clone.Parent = actor
				actor.Parent = actors
				clone.Enabled = true

				local v196 = actor.Event:Invoke(p46, t5)

				if not v196 then
					actor:Destroy()

					return
				end

				t3[p46] = v196

				local v197 = p46.Name
				local text: string = tostring(v196.ID)

				actor.Name = v197 .. text
				connection = nil
				connection = v196.RemovedEvent.Event:Connect(function()
					connection:Disconnect()

					if actor:FindFirstChild("Runtime") then
						actor.Runtime.Enabled = false
					end

					actor:Destroy()
				end)
				table.insert(t4, p46)

				if configDebug then
					warn("Created new SmartBone Object with ID: " .. t3[p46].ID)
				end

				return
			end

			table.insert(t4, p46)

			local v199 = p46:GetFullName()

			connection = "! Make sure you have defined the Root Bone(s) for this object!"

			if configDebug then
				warn("Failed to create SmartBone Object for " .. v199 .. connection)
			end

			return
		end
	end

	collectionService:GetInstanceAddedSignal("SmartBone"):Connect(registerSmartBoneObject)
	collectionService:GetInstanceRemovedSignal("SmartBone"):Connect(function(p47)
		local v201 = t3[p47]

		if not v201 then
			return
		end

		local text: string = tostring(v201.ID)

		if configDebug then
			warn("Removing SmartBone Object with ID: " .. text)
		end

		task.spawn(function()
			if typeof(v201.Connections) == "table" then
				for _, v in pairs(v201.Connections) do
					if v then
						v:Disconnect()
					end
				end
			end

			local simulationConnection = v201.SimulationConnection

			if simulationConnection then
				simulationConnection:Disconnect()
			end

			if typeof(v201.ParticleTrees) == "table" then
				for _, v in ipairs(v201.ParticleTrees) do
					for iterFirst, iterSecond in v.Particles, nil, nil do
						local recyclingBin = iterSecond.RecyclingBin

						if typeof(recyclingBin) == "table" then
							for iterFirst2, iterSecond2 in recyclingBin do
								if iterSecond2 then
									iterSecond2:Destroy()
								end
							end
						end
					end
				end
			end

			if v201.ID then
				t1[v201.ID] = nil
			end

			v201.Removed = true

			if v201.RemovedEvent then
				v201.RemovedEvent:Fire()
				v201.RemovedEvent:Destroy()
				v201.RemovedEvent = nil
			end

			t3[p47] = nil
		end)
	end)

	for _, v in pairs(v15) do
		if not t3[v] and not table.find(t4, v) then
			task.spawn(function()
				registerSmartBoneObject(v)
			end)
		end
	end
end

return module
