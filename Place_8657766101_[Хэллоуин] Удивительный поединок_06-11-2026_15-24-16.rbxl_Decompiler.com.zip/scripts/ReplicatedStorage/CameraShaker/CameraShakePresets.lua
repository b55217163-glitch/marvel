-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local cameraShakeInstance = require(script.Parent.CameraShakeInstance)

local t1: {[any]: any} = {
	Bump = function()
		local v3 = cameraShakeInstance.new(2.5, 4, 0.1, 0.75)

		v3.PositionInfluence = Vector3.new(0.15, 0.15, 0.15)
		v3.RotationInfluence = Vector3.new(1, 1, 1)

		return v3
	end,
	BigBump = function()
		local v4 = cameraShakeInstance.new(2.5, 4, 0.1, 0.75)

		v4.PositionInfluence = Vector3.new(0.8, 0.8, 0.8)
		v4.RotationInfluence = Vector3.new(1, 1, 1)

		return v4
	end,
	SmallBump = function()
		local v5 = cameraShakeInstance.new(2.5, 4, 0.1, 0.75)

		v5.PositionInfluence = Vector3.new(0.02, 0.02, 0.02)
		v5.RotationInfluence = Vector3.new(0.05, 0.05, 0.05)

		return v5
	end,
	Explosion = function()
		local v6 = cameraShakeInstance.new(10, 10, 0, 1.5)

		v6.PositionInfluence = Vector3.new(0.7, 0.7, 0.7)
		v6.RotationInfluence = Vector3.new(4, 4, 4)

		return v6
	end,
	BumpRemaked = function()
		local v7 = cameraShakeInstance.new(2, 5, 0, 1)

		v7.PositionInfluence = Vector3.new(0.2, 0.2, 0.2)
		v7.RotationInfluence = Vector3.new(3, 1, 1)

		return v7
	end,
	BigExplosion = function()
		local v8 = cameraShakeInstance.new(20, 40, 0, 2)

		v8.PositionInfluence = Vector3.new(0.55, 0.55, 0.55)
		v8.RotationInfluence = Vector3.new(5, 2, 2)

		return v8
	end,
	ReallyBigExplosion = function()
		local v9 = cameraShakeInstance.new(30, 50, 0, 1.5)

		v9.PositionInfluence = Vector3.new(1, 1, 1)
		v9.RotationInfluence = Vector3.new(5, 2, 2)

		return v9
	end,
	SmallExplosion = function()
		local v10 = cameraShakeInstance.new(5, 10, 0, 1.5)

		v10.PositionInfluence = Vector3.new(0.15, 0.15, 0.15)
		v10.RotationInfluence = Vector3.new(2, 1, 1)

		return v10
	end,
	ExplosionNormal = function()
		local v11 = cameraShakeInstance.new(5, 10, 0, 1.5)

		v11.PositionInfluence = Vector3.new(3, 3, 3)
		v11.RotationInfluence = Vector3.new(4, 1, 1)

		return v11
	end,
	Earthquake = function()
		local v12 = cameraShakeInstance.new(0.6, 3.5, 2, 10)

		v12.PositionInfluence = Vector3.new(0.25, 0.25, 0.25)
		v12.RotationInfluence = Vector3.new(1, 1, 4)

		return v12
	end,
	BadTrip = function()
		local v13 = cameraShakeInstance.new(10, 0.15, 5, 10)

		v13.PositionInfluence = Vector3.new(0, 0, 0.15)
		v13.RotationInfluence = Vector3.new(2, 1, 4)

		return v13
	end,
	HandheldCamera = function()
		local v14 = cameraShakeInstance.new(1, 0.25, 5, 10)

		v14.PositionInfluence = Vector3.new(0, 0, 0)
		v14.RotationInfluence = Vector3.new(1, 0.5, 0.5)

		return v14
	end,
	Vibration = function()
		local v15 = cameraShakeInstance.new(0.4, 20, 2, 2)

		v15.PositionInfluence = Vector3.new(0, 0.15, 0)
		v15.RotationInfluence = Vector3.new(1.25, 0, 4)

		return v15
	end,
	VibrationHard = function()
		local v16 = cameraShakeInstance.new(3, 15, 0.2, 1.2)

		v16.PositionInfluence = Vector3.new(0, 0.2, 0)
		v16.RotationInfluence = Vector3.new(1.5, 0.5, 3)

		return v16
	end,
	RoughDriving = function()
		local v17 = cameraShakeInstance.new(1, 2, 1, 1)

		v17.PositionInfluence = Vector3.new(0, 0, 0)
		v17.RotationInfluence = Vector3.new(1, 1, 1)

		return v17
	end,
	Vib2 = function()
		local v18 = cameraShakeInstance.new(2, 20, 4, 4)

		v18.PositionInfluence = Vector3.new(0, 0.25, 0)
		v18.RotationInfluence = Vector3.new(5, 10, 4)

		return v18
	end
}

return (setmetatable({}, {
	__index = function(_, p2)
		local v21 = t1[p2]

		if type(v21) == "function" then
			return v21()
		end

		error("No preset found with index \"" .. p2 .. "\"")
	end
}))
