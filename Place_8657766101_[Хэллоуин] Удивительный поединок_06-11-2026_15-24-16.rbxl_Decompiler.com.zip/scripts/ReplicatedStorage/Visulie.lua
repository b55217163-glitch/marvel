-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
--!native
local runService: RunService = game:GetService("RunService")
local ease = require(script.ease)
local signal = require(script.Signal)
local lerper = require(script.lerper)

local function fastFind(p1, p2)
	local n1: number = 1
	local n2: number = #p1

	while n1 <= n2 do
		local n3: number = (n1 + n2) // 2

		if p2 >= p1[n3].time then
			n1 = n3 + 1
		else
			n2 = n3 - 1
		end
	end

	return n1 - 1
end

local t1: {[any]: any} = {
	Attachment0 = true,
	Attachment1 = true,
	Adornee = true,
	Part0 = true,
	Part1 = true,
	PrimaryPart = true
}
local t2: {[any]: any} = { CFrame = true, WorldPivot = true }
local module: {[any]: any} = {}

module.__index = module

function module.new(p3, p4)
	local t4: {[any]: any} = {}
	local t5: {[any]: any} = {}

	for iterFirst, iterSecond in p3.init, nil, nil do
		local v21 = Instance.new(iterSecond.class)

		v21.Name = iterFirst
		t5[iterFirst] = v21
		v21 = 1

		local v22 = iterSecond.parent

		while v22 do
			v21 += 1

			local v23 = p3.init[v22]

			v22 = v23 and v23.parent or nil
		end

		t4[v21] = t4[v21] or {}
		table.insert(t4[v21], iterFirst)
	end

	local t6: {[any]: any} = {}

	for key, value in t4 do
		for iterFirst2, iterSecond2 in value do
			table.insert(t6, iterSecond2)
		end
	end

	t4 = {}

	for iterFirst3, iterSecond3 in p3.vfx, nil, nil do
		for iterFirst4, iterSecond4 in iterSecond3 do
			for iterFirst5, iterSecond5 in iterSecond4 do
				local tag = iterSecond5.tag

				if tag then
					t4[tag] = t4[tag] or {}
					table.insert(t4[tag], iterSecond5)
				end
			end
		end
	end

	for iterFirst6, iterSecond6 in p3.emit, nil, nil do
		for iterFirst7, iterSecond7 in iterSecond6 do
			local v40 = iterSecond7.tag

			if v40 then
				t4[v40] = t4[v40] or {}
				table.insert(t4[v40], iterSecond7)
			end
		end
	end

	local object = setmetatable({
		_Elapsed = 0,
		_PreviousTime = 0,
		_Runner = nil,
		Framerate = -1,
		PlackbackSpeed = 1,
		Loops = false,
		_ObjectContainer = p4 or workspace,
		_TaggedKeyframes = t4,
		_Data = p3,
		_LiveObjects = t5,
		_EventListeners = {},
		_UpdateOrder = t6,
		Completed = signal.new(),
		_Origin = CFrame.new()
	}, module)

	object:_Reset()

	return object
end
local function callRender(p5)
	module._Render(p5)
end
function module._LoadInstances(p6)
	if p6._Runner then
		return
	end

	for iterFirst, iterSecond in p6._Data.init, nil, nil do
		local parent = iterSecond.parent

		p6._LiveObjects[iterFirst].Parent = parent and p6._LiveObjects[parent] or p6._ObjectContainer
	end
end
function module._Apply(p7, p8, p9, p10)
	local v51 = p7._LiveObjects[p8]

	if v51:IsA("PVInstance") and t2[p9] then
		local v52 = p7._Origin
		local parent = p7._Data.init[p8].parent
		local v54 = parent and p7._LiveObjects[parent]

		if v54 and v54:IsA("PVInstance") then
			v52 = v54:GetPivot()
		end

		v51:PivotTo(v52:ToWorldSpace(p10))

		return
	end

	if t1[p9] then
		v51[p9] = p10 ~= nil and p7._LiveObjects[p10] or nil

		return
	end

	v51[p9] = p10
end
function module._Reset(p11)
	for iterFirst, iterSecond in p11._Data.vfx, nil, nil do
		for iterFirst2, iterSecond2 in iterSecond do
			p11._LiveObjects[iterFirst].Parent = nil
			p11:_Apply(iterFirst, iterFirst2, iterSecond2[1].value)
		end
	end

	if p11._Runner then
		p11._Runner:Disconnect()
		p11._Runner = nil
	end

	p11._Elapsed = 0
	p11._PreviousTime = -math.huge
end
function module.Play(p12, p13)
	p12:_Reset()
	p12:_LoadInstances()
	p12:_StartPlaying(p13)
end
function module._StartPlaying(p14, p15)
	if p14._Runner then
		p14._Runner:Disconnect()
	end

	p14._Runner = runService.Heartbeat:Connect(function(deltaTime: number)
		local v118 = p14

		v118._Elapsed = v118._Elapsed + deltaTime * p14.PlackbackSpeed

		if p14.Framerate ~= -1 and p14._Elapsed < p14._PreviousTime + p14.PlackbackSpeed / p14.Framerate then
			return
		end

		if p14._Elapsed > p14._Data.length then
			p14._Elapsed = p14._Data.length

			if p14._Runner then
				p14._Runner:Disconnect()
				p14._Runner = nil
			end

			p14._Runner = nil

			if p14.Loops then
				local n1 = p14._Elapsed - p14._Data.length

				p14:_Reset()

				local v120 = p14

				v120._Elapsed = v120._Elapsed + n1
				p14:Resume()
			elseif p15 then
				p14:Destroy()
			else
				p14:_Reset()
			end

			p14.Completed:Fire()

			return
		end

		module._Render(p14)
		p14._PreviousTime = p14._Elapsed
	end)
end
function module._Render(p17)
	for iterFirst, iterSecond in p17._UpdateOrder, nil, nil do
		local v67 = p17._Data.vfx[iterSecond]

		if v67 then
			for iterFirst2, iterSecond2 in v67 do
				local v70 = fastFind(iterSecond2, p17._Elapsed)
				local v71
				local v72
				local n1
				local v74

				if v70 == 0 then
					v71 = iterSecond2[1].value
					v72 = iterSecond2[1].value
					n1 = if iterSecond2[1].time > 0 then p17._Elapsed / iterSecond2[1].time else 1
					v74 = iterSecond2[1].ease
				elseif v70 == #iterSecond2 then
					v71 = iterSecond2[v70].value
					v72 = v71
					n1 = 1
					v74 = iterSecond2[v70].ease
				else
					v71 = iterSecond2[v70].value
					v72 = iterSecond2[v70 + 1].value
					n1 = (p17._Elapsed - iterSecond2[v70].time) / (iterSecond2[v70 + 1].time - iterSecond2[v70].time)
					v74 = iterSecond2[v70 + 1].ease
				end

				v70 = ease[v74]

				local typeName: string = typeof(v71)

				p17:_Apply(iterSecond, iterFirst2, lerper[typeName](v71, v72, v70(n1)))
			end
		end
	end

	for iterFirst3, iterSecond3 in p17._Data.emit, nil, nil do
		local v78 = fastFind(iterSecond3, p17._Elapsed)
		local v79 = iterSecond3[v78]

		if v79 and v79.time >= p17._PreviousTime and v79.time < p17._Elapsed then
			p17._LiveObjects[iterFirst3]:Emit(v79.value)
		end
	end

	for iterFirst4, iterSecond4 in p17._Data.sfx, nil, nil do
		local v82 = fastFind(iterSecond4, p17._Elapsed)
		local v83 = iterSecond4[v82]

		if v83 and v83.time >= p17._PreviousTime and v83.time < p17._Elapsed then
			local v84 = p17._LiveObjects[iterFirst4]

			v84[v83.value](v84)
		end
	end

	local events = p17._Data.events
	local v86 = fastFind(p17._Data.events, p17._Elapsed)
	local v87 = events[v86]

	if v87 and v87.time >= p17._PreviousTime and v87.time < p17._Elapsed then
		for iterFirst5, iterSecond5 in v87.list, nil, nil do
			local v90 = p17._EventListeners[iterSecond5.name]

			if v90 then
				v90:Fire(iterSecond5.param)
			end
		end
	end
end
function module.Pause(p18)
	if p18._Runner then
		p18._Runner:Disconnect()
		p18._Runner = nil
	end
end
function module.Resume(p19)
	p19:_LoadInstances()
	p19:_StartPlaying(nil)
end
function module.Stop(p20)
	p20:_Reset()
end
function module.ForEachWithTag(p21, p22, p23)
	local v97 = p21._TaggedKeyframes[p22]

	if not v97 then
		local v98 = ("%* is not a valid tag in the animation"):format(p22)

		error(v98)
	end

	for iterFirst, iterSecond in v97 do
		iterSecond.value = p23(iterSecond.value)
	end
end
function module.SetOrigin(p24, p25)
	p24._Origin = p25

	if not p24._Runner then
		module._Render(p24)
	end
end
function module.SetTime(p26, p27)
	p26._Elapsed = p27
	module._Render(p26)
	p26:_LoadInstances()
	p26._PreviousTime = p27
end
function module.FitTime(p28, p29)
	local length = p28._Data.length
	local v108 = math.max(p29, 0.000001)

	p28.PlackbackSpeed = length / v108
end
function module.GetEventReachedSignal(p30, p31)
	local v111 = p30._EventListeners[p31]

	if not v111 then
		v111 = signal.new()
		p30._EventListeners[p31] = v111
	end

	return v111
end
function module.Destroy(p32)
	p32:Pause()

	for iterFirst, iterSecond in p32._LiveObjects, nil, nil do
		iterSecond:Destroy()
	end

	for iterFirst2, iterSecond2 in p32._EventListeners, nil, nil do
		iterSecond2:Destroy()
	end
end

return module
