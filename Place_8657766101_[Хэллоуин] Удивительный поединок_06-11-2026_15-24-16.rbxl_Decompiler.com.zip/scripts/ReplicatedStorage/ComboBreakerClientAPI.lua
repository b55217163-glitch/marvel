-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")

local function getResetRemote()
	local characters: Instance = replicatedStorage:FindFirstChild("Characters")
	local combat: Instance = characters and characters:FindFirstChild("Combat")
	local v7: Instance = combat

	if v7 then
		v7 = combat:FindFirstChild("Remotes")
	end

	return v7 and v7:FindFirstChild("ComboBreakerResetRemote")
end
local function getResetBindable()
	return replicatedStorage:FindFirstChild("ComboBreakerResetBindable")
end

local module: {[any]: any} = {
	ResetMeter = function()
		local comboBreakerResetBindable: Instance = replicatedStorage:FindFirstChild("ComboBreakerResetBindable")

		if comboBreakerResetBindable and comboBreakerResetBindable:IsA("BindableEvent") then
			comboBreakerResetBindable:Fire()

			return true
		end

		local characters: Instance = replicatedStorage:FindFirstChild("Characters")
		local combat: Instance = characters and characters:FindFirstChild("Combat")
		local v11: Instance = combat

		if v11 then
			v11 = combat:FindFirstChild("Remotes")
		end

		local v12: Instance = v11

		if v12 then
			v12 = v11:FindFirstChild("ComboBreakerResetRemote")
		end

		if v12 and v12:IsA("RemoteEvent") then
			v12:FireServer()

			return true
		end

		return false
	end
}

module.ResetBar = module.ResetMeter
module.Reset = module.ResetMeter

return module
