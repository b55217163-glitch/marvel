-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {
	OmniMan = { SpecialMove = 30 },
	Thragg = {
		MoveOne = 10,
		MoveTwo = 14,
		MoveThree = 12,
		MoveFour = 15,
		MoveFive = 0.1,
		SpecialMove = 30
	},
	Vecna = {
		MoveOne = 11,
		MoveTwo = 10,
		MoveThree = 12,
		MoveFour = 14,
		MoveFive = 0.5,
		VinePierce = 8,
		MindFlayer = 9,
		SpecialMove = 240
	},
	Deep = {
		MoveOne = 10,
		MoveTwo = 11,
		MoveThree = 12,
		MoveFour = 25,
		MoveFive = 0.1,
		SpecialMove = 15
	}
}

for iterFirst, iterSecond in require(script.Parent:WaitForChild("AbilityConfig")).Characters, nil, nil do
	module[iterFirst] = module[iterFirst] or {}

	local abilities = iterSecond.Abilities

	if typeof(abilities) == "table" then
		for iterFirst2, iterSecond2 in abilities do
			if typeof(iterSecond2) == "table" and typeof(iterSecond2.Cooldown) == "number" then
				module[iterFirst][iterFirst2] = iterSecond2.Cooldown
			end
		end
	end
end

return module
