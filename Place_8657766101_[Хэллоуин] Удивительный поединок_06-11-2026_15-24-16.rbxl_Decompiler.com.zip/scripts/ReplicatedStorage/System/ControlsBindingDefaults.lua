-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {
	ActionOrder = {
		"MoveOne",
		"MoveTwo",
		"MoveThree",
		"MoveFour",
		"MoveFive",
		"SpecialMove",
		"Combat",
		"Guard",
		"Sprint",
		"ShiftLock",
		"Emote",
		"ComboBreaker",
		"PrivateServerCommands",
		"MapVoteOne",
		"MapVoteTwo",
		"MapVoteThree",
		"PhantomScareOne",
		"PhantomScareTwo",
		"PhantomScareThree",
		"PhantomScareFour",
		"MoonKnightForm",
		"MrKnightForm",
		"ThanosPowerStone",
		"ThanosSpaceStone",
		"ThanosRealityStone",
		"ThanosTimeStone"
	},
	Actions = {
		MoveOne = {
			DisplayName = "Move 1",
			Universal = true,
			Default = { Keyboard = "One", Controller = "DPadUp", VR = "" }
		},
		MoveTwo = {
			DisplayName = "Move 2",
			Universal = true,
			Default = { Keyboard = "Two", Controller = "DPadDown", VR = "" }
		},
		MoveThree = {
			DisplayName = "Move 3",
			Universal = true,
			Default = { Keyboard = "Three", Controller = "DPadLeft", VR = "" }
		},
		MoveFour = {
			DisplayName = "Move 4",
			Universal = true,
			Default = { Keyboard = "Four", Controller = "DPadRight", VR = "" }
		},
		MoveFive = {
			DisplayName = "Move 5",
			Universal = true,
			Default = { Keyboard = "Five", Controller = "ButtonR1", VR = "" }
		},
		SpecialMove = {
			DisplayName = "Special Move",
			Universal = true,
			Default = { Keyboard = "E", Controller = "ButtonL1", VR = "" }
		},
		Combat = {
			DisplayName = "Combat",
			Universal = true,
			Default = { Keyboard = "MouseButton1", Controller = "ButtonR2", VR = "" }
		},
		Guard = {
			DisplayName = "Guard",
			Universal = true,
			Default = { Keyboard = "F", Controller = "ButtonL2", VR = "" }
		},
		Sprint = {
			DisplayName = "Sprint",
			Universal = true,
			Editable = false,
			Default = { Keyboard = "LeftShift", Controller = "ButtonL3", VR = "" }
		},
		ShiftLock = {
			DisplayName = "Shift Lock",
			Universal = true,
			Default = { Keyboard = "K", Controller = "", VR = "" }
		},
		Emote = {
			DisplayName = "Emote",
			Universal = true,
			Default = { Keyboard = "G", Controller = "ButtonY", VR = "" }
		},
		ComboBreaker = {
			DisplayName = "Combo Breaker",
			Universal = true,
			Default = { Keyboard = "X", Controller = "ButtonY", VR = "" }
		},
		PrivateServerCommands = {
			DisplayName = "Private Server Commands",
			Universal = true,
			Default = { Keyboard = "P", Controller = "", VR = "" }
		},
		MapVoteOne = {
			DisplayName = "Vote Option 1",
			Universal = true,
			Default = { Keyboard = "Z", Controller = "", VR = "" }
		},
		MapVoteTwo = {
			DisplayName = "Vote Option 2",
			Universal = true,
			Default = { Keyboard = "C", Controller = "", VR = "" }
		},
		MapVoteThree = {
			DisplayName = "Vote Option 3",
			Universal = true,
			Default = { Keyboard = "V", Controller = "", VR = "" }
		},
		PhantomScareOne = {
			DisplayName = "Phantom Target 1",
			Universal = true,
			Default = { Keyboard = "Z", Controller = "DPadUp", VR = "" }
		},
		PhantomScareTwo = {
			DisplayName = "Phantom Target 2",
			Universal = true,
			Default = { Keyboard = "C", Controller = "DPadDown", VR = "" }
		},
		PhantomScareThree = {
			DisplayName = "Phantom Target 3",
			Universal = true,
			Default = { Keyboard = "V", Controller = "DPadLeft", VR = "" }
		},
		PhantomScareFour = {
			DisplayName = "Phantom Target 4",
			Universal = true,
			Default = { Keyboard = "B", Controller = "DPadRight", VR = "" }
		},
		MoonKnightForm = {
			DisplayName = "Move 8",
			Universal = false,
			Characters = { "MoonKnight" },
			Default = { Keyboard = "Eight", Controller = "ButtonSelect", VR = "" }
		},
		MrKnightForm = {
			DisplayName = "Move 9",
			Universal = false,
			Characters = { "MoonKnight" },
			Default = { Keyboard = "Nine", Controller = "ButtonStart", VR = "" }
		},
		ThanosPowerStone = {
			DisplayName = "Power Stone",
			Universal = false,
			Characters = { "Thanos" },
			Default = { Keyboard = "E", Controller = "ButtonL1", VR = "" }
		},
		ThanosSpaceStone = {
			DisplayName = "Space Stone",
			Universal = false,
			Characters = { "Thanos" },
			Default = { Keyboard = "R", Controller = "ButtonX", VR = "" }
		},
		ThanosRealityStone = {
			DisplayName = "Reality Stone",
			Universal = false,
			Characters = { "Thanos" },
			Default = { Keyboard = "T", Controller = "ButtonB", VR = "" }
		},
		ThanosTimeStone = {
			DisplayName = "Time Stone",
			Universal = false,
			Characters = { "Thanos" },
			Default = { Keyboard = "Y", Controller = "ButtonY", VR = "" }
		}
	},
	ValidInputTypes = {
		Keyboard = { KeyCode = true, UserInputType = true },
		Controller = { KeyCode = true, UserInputType = false },
		VR = { KeyCode = true, UserInputType = false }
	}
}

function module.GetDefaultBindings()
	local t2: {[any]: any} = {}

	for k, v in pairs(module.Actions) do
		t2[k] = {
			Keyboard = v.Default.Keyboard or "",
			Controller = v.Default.Controller or "",
			VR = v.Default.VR or ""
		}
	end

	return t2
end
function module.GetActionData(p1)
	return module.Actions[p1]
end
function module.IsSupportedForCharacter(p2, p3)
	local v8 = module.Actions[p2]

	if not v8 then
		return false
	end

	if v8.Universal then
		return true
	end

	if p3 and p3 ~= "" then
		local function normalizeName(p4)
			return string.lower(p4):gsub("[%s%p_]", "")
		end

		local replacedText = string.lower(p3):gsub("[%s%p_]", "")

		for _, v in ipairs(v8.Characters or {}) do
			local stringFind = string.find
			local replacedText2 = string.lower(v):gsub("[%s%p_]", "")

			if stringFind(replacedText, replacedText2, 1, true) then
				return true
			end
		end

		return false
	end

	return false
end

return module
