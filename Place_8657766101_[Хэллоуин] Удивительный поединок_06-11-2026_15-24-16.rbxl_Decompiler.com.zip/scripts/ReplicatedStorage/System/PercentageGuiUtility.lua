-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })
local t1: {[any]: any} = {}
local u5: boolean = false
local u6 = true
local u7 = true
local u8 = nil
local n1: number = 0

local function getActiveGuiCopRunCount()
	local LocalPlayer: Player = players.LocalPlayer
	local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
	local v26 = playerGui

	if v26 then
		v26 = playerGui:GetAttribute("GuiCopActiveRuns")
	end

	if typeof(v26) == "number" then
		return (math.max(0, v26))
	end

	return 0
end
local function hasSuppressionLocks()
	return next(t1) ~= nil
end
local function refreshEffectiveEnabled()
	local v27: boolean = u6

	if v27 then
		v27 = next(t1) == nil

		if v27 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v30 = playerGui

			if v30 then
				v30 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v27 = (if typeof(v30) == "number" then math.max(0, v30) else 0) <= 0
		end
	end

	u7 = v27
end
local function syncReplicatedState()
	workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
end
local function applyState(p1)
	local v32: boolean = u6

	if v32 then
		v32 = next(t1) == nil

		if v32 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v35 = playerGui

			if v35 then
				v35 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v32 = (if typeof(v35) == "number" then math.max(0, v35) else 0) <= 0
		end
	end

	u7 = v32
	p1.Enabled = u7

	if u7 and u8 then
		p1.MaxDistance = u8
	elseif not u7 then
		p1.MaxDistance = 0
	end
end
local function trackBillboard(p2)
	object[p2] = true

	local v37 = u6

	if v37 then
		v37 = next(t1) == nil

		if v37 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v40 = playerGui

			if v40 then
				v40 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v37 = (if typeof(v40) == "number" then math.max(0, v40) else 0) <= 0
		end
	end

	u7 = v37
	p2.Enabled = u7

	if u7 and u8 then
		p2.MaxDistance = u8
	elseif not u7 then
		p2.MaxDistance = 0
	end

	if object2[p2] then
		return
	end

	v37 = {}
	object2[p2] = v37

	local function enforceHiddenState()
		local v88: boolean = u6

		if v88 then
			v88 = next(t1) == nil

			if v88 then
				local LocalPlayer: Player = players.LocalPlayer
				local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
				local v91 = playerGui

				if v91 then
					v91 = playerGui:GetAttribute("GuiCopActiveRuns")
				end

				v88 = (if typeof(v91) == "number" then math.max(0, v91) else 0) <= 0
			end
		end

		u7 = v88

		if u7 == false and p2.Parent then
			if p2.Enabled then
				p2.Enabled = false
			end

			if p2.MaxDistance ~= 0 then
				p2.MaxDistance = 0
			end
		end
	end

	local v42 = p2:GetPropertyChangedSignal("Enabled")

	table.insert(v37, v42:Connect(enforceHiddenState))
	v42 = p2:GetPropertyChangedSignal("MaxDistance")
	table.insert(v37, v42:Connect(enforceHiddenState))
	table.insert(v37, p2.Destroying:Connect(function()
		object[p2] = nil

		local v92 = object2[p2]

		object2[p2] = nil

		if v92 then
			for iterFirst, iterSecond in v92 do
				iterSecond:Disconnect()
			end
		end
	end))
end
local function checkCharacterBillboard(p3)
	if not p3:IsA("Model") then
		return
	end

	local head = p3:FindFirstChild("Head")

	if not head then
		return
	end

	local percentage = head:FindFirstChild("Percentage")

	if percentage and percentage:IsA("BillboardGui") then
		trackBillboard(percentage)
	end
end
local function isPercentageGui(p4)
	return p4:IsA("BillboardGui") and p4.Name == "Percentage"
end
local function add(p5)
	if p5:IsA("BillboardGui") and p5.Name == "Percentage" then
		trackBillboard(p5)

		return
	end

	if p5:IsA("Model") then
		checkCharacterBillboard(p5)

		return
	end

	local v48 = p5.Name == "Head" and p5.Parent

	if v48 and v48:IsA("Model") then
		checkCharacterBillboard(v48)
	end
end
local function remove(p6)
	if object[p6] then
		object[p6] = nil
	end
end

local u20 = nil
local u21 = nil
local u22 = nil

u21 = function()
	for iterFirst, iterSecond in workspace:GetDescendants() do
		if iterSecond:IsA("BillboardGui") and iterSecond.Name == "Percentage" then
			trackBillboard(iterSecond)
		end
	end
end
u20 = function()
	local v52: boolean = u6

	if v52 then
		v52 = next(t1) == nil

		if v52 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v55 = playerGui

			if v55 then
				v55 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v52 = (if typeof(v55) == "number" then math.max(0, v55) else 0) <= 0
		end
	end

	u7 = v52

	if u7 == false then
		u21()
	end

	for iterValue in object do
		if iterValue.Parent then
			local v57: boolean = u6

			if v57 then
				v57 = next(t1) == nil

				if v57 then
					local LocalPlayer: Player = players.LocalPlayer
					local localPlayerPlayerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
					local v60 = localPlayerPlayerGui

					if v60 then
						v60 = localPlayerPlayerGui:GetAttribute("GuiCopActiveRuns")
					end

					v57 = (if typeof(v60) == "number" then math.max(0, v60) else 0) <= 0
				end
			end

			u7 = v57
			iterValue.Enabled = u7

			if u7 and u8 then
				iterValue.MaxDistance = u8
			elseif not u7 then
				iterValue.MaxDistance = 0
			end
		else
			object[iterValue] = nil
		end
	end
end
u22 = function()
	n1 += 1

	local v61: number = n1

	task.spawn(function()
		while v61 == n1 and u7 == false do
			u21()
			u20()
			task.wait(0.15)
		end
	end)
end

local module: {[any]: any} = {
	Init = function()
		if u5 then
			return
		end

		u5 = true

		for iterFirst, iterSecond in workspace:GetDescendants() do
			add(iterSecond)
		end

		workspace.ChildAdded:Connect(function(child: Instance)
			add(child)
			checkCharacterBillboard(child)
			task.defer(function()
				add(child)
				checkCharacterBillboard(child)
			end)
			task.delay(0.1, function()
				add(child)
				checkCharacterBillboard(child)
			end)
			task.delay(0.3, function()
				add(child)
				checkCharacterBillboard(child)
			end)
			task.delay(1, function()
				add(child)
				checkCharacterBillboard(child)
			end)
		end)
		workspace.DescendantAdded:Connect(function(descendant: Instance)
			add(descendant)

			if u7 == false and descendant:IsA("BillboardGui") and descendant.Name == "Percentage" then
				descendant.Enabled = false
				descendant.MaxDistance = 0
			end

			local descendantParent: Instance = descendant.Parent
			local descendantParentParent: Instance = descendantParent and descendantParent.Parent

			if descendant.Name == "Percentage" and descendant:IsA("BillboardGui") and descendantParent and descendantParent.Name == "Head" and descendantParentParent and descendantParentParent:IsA("Model") then
				checkCharacterBillboard(descendantParentParent)
			end
		end)
		workspace.DescendantRemoving:Connect(remove)

		local LocalPlayer: Player = players.LocalPlayer
		local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")

		if playerGui then
			playerGui:GetAttributeChangedSignal("GuiCopActiveRuns"):Connect(function()
				local v99: boolean = u6

				if v99 then
					v99 = next(t1) == nil

					if v99 then
						local LocalPlayer2: Player = players.LocalPlayer
						local playerGui = LocalPlayer2 and LocalPlayer2:FindFirstChild("PlayerGui")
						local v102 = playerGui

						if v102 then
							v102 = playerGui:GetAttribute("GuiCopActiveRuns")
						end

						v99 = (if typeof(v102) == "number" then math.max(0, v102) else 0) <= 0
					end
				end

				u7 = v99
				workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
				u20()

				if u7 then
					n1 += 1

					return
				end

				u22()
			end)
		end
	end
}

function module.SetEnabled(p9, p10)
	u6 = p9
	u8 = p10

	local v68 = u6

	if v68 then
		v68 = next(t1) == nil

		if v68 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v71 = playerGui

			if v71 then
				v71 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v68 = (if typeof(v71) == "number" then math.max(0, v71) else 0) <= 0
		end
	end

	u7 = v68
	workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
	module.Init()
	u20()

	if u7 then
		n1 += 1

		return
	end

	u22()
end
function module.AcquireSuppression(p11)
	t1[p11 or "Default"] = true

	local v73 = u6

	if v73 then
		v73 = next(t1) == nil

		if v73 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v76 = playerGui

			if v76 then
				v76 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v73 = (if typeof(v76) == "number" then math.max(0, v76) else 0) <= 0
		end
	end

	u7 = v73
	workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
	module.Init()
	u20()
	u22()
end
function module.ReleaseSuppression(p12)
	t1[p12 or "Default"] = nil

	local v78 = u6

	if v78 then
		v78 = next(t1) == nil

		if v78 then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v81 = playerGui

			if v81 then
				v81 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			v78 = (if typeof(v81) == "number" then math.max(0, v81) else 0) <= 0
		end
	end

	u7 = v78
	workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
	module.Init()
	u20()

	if u7 then
		n1 += 1

		return
	end

	u22()
end
function module.ForceRestore(p13)
	u6 = true
	u8 = p13 or u8 or 50

	for iterValue in t1 do
		t1[iterValue] = nil
	end

	u7 = true
	workspace:SetAttribute("PercentageBillboardsSuppressed", u7 == false)
	module.Init()
	u20()
	n1 += 1
end
function module.IsSuppressed()
	local u84: boolean = next(t1) ~= nil

	if not u84 then
		u84 = true

		if u6 ~= false then
			local LocalPlayer: Player = players.LocalPlayer
			local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
			local v87 = playerGui

			if v87 then
				v87 = playerGui:GetAttribute("GuiCopActiveRuns")
			end

			u84 = (if typeof(v87) == "number" then math.max(0, v87) else 0) > 0
		end
	end

	return u84
end

return module
