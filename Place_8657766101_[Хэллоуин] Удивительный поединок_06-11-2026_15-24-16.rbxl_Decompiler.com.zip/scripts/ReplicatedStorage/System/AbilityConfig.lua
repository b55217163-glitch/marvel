-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {
	Characters = {
		Hal = {
			Abilities = {
				MoveOne = { Name = "Force Blasts", Cooldown = 11 },
				MoveTwo = { Name = "Feeding Time", Cooldown = 14 },
				MoveTwoLeap = { Name = "Ring Launch", Cooldown = 14 },
				MoveThree = { Name = "Bubble Defence", Cooldown = 14, MaxHoldTime = 5 },
				MoveFour = { Name = "Hunter Tornado", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Lantern Charge", Cooldown = 30 }
			}
		},
		["2099"] = {
			Abilities = {
				MoveOne = { Name = "Pounce", Cooldown = 20 },
				MoveTwo = { Name = "Web Swing", Cooldown = 15 },
				MoveThree = { Name = "Counter", Cooldown = 14 },
				MoveFour = { Name = "Web Spikes", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Backup", Cooldown = 15 }
			}
		},
		["A-Train"] = {
			Abilities = {
				MoveOne = { Name = "Behind You", Cooldown = 8 },
				MoveTwo = { Name = "Fastest Man", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Run Barry", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Special", Cooldown = 120 },
				SpecialMoveCompoundV = { Name = "Compound V", Cooldown = 60 }
			}
		},
		Amazo = {
			Abilities = {
				MoveOne = { Name = "Stretch Punch", Cooldown = 10 },
				MoveTwo = { Name = "Fastest Man", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Flying Punch", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Eyes", Cooldown = 30 }
			}
		},
		Anakin = {
			Abilities = {
				MoveOne = { Name = "Slash Release", Cooldown = 8, MaxHoldTime = 10 },
				MoveTwo = { Name = "Fallen Angel", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Force Push", Cooldown = 8 },
				MoveFourRage = { Name = "Retribution", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Rage", Cooldown = 620 }
			}
		},
		AtomEve = {
			Abilities = {
				MoveOne = { Name = "Sharp Spear", Cooldown = 9 },
				MoveTwo = { Name = "Hammer of Doom", Cooldown = 12 },
				MoveThree = { Name = "Armor Counter", Cooldown = 15 },
				MoveFour = { Name = "Crushing Plates", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Flight / Atom Blast", Cooldown = 30 }
			}
		},
		Billy = {
			Abilities = {
				MoveOne = { Name = "Psycho Slip", Cooldown = 8 },
				MoveTwo = { Name = "Hidden Piece", Cooldown = 10 },
				MoveTwoEthan = { Name = "Shotgun Blast", Cooldown = 12 },
				MoveThree = { Name = "Bellystab Counter", Cooldown = 10 },
				MoveFour = { Name = "The Voicechanger", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "The Reveal", Cooldown = 95 }
			}
		},
		Brian = {
			Abilities = {
				MoveOne = { Name = "Ankle Breaker", Cooldown = 10 },
				MoveTwo = { Name = "Head Toss", Cooldown = 14 },
				MoveThree = { Name = "ChokeHold Counter", Cooldown = 12 },
				MoveFour = { Name = "Surgical Strike", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Born in Blood", Cooldown = 25 }
			}
		},
		DarthVader = {
			Abilities = {
				MoveOne = { Name = "Heavy Strike", Cooldown = 12 },
				MoveTwo = { Name = "Saber Throw", Cooldown = 10 },
				MoveThree = { Name = "Leap", Cooldown = 6 },
				MoveFour = { Name = "Force Pull", Cooldown = 22 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Rage", Cooldown = 120 }
			}
		},
		Deep = {
			Abilities = {
				MoveOne = { Name = "Ambrosius Slam", Cooldown = 10 },
				MoveTwo = { Name = "Wave Rider", Cooldown = 11 },
				MoveThree = { Name = "Sea Brawn Combo Counter", Cooldown = 12 },
				MoveFour = { Name = "Shark Swarm", Cooldown = 25 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Deep Thoughts", Cooldown = 15 }
			}
		},
		Deku = {
			Abilities = {
				MoveOne = { Name = "Chop", Cooldown = 8 },
				MoveTwo = { Name = "Delaware", Cooldown = 9 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Wind Explosion", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				MoveFiveFollowup = { Name = "Finisher Followup", Cooldown = 0.5 },
				SpecialMove = { Name = "Web Swing", Cooldown = 15 }
			}
		},
		Peacemaker = {
			Abilities = {
				MoveOne = { Name = "Shield Bash", Cooldown = 7 },
				MoveTwo = { Name = "Bullet Barrage", Cooldown = 10 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Human Torpedo", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Eagly", Cooldown = 35 }
			}
		},
		TheBatman = {
			Abilities = {
				MoveOne = { Name = "Knockout Punch", Cooldown = 14 },
				MoveTwo = { Name = "Glide", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 15 },
				MoveFourStickyBomb = { Name = "Sticky Bomb", Cooldown = 20 },
				MoveFour = { Name = "Utility Belt", Cooldown = 18 },
				MoveFourAdShot = { Name = "Ad Shot", Cooldown = 35 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 }
			}
		},
		DoctorStrange = {
			Abilities = {
				MoveOne = { Name = "Portal Bullets", Cooldown = 10 },
				MoveTwo = { Name = "Whip Attack", Cooldown = 14 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Suns", Cooldown = 12 },
				MoveFive = { Name = "Tendrils", Cooldown = 30 },
				SpecialMove = { Name = "Time Loop", Cooldown = 120 }
			}
		},
		MrFantastic = {
			Abilities = {
				MoveOne = { Name = "Stretch Punch", Cooldown = 8 },
				MoveTwo = { Name = "Stretch Slam", Cooldown = 10 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Spin", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Reflect", Cooldown = 20 }
			}
		},
		Vigilante = {
			Abilities = {
				MoveOne = { Name = "Quick Stab", Cooldown = 11 },
				MoveTwo = { Name = "Sword Combo", Cooldown = 11 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Sniper Rifle", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				SpecialMove = { Name = "Dynamite", Cooldown = 12 }
			}
		},
		Homelander = {
			Abilities = {
				MoveOne = { Name = "Cape Combo", Cooldown = 12 },
				MoveTwo = { Name = "Ear Clap", Cooldown = 18 },
				MoveTwoLeap = { Name = "Laser Eyes", Cooldown = 16 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Flying Punch", Cooldown = 12 },
				MoveFourAwakened = { Name = "Awakened Flying Punch", Cooldown = 16 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMoveCompoundV = { Name = "Compound V", Cooldown = 60 }
			}
		},
		Eleven = {
			Abilities = {
				MoveOne = { Name = "Arm Break", Cooldown = 10 },
				MoveTwo = { Name = "Tele Punch", Cooldown = 13 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Leap", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Special", Cooldown = 30 }
			}
		},
		SCPGuard = {
			Abilities = {
				MoveOne = { Name = "Shotgun", Cooldown = 8 },
				MoveTwo = { Name = "Sculpture", Cooldown = 15 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Grenade", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Special", Cooldown = 45 }
			}
		},
		GigaChad = {
			Abilities = {
				MoveOne = { Name = "Barrage", Cooldown = 5 },
				MoveTwo = { Name = "Lunge", Cooldown = 11 },
				MoveThree = { Name = "Counter", Cooldown = 7 },
				MoveFour = { Name = "Giga Run", Cooldown = 10 },
				MoveFive = { Name = "Final Punch", Cooldown = 40 }
			}
		},
		TheFlashCW = {
			Abilities = {
				MoveOne = { Name = "Barrage", Cooldown = 8 },
				MoveTwo = { Name = "Super Speed", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 18 },
				MoveFour = { Name = "Lightning Throw", Cooldown = 12 },
				MoveFourQuick = { Name = "Quick Lightning Throw", Cooldown = 4 },
				SpecialMove = { Name = "Tornado", Cooldown = 32 }
			}
		},
		ReverseFlash = {
			Abilities = {
				MoveOne = { Name = "Rampant Flurry", Cooldown = 11 },
				MoveTwo = { Name = "Super Speed", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Rush", Cooldown = 10 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				SpecialMove = { Name = "Negative Wave", Cooldown = 12 }
			}
		},
		SoldierBoy = {
			Abilities = {
				MoveOne = { Name = "Barrage Slam", Cooldown = 9 },
				MoveTwo = { Name = "Move Two", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 15 },
				MoveFour = { Name = "Radiation", Cooldown = 20 },
				MoveFourNuke = { Name = "Nuke", Cooldown = 30 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "PTSD", Cooldown = 12 }
			}
		},
		StarLight = {
			Abilities = {
				MoveOne = { Name = "Close Blast", Cooldown = 8 },
				MoveTwo = { Name = "Range Blast", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Ground Blast", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Dash/Launch", Cooldown = 10 }
			}
		},
		Springtrap = {
			Abilities = {
				MoveOne = { Name = "Down Strike", Cooldown = 8 },
				MoveTwo = { Name = "Jumpscare", Cooldown = 14 },
				MoveThree = { Name = "Counter", Cooldown = 15 },
				MoveFour = { Name = "Phantom Rage", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "E Move", Cooldown = 70 }
			}
		},
		Rambo = {
			Abilities = {
				MoveOne = { Name = "Down Strike", Cooldown = 12 },
				MoveTwo = { Name = "Bullet Barrage", Cooldown = 16 },
				MoveThree = { Name = "Roll", Cooldown = 7 },
				MoveFour = { Name = "Sniper / Trap", Cooldown = 14 },
				MoveFourTrap = { Name = "Spike Trap", Cooldown = 10 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Wound Heal", Cooldown = 30 }
			}
		},
		Miles = {
			Abilities = {
				MoveOne = { Name = "Absorb", Cooldown = 8 },
				MoveTwo = { Name = "Web Swing", Cooldown = 15 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Invisibility", Cooldown = 11 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Spider Sense", Cooldown = 50 }
			}
		},
		IronMan = {
			Abilities = {
				MoveOne = { Name = "Repulsor Blast", Cooldown = 12 },
				MoveTwo = { Name = "Dash Blast", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Ground Blast", Cooldown = 20 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				SpecialMove = { Name = "Flight", Cooldown = 33 }
			}
		},
		Demogorgon = {
			Abilities = {
				MoveOne = { Name = "Chop", Cooldown = 8 },
				MoveTwo = { Name = "Jumpscare", Cooldown = 14 },
				MoveThree = { Name = "Counter", Cooldown = 15 },
				MoveFour = { Name = "Rage Run", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Special", Cooldown = 15 }
			}
		},
		Dexter = {
			Abilities = {
				MoveOne = { Name = "Liver Blows", Cooldown = 10 },
				MoveTwo = { Name = "Harpoon", Cooldown = 20 },
				MoveThree = { Name = "Counter", Cooldown = 20 },
				MoveFour = { Name = "Needle Tech", Cooldown = 16 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "M99", Cooldown = 40 }
			}
		},
		Eddie = {
			Abilities = {
				MoveOne = { Name = "Hellfire Skewer", Cooldown = 9 },
				MoveTwo = { Name = "Dirty Mattress", Cooldown = 12 },
				MoveThree = { Name = "Trashcan Spike Counter", Cooldown = 15 },
				MoveFour = { Name = "Hellride Escape", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Master of Puppets", Cooldown = 30 }
			}
		},
		Eren = {
			Abilities = {
				MoveOne = { Name = "Threatening Grab", Cooldown = 12 },
				MoveTwo = { Name = "Fair Fight", Cooldown = 12 },
				MoveThree = { Name = "Crystalize Counter", Cooldown = 20 },
				MoveFour = { Name = "Charge Up", Cooldown = 15 },
				MoveFive = { Name = "Handshake Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Titan Beatdown", Cooldown = 9 }
			}
		},
		Freddy = {
			Abilities = {
				MoveOne = { Name = "Mic Slam", Cooldown = 7 },
				MoveTwo = { Name = "Leap", Cooldown = 10 },
				MoveThree = { Name = "87 Counter", Cooldown = 15 },
				MoveFour = { Name = "IT'S ME", Cooldown = 10 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 }
			}
		},
		FluteLady = {
			Abilities = {
				MoveOne = { Name = "Spider Maul", Cooldown = 8 },
				MoveTwo = { Name = "Take It", Cooldown = 12 },
				MoveThree = { Name = "Manifest Fear Counter", Cooldown = 12 },
				MoveFour = { Name = "Coffin Ambush", Cooldown = 13 },
				MoveFive = { Name = "Deadlights Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Feast Rush", Cooldown = 10 },
				SpecialMoveDestruction = { Name = "Spider Destruction", Cooldown = 9 }
			}
		},
		FrontMan = {
			Abilities = {
				MoveOne = { Name = "Mingle Shove", Cooldown = 8 },
				MoveTwo = { Name = "Spinning Tops", Cooldown = 12 },
				MoveThree = { Name = "Mealtime Counter", Cooldown = 12 },
				MoveFour = { Name = "Mp5 Slaughter", Cooldown = 12 },
				MoveFive = { Name = "Betraying Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Lights Out", Cooldown = 35 }
			}
		},
		Ghostface = {
			Abilities = {
				MoveOne = { Name = "Wrong Answer!", Cooldown = 12 },
				MoveTwo = { Name = "Decoy", Cooldown = 14 },
				MoveThree = { Name = "Stab Counter", Cooldown = 14 },
				MoveFourShotgun = { Name = "Shotgun", Cooldown = 15 },
				MoveFour = { Name = "Double Trouble", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Distraction Call", Cooldown = 16 }
			}
		},
		HumanTorch = {
			Abilities = {
				MoveOne = { Name = "Blazing Shot", Cooldown = 8 },
				MoveTwo = { Name = "Inferno Surge", Cooldown = 13 },
				MoveThree = { Name = "Flashfire Counter", Cooldown = 15 },
				MoveFour = { Name = "Hellstream", Cooldown = 18 },
				MoveFive = { Name = "Nova Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Flame On!", Cooldown = 120 }
			}
		},
		Invincible = {
			Abilities = {
				MoveOne = { Name = "Invincible Swipes", Cooldown = 8 },
				MoveTwo = { Name = "The Backhand", Cooldown = 15 },
				MoveThree = { Name = "Slamdown Counter", Cooldown = 12 },
				MoveFour = { Name = "Drill Uppercut", Cooldown = 15 },
				MoveFive = { Name = "Stronger Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Flight", Cooldown = 30 }
			}
		},
		Iris = {
			Abilities = {
				MoveOne = { Name = "Move One", Cooldown = 8 },
				MoveTwo = { Name = "Move Two", Cooldown = 11 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveThreeSelfControl = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Move Four", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Special", Cooldown = 80 }
			}
		},
		Jeff = {
			Abilities = {
				MoveOne = { Name = "Serial Slicer", Cooldown = 8 },
				MoveTwo = { Name = "Knife Toss", Cooldown = 12 },
				MoveThree = { Name = "Drill Counter", Cooldown = 12 },
				MoveFourAwakened = { Name = "Bedtime Footsteps", Cooldown = 12 },
				MoveFour = { Name = "Bedtime Footsteps", Cooldown = 15 },
				MoveFive = { Name = "Carving Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Bloodlust", Cooldown = 107 }
			}
		},
		Joe = {
			Abilities = {
				MoveOne = { Name = "Runners High", Cooldown = 8 },
				MoveTwo = { Name = "Stranglehold", Cooldown = 12 },
				MoveThree = { Name = "For Her Counter", Cooldown = 12 },
				MoveFour = { Name = "The Cage", Cooldown = 35 },
				MoveFive = { Name = "Pages Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Stalker Mode", Cooldown = 60 }
			}
		},
		Kira = {
			Abilities = {
				MoveOne = { Name = "Cardiac Judgement", Cooldown = 8 },
				MoveTwo = { Name = "Compelled End", Cooldown = 12 },
				MoveThree = { Name = "Shinigami Counter", Cooldown = 12 },
				MoveFour = { Name = "Written Collision", Cooldown = 20 },
				MoveFive = { Name = "Eyes of Death Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "The New World", Cooldown = 30 }
			}
		},
		Kratos = {
			Abilities = {
				MoveOne = { Name = "Cold Axe", Cooldown = 13 },
				MoveTwo = { Name = "Chaos Blades", Cooldown = 7 },
				MoveThree = { Name = "Shield Counter", Cooldown = 10 },
				MoveFour = { Name = "Draupnir Spear Rain", Cooldown = 10 },
				MoveFourHeavy = { Name = "Draupnir Spear Rain", Cooldown = 12 },
				MoveFive = { Name = "Quick Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Spartan Rage", Cooldown = 30 }
			}
		},
		Lawliet = {
			Abilities = {
				MoveOne = { Name = "Pinpoint Kick", Cooldown = 8 },
				MoveTwo = { Name = "Tennis Insight", Cooldown = 9 },
				MoveThree = { Name = "Truth for Truth Counter", Cooldown = 12 },
				MoveFour = { Name = "Bound Deduction Counter", Cooldown = 18 },
				MoveFive = { Name = "You are Kira Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Sugar Rush", Cooldown = 0 }
			}
		},
		Luffy = {
			Abilities = {
				MoveOne = { Name = "Pistol", Cooldown = 8 },
				MoveTwo = { Name = "Gatling", Cooldown = 12 },
				MoveThree = { Name = "Bell Counter", Cooldown = 10 },
				MoveFour = { Name = "Battle Axe", Cooldown = 12 },
				MoveFive = { Name = "Rocket Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Rubber Dodge", Cooldown = 0 }
			}
		},
		Michael = {
			Abilities = {
				MoveOne = { Name = "Smooth Tornado", Cooldown = 8 },
				MoveTwo = { Name = "Pop Combo", Cooldown = 12 },
				MoveThree = { Name = "Bad Counter", Cooldown = 12 },
				MoveFour = { Name = "Moonwalk Mystique", Cooldown = 14 },
				MoveFive = { Name = "Thriller Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Beat It Ultimate", Cooldown = 0 }
			}
		},
		Mohawk = {
			Abilities = {
				MoveOne = { Name = "Destabilize", Cooldown = 10 },
				MoveTwo = { Name = "The Backhand", Cooldown = 15 },
				MoveThree = { Name = "Slamdown Counter", Cooldown = 12 },
				MoveFour = { Name = "Boulder Throw", Cooldown = 15 },
				MoveFive = { Name = "Stronger Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Flight", Cooldown = 30 }
			}
		},
		Myers = {
			Abilities = {
				MoveOne = { Name = "Silent Slasher", Cooldown = 8 },
				MoveTwo = { Name = "Inferno Rampage", Cooldown = 10 },
				MoveThree = { Name = "Blinded Fury Counter", Cooldown = 14 },
				MoveFour = { Name = "Choke Throw", Cooldown = 12 },
				MoveFive = { Name = "The Shape Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Behind the Bush", Cooldown = 2 }
			}
		},
		Nikki = {
			Abilities = {
				MoveOne = { Name = "Move One", Cooldown = 14 },
				MoveTwo = { Name = "Move Two", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 15 },
				MoveFour = { Name = "Move Four", Cooldown = 20 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				SpecialMove = { Name = "Special", Cooldown = 30 },
				SpecialMoveStarting = { Name = "Special Starting Cooldown", Cooldown = 12 },
				SpecialMoveIan = { Name = "Ian Special", Cooldown = 12 }
			}
		},
		OmniMan = {
			Abilities = {
				MoveOne = { Name = "Chop", Cooldown = 8 },
				MoveTwo = { Name = "Shockwave Clap", Cooldown = 10 },
				MoveThree = { Name = "Viltrumite Counter", Cooldown = 12 },
				MoveFour = { Name = "Spike Stab", Cooldown = 14 },
				MoveFive = { Name = "Brutal Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Flight", Cooldown = 30 }
			}
		},
		Orange = {
			Abilities = {
				MoveOne = { Name = "Hey Apple", Cooldown = 0.5 },
				MoveTwo = { Name = "nehnehnehnehneh", Cooldown = 1 },
				MoveThree = { Name = "Laugh", Cooldown = 1 },
				MoveFour = { Name = "Orange you glad...", Cooldown = 1 },
				MoveFive = { Name = "Hey", Cooldown = 1 }
			}
		},
		Patrick = {
			Abilities = {
				MoveOne = { Name = "Hey Paul!", Cooldown = 8 },
				MoveTwo = { Name = "Business Card", Cooldown = 12 },
				MoveThree = { Name = "Stray Cat Counter", Cooldown = 15 },
				MoveFour = { Name = "Chainsaw Rampage", Cooldown = 15 },
				MoveFive = { Name = "Hip to be Square Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Stereo Psychosis", Cooldown = 180 }
			}
		},
		Paul = {
			Abilities = {
				MoveOne = { Name = "Headbump", Cooldown = 10 },
				MoveTwo = { Name = "Voice", Cooldown = 12 },
				MoveThree = { Name = "Reversal Counter", Cooldown = 12 },
				MoveFour = { Name = "Long Live Fighters!", Cooldown = 20 },
				MoveFourPowered = { Name = "Long Live Fighters!", Cooldown = 25 },
				MoveFive = { Name = "Backstab Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Forcefield", Cooldown = 23 }
			}
		},
		Pennywise = {
			Abilities = {
				MoveOne = { Name = "Spider Maul", Cooldown = 8 },
				MoveTwo = { Name = "Take It", Cooldown = 12 },
				MoveThree = { Name = "Manifest Fear Counter", Cooldown = 12 },
				MoveFour = { Name = "Coffin Ambush", Cooldown = 13 },
				MoveFive = { Name = "Deadlights Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Feast Rush", Cooldown = 10 },
				SpecialMoveDestruction = { Name = "Spider Destruction", Cooldown = 9 }
			}
		},
		Pibby = {
			Abilities = {
				MoveOne = { Name = "Corrupted Swipe", Cooldown = 13 },
				MoveTwo = { Name = "Sword Rush", Cooldown = 12 },
				MoveThree = { Name = "Hug Counter", Cooldown = 14 },
				MoveFour = { Name = "Disrupted Dash", Cooldown = 12 },
				MoveFive = { Name = "Glitch Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Darkness Heal", Cooldown = 70 }
			}
		},
		Riddler = {
			Abilities = {
				MoveOne = { Name = "Riddle me this", Cooldown = 12 },
				MoveTwo = { Name = "No More Lies", Cooldown = 12 },
				MoveThree = { Name = "Under The Light Counter", Cooldown = 12 },
				MoveFour = { Name = "Followers of Truth", Cooldown = 20 },
				MoveFive = { Name = "Forgiveness Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Going Live", Cooldown = 20 },
				SpecialMoveJudgement = { Name = "Judgement Day", Cooldown = 40 }
			}
		},
		["SCP-173"] = {
			Abilities = {
				MoveOne = { Name = "Move", Cooldown = 0.7 },
				MoveTwo = { Name = "Dash", Cooldown = 14 },
				MoveFour = { Name = "Blink Rush", Cooldown = 12 }
			}
		},
		Sahur = {
			Abilities = {
				MoveOne = { Name = "Homerun", Cooldown = 8 },
				MoveOneQuick = { Name = "Homerun", Cooldown = 5 },
				MoveTwoQuick = { Name = "Vine Slammer", Cooldown = 5 },
				MoveTwo = { Name = "Vine Slammer", Cooldown = 12 },
				SpecialMove = { Name = "Flight", Cooldown = 18 }
			}
		},
		Sidney = {
			Abilities = {
				MoveOne = { Name = "Stop Right There!", Cooldown = 10 },
				MoveTwoFinalGirl = { Name = "Door Slam", Cooldown = 10 },
				MoveTwo = { Name = "Door Slam", Cooldown = 13 },
				MoveThree = { Name = "Umbrella Counter", Cooldown = 12 },
				MoveFour = { Name = "Distraction Phone", Cooldown = 12 },
				MoveFive = { Name = "Wrong Channel Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Final Girl", Cooldown = 60 }
			}
		},
		Sonic = {
			Abilities = {
				MoveOne = { Name = "Spin Dash", Cooldown = 10 },
				MoveTwo = { Name = "Super Speed", Cooldown = 12 },
				MoveThree = { Name = "Spin Counter", Cooldown = 13 },
				MoveFour = { Name = "Electricity Steal", Cooldown = 12 },
				MoveFive = { Name = "Blitz Finisher", Cooldown = 0.1 },
				MoveFiveLong = { Name = "Blitz Finisher", Cooldown = 15 },
				SpecialMove = { Name = "Super Sonic", Cooldown = 0 }
			}
		},
		Speed = {
			Abilities = {
				MoveOne = { Name = "Bark Barrage", Cooldown = 5 },
				MoveTwo = { Name = "Soccer Tackle", Cooldown = 12 },
				MoveThree = { Name = "Pika Counter", Cooldown = 10 },
				MoveFour = { Name = "Shake Dance", Cooldown = 30 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Special", Cooldown = 15 }
			}
		},
		SpiderMan = {
			Abilities = {
				MoveOne = { Name = "Spider-Sting", Cooldown = 10 },
				MoveTwo = { Name = "Web Ball", Cooldown = 12 },
				MoveThree = { Name = "Blizzard Counter", Cooldown = 20 },
				MoveFour = { Name = "Webswing Kick", Cooldown = 14 },
				MoveFive = { Name = "Sticky Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Symbiote Recovery", Cooldown = 500 }
			}
		},
		Springbonnie = {
			Abilities = {
				MoveOne = { Name = "Symmetry Thrust", Cooldown = 10 },
				MoveTwo = { Name = "Spring Strike", Cooldown = 12 },
				MoveThree = { Name = "Cupcake Counter", Cooldown = 15 },
				MoveFour = { Name = "Ghost Children", Cooldown = 15 },
				MoveFive = { Name = "Party Trick Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Afton's Embrace", Cooldown = 35 }
			}
		},
		Steve = {
			Abilities = {
				MoveOne = { Name = "Mine", Cooldown = 1 },
				MoveTwo = { Name = "Bow", Cooldown = 12 },
				MoveThree = { Name = "Flint n' Steel", Cooldown = 10 },
				MoveThreeLong = { Name = "Flint n' Steel", Cooldown = 12 },
				MoveFour = { Name = "Minecart", Cooldown = 12 },
				MoveFive = { Name = "Invisibility Potion", Cooldown = 65 }
			}
		},
		Steve_H = {
			Abilities = {
				MoveOne = { Name = "Homerun", Cooldown = 12 },
				MoveTwo = { Name = "Vine Slammer", Cooldown = 15 },
				MoveTwoQuick = { Name = "Vine Slammer", Cooldown = 12 },
				MoveThree = { Name = "King Steve Counter", Cooldown = 15 },
				MoveFour = { Name = "Stealthy Ninja", Cooldown = 15 },
				MoveFive = { Name = "Melt With You Finisher", Cooldown = 0.5 },
				SpecialMoveQuick = { Name = "Firework Throw", Cooldown = 8 },
				SpecialMove = { Name = "Firework Throw", Cooldown = 30 }
			}
		},
		Tate = {
			Abilities = {
				MoveOne = { Name = "Barrage Slam", Cooldown = 10 },
				MoveTwo = { Name = "Shotgun", Cooldown = 14 },
				MoveThree = { Name = "Counter", Cooldown = 13 },
				MoveFour = { Name = "Trap", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 1 },
				SpecialMove = { Name = "Rubber", Cooldown = 10 }
			}
		},
		SuperMan = {
			Abilities = {
				MoveOne = { Name = "Down Strike", Cooldown = 10 },
				MoveTwo = { Name = "Bullet Barrage", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 14 },
				MoveFour = { Name = "Kryptonian Grip", Cooldown = 25 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Wound Heal", Cooldown = 6 }
			}
		},
		Thanos = {
			Abilities = {
				MoveOne = { Name = "Power Slam", Cooldown = 4 },
				MoveOneAlt = { Name = "Power Slam", Cooldown = 3 },
				MoveOneInvis = { Name = "Invisibility", Cooldown = 8 },
				MoveOneAltLong = { Name = "Power Slam", Cooldown = 7 },
				MoveTwo = { Name = "Power Beam", Cooldown = 7 },
				MoveTwoAlt = { Name = "Power Beam", Cooldown = 12 },
				MoveTwoReality = { Name = "Reality Beam", Cooldown = 8 },
				MoveTwoAltShort = { Name = "Power Beam", Cooldown = 6 },
				MoveThree = { Name = "Meteor", Cooldown = 25 },
				MoveThreeCounter = { Name = "Counter", Cooldown = 4 },
				MoveThreeReality = { Name = "Earth Spikes", Cooldown = 7 },
				MoveFour = { Name = "Sword", Cooldown = 12 },
				MoveFourAlt = { Name = "Sword", Cooldown = 8 },
				MoveFourSpin = { Name = "Sword Spin", Cooldown = 4 },
				MoveFive = { Name = "Infinity Snap", Cooldown = 120 }
			}
		},
		Trinity = {
			Abilities = {
				MoveOne = { Name = "Barrage Slam", Cooldown = 12 },
				MoveTwo = { Name = "Bullet Barrage", Cooldown = 10 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Trap", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Drink", Cooldown = 20 }
			}
		},
		Vecna = {
			Abilities = {
				VinePierce = { Name = "Vine Pierce", Cooldown = 10 },
				MoveOne = { Name = "Move One", Cooldown = 10 },
				MoveTwo = { Name = "Move Two", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Move Four", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				MindFlayer = { Name = "Mind Flayer", Cooldown = 30 },
				SpecialMove = { Name = "Special", Cooldown = 120 }
			}
		},
		Walter = {
			Abilities = {
				MoveOne = { Name = "Punches Combo", Cooldown = 6 },
				MoveTwo = { Name = "Meth Throw", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Trap", Cooldown = 18 },
				MoveFive = { Name = "Car Crash", Cooldown = 50 }
			}
		},
		Wanda = {
			Abilities = {
				MoveOne = { Name = "Chaos Shock", Cooldown = 10 },
				MoveTwo = { Name = "Torture", Cooldown = 10 },
				MoveThree = { Name = "Counter", Cooldown = 10 },
				MoveFour = { Name = "Power Steal", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Leap", Cooldown = 10 }
			}
		},
		Wednesday = {
			Abilities = {
				MoveOne = { Name = "Close Blast", Cooldown = 8 },
				MoveTwo = { Name = "Range Blast", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Ground Blast", Cooldown = 15 },
				MoveFive = { Name = "Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Cello", Cooldown = 20 }
			}
		},
		Zoom = {
			Abilities = {
				MoveOne = { Name = "Barrage", Cooldown = 10 },
				MoveTwo = { Name = "Fastest Man", Cooldown = 12 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Wind Tunnel", Cooldown = 14 },
				MoveFive = { Name = "Run Barry", Cooldown = 0.5 },
				SpecialMove = { Name = "V9", Cooldown = 45 },
				SpecialMoveAlt = { Name = "V9", Cooldown = 120 }
			}
		},
		TomSpider = {
			Abilities = {
				MoveOne = { Name = "Web Shot", Cooldown = 10 },
				MoveOneAwakened = { Name = "Web Shot", Cooldown = 12 },
				MoveTwo = { Name = "Glue", Cooldown = 14 },
				MoveThree = { Name = "Counter", Cooldown = 20 },
				MoveFour = { Name = "Webshoot", Cooldown = 10 },
				MoveFourAwakened = { Name = "Webshoot", Cooldown = 14 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Web Tornado", Cooldown = 25 }
			}
		},
		Thragg = {
			Abilities = {
				MoveOne = { Name = "Slamdown", Cooldown = 10 },
				MoveTwo = { Name = "Cape Combo", Cooldown = 15 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveFour = { Name = "Rush", Cooldown = 12 },
				MoveFive = { Name = "Finisher", Cooldown = 0.1 },
				SpecialMove = { Name = "Fastest Man", Cooldown = 30 }
			}
		},
		MoonKnight = {
			Abilities = {
				MoveOne = { Name = "Baseball", Cooldown = 10 },
				MoveOneMarc = { Name = "Cornered Batter", Cooldown = 6 },
				MoveOneMrKnight = { Name = "Truncheon Toss", Cooldown = 8 },
				MoveOneMoonKnight = { Name = "Moon Kick", Cooldown = 10 },
				MoveTwo = { Name = "Gun", Cooldown = 12 },
				MoveTwoMarc = { Name = "Shoulder Shots", Cooldown = 14 },
				MoveTwoMrKnight = { Name = "Grab", Cooldown = 13 },
				MoveTwoMoonKnight = { Name = "Crescent Throw", Cooldown = 8 },
				MoveThree = { Name = "Counter", Cooldown = 12 },
				MoveThreeMarc = { Name = "Counter", Cooldown = 10 },
				MoveThreeMrKnight = { Name = "Counter", Cooldown = 10 },
				MoveThreeMoonKnight = { Name = "Counter", Cooldown = 8 },
				MoveFour = { Name = "Move Four", Cooldown = 12 },
				MoveFourMarc = { Name = "Blackout Barrage", Cooldown = 12 },
				MoveFourMrKnight = { Name = "Heal", Cooldown = 20 },
				MoveFourMoonKnight = { Name = "Grapple Kick", Cooldown = 15 },
				MoveFive = { Name = "Khonshu Slam", Cooldown = 18 },
				MoveFiveMrKnight = { Name = "Mr Knight Finisher", Cooldown = 60 },
				MoveFiveMoonKnight = { Name = "Moon Knight Finisher", Cooldown = 0.5 },
				SpecialMove = { Name = "Lockley Takedown", Cooldown = 120 }
			}
		}
	}
}

function module.GetCharacterConfig(p1)
	if typeof(p1) == "string" then
		return module.Characters[p1]
	end

	return nil
end
function module.GetAbilityConfig(p2, p3)
	local v5 = module.GetCharacterConfig(p2)

	if not v5 or not v5.Abilities then
		return nil
	end

	return v5.Abilities[p3]
end
function module.GetCooldown(p4, p5, p6)
	local v9 = module.GetAbilityConfig(p4, p5)
	local cooldown = v9 and v9.Cooldown

	if typeof(cooldown) == "number" then
		return cooldown
	end

	return p6 or 0
end

return module
