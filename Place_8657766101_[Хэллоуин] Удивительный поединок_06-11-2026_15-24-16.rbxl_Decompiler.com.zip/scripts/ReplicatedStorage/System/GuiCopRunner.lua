-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local userInputService: UserInputService = game:GetService("UserInputService")
local runService: RunService = game:GetService("RunService")
local lightingEffects = require(replicatedStorage:WaitForChild("LightingEffects"))
local LocalPlayer: Player = players.LocalPlayer
local t1: {[any]: any} = {}
local t2: {[any]: any} = {}
local n1: number = 0
local u11 = nil
local n2 = 0
local n3: number = 0
local u14 = nil

local function getActiveRunCount()
	local n1: number = 0

	for iterValue in t1 do
		n1 += 1
	end

	return n1
end
local function pruneStaleRuns(p1)
	local v63 = p1 or os.clock()
	local u64: boolean = false

	for iterValue in t1 do
		local v66 = t2[iterValue]

		if typeof(v66) == "number" and v63 >= v66 then
			t1[iterValue] = nil
			t2[iterValue] = nil

			if u14 then
				u14(iterValue, false)
			end

			u64 = true
		end
	end

	return u64
end
local function hasActiveRuns()
	pruneStaleRuns()

	return next(t1) ~= nil
end
local function refreshActiveRunAttributes(p2, p3)
	local playerGui: Instance = LocalPlayer:FindFirstChild("PlayerGui")

	if not playerGui then
		return
	end

	local v70 = pruneStaleRuns()
	local n2: number = 0

	for iterValue in t1 do
		n2 += 1
	end

	playerGui:SetAttribute("GuiCopActiveRuns", n2)

	if p2 == true then
		playerGui:SetAttribute("GuiCopLastRunStartedAt", os.clock())
		playerGui:SetAttribute("GuiCopRunGeneration", n1)

		if typeof(p3) == "number" and (typeof((playerGui:GetAttribute("GuiCopRunDeadlineAt"))) ~= "number" or p3 > playerGui:GetAttribute("GuiCopRunDeadlineAt")) then
			playerGui:SetAttribute("GuiCopRunDeadlineAt", p3)

			return
		end
	else
		if n2 <= 0 then
			playerGui:SetAttribute("GuiCopLastRunStartedAt", nil)
			playerGui:SetAttribute("GuiCopRunDeadlineAt", nil)
			playerGui:SetAttribute("GuiCopLastRunEndedAt", os.clock())

			return
		end

		if v70 then
			local v73 = nil

			for key, value in t2 do
				if typeof(value) == "number" and (v73 == nil or v73 < value) then
					v73 = value
				end
			end

			playerGui:SetAttribute("GuiCopRunDeadlineAt", v73)
		end
	end
end

local u19 = nil
local u20: boolean = false

local function loadPercentageUtility()
	if u20 then
		return u19
	end

	u20 = true

	local system: Instance = replicatedStorage:FindFirstChild("System")
	local percentageGuiUtility: Instance = system and system:FindFirstChild("PercentageGuiUtility")

	if percentageGuiUtility and percentageGuiUtility:IsA("ModuleScript") then
		local ok, result = pcall(require, percentageGuiUtility)

		if ok then
			u19 = result
		end
	end

	return u19
end

u14 = function(p4, p5)
	local v82 = loadPercentageUtility()

	if not v82 then
		return
	end

	local s1: string = "GuiCopRun:" .. tostring(p4)

	if p5 and typeof(v82.AcquireSuppression) == "function" then
		v82.AcquireSuppression(s1)
	elseif not p5 and typeof(v82.ReleaseSuppression) == "function" then
		v82.ReleaseSuppression(s1)
	end
end

local t3: {[any]: any} = {
	Duration = nil,
	FireFlipSide = true,
	UseExitLookAtTarget = true,
	ExitLookAtDuration = 0.35,
	ExitLookAtStrength = 0.7,
	ExitLookAtRange = 35,
	HideCharacterGui = true,
	HideUiThing = true,
	HideVig = true,
	HideMoveset = true,
	HidePercentageGuis = true,
	HideMouseIcon = true,
	UseCutsceneCamera = true,
	CameraPartName = "CamCutscene",
	ShowBlackLines = true,
	TweenTime = 0.35,
	PercentageMaxDistance = 50,
	RestoreCameraFlip = false,
	RestoreSavedCameraCFrame = true,
	HardTimeoutPadding = 4,
	BlackLinesPath = { "Characters", "TheBatman", "Other", "BlackLines" },
	BlackLineInUp = UDim2.new(0, 0, 0, 0),
	BlackLineInDown = UDim2.new(0, 0, 0.849, 0),
	BlackLineOutUp = UDim2.new(0, 0, -0.2, 0),
	BlackLineOutDown = UDim2.new(0, 0, 1, 0)
}

local function shallowMerge(p6)
	local t5: {[any]: any} = {}

	for key, value in t3 do
		t5[key] = value
	end

	for iterFirst, iterSecond in p6 or {}, nil, nil do
		t5[iterFirst] = iterSecond
	end

	return t5
end
local function getPlayerGui()
	return LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")
end
local function findByPath(p7, p8)
	local v92 = p7

	for i = 1, #p8 do
		if not v92 then
			return nil
		end

		v92 = v92:FindFirstChild(p8[i])
	end

	return v92
end
local function getScreenGui(p9)
	local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild(p9)

	if foundChild and foundChild:IsA("ScreenGui") then
		return foundChild
	end

	return nil
end
local function isMenuOpen()
	local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
	local v97 = if menu and menu:IsA("ScreenGui") then menu else nil

	return v97 ~= nil and v97.Enabled == true
end
local function forceMenuSafeCinematicState()
	local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
	local v99 = if menu and menu:IsA("ScreenGui") then menu else nil

	if v99 == nil or v99.Enabled ~= true then
		return
	end

	local blackLineOutUp = t3.BlackLineOutUp
	local blackLineOutDown = t3.BlackLineOutDown

	for iterFirst, iterSecond in (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):GetChildren() do
		if iterSecond:IsA("ScreenGui") then
			local foundChild = iterSecond:FindFirstChild("BlackLineUp", true)
			local foundChild2 = iterSecond:FindFirstChild("BlackLineDown", true)

			if foundChild or foundChild2 then
				if foundChild and foundChild:IsA("GuiObject") then
					foundChild.Position = blackLineOutUp
					foundChild.Visible = false
				end

				if foundChild2 and foundChild2:IsA("GuiObject") then
					foundChild2.Position = blackLineOutDown
					foundChild2.Visible = false
				end

				if iterSecond.Name == "CinLines" or iterSecond.Name == "GuiCopBlackLines" then
					iterSecond.Enabled = false
				else
					iterSecond.Enabled = false
					iterSecond.Parent = nil
				end
			end
		end
	end

	local CurrentCamera: Camera = workspace.CurrentCamera
	local Character: Model = LocalPlayer.Character
	local v108 = Character

	if v108 then
		v108 = Character:FindFirstChildOfClass("Humanoid")
	end

	if CurrentCamera then
		CurrentCamera.CameraType = Enum.CameraType.Custom

		if v108 then
			CurrentCamera.CameraSubject = v108
		end
	end
end

local u29: boolean = false

local function hookMenuCleanup()
	if u29 then
		return
	end

	u29 = true

	local v109: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")

	local function attach(p10)
		if not p10 or not p10:IsA("ScreenGui") then
			return
		end

		p10:GetPropertyChangedSignal("Enabled"):Connect(function()
			if p10.Enabled then
				forceMenuSafeCinematicState()
			end
		end)

		if p10.Enabled then
			forceMenuSafeCinematicState()
		end
	end

	attach(v109:FindFirstChild("Menu"))
	v109.ChildAdded:Connect(function(p11: Instance)
		if p11.Name == "Menu" then
			attach(p11)

			return
		end

		local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
		local v350 = if menu and menu:IsA("ScreenGui") then menu else nil

		if v350 ~= nil and v350.Enabled == true and p11:IsA("ScreenGui") then
			task.defer(forceMenuSafeCinematicState)
		end
	end)
end
local function characterHasValues()
	local Character: Model = LocalPlayer.Character

	if not Character or not Character:FindFirstChild("Values") then
		return false
	end

	if LocalPlayer:GetAttribute("DUEL_SOUL") == true then
		return false
	end

	local characterCHOSENVALUE: Instance = Character:FindFirstChild("CharacterCHOSENVALUE")

	if characterCHOSENVALUE and characterCHOSENVALUE:IsA("StringValue") and characterCHOSENVALUE.Value == "Soul" then
		return false
	end

	return true
end
local function setScreenGui(p12, enabled)
	local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild(p12)
	local v116 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

	if v116 then
		v116.Enabled = enabled
	end
end
local function setMovesetRestored(_)
	local enabled = characterHasValues()
	local moveset = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Moveset")
	local v120 = if moveset and moveset:IsA("ScreenGui") then moveset else nil

	if v120 then
		v120.Enabled = enabled
	end
end

local n4: number = 0
local u35: boolean = false

local function getCharacterRoot(p15)
	if not p15 or not p15:IsA("Model") then
		return nil
	end

	local humanoidRootPart = p15:FindFirstChild("HumanoidRootPart")

	if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
		return humanoidRootPart
	end

	local upperTorso = p15:FindFirstChild("UpperTorso")

	if upperTorso and upperTorso:IsA("BasePart") then
		return upperTorso
	end

	local head = p15:FindFirstChild("Head")

	if head and head:IsA("BasePart") then
		return head
	end

	return nil
end
local function findNearestExitLookTarget(p16, p17)
	local v127 = getCharacterRoot(p16)

	if not v127 then
		return nil
	end

	local v128 = nil
	local numberValue = tonumber(p17) or 35
	local t6: {[any]: any} = {}
	local t7: {[any]: any} = { workspace:FindFirstChild("CharHitbox"), workspace }

	for i = 1, #t7 do
		local v133 = t7[i]

		if v133 then
			for iterFirst, iterSecond in v133:GetDescendants() do
				local character = iterSecond:IsA("Model") and iterSecond or iterSecond:FindFirstAncestorOfClass("Model")

				if character and character ~= p16 and not t6[character] then
					t6[character] = true

					local humanoid = character:FindFirstChildOfClass("Humanoid")
					local v138 = getCharacterRoot(character)

					if humanoid and humanoid.Health > 0 and v138 then
						local magnitude = (v138.Position - v127.Position).Magnitude

						if numberValue > magnitude then
							numberValue = magnitude
							v128 = v138
						end
					end
				end
			end
		end
	end

	return v128
end
local function stopExitLookAt()
	n4 += 1

	if u35 then
		runService:UnbindFromRenderStep("GuiCopExitLookAtTarget")
		u35 = false
	end
end
local function startExitLookAtTarget(p18, p19, p20)
	local CurrentCamera: Camera = workspace.CurrentCamera

	if CurrentCamera and p18 then
		local numberValue: number? = tonumber(p19)
		local u145 = math.clamp(numberValue or 0.35, 0.05, 2)
		local numberValue2: number? = tonumber(p20)
		local u147 = math.clamp(numberValue2 or 0.7, 0, 1)

		n4 += 1

		if u35 then
			runService:UnbindFromRenderStep("GuiCopExitLookAtTarget")
			u35 = false
		end

		n4 += 1

		local v148: number = n4
		local v149 = os.clock()

		u35 = true
		runService:BindToRenderStep("GuiCopExitLookAtTarget", Enum.RenderPriority.Camera.Value + 3, function()
			if v148 ~= n4 or not p18.Parent then
				n4 += 1

				if u35 then
					runService:UnbindFromRenderStep("GuiCopExitLookAtTarget")
					u35 = false
				end

				return
			end

			local n1 = os.clock() - v149

			if n1 >= u145 then
				n4 += 1

				if u35 then
					runService:UnbindFromRenderStep("GuiCopExitLookAtTarget")
					u35 = false
				end

				return
			end

			local currentCameraCFrame: CFrame = CurrentCamera.CFrame
			local v353 = CFrame.lookAt(currentCameraCFrame.Position, p18.Position + Vector3.new(0, 1.5, 0))
			local n2 = u145 - n1
			local n3 = 1

			if n1 < 0.08 then
				n3 = n1 / 0.08
			elseif n2 < 0.12 then
				n3 = n2 / 0.12
			end

			local v356 = u147
			local v357 = math.clamp(n3, 0, 1)

			CurrentCamera.CFrame = currentCameraCFrame:Lerp(v353, v356 * v357)
		end)

		return
	end
end
local function scheduleExitLookAt(p21)
	if p21 and p21.UseExitLookAtTarget ~= false then
		task.delay(0.05, function()
			local v358 = findNearestExitLookTarget(LocalPlayer.Character, p21.ExitLookAtRange)

			if v358 then
				startExitLookAtTarget(v358, p21.ExitLookAtDuration, p21.ExitLookAtStrength)
			end
		end)

		return
	end
end
local function restoreCameraLook(p22, p23)
	task.defer(function()
		local CurrentCamera: Camera = workspace.CurrentCamera
		local Character: Model = LocalPlayer.Character
		local humanoid = Character and Character:FindFirstChildOfClass("Humanoid")

		if not CurrentCamera then
			return
		end

		CurrentCamera.CameraType = Enum.CameraType.Custom

		if humanoid then
			CurrentCamera.CameraSubject = humanoid
		end

		if typeof(p22) == "CFrame" and (not p23 or p23.RestoreSavedCameraCFrame ~= false) then
			CurrentCamera.CFrame = p22
		end

		if p23 and p23.RestoreCameraFlip == false then
			return
		end

		task.delay(0.1, function()
			CurrentCamera = workspace.CurrentCamera

			if not CurrentCamera then
				return
			end

			local currentCameraCFrame: CFrame = CurrentCamera.CFrame
			local currentCameraCFramePosition = currentCameraCFrame.Position

			CurrentCamera.CFrame = CFrame.lookAt(currentCameraCFramePosition, currentCameraCFramePosition - currentCameraCFrame.LookVector, currentCameraCFrame.UpVector)
		end)
	end)
end
local function saveOriginalState()
	if u11 then
		return
	end

	local CurrentCamera: Camera = workspace.CurrentCamera
	local v154: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")
	local mouse: Mouse = LocalPlayer:GetMouse()

	local function readEnabled(p24)
		local foundChild: Instance = v154:FindFirstChild(p24)

		if foundChild and foundChild:IsA("ScreenGui") then
			return foundChild.Enabled
		end

		return nil
	end

	local characterGui: Instance = v154:FindFirstChild("CharacterGui")
	local t8: {[any]: any} = {
		CharacterGui = if characterGui and characterGui:IsA("ScreenGui") then characterGui.Enabled else nil
	}
	local foundChild: Instance = v154:FindFirstChild("UI thing")

	t8.UiThing = if foundChild and foundChild:IsA("ScreenGui") then foundChild.Enabled else nil

	local vig: Instance = v154:FindFirstChild("Vig")

	t8.Vig = if vig and vig:IsA("ScreenGui") then vig.Enabled else nil

	local moveset: Instance = v154:FindFirstChild("Moveset")

	t8.Moveset = if moveset and moveset:IsA("ScreenGui") then moveset.Enabled else nil
	t8.MouseIconEnabled = userInputService.MouseIconEnabled
	t8.MouseIcon = mouse and mouse.Icon or nil
	t8.CameraType = CurrentCamera and CurrentCamera.CameraType or nil
	t8.CameraSubject = CurrentCamera and CurrentCamera.CameraSubject or nil
	t8.CameraCFrame = CurrentCamera and CurrentCamera.CFrame or nil
	u11 = t8
end
local function tweenPosition(p25, p26, p27)
	if not p25 or not p25:IsA("GuiObject") then
		return
	end

	local tweenInfo = TweenInfo.new(p27, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

	tweenService:Create(p25, tweenInfo, { Position = p26 }):Play()
end
local function createBlackLines(p28)
	if p28.ShowBlackLines == false then
		return nil
	end

	local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
	local v168 = if menu and menu:IsA("ScreenGui") then menu else nil

	if v168 ~= nil and v168.Enabled == true then
		return nil
	end

	local parent: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")
	local guiCopBlackLines = parent:FindFirstChild("GuiCopBlackLines")
	local menu2
	local v172
	local foundChild
	local foundChild3

	if not guiCopBlackLines or not guiCopBlackLines:IsA("ScreenGui") then
		local guiCopBlackLines2: Instance = game:GetService("StarterGui"):FindFirstChild("GuiCopBlackLines")

		if guiCopBlackLines2 and guiCopBlackLines2:IsA("ScreenGui") then
			guiCopBlackLines = guiCopBlackLines2:Clone()
		else
			local v176 = p28.BlackLines

			if not v176 then
				local blackLinesPath = p28.BlackLinesPath
				local v178 = replicatedStorage

				for i = 1, #blackLinesPath do
					if not v178 then
						v176 = nil
					else
						v178 = v178:FindFirstChild(blackLinesPath[i])
					end

					if v176 and v176:IsA("ScreenGui") then
						guiCopBlackLines = v176:Clone()
					end

					if guiCopBlackLines then
						guiCopBlackLines.Name = "GuiCopBlackLines"
						guiCopBlackLines.ResetOnSpawn = false
						guiCopBlackLines.Parent = parent
					end

					if not guiCopBlackLines or not guiCopBlackLines:IsA("ScreenGui") then
						return nil
					end

					n3 += 1
					guiCopBlackLines:SetAttribute("GuiCopGeneration", n3)
					guiCopBlackLines.Enabled = true
					guiCopBlackLines.ResetOnSpawn = false
					guiCopBlackLines.IgnoreGuiInset = true
					guiCopBlackLines.DisplayOrder = p28.BlackLinesDisplayOrder or 1000
					menu2 = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
					v172 = if menu2 and menu2:IsA("ScreenGui") then menu2 else nil

					if v172 ~= nil and v172.Enabled == true then
						forceMenuSafeCinematicState()

						return nil
					end

					foundChild = guiCopBlackLines:FindFirstChild("BlackLineUp", true)
					foundChild3 = guiCopBlackLines:FindFirstChild("BlackLineDown", true)

					if foundChild and foundChild:IsA("GuiObject") then
						foundChild.Visible = true
						foundChild.BackgroundTransparency = p28.BlackLineTransparency or 0
						foundChild.Position = p28.BlackLineOutUp
					end

					if foundChild3 and foundChild3:IsA("GuiObject") then
						foundChild3.Visible = true
						foundChild3.BackgroundTransparency = p28.BlackLineTransparency or 0
						foundChild3.Position = p28.BlackLineOutDown
					end

					tweenPosition(foundChild, p28.BlackLineInUp, p28.TweenTime)
					tweenPosition(foundChild3, p28.BlackLineInDown, p28.TweenTime)

					return guiCopBlackLines
				end

				v176 = v178
			end
		end
	end

	do
		if not guiCopBlackLines or not guiCopBlackLines:IsA("ScreenGui") then
			return nil
		end

		n3 += 1
		guiCopBlackLines:SetAttribute("GuiCopGeneration", n3)
		guiCopBlackLines.Enabled = true
		guiCopBlackLines.ResetOnSpawn = false
		guiCopBlackLines.IgnoreGuiInset = true
		guiCopBlackLines.DisplayOrder = p28.BlackLinesDisplayOrder or 1000

		local menu2 = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
		local v172 = if menu2 and menu2:IsA("ScreenGui") then menu2 else nil

		if v172 ~= nil and v172.Enabled == true then
			forceMenuSafeCinematicState()

			return nil
		end

		local foundChild = guiCopBlackLines:FindFirstChild("BlackLineUp", true)
		local foundChild3 = guiCopBlackLines:FindFirstChild("BlackLineDown", true)

		if foundChild and foundChild:IsA("GuiObject") then
			foundChild.Visible = true
			foundChild.BackgroundTransparency = p28.BlackLineTransparency or 0
			foundChild.Position = p28.BlackLineOutUp
		end

		if foundChild3 and foundChild3:IsA("GuiObject") then
			foundChild3.Visible = true
			foundChild3.BackgroundTransparency = p28.BlackLineTransparency or 0
			foundChild3.Position = p28.BlackLineOutDown
		end

		tweenPosition(foundChild, p28.BlackLineInUp, p28.TweenTime)
		tweenPosition(foundChild3, p28.BlackLineInDown, p28.TweenTime)

		return guiCopBlackLines
	end
end
local function forceHideBlackLines(p29, p30)
	if not p29 or not p29.Parent then
		return
	end

	local v182 = shallowMerge(p30 or {})
	local foundChild = p29:FindFirstChild("BlackLineUp", true)
	local foundChild4 = p29:FindFirstChild("BlackLineDown", true)

	if foundChild and foundChild:IsA("GuiObject") then
		foundChild.Position = v182.BlackLineOutUp
		foundChild.Visible = false
	end

	if foundChild4 and foundChild4:IsA("GuiObject") then
		foundChild4.Position = v182.BlackLineOutDown
		foundChild4.Visible = false
	end

	p29.Enabled = false
end
local function removeBlackLines(p31, p32)
	if not p31 then
		return
	end

	local v187: number = n3
	local foundChild = p31:FindFirstChild("BlackLineUp", true)
	local foundChild5 = p31:FindFirstChild("BlackLineDown", true)

	tweenPosition(foundChild, p32.BlackLineOutUp, p32.TweenTime)
	tweenPosition(foundChild5, p32.BlackLineOutDown, p32.TweenTime)
	task.delay(p32.TweenTime + 0.1, function()
		if not p31 or not p31.Parent then
		elseif v187 == n3 then
			pruneStaleRuns()

			if next(t1) ~= nil then
				return
			end

			if foundChild and foundChild:IsA("GuiObject") then
				foundChild.Visible = false
			end

			if foundChild5 and foundChild5:IsA("GuiObject") then
				foundChild5.Visible = false
			end

			p31.Enabled = false

			return
		end
	end)
	task.delay((p32.TweenTime or 0.35) + 1, function()
		if p31 and p31.Parent and v187 == n3 then
			pruneStaleRuns()

			if next(t1) == nil then
				forceHideBlackLines(p31, p32)
			end
		end
	end)
end
local function applyStartState(p33)
	if not u11 then
		saveOriginalState()
	end

	local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
	local v192 = if menu and menu:IsA("ScreenGui") then menu else nil

	if v192 ~= nil and v192.Enabled == true then
		forceMenuSafeCinematicState()

		return
	end

	if p33.HideCharacterGui then
		local characterGui = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("CharacterGui")
		local v194 = if characterGui and characterGui:IsA("ScreenGui") then characterGui else nil

		if v194 then
			v194.Enabled = false
		end
	end

	if p33.HideUiThing then
		local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("UI thing")
		local v196 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

		if v196 then
			v196.Enabled = false
		end
	end

	if p33.HideVig then
		local vig = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Vig")
		local v198 = if vig and vig:IsA("ScreenGui") then vig else nil

		if v198 then
			v198.Enabled = false
		end
	end

	if p33.HideMoveset then
		local moveset = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Moveset")
		local v200 = if moveset and moveset:IsA("ScreenGui") then moveset else nil

		if v200 then
			v200.Enabled = false
		end
	end

	if p33.HideMouseIcon then
		userInputService.MouseIconEnabled = false
	end

	local v201 = p33.HidePercentageGuis and loadPercentageUtility()

	if v201 and v201.SetEnabled then
		pcall(function()
			v201.SetEnabled(false)
		end)
	end

	if p33.UseCutsceneCamera then
		local CurrentCamera: Camera = workspace.CurrentCamera
		local Character: Model = LocalPlayer.Character
		local cameraSubject = Character and Character:FindFirstChild(p33.CameraPartName or "CamCutscene", true)

		if CurrentCamera and cameraSubject and cameraSubject:IsA("BasePart") then
			CurrentCamera.CameraType = Enum.CameraType.Scriptable
			CurrentCamera.CameraSubject = cameraSubject
			CurrentCamera.CFrame = cameraSubject.CFrame
		end
	end
end
local function forceHidePersistentBlackLines(p34, p35)
	local v207 = p35 or t3.TweenTime

	n3 += 1

	local v208: number = n3

	for iterFirst, value in { "CinLines", "GuiCopBlackLines" }, nil, nil do
		local value = p34:FindFirstChild(value)

		if value and value:IsA("ScreenGui") then
			value.Enabled = true
			value:SetAttribute("GuiCopHidingGeneration", v208)

			for iterFirst2, iterSecond in value:GetDescendants() do
				if iterSecond:IsA("GuiObject") and (iterSecond.Name == "BlackLineUp" or iterSecond.Name == "BlackLineDown") then
					iterSecond.Visible = true

					local v214 = iterSecond.Name == "BlackLineUp" and t3.BlackLineOutUp or t3.BlackLineOutDown
					local tweenInfo = TweenInfo.new(v207, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

					tweenService:Create(iterSecond, tweenInfo, { Position = v214 }):Play()
				end
			end

			task.delay(v207 + 0.1, function()
				if value and value.Parent and value:GetAttribute("GuiCopHidingGeneration") == v208 then
					pruneStaleRuns()

					if next(t1) == nil then
						for iterFirst, iterSecond in value:GetDescendants() do
							if iterSecond:IsA("GuiObject") and (iterSecond.Name == "BlackLineUp" or iterSecond.Name == "BlackLineDown") then
								iterSecond.Position = iterSecond.Name == "BlackLineUp" and t3.BlackLineOutUp or t3.BlackLineOutDown
								iterSecond.Visible = false
								iterSecond.BackgroundTransparency = 1
							end
						end

						value.Enabled = false
					end
				end
			end)
		end
	end
end
local function tweenGuiObjectOut(p36, p37)
	local v218 = p37 or 0.35

	if not p36:IsA("ImageLabel") and not p36:IsA("ImageButton") then
		if not p36:IsA("TextLabel") and not p36:IsA("TextButton") and not p36:IsA("TextBox") then
			if p36:IsA("Frame") or p36:IsA("ScrollingFrame") or p36:IsA("ViewportFrame") then
				local tweenInfo = TweenInfo.new(v218, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

				tweenService:Create(p36, tweenInfo, { BackgroundTransparency = 1 }):Play()
			end

			return
		end

		local tweenInfo = TweenInfo.new(v218, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(p36, tweenInfo, { TextTransparency = 1, BackgroundTransparency = 1 }):Play()

		return
	end

	local tweenInfo = TweenInfo.new(v218, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

	tweenService:Create(p36, tweenInfo, { ImageTransparency = 1 }):Play()
end
local function resetCinematicOverlays(p38, p39)
	local function isInsideCharacterSpecial(p40)
		local v367 = p40.Parent

		while v367 do
			if v367.Name == "CharacterSpecial" then
				return true
			end

			v367 = v367.Parent
		end

		return false
	end
	local function isPersistentCharacterHud(p41)
		local v369 = p41

		while v369 and v369 ~= p38 do
			local lowerText = string.lower(v369.Name)

			if string.find(lowerText, "meter", 1, true) or string.find(lowerText, "amount", 1, true) or string.find(lowerText, "charge", 1, true) or string.find(lowerText, "extra", 1, true) or string.find(lowerText, "hud", 1, true) or string.find(lowerText, "stamina", 1, true) or string.find(lowerText, "rage", 1, true) or string.find(lowerText, "stone", 1, true) or string.find(lowerText, "names", 1, true) then
				return true
			end

			v369 = v369.Parent
		end

		return false
	end

	for iterFirst, iterSecond in p38:GetDescendants() do
		if iterSecond:IsA("GuiObject") then
			local lowerText = string.lower(iterSecond.Name)
			local u229: boolean = false

			if string.find(lowerText, "vign", 1, true) or string.find(lowerText, "vignette", 1, true) or string.find(lowerText, "darthvader", 1, true) or string.find(lowerText, "cinematic", 1, true) or string.find(lowerText, "scare", 1, true) or string.find(lowerText, "splash", 1, true) or string.find(lowerText, "blood", 1, true) or string.find(lowerText, "redimage", 1, true) or string.find(lowerText, "blackimage", 1, true) then
				u229 = true
			end

			if u229 then
				local v230 = iterSecond.Parent
				local u231

				while v230 do
					if v230.Name == "CharacterSpecial" then
						u231 = true

						break
					end

					v230 = v230.Parent
				end

				if not v230 then
					u231 = false
				end

				if u231 and isPersistentCharacterHud(iterSecond) then
					u229 = false
				end
			end

			if u229 then
				tweenGuiObjectOut(iterSecond, p39 or 0.35)
			end
		end
	end
end
local function resetCinematicEffects(p42)
	pcall(function()
		lightingEffects.ResetDefault({
			ColorDuration = p42 or 0.35,
			BlurDuration = p42 or 0.35,
			DepthDuration = p42 or 0.35,
			BloomDuration = p42 or 0.5,
			LightingDuration = p42 or 0.5,
			SunRaysDuration = p42 or 0.5
		})

		local lighting: Lighting = game:GetService("Lighting")
		local tweenInfo = TweenInfo.new(p42 or 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

		tweenService:Create(lighting, tweenInfo, { ExposureCompensation = 0 }):Play()
	end)

	local v233: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")

	forceHidePersistentBlackLines(v233, p42 or 0.35)
	v233 = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")
	resetCinematicOverlays(v233, p42 or 0.35)
end
local function restoreOriginalState(p43)
	local v235 = u11

	u11 = nil

	local menu = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Menu")
	local v237 = if menu and menu:IsA("ScreenGui") then menu else nil

	if v237 ~= nil and v237.Enabled == true then
		forceMenuSafeCinematicState()

		return
	end

	local function restoreGui(p44, enabled)
		if enabled == nil then
			local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild(p44)
			local v376 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

			if v376 then
				v376.Enabled = true
			end
		else
			local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild(p44)
			local v378 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

			if v378 then
				v378.Enabled = enabled

				return
			end
		end
	end

	local enabled = v235 and v235.CharacterGui

	if enabled == nil then
		local characterGui = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("CharacterGui")
		local v241 = if characterGui and characterGui:IsA("ScreenGui") then characterGui else nil

		if v241 then
			v241.Enabled = true
		end
	else
		local characterGui = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("CharacterGui")
		local v243 = if characterGui and characterGui:IsA("ScreenGui") then characterGui else nil

		if v243 then
			v243.Enabled = enabled
		end
	end

	local uiThing = v235 and v235.UiThing

	if uiThing == nil then
		local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("UI thing")
		local v246 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

		if v246 then
			v246.Enabled = true
		end
	else
		local foundChild = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("UI thing")
		local v248 = if foundChild and foundChild:IsA("ScreenGui") then foundChild else nil

		if v248 then
			v248.Enabled = uiThing
		end
	end

	local v249 = v235 and v235.Vig

	if v249 == nil then
		local vig = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Vig")
		local v251 = if vig and vig:IsA("ScreenGui") then vig else nil

		if v251 then
			v251.Enabled = true
		end
	else
		local vig = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Vig")
		local v253 = if vig and vig:IsA("ScreenGui") then vig else nil

		if v253 then
			v253.Enabled = v249
		end
	end

	local v254 = characterHasValues()
	local moveset = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("Moveset")
	local v256 = if moveset and moveset:IsA("ScreenGui") then moveset else nil

	if v256 then
		v256.Enabled = v254
	end

	if v235 and v235.MouseIconEnabled ~= nil then
		userInputService.MouseIconEnabled = v235.MouseIconEnabled
	else
		userInputService.MouseIconEnabled = true
	end

	local mouse: Mouse = LocalPlayer:GetMouse()

	if mouse and v235 and v235.MouseIcon then
		mouse.Icon = v235.MouseIcon
	end

	local v258 = p43.HidePercentageGuis and loadPercentageUtility()

	if v258 then
		pcall(function()
			if v258.ForceRestore then
				v258.ForceRestore(p43.PercentageMaxDistance)
			elseif v258.SetEnabled then
				v258.SetEnabled(true, p43.PercentageMaxDistance)
			end
		end)
	end

	local CurrentCamera: Camera = workspace.CurrentCamera
	local Character: Model = LocalPlayer.Character
	local humanoid = Character and Character:FindFirstChildOfClass("Humanoid")

	if CurrentCamera then
		CurrentCamera.CameraType = Enum.CameraType.Custom
		CurrentCamera.CameraSubject = humanoid or v235 and v235.CameraSubject or CurrentCamera.CameraSubject
	end

	local cameraCFrame = v235 and v235.CameraCFrame

	task.defer(function()
		local CurrentCamera2: Camera = workspace.CurrentCamera
		local Character2: Model = LocalPlayer.Character
		local humanoid = Character2 and Character2:FindFirstChildOfClass("Humanoid")

		if not CurrentCamera2 then
			return
		end

		CurrentCamera2.CameraType = Enum.CameraType.Custom

		if humanoid then
			CurrentCamera2.CameraSubject = humanoid
		end

		if typeof(cameraCFrame) == "CFrame" and (not p43 or p43.RestoreSavedCameraCFrame ~= false) then
			CurrentCamera2.CFrame = cameraCFrame
		end

		if p43 and p43.RestoreCameraFlip == false then
			return
		end

		task.delay(0.1, function()
			CurrentCamera2 = workspace.CurrentCamera

			if not CurrentCamera2 then
				return
			end

			local currentCamera2CFrame: CFrame = CurrentCamera2.CFrame
			local currentCamera2CFramePosition = currentCamera2CFrame.Position

			CurrentCamera2.CFrame = CFrame.lookAt(currentCamera2CFramePosition, currentCamera2CFramePosition - currentCamera2CFrame.LookVector, currentCamera2CFrame.UpVector)
		end)
	end)

	if not p43 then
		return
	end

	if p43.UseExitLookAtTarget == false then
		return
	end

	task.delay(0.05, function()
		local v382 = findNearestExitLookTarget(LocalPlayer.Character, p43.ExitLookAtRange)

		if v382 then
			startExitLookAtTarget(v382, p43.ExitLookAtDuration, p43.ExitLookAtStrength)
		end
	end)
end
local function getDuration(p46, p47)
	if typeof(p47.Duration) == "number" then
		return (math.max(0, p47.Duration))
	end

	if p46 then
		local v265 = p46.Parent
		local realVal = v265 and v265:FindFirstChild("RealVal")

		if realVal and realVal:IsA("NumberValue") then
			return (math.max(0, realVal.Value))
		end

		return 5
	end

	return 5
end
local function unregister(p48, p49, p50)
	if not t1[p48] then
		return
	end

	t1[p48] = nil
	t2[p48] = nil
	u14(p48, false)
	refreshActiveRunAttributes()
	pruneStaleRuns()

	if next(t1) ~= nil then
		refreshActiveRunAttributes()

		return
	end

	removeBlackLines(p50, p49)
	restoreOriginalState(p49)
	resetCinematicEffects(0.5)
end
local function safeCall(p51, p52, p53)
	if typeof(p51) == "function" then
		local ok, result = pcall(p51, p52)

		if not ok then
			local text: string = tostring(p53 or "callback")

			warn("GuiCopRunner " .. text .. " failed:", result)
		end

		return
	end
end
local function makeContext(p54, p55, p56, p57, p58)
	return {
		Player = LocalPlayer,
		PlayerGui = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui"),
		Character = LocalPlayer.Character,
		Camera = workspace.CurrentCamera,
		ReplicatedStorage = replicatedStorage,
		TweenService = tweenService,
		UserInputService = userInputService,
		SourceScript = p54,
		Config = p55,
		Duration = p56,
		BlackLines = p57,
		Finish = p58
	}
end
local function scheduleTimedEvents(p59, p60)
	if typeof(p59.TimedEvents) == "table" then
		for i = 1, #p59.TimedEvents do
			local v284 = p59.TimedEvents[i]

			if typeof(v284) == "table" then
				local v285 = tonumber(v284.Time) or tonumber(v284.Delay) or 0
				local v286 = v284.Callback or v284[1]
				local taskDelay = task.delay
				local v288 = math.max(0, v285)

				taskDelay(v288, function()
					if p60.Finished then
						return
					end

					local v383 = v286
					local v384 = p60
					local s1: string = "TimedEvents[" .. i .. "]"

					if typeof(v383) == "function" then
						local ok, result = pcall(v383, v384)

						if not ok then
							local text: string = tostring(s1 or "callback")

							warn("GuiCopRunner " .. text .. " failed:", result)
						end

						return
					end
				end)
			end
		end

		return
	end
end
local function scheduleDeadlineCleanup(p61, p62, p63)
	local v292 = math.max(0, (p63 or 0) + (p62.HardTimeoutPadding or 4) + (p62.TweenTime or 0.35) + 0.75)

	task.delay(v292, function()
		if t1[p61] then
			t1[p61] = nil
			t2[p61] = nil
			u14(p61, false)
			refreshActiveRunAttributes()
		end

		pruneStaleRuns()

		if next(t1) == nil then
			local v389 = shallowMerge(p62 or {})
			local v390: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")

			forceHidePersistentBlackLines(v390, 0.35)
			resetCinematicEffects(0.35)

			local guiCopBlackLines = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("GuiCopBlackLines")

			removeBlackLines(guiCopBlackLines, v389)
		end
	end)
end

local module: {[any]: any} = {
	Begin = function(p64)
		local v294 = shallowMerge(p64)
		local v295 = if typeof(v294.Duration) == "number" then math.max(0, v294.Duration) else 5

		pruneStaleRuns()
		n1 += 1

		local v296: number = n1
		local n3 = os.clock() + v295 + v294.HardTimeoutPadding + 1

		t1[v296] = true
		t2[v296] = n3
		u14(v296, true)
		refreshActiveRunAttributes(true, n3)

		local u298 = nil
		local u299 = nil
		local u300: boolean = false

		local function cleanup()
			if u300 then
				return
			end

			u300 = true

			if u299 then
				u299.Finished = true

				local onCleanup = v294.OnCleanup
				local v393 = u299

				if typeof(onCleanup) == "function" then
					local ok, result = pcall(onCleanup, v393)

					if not ok then
						local text: string = tostring("OnCleanup")

						warn("GuiCopRunner " .. text .. " failed:", result)
					end
				end
			end

			unregister(v296, v294, u298)

			if u299 then
				local onFinished = v294.OnFinished
				local v398 = u299

				if typeof(onFinished) == "function" then
					local ok, result = pcall(onFinished, v398)

					if not ok then
						local text: string = tostring("OnFinished")

						warn("GuiCopRunner " .. text .. " failed:", result)
					end

					return
				end

				return
			end
		end

		local ok, result = pcall(function()
			hookMenuCleanup()
			forceMenuSafeCinematicState()
			saveOriginalState()

			if v294.FireFlipSide then
				local v402 = os.clock()

				if v402 - n2 >= 0.75 then
					n2 = v402

					local flipSide: Instance = replicatedStorage:FindFirstChild("FlipSide")

					if flipSide and flipSide:IsA("RemoteEvent") then
						flipSide:FireServer(LocalPlayer)
					end
				end
			end

			applyStartState(v294)
			u298 = createBlackLines(v294)
			u299 = makeContext(nil, v294, v295, u298, cleanup)

			local onStart = v294.OnStart
			local v405 = u299

			if typeof(onStart) == "function" then
				local ok2, result2 = pcall(onStart, v405)

				if not ok2 then
					local text: string = tostring("OnStart")

					warn("GuiCopRunner " .. text .. " failed:", result2)
				end
			end

			scheduleTimedEvents(v294, u299)
		end)

		if not ok then
			warn("GuiCopRunner Begin failed:", result)

			if not u300 then
				u300 = true

				if u299 then
					u299.Finished = true

					local onCleanup = v294.OnCleanup
					local v305 = u299

					if typeof(onCleanup) == "function" then
						local ok3, result3 = pcall(onCleanup, v305)

						if not ok3 then
							local text: string = tostring("OnCleanup")

							warn("GuiCopRunner " .. text .. " failed:", result3)
						end
					end
				end

				unregister(v296, v294, u298)

				if u299 then
					local onFinished = v294.OnFinished
					local v310 = u299

					if typeof(onFinished) == "function" then
						local ok4, result4 = pcall(onFinished, v310)

						if not ok4 then
							local text: string = tostring("OnFinished")

							warn("GuiCopRunner " .. text .. " failed:", result4)
						end
					end
				end
			end
		end

		if typeof(p64) == "table" and p64.AutoCleanup == true then
			task.delay(v295, cleanup)
		end

		local v314 = math.max(0, (v295 or 0) + (v294.HardTimeoutPadding or 4) + (v294.TweenTime or 0.35) + 0.75)

		task.delay(v314, function()
			if t1[v296] then
				t1[v296] = nil
				t2[v296] = nil
				u14(v296, false)
				refreshActiveRunAttributes()
			end

			pruneStaleRuns()

			if next(t1) == nil then
				local v409 = shallowMerge(v294 or {})
				local v410: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")

				forceHidePersistentBlackLines(v410, 0.35)
				resetCinematicEffects(0.35)

				local guiCopBlackLines = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("GuiCopBlackLines")

				removeBlackLines(guiCopBlackLines, v409)
			end
		end)

		return { Context = u299, Cleanup = cleanup, Finish = cleanup }
	end,
	Run = function(p65, p66)
		local v317 = shallowMerge(p66)
		local v318

		if typeof(v317.Duration) == "number" then
			v318 = math.max(0, v317.Duration)
		elseif p65 then
			local v319 = p65.Parent
			local realVal = v319 and v319:FindFirstChild("RealVal")

			if realVal and realVal:IsA("NumberValue") then
				v318 = math.max(0, realVal.Value)
			else
				v318 = 5
			end
		else
			v318 = 5
		end

		pruneStaleRuns()
		n1 += 1

		local v321: number = n1
		local n3 = os.clock() + v318 + v317.HardTimeoutPadding + 1

		t1[v321] = true
		t2[v321] = n3
		u14(v321, true)
		refreshActiveRunAttributes(true, n3)

		local u323 = nil
		local u324 = nil
		local u325: boolean = false

		local function finish()
			if u325 then
				return
			end

			u325 = true

			if u324 then
				u324.Finished = true

				local onCleanup = v317.OnCleanup
				local v413 = u324

				if typeof(onCleanup) == "function" then
					local ok, result = pcall(onCleanup, v413)

					if not ok then
						local text: string = tostring("OnCleanup")

						warn("GuiCopRunner " .. text .. " failed:", result)
					end
				end
			end

			unregister(v321, v317, u323)

			if u324 then
				local onFinished = v317.OnFinished
				local v418 = u324

				if typeof(onFinished) == "function" then
					local ok, result = pcall(onFinished, v418)

					if not ok then
						local text: string = tostring("OnFinished")

						warn("GuiCopRunner " .. text .. " failed:", result)
					end

					return
				end

				return
			end
		end

		local ok, result = pcall(function()
			hookMenuCleanup()
			forceMenuSafeCinematicState()
			saveOriginalState()

			if v317.FireFlipSide then
				local v422 = os.clock()

				if v422 - n2 >= 0.75 then
					n2 = v422

					local flipSide: Instance = replicatedStorage:FindFirstChild("FlipSide")

					if flipSide and flipSide:IsA("RemoteEvent") then
						flipSide:FireServer(LocalPlayer)
					end
				end
			end

			applyStartState(v317)
			u323 = createBlackLines(v317)
			u324 = makeContext(p65, v317, v318, u323, finish)

			local onStart = v317.OnStart
			local v425 = u324

			if typeof(onStart) == "function" then
				local ok5, result5 = pcall(onStart, v425)

				if not ok5 then
					local text: string = tostring("OnStart")

					warn("GuiCopRunner " .. text .. " failed:", result5)
				end
			end

			scheduleTimedEvents(v317, u324)
		end)

		if not ok then
			warn("GuiCopRunner start failed:", result)

			if not u325 then
				u325 = true

				if u324 then
					u324.Finished = true

					local onCleanup = v317.OnCleanup
					local v330 = u324

					if typeof(onCleanup) == "function" then
						local ok6, result6 = pcall(onCleanup, v330)

						if not ok6 then
							local text: string = tostring("OnCleanup")

							warn("GuiCopRunner " .. text .. " failed:", result6)
						end
					end
				end

				unregister(v321, v317, u323)

				if u324 then
					local onFinished = v317.OnFinished
					local v335 = u324

					if typeof(onFinished) == "function" then
						local ok7, result7 = pcall(onFinished, v335)

						if not ok7 then
							local text: string = tostring("OnFinished")

							warn("GuiCopRunner " .. text .. " failed:", result7)
						end
					end
				end
			end

			return false
		end

		task.delay(v318, finish)
		task.delay(v318 + v317.HardTimeoutPadding, finish)

		local v339 = math.max(0, (v318 or 0) + (v317.HardTimeoutPadding or 4) + (v317.TweenTime or 0.35) + 0.75)

		task.delay(v339, function()
			if t1[v321] then
				t1[v321] = nil
				t2[v321] = nil
				u14(v321, false)
				refreshActiveRunAttributes()
			end

			pruneStaleRuns()

			if next(t1) == nil then
				local v429 = shallowMerge(v317 or {})
				local v430: Instance = LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")

				forceHidePersistentBlackLines(v430, 0.35)
				resetCinematicEffects(0.35)

				local guiCopBlackLines = (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):FindFirstChild("GuiCopBlackLines")

				removeBlackLines(guiCopBlackLines, v429)
			end
		end)

		return true
	end
}

function module.SuppressPercentages(p67)
	local v341 = module.Begin({
		FireFlipSide = true,
		ShowBlackLines = false,
		UseCutsceneCamera = false,
		HideCharacterGui = false,
		HideUiThing = false,
		HideVig = false,
		HideMoveset = false,
		HideMouseIcon = false,
		HidePercentageGuis = true
	})

	if typeof(p67) == "number" then
		task.delay(p67, v341.Cleanup)
	end

	return v341
end
function module.ForceCleanup()
	for iterValue in t1 do
		t1[iterValue] = nil
		t2[iterValue] = nil
		u14(iterValue, false)
	end

	refreshActiveRunAttributes()

	for iterFirst, iterSecond in (LocalPlayer:FindFirstChild("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui")):GetChildren() do
		if iterSecond:IsA("ScreenGui") and iterSecond:FindFirstChild("BlackLineUp", true) and iterSecond:FindFirstChild("BlackLineDown", true) then
			local v345 = shallowMerge({})

			removeBlackLines(iterSecond, v345)
			forceHideBlackLines(iterSecond, v345)
		end
	end

	local v346 = shallowMerge({})

	restoreOriginalState(v346)
	resetCinematicEffects(0.25)
end

return module
