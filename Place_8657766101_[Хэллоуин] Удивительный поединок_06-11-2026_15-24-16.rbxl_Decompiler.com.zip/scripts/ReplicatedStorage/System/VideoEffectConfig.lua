-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
return {
	Freddy = {
		FrameName = "Freddy",
		StartDelay = 0.1,
		HoldBeforeFade = 0.5,
		Duration = 1.5,
		FadeInTime = 0.3,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	Foxy = {
		FrameName = "Foxy",
		StartDelay = 0.1,
		HoldBeforeFade = 0.5,
		Duration = 1.5,
		FadeInTime = 0.3,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	Puppet = {
		FrameName = "Puppet",
		StartDelay = 0.1,
		HoldBeforeFade = 0.5,
		Duration = 3.7,
		FadeInTime = 0.3,
		FadeInBackgroundTransparency = 0.3,
		FadeOutTime = 0.3,
		VideoTransparency = 0.3,
		EndVideoTransparency = 1,
		HideMouse = true
	},
	Springlock = {
		FrameName = "Springlock",
		StartDelay = 0.1,
		HoldBeforeFade = 0.5,
		Duration = 0.3,
		FadeInTime = 0.3,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	StaticSpring = {
		FrameName = "StaticSpring",
		StartDelay = 0.1,
		HoldBeforeFade = 0,
		Duration = 3.5,
		FadeInTime = 0,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	StaticSpringE = {
		FrameName = "StaticSpringE",
		StartDelay = 0.1,
		HoldBeforeFade = 0,
		Duration = 4,
		FadeInTime = 0,
		FadeInBackgroundTransparency = 1,
		FadeOutTime = 0.3,
		VideoTransparency = 0.3,
		EndVideoTransparency = 1,
		HideMouse = true,
		UpperZIndex = 1,
		VideoZIndex = 10
	},
	LawlietDeath = {
		FrameName = "LawlietDeath",
		StartDelay = 0.1,
		HoldBeforeFade = 6,
		Duration = 0.3,
		FadeInTime = 0.3,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	Rumbling = {
		FrameName = "Rumbling",
		StartDelay = 0.1,
		HoldBeforeFade = 0.5,
		Duration = "TimeLength",
		FallbackDuration = 8,
		MaxDuration = 20,
		FadeInTime = 0.6,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = true
	},
	FlashRun = {
		FrameName = "FlashRun",
		StartDelay = 0,
		HoldBeforeFade = 0,
		Duration = 4,
		FadeInTime = 0,
		FadeInBackgroundTransparency = 1,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = false
	},
	FlashRun2023 = {
		FrameName = "FlashRun2023",
		StartDelay = 0,
		HoldBeforeFade = 0,
		Duration = 4,
		FadeInTime = 0,
		FadeInBackgroundTransparency = 1,
		FadeOutTime = 0.3,
		VideoTransparency = 0,
		HideMouse = false
	},
	ThraggImpact = {
		FrameName = "ThraggImpact",
		StartDelay = 0,
		HoldBeforeFade = "TimeLength",
		FallbackDuration = 2,
		MaxDuration = 8,
		Duration = 0.1,
		FadeInTime = 0.1,
		FadeInBackgroundTransparency = 0,
		FadeOutTime = 0,
		VideoTransparency = 0,
		HideMouse = true
	}
}
