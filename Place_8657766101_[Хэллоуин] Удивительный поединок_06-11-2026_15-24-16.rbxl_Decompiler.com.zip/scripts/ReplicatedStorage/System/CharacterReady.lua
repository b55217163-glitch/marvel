-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")

local function waitForChildOfClass(p1, p2, p3)
	local v6 = p1 and p1:FindFirstChildOfClass(p2)

	if v6 then
		return v6
	end

	local n1 = os.clock() + p3

	while p1 and p1.Parent and n1 > os.clock() do
		local foundChild = p1:FindFirstChildOfClass(p2)

		if foundChild then
			return foundChild
		end

		task.wait(0.05)
	end

	return p1 and p1:FindFirstChildOfClass(p2) or nil
end

return {
	Wait = function(p4, p5)
		local player = p4 or players.LocalPlayer
		local numberValue = tonumber(p5)

		numberValue = os.clock() + (numberValue or 15)

		local Character = player.Character

		while (not Character or not Character.Parent) and numberValue > os.clock() do
			Character = player.Character

			if Character and Character.Parent then
				break
			end

			task.wait(0.05)
		end

		if not Character or not Character.Parent then
			return nil, nil, nil
		end

		local v14 = os.clock()
		local v15 = math.max(0.05, numberValue - v14)
		local v16 = waitForChildOfClass(Character, "Humanoid", v15)
		local v17 = os.clock()
		local v18 = math.max(0.05, numberValue - v17)

		v18 = Character:FindFirstChild("HumanoidRootPart") or Character:WaitForChild("HumanoidRootPart", v18)

		while Character.Parent and Character:GetAttribute("CombatSpawnReady") == false and numberValue > os.clock() do
			task.wait(0.05)
		end

		return Character, v16, v18
	end
}
