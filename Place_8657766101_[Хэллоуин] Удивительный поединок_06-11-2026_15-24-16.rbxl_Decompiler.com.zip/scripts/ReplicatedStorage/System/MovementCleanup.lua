-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local t1: {[any]: any} = {
	BodyVelocity = true,
	BodyPosition = true,
	BodyGyro = true,
	BodyAngularVelocity = true,
	BodyForce = true,
	BodyThrust = true,
	LinearVelocity = true,
	AngularVelocity = true,
	VectorForce = true,
	AlignPosition = true,
	AlignOrientation = true,
	RocketPropulsion = true
}

return {
	ClearForDash = function(p1, p2)
		if not p1 or not p1:IsA("BasePart") then
			return
		end

		local v4 = p1.Parent
		local t2: {[any]: any} = { p1 }

		if v4 then
			table.insert(t2, v4)
		end

		for i = 1, #t2 do
			local descendants = t2[i]:GetDescendants()

			for j = 1, #descendants do
				local v9 = descendants[j]

				if t1[v9.ClassName] and v9 ~= p2 then
					v9.Parent = nil
				end
			end
		end

		p1.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		p1.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	end
}
