-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local contentProvider: ContentProvider = game:GetService("ContentProvider")

local module: {[any]: any} = {
	Setup = function(p1, p2)
		if not p1 or not p1:IsA("Sound") then
			return false
		end

		local lazySoundId = p1:GetAttribute("LazySoundId")

		if typeof(lazySoundId) ~= "string" or lazySoundId == "" then
			lazySoundId = p1.SoundId
		end

		if typeof(lazySoundId) == "string" and lazySoundId ~= "" then
			p1:SetAttribute("LazySoundId", lazySoundId)
			p1:SetAttribute("LazyClearAfterPlay", p2 == true)
			p1.SoundId = ""

			return true
		end

		return false
	end,
	Restore = function(p3)
		if not p3 or not p3:IsA("Sound") then
			return false
		end

		if p3.SoundId == "" then
			local lazySoundId = p3:GetAttribute("LazySoundId")

			if typeof(lazySoundId) ~= "string" or lazySoundId == "" then
				lazySoundId = p3:GetAttribute("OriginalSoundId")
			end

			if typeof(lazySoundId) == "string" and lazySoundId ~= "" then
				p3.SoundId = lazySoundId

				return true
			end

			local ok, result = pcall(function()
				return p3.AudioContent
			end)

			if ok and result ~= nil and tostring(result) ~= "" then
				return true
			end

			return false
		end

		return true
	end,
	Clear = function(p4)
		if not p4 or not p4:IsA("Sound") then
			return false
		end

		if p4.Playing then
			return false
		end

		local lazySoundId = p4:GetAttribute("LazySoundId")

		if typeof(lazySoundId) == "string" and lazySoundId ~= "" then
			p4.SoundId = ""

			return true
		end

		return false
	end
}

function module.Preload(p5)
	if not module.Restore(p5) then
		return false
	end

	if p5:GetAttribute("LazyPreloaded") == true then
		return true
	end

	local v13 = pcall(function()
		contentProvider:PreloadAsync({ p5 })
	end)

	if v13 then
		p5:SetAttribute("LazyPreloaded", true)
	end

	return v13
end
function module.GetDuration(p6, p7)
	if not p6 or not p6:IsA("Sound") then
		return p7 or 3
	end

	if p6.TimeLength and p6.TimeLength > 0 then
		local v16 = p6.PlaybackSpeed

		if typeof(v16) ~= "number" or v16 <= 0 then
			v16 = 1
		end

		return p6.TimeLength / v16
	end

	return p7 or 4
end
function module.Play(p8, p9)
	if not p8 or not p8:IsA("Sound") then
		return false
	end

	if p9 then
		module.Preload(p8)
	elseif not module.Restore(p8) then
		return false
	end

	p8:Play()

	if p8:GetAttribute("LazyClearAfterPlay") == true then
		local v19 = os.clock()

		p8:SetAttribute("LazyLastPlayId", v19)

		local u20: boolean = false

		p8.Ended:Once(function()
			if u20 then
				return
			end

			u20 = true
			task.delay(0.25, function()
				if p8 and p8.Parent and p8:GetAttribute("LazyLastPlayId") == v19 and not p8.Playing then
					module.Clear(p8)
				end
			end)
		end)
	end

	return true
end

return module
