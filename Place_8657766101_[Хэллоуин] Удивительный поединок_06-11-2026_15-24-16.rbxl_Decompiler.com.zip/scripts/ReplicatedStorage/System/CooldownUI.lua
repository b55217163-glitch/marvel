-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local module: {[any]: any} = {}
local object = setmetatable({}, { __mode = "k" })
local u5: boolean = false
local t2: {[any]: any} = {}

local function getSyncKey(p1, p2)
	local text: string = tostring(p1 or "")
	local text2: string = tostring(p2 or "")

	return text .. ":" .. text2
end
local function getRemainingWholeSeconds(p3)
	local v21 = os.clock()
	local roundedUp = math.ceil(p3 - v21)

	return (math.max(0, roundedUp))
end

local t3: {[any]: any} = {
	MoveOne = { TextLabel = "OneMove", CooldownImage = "Onecd" },
	MoveTwo = { TextLabel = "TwoMove", CooldownImage = "Twocd" },
	MoveThree = { TextLabel = "ThreeMove", CooldownImage = "Threecd" },
	MoveFour = { TextLabel = "FourMove", CooldownImage = "Fourcd" },
	MoveFive = { TextLabel = "FiveMove", CooldownImage = "Fivecd" },
	MoveFiveMrKnight = { TextLabel = "FiveMove", CooldownImage = "Fivecd" },
	SpecialMove = { TextLabel = "Emove", CooldownImage = "Ecd" },
	SpecialMoveCompoundV = { TextLabel = "Emove", CooldownImage = "Ecd" },
	MoveFourRage = { TextLabel = "FourMove", CooldownImage = "Fourcd" }
}

local function findCooldownTargets(p4)
	local LocalPlayer: Player = players.LocalPlayer
	local playerGui = LocalPlayer and LocalPlayer:FindFirstChild("PlayerGui")
	local v26 = playerGui

	if v26 then
		v26 = playerGui:FindFirstChild("Moveset")
	end

	local frame = v26 and v26:FindFirstChild("Frame")

	v26 = frame

	if v26 then
		v26 = frame:FindFirstChild("Hold")
	end

	local v28 = t3[p4]

	if v26 and v28 then
		return v26:FindFirstChild(v28.TextLabel), v26:FindFirstChild(v28.CooldownImage)
	end

	return nil, nil
end
local function getOrCreateCountdownLabel(p5, parent, p7)
	if not parent then
		return nil
	end

	local cooldownCountdown = parent:FindFirstChild("CooldownCountdown")

	if not cooldownCountdown then
		cooldownCountdown = Instance.new("TextLabel")
		cooldownCountdown.Name = "CooldownCountdown"
		cooldownCountdown.BackgroundTransparency = 1
		cooldownCountdown.BorderSizePixel = 0
		cooldownCountdown.AnchorPoint = Vector2.new(0.5, 0.5)
		cooldownCountdown.Position = UDim2.fromScale(0.5, 0.5)
		cooldownCountdown.Size = UDim2.fromScale(0.72, 0.72)
		cooldownCountdown.TextXAlignment = Enum.TextXAlignment.Center
		cooldownCountdown.TextYAlignment = Enum.TextYAlignment.Center
		cooldownCountdown.TextColor3 = Color3.new(1, 1, 1)
		cooldownCountdown.TextStrokeColor3 = Color3.new(0, 0, 0)
		cooldownCountdown.TextStrokeTransparency = 0
		cooldownCountdown.TextScaled = true
		cooldownCountdown.Visible = false
		cooldownCountdown.Parent = parent

		local cooldownTextSizeConstraint: UITextSizeConstraint = Instance.new("UITextSizeConstraint")

		cooldownTextSizeConstraint.Name = "CooldownTextSizeConstraint"
		cooldownTextSizeConstraint.MinTextSize = 8
		cooldownTextSizeConstraint.MaxTextSize = p7 or 16
		cooldownTextSizeConstraint.Parent = cooldownCountdown
	end

	if p5 then
		cooldownCountdown.FontFace = p5.FontFace
		cooldownCountdown.TextColor3 = p5.TextColor3
		cooldownCountdown.TextStrokeColor3 = p5.TextStrokeColor3
		cooldownCountdown.TextStrokeTransparency = p5.TextStrokeTransparency
	end

	local cooldownTextSizeConstraint = cooldownCountdown:FindFirstChild("CooldownTextSizeConstraint")

	if cooldownTextSizeConstraint then
		cooldownTextSizeConstraint.MaxTextSize = p7 or 16
	end

	cooldownCountdown.ZIndex = math.max(parent.ZIndex + 1, p5 and p5.ZIndex + 1 or parent.ZIndex + 1)

	return cooldownCountdown
end
local function finishCooldown(p8, p9, p10)
	if p9 ~= object[p8] then
		return
	end

	if p10 ~= p9.Token then
		return
	end

	if p9.Finished then
		return
	end

	p9.Finished = true

	if p9.CooldownImage then
		p9.CooldownImage.ImageTransparency = 1
	end

	if p9.CountdownLabel then
		p9.CountdownLabel.Text = ""
		p9.CountdownLabel.Visible = false
	end

	object[p8] = nil

	if type(p9.OnFinished) == "function" then
		p9.OnFinished()
	end
end
local function isBatmanBeltAbility(p11, p12)
	local u40: boolean = false

	if p11 == "TheBatman" then
		u40 = true

		if p12 ~= "MoveFour" then
			u40 = true

			if p12 ~= "MoveFourStickyBomb" then
				u40 = p12 == "MoveFourAdShot"
			end
		end
	end

	return u40
end
local function applyServerCooldown(p13, p14, p15, p16)
	local u45: boolean = false

	if p13 == "TheBatman" then
		u45 = true

		if p14 ~= "MoveFour" then
			u45 = true

			if p14 ~= "MoveFourStickyBomb" then
				u45 = p14 == "MoveFourAdShot"
			end
		end
	end

	if u45 then
		return false
	end

	local numberValue: number? = tonumber(p15)
	local v47 = math.max(0, numberValue or 0)

	if v47 <= 0 then
		return false
	end

	local v48, v49 = findCooldownTargets(p14)

	if not v48 then
		local text: string = tostring(p13 or "")
		local text3: string = tostring(p14 or "")
		local v52 = os.clock()

		t2[text .. ":" .. text3] = { Duration = v47, ReceivedAt = v52, Status = p16 }

		return false
	end

	module.Start({
		TextLabel = v48,
		CooldownImage = v49,
		Duration = v47,
		CharacterName = p13,
		AbilityName = p14
	})

	return true
end
local function consumePendingSync(p21, p22)
	local text: string = tostring(p21 or "")
	local text4: string = tostring(p22 or "")
	local s1: string = text .. ":" .. text4
	local v58 = t2[s1]

	if not v58 then
		return nil
	end

	t2[s1] = nil

	local v59 = os.clock()

	v59 = math.max(0, v58.Duration - (v59 - v58.ReceivedAt))

	if v59 <= 0 then
		return nil
	end

	return v59
end
function module.Start(p23)
	if type(p23) == "table" then
		local textLabel = p23.TextLabel
		local cooldownImage = p23.CooldownImage
		local numberValue: number? = tonumber(p23.Duration)
		local v64 = math.max(0, numberValue or 0)
		local abilityName = p23.AbilityName
		local text: string = tostring(p23.CharacterName or "")
		local text5: string = tostring(abilityName or "")
		local s1: string = text .. ":" .. text5
		local v69 = t2[s1]
		local v70

		if not v69 then
			v70 = nil
		else
			t2[s1] = nil

			local v71 = os.clock()

			v71 = math.max(0, v69.Duration - (v71 - v69.ReceivedAt))
			v70 = if v71 <= 0 then nil else v71
		end

		if v70 and v64 < v70 then
			v64 = v70
		end

		local LocalPlayer: Player = players.LocalPlayer

		if LocalPlayer and LocalPlayer:GetAttribute("NoCooldown") == true then
			v64 = 0
		end

		local onFinished = p23.OnFinished
		local numberValue2: number? = tonumber(p23.CountdownTextSize)

		if not textLabel then
			return
		end

		local t4 = object[textLabel]
		local v76 = t4 and t4.OnFinished

		if not t4 then
			t4 = { Token = 0, OriginalText = textLabel.Text }
			object[textLabel] = t4
		end

		t4.Token = t4.Token + 1
		t4.Finished = false
		t4.EndTime = os.clock() + v64
		t4.OnFinished = onFinished or v76
		t4.CooldownImage = cooldownImage
		t4.CountdownLabel = getOrCreateCountdownLabel(textLabel, cooldownImage, numberValue2 or 14)

		local token = t4.Token

		if cooldownImage then
			cooldownImage.ImageTransparency = 0.5
		end

		if t4.CountdownLabel then
			local countdownLabel = t4.CountdownLabel
			local endTime = t4.EndTime
			local v80 = os.clock()
			local roundedUp = math.ceil(endTime - v80)
			local v82 = math.max(0, roundedUp)

			countdownLabel.Text = tostring(v82)
			t4.CountdownLabel.Visible = true
		end

		task.spawn(function()
			while object[textLabel] == t4 and t4.Token == token and not t4.Finished and not (t4.EndTime - os.clock() <= 0) do
				if t4.CountdownLabel then
					local countdownLabel = t4.CountdownLabel
					local endTime = t4.EndTime
					local v111 = os.clock()
					local roundedUp = math.ceil(endTime - v111)
					local v113 = math.max(0, roundedUp)

					countdownLabel.Text = tostring(v113)
				end

				task.wait(0.1)
			end

			finishCooldown(textLabel, t4, token)
		end)

		return
	end
end
function module.ReduceAll(p24)
	local numberValue: number? = tonumber(p24)
	local v85 = math.max(0, numberValue or 0)

	if v85 <= 0 then
		return 0
	end

	local n1: number = 0
	local t5: {[any]: any} = {}

	for k, v in pairs(object) do
		if k and k.Parent and v and not v.Finished then
			v.EndTime = v.EndTime - v85
			n1 += 1

			local vEndTime = v.EndTime
			local v91 = os.clock()

			if vEndTime <= v91 then
				table.insert(t5, { TextLabel = k, State = v, Token = v.Token })
			elseif v.CountdownLabel then
				local vCountdownLabel = v.CountdownLabel
				local endTime = v.EndTime
				local v94 = os.clock()
				local roundedUp = math.ceil(endTime - v94)
				local v96 = math.max(0, roundedUp)

				vCountdownLabel.Text = tostring(v96)
			end
		end
	end

	for _, v in ipairs(t5) do
		finishCooldown(v.TextLabel, v.State, v.Token)
	end

	return n1
end
function module.FinishAll()
	local t6: {[any]: any} = {}

	for k, v in pairs(object) do
		if v and not v.Finished then
			table.insert(t6, { TextLabel = k, State = v, Token = v.Token })
		end
	end

	for _, v in ipairs(t6) do
		finishCooldown(v.TextLabel, v.State, v.Token)
	end

	return #t6
end
function module.IsNoCooldownEnabled()
	local LocalPlayer: Player = players.LocalPlayer

	return LocalPlayer ~= nil and LocalPlayer:GetAttribute("NoCooldown") == true
end
function module.SetOverlay(p25, p26)
	if not p25 then
		return
	end

	p25.ImageTransparency = if p26 then 0.5 else 1
end;

(function()
	if u5 then
		return
	end

	u5 = true

	local system: Instance = replicatedStorage:FindFirstChild("System")
	local cooldownSync: Instance = system and system:FindFirstChild("CooldownSync")

	if not cooldownSync or not cooldownSync:IsA("RemoteEvent") then
		return
	end

	cooldownSync.OnClientEvent:Connect(function(p17, p18, p19, p20)
		applyServerCooldown(p17, p18, p19, p20)
	end)
end)()

return module
