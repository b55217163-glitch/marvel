-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")

local function getAssetsRoot()
	local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")

	return uiAssets and uiAssets:FindFirstChild("CharacterSpecialAssets")
end
local function getOrCreateCharacterSpecial(parent)
	local characterSpecial = parent:FindFirstChild("CharacterSpecial")

	if characterSpecial and characterSpecial:IsA("ScreenGui") then
		return characterSpecial
	end

	local parentCharacterSpecial = parent:WaitForChild("CharacterSpecial", 2)

	if parentCharacterSpecial and parentCharacterSpecial:IsA("ScreenGui") then
		return parentCharacterSpecial
	end

	local characterSpecial2: Instance = game:GetService("StarterGui"):FindFirstChild("CharacterSpecial")

	if characterSpecial2 and characterSpecial2:IsA("ScreenGui") then
		local clone: Instance = characterSpecial2:Clone()

		clone.Parent = parent

		return clone
	end

	local characterSpecial: ScreenGui = Instance.new("ScreenGui")

	characterSpecial.Name = "CharacterSpecial"
	characterSpecial.ResetOnSpawn = false
	characterSpecial.IgnoreGuiInset = true
	characterSpecial.Parent = parent

	return characterSpecial
end

return {
	Ensure = function(p2, p3)
		if p2 and typeof(p3) == "string" and p3 ~= "" then
			local v13 = p2:FindFirstChild("PlayerGui") or p2:WaitForChild("PlayerGui", 8)

			if not v13 then
				return nil
			end

			local parent = getOrCreateCharacterSpecial(v13)

			if not parent then
				return nil
			end

			local foundChild = parent:FindFirstChild(p3)

			if foundChild then
				return foundChild
			end

			local uiAssets: Instance = replicatedStorage:FindFirstChild("UIAssets")

			v13 = uiAssets

			if v13 then
				v13 = uiAssets:FindFirstChild("CharacterSpecialAssets")
			end

			local v17 = v13 and v13:FindFirstChild(p3)

			if not v17 then
				return nil
			end

			local clone = v17:Clone()

			clone.Parent = parent

			return clone
		end

		return nil
	end
}
