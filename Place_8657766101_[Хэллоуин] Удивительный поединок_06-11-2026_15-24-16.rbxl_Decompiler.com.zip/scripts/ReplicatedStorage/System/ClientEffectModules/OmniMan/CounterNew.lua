-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local slamdown = replicatedStorage.Characters.OmniMan.Remotes.Slamdown
		local effects: Instance = workspace:WaitForChild("Effects")
		local rock = replicatedStorage.Characters.Physics:WaitForChild("Rock")
		local flightStop = replicatedStorage.Characters.OmniMan.Fx.FlightStop
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function makeMapRayParams()
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace:WaitForChild("Map") }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function getGroundHit(p1)
			local v23 = makeMapRayParams()

			return workspace:Raycast(p1 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v23)
		end
		local function cloneSurfaceLook(p2, parent)
			for _, v in ipairs(p2:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("ParticleEmitter")) then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeAndShrinkRock(p4, p5, p6)
			task.delay(p5, function()
				if not p4 or not p4.Parent then
					return
				end

				for _, v in ipairs(p4:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v109 = tweenInfoNew(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

						tweenService:Create(v, v109, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local v110 = tweenInfoNew(p6, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

				tweenService:Create(p4, v110, { Size = Vector3.new(0, 0, 0) }):Play()
			end)
		end
		local function emitSmokeAt(p7, p8, p9)
			local clone = flightStop:Clone()

			clone.Parent = effects

			if clone:IsA("BasePart") then
				clone.CFrame = CFrame.new(p7)
				clone.Anchored = true
				clone.CanCollide = false
				clone.CanTouch = false
			end

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					if p8 then
						v.Color = ColorSequence.new(p8)
					end

					local t1: {[any]: any} = {}

					for _, iterValue in ipairs(v.Size.Keypoints) do
						table.insert(t1, NumberSequenceKeypoint.new(iterValue.Time, iterValue.Value * (p9 or 1), iterValue.Envelope))
					end

					v.Size = NumberSequence.new(t1)
					v:Emit(2)
				elseif v:IsA("BasePart") then
					v.CanCollide = false
					v.CanTouch = false
					v.Anchored = true
				end
			end

			debris:AddItem(clone, 5)
		end
		local function makeRockFromHit(p10, p11)
			local impactRock: Part = Instance.new("Part")

			impactRock.Name = "ImpactRock"
			impactRock.Anchored = true
			impactRock.CanCollide = false
			impactRock.CanTouch = false
			impactRock.CastShadow = true
			impactRock.Material = p10.Material
			impactRock.Color = p10.Color
			impactRock.Size = p11
			cloneSurfaceLook(p10, impactRock)

			return impactRock
		end
		local function launchSideShard(p12, p13, p14, p15, p16, p17, p18, p19, p20)
			local clone = rock:Clone()

			clone.Parent = effects
			clone.Material = p13.Material
			clone.Color = p13.Color
			clone.CanCollide = false
			clone.CanTouch = false

			if clone:FindFirstChild("Trail") then
				clone.Trail.Color = ColorSequence.new(p13.Color)
			end

			local n1 = mathRandom(p19 * 10, p20 * 10) / 10

			if clone:IsA("BasePart") then
				clone.Size = Vector3.new(n1, n1, n1)

				local cFrame = CFrame.new(p12)
				local cFrameAngles = CFrame.Angles
				local v57 = mathRandom(-180, 180)
				local v58 = math.rad(v57)
				local v59 = mathRandom(-180, 180)

				v57 = math.rad(v59)

				local v60 = mathRandom(-180, 180)

				v59 = math.rad(v60)

				local v61 = cFrameAngles(v58, v57, v59)

				clone.CFrame = cFrame * v61
			end

			n1 = mathRandom(p17, p18)

			local v62 = mathRandom(p15 * 100, p16 * 100)
			local v63 = mathRandom(-30, 30)
			local v64 = mathRandom(-30, 30)
			local vector3 = Vector3.new(v63 / 100, v62 / 100, v64 / 100)
			local unit = (p14 + vector3).Unit
			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)
			bodyVelocity.Velocity = unit * n1
			bodyVelocity.Parent = clone
			debris:AddItem(bodyVelocity, 0.18)
			debris:AddItem(clone, 2.5)
		end
		local function spawnGroundChunk(p21, p22, p23, p24, p25, p26)
			local v74 = mathRandom(p24 * 10, p25 * 10)
			local v75 = mathRandom(p24 * 10, p25 * 10)
			local v76 = mathRandom(p24 * 10, p25 * 10)
			local vector3 = Vector3.new(v74 / 10, v75 / 10, v76 / 10)
			local impactRock: Part = Instance.new("Part")

			impactRock.Name = "ImpactRock"
			impactRock.Anchored = true
			impactRock.CanCollide = false
			impactRock.CanTouch = false
			impactRock.CastShadow = true
			impactRock.Material = p21.Material
			impactRock.Color = p21.Color
			impactRock.Size = vector3
			cloneSurfaceLook(p21, impactRock)

			local cFrameNew = CFrame.new
			local vector32 = Vector3.new(0, p23, 0)
			local cFrame = cFrameNew(p22 + vector32)
			local cFrameAngles = CFrame.Angles
			local v83 = mathRandom(-180, 180)
			local v84 = math.rad(v83)
			local v85 = mathRandom(-180, 180)

			v83 = math.rad(v85)

			local v86 = mathRandom(-180, 180)

			v85 = math.rad(v86)

			local v87 = cFrameAngles(v84, v83, v85)

			impactRock.CFrame = cFrame * v87
			impactRock.Parent = effects
			v84 = tweenInfoNew(0.16, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			tweenService:Create(impactRock, v84, { Position = p22 }):Play()

			local n1: number = 0.45

			task.delay(p26, function()
				if not impactRock or not impactRock.Parent then
					return
				end

				for _, v in ipairs(impactRock:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v113 = tweenInfoNew(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

						tweenService:Create(v, v113, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local v114 = tweenInfoNew(n1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

				tweenService:Create(impactRock, v114, { Size = Vector3.new(0, 0, 0) }):Play()
			end)
			debris:AddItem(impactRock, p26 + 1)
		end
		local function spawnPunchCorridor(p27)
			local lookVector = p27.CFrame.LookVector
			local rightVector = p27.CFrame.RightVector
			local v92 = p27.Position
			local v93 = makeMapRayParams()
			local v94 = workspace:Raycast(v92 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v93)

			if not v94 or not v94.Instance or not v94.Instance:IsA("BasePart") then
				return
			end

			local InstanceColor = v94.Instance.Color

			for i = 1, 12 do
				task.delay((i - 1) * 0.02, function()
					local n1: number = (i - 1) / 11
					local n2 = p27.Position + lookVector * (i * 3.8 + 2.5)
					local v117 = makeMapRayParams()
					local v118 = workspace:Raycast(n2 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v117)

					if not v118 or not v118.Instance or not v118.Instance:IsA("BasePart") then
						return
					end

					v117 = v118.Instance

					local v119 = v118.Position

					for _ = 1, math.floor(n1 * 2) + 1 do
						local v121 = mathRandom(-5, 5)
						local v122 = mathRandom(-2, 2)

						spawnGroundChunk(v117, v119 + (rightVector * (v121 / 10) + lookVector * (v122 / 10)), n1 * 3 + 1.5, n1 * 1.1 + 0.8, n1 * 2.4 + 1.4, 2.4)
					end

					for i2 = -1, 1, 2 do
						local n3 = rightVector * i2
						local n4 = math.floor(n1 * 2) + 2

						for j = 1, n4 do
							local n5 = j / n4
							local v128 = mathRandom(-3, 3)
							local v129 = mathRandom(-3, 3)
							local v130 = makeMapRayParams()
							local v131 = workspace:Raycast(n2 + n3 * (n5 * (n1 * 13 + 1.5)) + lookVector * (n5 * (n1 * 7.5 + 1.2)) + rightVector * (v128 / 10) + lookVector * (v129 / 10) + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v130)

							if v131 and v131.Instance and v131.Instance:IsA("BasePart") then
								local instance = v131.Instance
								local v133 = v131.Position

								spawnGroundChunk(instance, v133, n1 * 3.8 + 1.2, n1 * 1.4 + 1, n1 * 3.6 + 1.8, 2.6)

								if not (n1 > 0.25) then
									continue
								end

								local vector3 = Vector3.new(0, n1 * 0.5 + 0.4, 0)
								local floored = math.floor(n1 * 18)
								local floored2 = math.floor(n1 * 28)

								launchSideShard(v133 + vector3, instance, n3 * (n1 * 1.2 + 1) + lookVector * (n1 * 0.9 + 0.2), n1 * 0.3 + 0.7, n1 * 0.6 + 1.1, floored + 30, floored2 + 50, n1 * 0.5 + 0.6, n1 * 1.3 + 1.2)
							end
						end
					end

					if i % 3 == 0 then
						emitSmokeAt(v119 - Vector3.new(0, 2, 0), InstanceColor, n1 * 1.8 + 0.9)
					end
				end)
			end

			for i = -1, 1, 2 do
				for _ = 1, 3 do
					local v99 = p27.Position
					local v100 = mathRandom(8, 14)
					local v101 = makeMapRayParams()
					local v102 = workspace:Raycast(v99 + rightVector * i * v100 / 10 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v101)

					if v102 and v102.Instance and v102.Instance:IsA("BasePart") then
						launchSideShard(v102.Position + Vector3.new(0, 0.8, 0), v102.Instance, rightVector * i * 1.1 + lookVector * 0.06, 0.7, 1, 28, 45, 0.7, 1.2)
					end
				end
			end

			task.delay(0.05, function()
				emitSmokeAt(p27.Position + lookVector * 18 - Vector3.new(0, 2.5, 0), InstanceColor, 1.5)
			end)
			task.delay(0.1, function()
				emitSmokeAt(p27.Position + lookVector * 32 - Vector3.new(0, 2.5, 0), InstanceColor, 2.4)
			end)
		end

		slamdown.OnClientEvent:Connect(function(player, _)
			local character = player and player.Character

			if not character then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			spawnPunchCorridor(humanoidRootPart)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.CounterNew", result)
	end
end)

return true
