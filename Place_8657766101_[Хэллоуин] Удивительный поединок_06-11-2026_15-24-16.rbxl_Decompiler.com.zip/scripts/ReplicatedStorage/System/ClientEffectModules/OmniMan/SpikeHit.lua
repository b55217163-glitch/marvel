-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local spikeHit = replicatedStorage.Characters.OmniMan.Fx.SpikeHit

		local function getWeaponColorAndMaterial(p1, p2)
			if p2 == "Hammer" then
				local hammer = p1:FindFirstChild("Hammer")

				if hammer and hammer:IsA("BasePart") then
					return hammer.Color, hammer.Material
				end
			else
				local spike = p1:FindFirstChild("Spike")

				if spike and spike:IsA("BasePart") then
					return spike.Color, spike.Material
				end
			end

			return Color3.new(1, 1, 1), Enum.Material.SmoothPlastic
		end

		replicatedStorage.Characters.OmniMan.Remotes.SpikeHit.OnClientEvent:Connect(function(p3, parent, p5)
			local v15 = p5 or "Spike"

			if p3 and parent then
				if not parent:FindFirstChild("UpperTorso") then
					return
				end

				local clone = spikeHit:Clone()

				clone.Parent = parent

				local v17, v18 = getWeaponColorAndMaterial(p3, v15)

				if clone:FindFirstChild("Spike") then
					clone.Spike.Color = v17
					clone.Spike.Material = v18

					if v15 == "Hammer" then
						clone.Spike.Transparency = 1
					else
						clone.Spike.Transparency = 0

						local trail = clone.Spike:FindFirstChild("Trail")

						if trail then
							trail.Enabled = false
						end
					end
				end

				debris:AddItem(clone, 3)
				clone.FUpperTorso.HitAt.Shock:Emit(1)
				clone.FUpperTorso.HitAt.ShockwaveMiddle:Emit(1)
				clone.FUpperTorso.HitAt.SparksCircle:Emit(8)

				local motor6D: Motor6D = Instance.new("Motor6D")

				motor6D.Parent = parent
				motor6D.Part0 = parent.UpperTorso
				motor6D.Part1 = clone.FUpperTorso
				motor6D.C0 = CFrame.new(0, 0, 0)
				clone.FUpperTorso.LowAt.Bl2:Emit(100)
				clone.FUpperTorso.LowAt.Blood:Emit(100)
				clone.FUpperTorso.LowAt.Blood2:Emit(100)
				clone.FUpperTorso.LowAt.Shockwave:Emit(1)

				local blood1 = clone.FUpperTorso:FindFirstChild("Blood1")
				local blood0 = clone.FUpperTorso:FindFirstChild("Blood0")

				if blood1 then
					blood1.Parent = parent.UpperTorso
				end

				if blood0 then
					blood0.Parent = parent.UpperTorso
				end

				if v15 == "Hammer" then
					local v23 = p3:FindFirstChild("Hammer") and p3.Hammer:FindFirstChild("Trail")

					if v23 then
						v23.Enabled = false
					end
				elseif p3:FindFirstChild("Spike") then
					p3.Spike.Transparency = 1

					local trail = p3.Spike:FindFirstChild("Trail")

					if trail then
						trail.Enabled = false
					end
				end

				local clone2 = nil

				if p3:FindFirstChild("Head") then
					if v15 == "Hammer" and p3.Head:FindFirstChild("HammerHit") then
						clone2 = p3.Head.HammerHit:Clone()
					elseif p3.Head:FindFirstChild("SpikeHit") then
						clone2 = p3.Head.SpikeHit:Clone()
					end
				end

				if clone2 then
					clone2.Parent = parent.UpperTorso
					clone2:Play()
					debris:AddItem(clone2, 4)
				end

				task.wait(1.5)

				if motor6D then
					motor6D:Destroy()
				end

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.Parent = clone.FUpperTorso
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)
				bodyVelocity.Velocity = Vector3.new(-30, 0, 0)
				debris:AddItem(bodyVelocity, 0.15)
				clone.FUpperTorso.LowAt.Bl2:Emit(50)
				clone.FUpperTorso.LowAt.Blood:Emit(50)
				clone.FUpperTorso.LowAt.Blood2:Emit(50)

				if blood1 then
					debris:AddItem(blood1, 6)
					tweenService:Create(blood1, TweenInfo.new(6), { Transparency = 1 }):Play()
				end

				if blood0 then
					debris:AddItem(blood0, 6)
					tweenService:Create(blood0, TweenInfo.new(6), { Transparency = 1 }):Play()
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.SpikeHit", result)
	end
end)

return true
