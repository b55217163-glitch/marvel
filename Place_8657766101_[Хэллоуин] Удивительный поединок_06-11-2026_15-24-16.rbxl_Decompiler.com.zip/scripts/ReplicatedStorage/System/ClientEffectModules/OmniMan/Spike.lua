-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.5)

		local debris: Debris = game:GetService("Debris")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local spike = replicatedStorage.Characters.OmniMan.Remotes.Spike
		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function Math(p1, p2, p3)
			return p1 + (p2 - p1) * p3
		end
		local function getWeapon(p4, p5)
			if p5 == "Hammer" then
				return p4:FindFirstChild("Hammer")
			end

			return p4:FindFirstChild("Spike")
		end
		local function fadeOutDroppedWeapon(p6)
			task.delay(6, function()
				if not p6 or not p6.Parent then
					return
				end

				for _, v in ipairs(p6:GetDescendants()) do
					if v:IsA("BasePart") then
						tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
					elseif not v:IsA("Decal") and not v:IsA("Texture") then
						if v:IsA("Trail") or v:IsA("ParticleEmitter") then
							v.Enabled = false
						end
					else
						tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
					end
				end

				debris:AddItem(p6, 1.2)
			end)
		end
		local function dropMissWeapon(p7, p8)
			local v27 = if p8 == "Hammer" then p7:FindFirstChild("Hammer") else p7:FindFirstChild("Spike")

			if not v27 then
				return
			end

			local clone = v27:Clone()

			clone.Name = p8 .. "_Dropped"

			for _, v in ipairs(clone:GetDescendants()) do
				if not v:IsA("Script") and not v:IsA("LocalScript") then
					if v:IsA("Trail") or v:IsA("ParticleEmitter") then
						v.Enabled = false
					elseif v:IsA("Sound") then
						v:Stop()
					elseif v:IsA("Weld") or v:IsA("Motor6D") or v:IsA("WeldConstraint") then
						v:Destroy()
					end
				else
					v:Destroy()
				end
			end

			if clone:IsA("BasePart") then
				clone.CFrame = v27.CFrame
				clone.Transparency = 0
				clone.Anchored = false
				clone.CanCollide = true
				clone.CanTouch = false
				clone.Massless = false
				clone.Parent = workspace.Effects

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

				local lookVector = v27.CFrame.LookVector
				local v33 = mathRandom(8, 14)

				bodyVelocity.Velocity = lookVector * v33 + v27.CFrame.UpVector * 2 + Vector3.new(0, -8, 0)
				bodyVelocity.Parent = clone
				debris:AddItem(bodyVelocity, 0.15)

				local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

				bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

				local v35 = mathRandom(-8, 8)
				local v36 = math.rad(v35)
				local v37 = mathRandom(-12, 12)

				v35 = math.rad(v37)
				v33 = mathRandom(-8, 8)
				v37 = math.rad(v33)
				bodyAngularVelocity.AngularVelocity = Vector3.new(v36, v35, v37)
				bodyAngularVelocity.Parent = clone
				debris:AddItem(bodyAngularVelocity, 0.2)
				task.delay(6, function()
					if not clone or not clone.Parent then
						return
					end

					for _, v in ipairs(clone:GetDescendants()) do
						if v:IsA("BasePart") then
							tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
						elseif not v:IsA("Decal") and not v:IsA("Texture") then
							if v:IsA("Trail") or v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						else
							tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
						end
					end

					debris:AddItem(clone, 1.2)
				end)

				return
			end

			local parent = clone.PrimaryPart or clone:FindFirstChildWhichIsA("BasePart")

			if not parent then
				clone:Destroy()

				return
			end

			if not clone.PrimaryPart then
				clone.PrimaryPart = parent
			end

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("BasePart") then
					v.Anchored = false
					v.CanCollide = true
					v.CanTouch = false
					v.Massless = false
					v.Transparency = 0
				end
			end

			clone:PivotTo(v27.CFrame)
			clone.Parent = workspace.Effects

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

			local v42 = v27.CFrame.LookVector
			local v43 = mathRandom(8, 14)

			bodyVelocity.Velocity = v42 * v43 + v27.CFrame.UpVector * 2 + Vector3.new(0, -8, 0)
			bodyVelocity.Parent = parent
			debris:AddItem(bodyVelocity, 0.15)

			local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

			bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

			local v45 = mathRandom(-8, 8)
			local v46 = math.rad(v45)
			local v47 = mathRandom(-12, 12)

			v45 = math.rad(v47)
			v43 = mathRandom(-8, 8)
			v47 = math.rad(v43)
			bodyAngularVelocity.AngularVelocity = Vector3.new(v46, v45, v47)
			bodyAngularVelocity.Parent = parent
			debris:AddItem(bodyAngularVelocity, 0.2)
			task.delay(6, function()
				if not clone or not clone.Parent then
					return
				end

				for _, v in ipairs(clone:GetDescendants()) do
					if v:IsA("BasePart") then
						tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
					elseif not v:IsA("Decal") and not v:IsA("Texture") then
						if v:IsA("Trail") or v:IsA("ParticleEmitter") then
							v.Enabled = false
						end
					else
						tweenService:Create(v, TweenInfo.new(1), { Transparency = 1 }):Play()
					end
				end

				debris:AddItem(clone, 1.2)
			end)
		end
		local function showWeapon(p9, p10, p11, material, p13)
			local v53 = if p10 == "Hammer" then p9:FindFirstChild("Hammer") else p9:FindFirstChild("Spike")

			if not v53 then
				return
			end

			if p11 then
				v53.Color = p11
			end

			if material then
				v53.Material = material
			end

			v53.Transparency = 0

			local trail = v53:FindFirstChild("Trail")

			if trail then
				trail.Enabled = true
			end

			task.delay(1, function()
				if not v53 or not v53.Parent then
					return
				end

				v53.Transparency = 1

				local trail2 = v53:FindFirstChild("Trail")

				if trail2 then
					trail2.Enabled = false
				end

				if p13 then
					dropMissWeapon(p9, p10)
				end
			end)
		end
		local function RockSpawn(p14, p15: number, p16, parent, p18, p19, p20)
			if p15 > 180 or p15 < 0 then
				warn("Too high or low of a number!")
				p15 = 15
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p15 do
				local v65 = p14.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v67 = math.rad(n1)
				local v68 = cFrameFromEulerAnglesXYZ(0, v67, 0)
				local cFrame = CFrame.new(0, 0, p18)
				local n2 = v65 * v68 * cFrame.Position
				local v71 = p14.CFrame
				local v72 = CFrame.fromEulerAnglesXYZ
				local v73 = math.rad(n1)
				local v74 = v72(0, v73, 0)
				local cFrame2 = CFrame.new(0, 0, -p18 / 1.25)
				local n3 = v71 * v74 * cFrame2.Position
				local vector3 = Vector3.new(0, -p18, 0)
				local v78 = workspace:Raycast(n2, n3 + vector3 - n2, raycastParams)

				n1 += p15

				if v78 then
					local instance = v78.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local cFrame3 = CFrame.new(v78.Position, p14.Position)
					local cFrameAngles = CFrame.Angles
					local v83 = mathRandom(-3.141592653589793, 3.141592653589793)
					local v84 = cFrameAngles(v83, 0, 0)
					local v85 = p14.Position
					local n4 = v85 + (v78.Position - v85) * 0.2
					local magnitude = (p14.Position - v78.Position).Magnitude

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.CFrame = CFrame.new(n4, p14.Position)
					debris:AddItem(part, 5)

					for _, v in pairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					if p20 == true then
						local v91 = mathRandom(p16.Min, p16.Max)
						local v92 = mathRandom(p16.Min, p16.Max)

						part.Size = Vector3.new(v91, v92, mathRandom(p16.Min, p16.Max))
					else
						part.Size = p16
					end

					if p19 == true then
						local v93 = mathRandom(-180, 180)
						local v94 = mathRandom(-180, 180)

						part.Orientation = Vector3.new(v93, v94, mathRandom(-180, 180))

						local v95 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService:Create(part, v95, { Position = v78.Position }):Play()
					elseif p19 == false then
						local v96 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local cFrame4 = CFrame.new(v78.Position, p14.Position)

						tweenService:Create(part, v96, { CFrame = cFrame4 }):Play()
					elseif p19 == "Middle" then
						local v98 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService:Create(part, v98, { CFrame = cFrame3 * v84 }):Play()
					end

					part.Parent = parent
					task.delay(4, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v119 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v119, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v120 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v120, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
					end)
				end
			end
		end

		local lungeCrack = replicatedStorage.Characters.Gigachad.Fx.LungeCrack
		local smoke = replicatedStorage.Characters.Gigachad.Fx.Smoke
		local rock = replicatedStorage.Characters.Gigachad.Fx.Rock
		local clap = replicatedStorage.Characters.OmniMan.Fx.ClapShock.Clap

		spike.OnClientEvent:Connect(function(player, p22)
			local v101 = if player:FindFirstChild("Humanoid") then player else player.Character

			if not v101 or not v101:FindFirstChild("HumanoidRootPart") then
				return
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			local v103 = workspace:Raycast(v101.HumanoidRootPart.Position, v101.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

			if (p22 or "Spike") == "Hammer" then
				if v101:FindFirstChild("Head") and v101.Head:FindFirstChild("SpikeAir") then
					v101.Head.SpikeAir:Play()
				end

				showWeapon(v101, "Hammer", nil, nil, true)

				return
			end

			if v103 == nil then
				if v101:FindFirstChild("Head") and v101.Head:FindFirstChild("SpikeAir") then
					v101.Head.SpikeAir:Play()
				end

				showWeapon(v101, "Spike", nil, nil, true)

				return
			end

			local instance = v103.Instance

			if not instance or not instance:IsA("BasePart") then
				return
			end

			local instanceColor = instance.Color
			local material = instance.Material
			local clone = lungeCrack:Clone()

			clone.Parent = workspace
			clone.Position = v103.Position

			local randomNumber = math.random(-180, 180)

			clone.Orientation = Vector3.new(0, randomNumber, 0)
			debris:AddItem(clone, 10)

			local clone2 = smoke:Clone()

			clone2.Parent = clone
			clone2.Color = ColorSequence.new(instanceColor)
			clone2:Emit(10)
			debris:AddItem(clone2, 7)

			local clone3 = rock:Clone()

			clone3.Parent = clone
			clone3.Color = ColorSequence.new(instanceColor)
			clone3:Emit(30)
			debris:AddItem(clone3, 7)

			if v101:FindFirstChild("Head") and v101.Head:FindFirstChild("Spike") then
				v101.Head.Spike:Play()
			end

			if clone:FindFirstChild("Decal") then
				tweenService:Create(clone.Decal, TweenInfo.new(5), { Transparency = 1 }):Play()
			end

			RockSpawn(v101.HumanoidRootPart, 30, NumberRange.new(0.5, 2), workspace.Effects, 7, false, true)

			local clone4 = clap:Clone()

			clone4.Parent = v101.HumanoidRootPart

			if clone4:FindFirstChild("Sparks") then
				clone4.Sparks:Emit(3)
			end

			debris:AddItem(clone4, 4)
			showWeapon(v101, "Spike", instanceColor, material, false)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.Spike", result)
	end
end)

return true
