-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local function playSound(p1, p2)
			local v9 = p1 and p1:FindFirstChild(p2)

			if v9 and v9:IsA("Sound") then
				v9:Play()
			end
		end
		local function emitEffect(p3, p4, p5, p6)
			local v14 = p3 and p3:FindFirstChild(p4)
			local v15 = v14 and v14:FindFirstChild(p5)

			if v15 and v15:IsA("ParticleEmitter") then
				v15:Emit(p6)
			end
		end
		local function setEmitterColor(p7, p8, p9, p10)
			local v20 = p7 and p7:FindFirstChild(p8)
			local v21 = v20 and v20:FindFirstChild(p9)

			if v21 and v21:IsA("ParticleEmitter") then
				v21.Color = ColorSequence.new(p10)
			end
		end
		local function getGroundColor(p11)
			local map: Instance = workspace:FindFirstChild("Map")

			if not map then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }

			local v25 = workspace:Raycast(p11.Position, p11.CFrame.UpVector * -6, raycastParams)

			if v25 and v25.Instance:IsA("BasePart") then
				return v25.Instance.Color
			end

			return nil
		end

		game:GetService("ReplicatedStorage"):WaitForChild("Characters"):WaitForChild("OmniMan"):WaitForChild("Remotes"):WaitForChild("Chop").OnClientEvent:Connect(function(player, p13)
			local Character = nil

			if p13 then
				Character = p13
			elseif player then
				Character = player.Character
			end

			if not Character then
				return
			end

			local fakeUpperTorso = Character:FindFirstChild("FakeUpperTorso")
			local head = Character:FindFirstChild("Head")

			if fakeUpperTorso and head then
				if not Character:FindFirstChild("Demogorgon") and not Character:FindFirstChild("BlackCat") then
					local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
					local v32 = humanoidRootPart

					if v32 then
						v32 = humanoidRootPart:FindFirstChild("Charge")
					end

					if v32 then
						local ring = v32:FindFirstChild("Ring")
						local ring2 = v32:FindFirstChild("Ring2")

						if ring and ring:IsA("ParticleEmitter") then
							ring:Emit(2)
						end

						if ring2 and ring2:IsA("ParticleEmitter") then
							ring2:Emit(2)
						end
					end

					v32 = head

					if v32 then
						v32 = head:FindFirstChild("Chop")
					end

					if v32 and v32:IsA("Sound") then
						v32:Play()
					end

					if math.random(1, 2) == 1 then
						local chop1 = head and head:FindFirstChild("Chop1")

						if chop1 and chop1:IsA("Sound") then
							chop1:Play()
						end
					else
						local chop2 = head and head:FindFirstChild("Chop2")

						if chop2 and chop2:IsA("Sound") then
							chop2:Play()
						end
					end

					task.wait(0.3)

					local v37 = getGroundColor(fakeUpperTorso)

					if v37 then
						local fakeUpperTorsoChop2 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
						local rock = fakeUpperTorsoChop2 and fakeUpperTorsoChop2:FindFirstChild("Rock")

						if rock and rock:IsA("ParticleEmitter") then
							rock.Color = ColorSequence.new(v37)
						end

						local v40 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
						local smoke = v40 and v40:FindFirstChild("Smoke")

						if smoke and smoke:IsA("ParticleEmitter") then
							smoke.Color = ColorSequence.new(v37)
						end
					end

					local chop = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop")
					local flare = chop and chop:FindFirstChild("Flare")

					if flare and flare:IsA("ParticleEmitter") then
						flare:Emit(5)
					end

					local fakeUpperTorsoChop = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop")
					local flare2 = fakeUpperTorsoChop and fakeUpperTorsoChop:FindFirstChild("Flare2")

					if flare2 and flare2:IsA("ParticleEmitter") then
						flare2:Emit(5)
					end

					if v37 then
						local v46 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
						local v47 = v46 and v46:FindFirstChild("Rock")

						if v47 and v47:IsA("ParticleEmitter") then
							v47:Emit(30)
						end

						local v48 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
						local v49 = v48 and v48:FindFirstChild("Smoke")

						if v49 and v49:IsA("ParticleEmitter") then
							v49:Emit(10)
						end
					end

					return
				end

				local moveOne = head and head:FindFirstChild("MoveOne")

				if moveOne and moveOne:IsA("Sound") then
					moveOne:Play()
				end

				task.wait(0.3)

				local v51 = getGroundColor(fakeUpperTorso)

				if v51 then
					local v52 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
					local v53 = v52 and v52:FindFirstChild("Rock")

					if v53 and v53:IsA("ParticleEmitter") then
						v53.Color = ColorSequence.new(v51)
					end

					local v54 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
					local v55 = v54 and v54:FindFirstChild("Smoke")

					if v55 and v55:IsA("ParticleEmitter") then
						v55.Color = ColorSequence.new(v51)
					end
				end

				local chopa = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopa")
				local chopaFlare = chopa and chopa:FindFirstChild("Flare")

				if chopaFlare and chopaFlare:IsA("ParticleEmitter") then
					chopaFlare:Emit(5)
				end

				local fakeUpperTorsoChopa = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopa")
				local fakeUpperTorsoChopaFlare2 = fakeUpperTorsoChopa and fakeUpperTorsoChopa:FindFirstChild("Flare2")

				if fakeUpperTorsoChopaFlare2 and fakeUpperTorsoChopaFlare2:IsA("ParticleEmitter") then
					fakeUpperTorsoChopaFlare2:Emit(5)
				end

				local chopb = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopb")
				local chopbFlare = chopb and chopb:FindFirstChild("Flare")

				if chopbFlare and chopbFlare:IsA("ParticleEmitter") then
					chopbFlare:Emit(5)
				end

				local fakeUpperTorsoChopb = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopb")
				local fakeUpperTorsoChopbFlare2 = fakeUpperTorsoChopb and fakeUpperTorsoChopb:FindFirstChild("Flare2")

				if fakeUpperTorsoChopbFlare2 and fakeUpperTorsoChopbFlare2:IsA("ParticleEmitter") then
					fakeUpperTorsoChopbFlare2:Emit(5)
				end

				local chopc = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopc")
				local chopcFlare = chopc and chopc:FindFirstChild("Flare")

				if chopcFlare and chopcFlare:IsA("ParticleEmitter") then
					chopcFlare:Emit(5)
				end

				local fakeUpperTorsoChopc = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chopc")
				local fakeUpperTorsoChopcFlare2 = fakeUpperTorsoChopc and fakeUpperTorsoChopc:FindFirstChild("Flare2")

				if fakeUpperTorsoChopcFlare2 and fakeUpperTorsoChopcFlare2:IsA("ParticleEmitter") then
					fakeUpperTorsoChopcFlare2:Emit(5)
				end

				if v51 then
					local v68 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
					local v69 = v68 and v68:FindFirstChild("Rock")

					if v69 and v69:IsA("ParticleEmitter") then
						v69:Emit(30)
					end

					local v70 = fakeUpperTorso and fakeUpperTorso:FindFirstChild("Chop2")
					local v71 = v70 and v70:FindFirstChild("Smoke")

					if v71 and v71:IsA("ParticleEmitter") then
						v71:Emit(10)
					end
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.Chop", result)
	end
end)

return true
