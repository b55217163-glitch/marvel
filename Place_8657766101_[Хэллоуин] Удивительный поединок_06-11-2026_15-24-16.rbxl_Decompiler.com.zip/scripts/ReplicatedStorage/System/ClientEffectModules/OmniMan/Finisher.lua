-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local finisher = replicatedStorage.Characters.OmniMan.Remotes.Finisher
		local smoke = replicatedStorage.Characters.Vecna.Fx.Smoke

		game:GetService("TextChatService"):WaitForChild("TextChannels"):FindFirstChild("RBXSystem")

		local effects: Instance = workspace:WaitForChild("Effects")

		local function copySurfaceStuff(p1, parent)
			for _, v in ipairs(p1:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeTexturesAndEmitters(p3)
			for _, v in ipairs(p3:GetChildren()) do
				if v:IsA("Texture") or v:IsA("Decal") then
					local tweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

					tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
				elseif v:IsA("ParticleEmitter") then
					v.Enabled = false
				end
			end
		end
		local function setSmokeColor(p4, p5)
			for _, v in ipairs(p4:GetDescendants()) do
				if v:IsA("ParticleEmitter") or v:IsA("Trail") then
					v.Color = ColorSequence.new(p5)
				elseif v:IsA("BasePart") then
					v.Color = p5
				end
			end
		end
		local function getGroundHit(p6, p7, p8)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			local vector3 = Vector3.new(0, p7, 0)
			local vector32 = Vector3.new(0, -p8, 0)

			return workspace:Raycast(p6 + vector3, vector32, raycastParams)
		end
		local function makeImpactChunk(p9, p10, p11, p12)
			local impactChunk: Part = Instance.new("Part")

			impactChunk.Name = "ImpactChunk"
			impactChunk.Anchored = false
			impactChunk.CanCollide = false
			impactChunk.CanTouch = false
			impactChunk.CanQuery = false
			impactChunk.Material = p9.Material
			impactChunk.Color = p9.Color
			impactChunk.Size = p11
			impactChunk.CastShadow = true
			impactChunk.TopSurface = Enum.SurfaceType.Smooth
			impactChunk.BottomSurface = Enum.SurfaceType.Smooth

			local cFrame = CFrame.new(p10)
			local cFrameAngles = CFrame.Angles
			local randomNumber = math.random(-180, 180)
			local v46 = math.rad(randomNumber)
			local randomNumber2 = math.random(-180, 180)
			local v48 = math.rad(randomNumber2)
			local randomNumber3 = math.random(-180, 180)
			local v50 = math.rad(randomNumber3)
			local v51 = cFrameAngles(v46, v48, v50)

			impactChunk.CFrame = cFrame * v51
			copySurfaceStuff(p9, impactChunk)
			impactChunk.Parent = effects
			debris:AddItem(impactChunk, p12 or 4)
			task.delay((p12 or 4) - 1.2, function()
				if not impactChunk or not impactChunk.Parent then
					return
				end

				fadeTexturesAndEmitters(impactChunk)

				local tweenInfo = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				local impactChunkPosition: Vector3 = impactChunk.Position
				local v174 = math.max(impactChunk.Size.Y * 0.6, 1)
				local vector3 = Vector3.new(0, v174, 0)

				tweenService:Create(impactChunk, tweenInfo, {
					Size = Vector3.new(0, 0, 0),
					Position = impactChunkPosition - vector3
				}):Play()
			end)

			return impactChunk
		end
		local function throwChunk(parent, velocity, angularVelocity, p16)
			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyVelocity.Velocity = velocity
			bodyVelocity.Parent = parent
			debris:AddItem(bodyVelocity, p16 or 0.18)

			local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

			bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)
			bodyAngularVelocity.AngularVelocity = angularVelocity
			bodyAngularVelocity.Parent = parent
			debris:AddItem(bodyAngularVelocity, p16 or 0.18)
		end
		local function createGroundScar(p17, p18, p19)
			local meteorScar: Folder = Instance.new("Folder")

			meteorScar.Name = "MeteorScar"
			meteorScar.Parent = effects
			debris:AddItem(meteorScar, 14)

			local impactMark: Part = Instance.new("Part")

			impactMark.Name = "ImpactMark"
			impactMark.Anchored = true
			impactMark.CanCollide = false
			impactMark.CanTouch = false
			impactMark.CanQuery = false
			impactMark.Material = p18.Material
			impactMark.Color = p18.Color:Lerp(Color3.new(0, 0, 0), 0.35)
			impactMark.Transparency = 0.15
			impactMark.Size = Vector3.new(1, 0.25, 1)

			local cFrame = CFrame.new(p17 + p19 * 0.03)
			local cFrameAngles = CFrame.Angles
			local randomNumber = math.random(0, 360)
			local v66 = math.rad(randomNumber)
			local v67 = cFrameAngles(0, v66, 0)

			impactMark.CFrame = cFrame * v67
			impactMark.Parent = meteorScar

			local specialMesh: SpecialMesh = Instance.new("SpecialMesh")

			specialMesh.MeshType = Enum.MeshType.Cylinder
			specialMesh.Scale = Vector3.new(1, 1, 1)
			specialMesh.Parent = impactMark

			local tweenInfo = TweenInfo.new(0.18, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

			tweenService:Create(impactMark, tweenInfo, { Size = Vector3.new(18, 0.25, 18) }):Play()
			task.delay(10, function()
				if impactMark and impactMark.Parent then
					local tweenInfo2 = TweenInfo.new(1.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

					tweenService:Create(impactMark, tweenInfo2, { Transparency = 1, Size = Vector3.new(21, 0.25, 21) }):Play()
				end
			end)

			for i = 1, 18 do
				local randomNumber4 = math.random(-6, 6)
				local v72 = math.rad(i * 20 + randomNumber4)
				local randomNumber5 = math.random(7, 10)
				local cosine = math.cos(v72)
				local sine = math.sin(v72)
				local vector3 = Vector3.new(cosine, 0, sine)
				local v77 = getGroundHit(p17 + vector3 * randomNumber5, 8, 20)

				if v77 and v77.Instance and v77.Instance:IsA("BasePart") then
					local n1 = math.random(16, 28) / 10
					local craterRimRock: Part = Instance.new("Part")

					craterRimRock.Name = "CraterRimRock"
					craterRimRock.Anchored = true
					craterRimRock.CanCollide = false
					craterRimRock.CanTouch = false
					craterRimRock.CanQuery = false
					craterRimRock.Material = v77.Instance.Material
					craterRimRock.Color = v77.Instance.Color

					local randomNumber6 = math.random(8, 16)

					craterRimRock.Size = Vector3.new(n1, randomNumber6 / 10, n1)

					local cFrameNew = CFrame.new
					local v82 = v77.Position
					local vector33 = Vector3.new(0, craterRimRock.Size.Y * 0.45, 0)
					local v84 = cFrameNew(v82 - vector33)
					local angles = CFrame.Angles
					local randomNumber7 = math.random(-25, 25)

					v82 = math.rad(randomNumber7)

					local randomNumber8 = math.random(-180, 180)
					local v88 = math.rad(randomNumber8)
					local randomNumber9 = math.random(-25, 25)
					local v90 = math.rad(randomNumber9)
					local v91 = angles(v82, v88, v90)

					craterRimRock.CFrame = v84 * v91
					copySurfaceStuff(v77.Instance, craterRimRock)
					craterRimRock.Parent = meteorScar
					task.delay(10, function()
						if craterRimRock and craterRimRock.Parent then
							fadeTexturesAndEmitters(craterRimRock)

							local tweenInfo3 = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							local craterRimRockPosition: Vector3 = craterRimRock.Position
							local vector34 = Vector3.new(0, craterRimRock.Size.Y * 0.5, 0)

							tweenService:Create(craterRimRock, tweenInfo3, {
								Transparency = 1,
								Size = Vector3.new(0, 0, 0),
								Position = craterRimRockPosition - vector34
							}):Play()
						end
					end)
				end
			end

			for _ = 1, 10 do
				local randomNumber10 = math.random(-5, 5)
				local vector35 = Vector3.new(randomNumber10, 0, math.random(-5, 5))

				vector35 = getGroundHit(p17 + vector35, 8, 20)

				if vector35 and vector35.Instance and vector35.Instance:IsA("BasePart") then
					local n2 = math.random(12, 25) / 10
					local embeddedImpactRock: Part = Instance.new("Part")

					embeddedImpactRock.Name = "EmbeddedImpactRock"
					embeddedImpactRock.Anchored = true
					embeddedImpactRock.CanCollide = false
					embeddedImpactRock.CanTouch = false
					embeddedImpactRock.CanQuery = false
					embeddedImpactRock.Material = vector35.Instance.Material
					embeddedImpactRock.Color = vector35.Instance.Color
					embeddedImpactRock.Size = Vector3.new(n2, n2, n2)

					local v97 = CFrame.new
					local v98 = vector35.Position
					local vector36 = Vector3.new(0, n2 * 0.35, 0)
					local v100 = v97(v98 - vector36)
					local v101 = CFrame.Angles
					local randomNumber11 = math.random(-40, 40)

					v98 = math.rad(randomNumber11)

					local randomNumber12 = math.random(-180, 180)
					local v104 = math.rad(randomNumber12)
					local randomNumber13 = math.random(-40, 40)
					local v106 = math.rad(randomNumber13)
					local v107 = v101(v98, v104, v106)

					embeddedImpactRock.CFrame = v100 * v107
					copySurfaceStuff(vector35.Instance, embeddedImpactRock)
					embeddedImpactRock.Parent = meteorScar
					task.delay(10, function()
						if embeddedImpactRock and embeddedImpactRock.Parent then
							fadeTexturesAndEmitters(embeddedImpactRock)

							local tweenInfo4 = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							local embeddedImpactRockPosition: Vector3 = embeddedImpactRock.Position
							local vector37 = Vector3.new(0, embeddedImpactRock.Size.Y * 0.45, 0)

							tweenService:Create(embeddedImpactRock, tweenInfo4, {
								Transparency = 1,
								Size = Vector3.new(0, 0, 0),
								Position = embeddedImpactRockPosition - vector37
							}):Play()
						end
					end)
				end
			end
		end
		local function spawnColoredSmoke(p20, p21, p22)
			if not smoke then
				return
			end

			local clone = smoke:Clone()

			clone.Parent = p22 or effects

			if clone:IsA("Model") then
				if clone.PrimaryPart or clone:FindFirstChildWhichIsA("BasePart") then
					local cFrame = CFrame.new(p20)
					local v113 = CFrame.Angles(0, 0, 1.5707963267948966)

					clone:PivotTo(cFrame * v113)
				end
			elseif clone:IsA("BasePart") then
				local cFrame = CFrame.new(p20)
				local v115 = CFrame.Angles(0, 0, 1.5707963267948966)

				clone.CFrame = cFrame * v115
			end

			setSmokeColor(clone, p21.Color)

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					local v118 = v.Rate > 0 and math.floor(v.Rate * 0.35) or 16
					local v119 = math.clamp(v118, 10, 50)

					v:Emit(v119)
				end
			end

			debris:AddItem(clone, 3)
		end
		local function spawnMeteorRing(p23, p24, p25, p26, p27, p28, p29, p30)
			task.delay(p30 or 0, function()
				if not p23 or not p23.Parent then
					return
				end

				for i = 1, p25 do
					local randomNumber = math.random(-8, 8)
					local v185 = math.rad(360 / p25 * i + randomNumber)
					local cosine = math.cos(v185)
					local sine = math.sin(v185)
					local vector3 = Vector3.new(cosine, 0, sine)
					local randomNumber14 = math.random(-2, 2)
					local n1 = vector3 * (p24 + randomNumber14)
					local v191 = getGroundHit(p23.Position + n1, 12, 40)

					if v191 and v191.Instance and v191.Instance:IsA("BasePart") then
						local v192 = v191.Position
						local instance = v191.Instance
						local n2 = math.random(p26 * 10, p27 * 10) / 10
						local vector38 = Vector3.new(n2, n2, n2)
						local vector39 = Vector3.new(0, n2 * 0.35, 0)
						local v197 = makeImpactChunk(instance, v192 - vector39, vector38, 4)
						local randomNumber15 = math.random(2, 5)
						local tweenInfo = TweenInfo.new(0.08, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local vector310 = Vector3.new(0, randomNumber15, 0)

						tweenService:Create(v197, tweenInfo, { Position = v192 + vector310 }):Play()

						local v201 = n1.Magnitude > 0 and n1.Unit or Vector3.new(0, 0, 1)

						task.delay(0.04, function()
							if v197 and v197.Parent then
								local randomNumber16 = math.random(p29 - 12, p29 + 12)
								local randomNumber17 = math.random(p28 - 8, p28 + 8)
								local vector311 = Vector3.new(0, randomNumber17, 0)
								local randomNumber18 = math.random(-720, 720)
								local v381 = math.rad(randomNumber18)
								local randomNumber19 = math.random(-720, 720)
								local v383 = math.rad(randomNumber19)
								local randomNumber20 = math.random(-720, 720)
								local v385 = math.rad(randomNumber20)
								local vector312 = Vector3.new(v381, v383, v385)

								throwChunk(v197, v201 * randomNumber16 + vector311, vector312, 0.22)
							end
						end)

						if math.random(1, 3) ~= 1 then
							continue
						end

						local clone = replicatedStorage.Characters.Physics.Rock:Clone()

						clone.Material = instance.Material
						clone.Color = instance.Color

						if clone:FindFirstChild("Trail") then
							clone.Trail.Color = ColorSequence.new(instance.Color)
						end

						clone.CFrame = CFrame.new(v192 + Vector3.new(0, 1, 0))
						clone.Parent = effects

						local randomNumber21 = math.random(-30, 30)
						local randomNumber22 = math.random(-30, 30)
						local vector313 = Vector3.new(randomNumber21 / 100, 0, randomNumber22 / 100)
						local n3 = v201 + vector313
						local v207 = n3.Magnitude > 0 and n3.Unit or v201
						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber23 = math.random(p29, p29 + 20)
						local randomNumber24 = math.random(p28 + 10, p28 + 25)
						local vector314 = Vector3.new(0, randomNumber24, 0)

						bodyVelocity.Velocity = v207 * randomNumber23 + vector314
						bodyVelocity.Parent = clone

						local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

						bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber25 = math.random(-1080, 1080)
						local v214 = math.rad(randomNumber25)
						local randomNumber26 = math.random(-1080, 1080)
						local v216 = math.rad(randomNumber26)
						local randomNumber27 = math.random(-1080, 1080)
						local v218 = math.rad(randomNumber27)

						bodyAngularVelocity.AngularVelocity = Vector3.new(v214, v216, v218)
						bodyAngularVelocity.Parent = clone
						debris:AddItem(bodyVelocity, 0.2)
						debris:AddItem(bodyAngularVelocity, 0.25)
						debris:AddItem(clone, 3)
					end
				end
			end)
		end
		local function spawnMeteorImpact(p31)
			if not p31 or not p31.Parent then
				return
			end

			local v129 = getGroundHit(p31.Position, 12, 40)

			if not v129 or not v129.Instance or not v129.Instance:IsA("BasePart") then
				return
			end

			local instance = v129.Instance
			local v131 = v129.Position

			createGroundScar(v131, instance, v129.Normal)
			spawnColoredSmoke(v131, instance, effects)

			for _ = 1, 8 do
				local n1 = math.random(22, 38) / 10
				local randomNumber = math.random(-2, 2)
				local vector3 = Vector3.new(randomNumber, -1, math.random(-2, 2))
				local vector315 = Vector3.new(n1, n1, n1)
				local v137 = makeImpactChunk(instance, v131 + vector3, vector315, 4.5)
				local tweenInfo = TweenInfo.new(0.06, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				local randomNumber28 = math.random(-3, 3)
				local randomNumber29 = math.random(4, 8)
				local vector316 = Vector3.new(randomNumber28, randomNumber29, math.random(-3, 3))

				tweenService:Create(v137, tweenInfo, { Position = v131 + vector316 }):Play()
				task.delay(0.03, function()
					if v137 and v137.Parent then
						local randomNumber30 = math.random(-100, 100)
						local randomNumber31 = math.random(-100, 100)
						local vector317 = Vector3.new(randomNumber30 / 100, 0, randomNumber31 / 100)

						if vector317.Magnitude == 0 then
							vector317 = Vector3.new(0, 0, 1)
						end

						local vector317Unit = vector317.Unit
						local randomNumber32 = math.random(25, 45)
						local randomNumber33 = math.random(55, 80)
						local vector318 = Vector3.new(0, randomNumber33, 0)
						local randomNumber34 = math.random(-900, 900)
						local v227 = math.rad(randomNumber34)
						local randomNumber35 = math.random(-900, 900)
						local v229 = math.rad(randomNumber35)
						local randomNumber36 = math.random(-900, 900)
						local v231 = math.rad(randomNumber36)
						local vector319 = Vector3.new(v227, v229, v231)

						throwChunk(v137, vector317Unit * randomNumber32 + vector318, vector319, 0.25)
					end
				end)
			end

			local n2: number = 10
			local n3: number = 4
			local n4: number = 1.8
			local n5: number = 3.2
			local n6: number = 32
			local n7: number = 48

			task.delay(0.02, function()
				if not p31 or not p31.Parent then
					return
				end

				for i = 1, n2 do
					local randomNumber37 = math.random(-8, 8)
					local v235 = math.rad(360 / n2 * i + randomNumber37)
					local cosine = math.cos(v235)
					local sine = math.sin(v235)
					local vector320 = Vector3.new(cosine, 0, sine)
					local randomNumber38 = math.random(-2, 2)
					local n1 = vector320 * (n3 + randomNumber38)
					local v241 = getGroundHit(p31.Position + n1, 12, 40)

					if v241 and v241.Instance and v241.Instance:IsA("BasePart") then
						local v242 = v241.Position
						local instance = v241.Instance
						local n8 = math.random(n4 * 10, n5 * 10) / 10
						local vector321 = Vector3.new(n8, n8, n8)
						local vector322 = Vector3.new(0, n8 * 0.35, 0)
						local v247 = makeImpactChunk(instance, v242 - vector322, vector321, 4)
						local randomNumber39 = math.random(2, 5)
						local tweenInfo5 = TweenInfo.new(0.08, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local vector323 = Vector3.new(0, randomNumber39, 0)

						tweenService:Create(v247, tweenInfo5, { Position = v242 + vector323 }):Play()

						local v251 = n1.Magnitude > 0 and n1.Unit or Vector3.new(0, 0, 1)

						task.delay(0.04, function()
							if v247 and v247.Parent then
								local randomNumber40 = math.random(n6 - 12, n6 + 12)
								local randomNumber41 = math.random(n7 - 8, n7 + 8)
								local vector324 = Vector3.new(0, randomNumber41, 0)
								local randomNumber42 = math.random(-720, 720)
								local v391 = math.rad(randomNumber42)
								local randomNumber43 = math.random(-720, 720)
								local v393 = math.rad(randomNumber43)
								local randomNumber44 = math.random(-720, 720)
								local v395 = math.rad(randomNumber44)
								local vector325 = Vector3.new(v391, v393, v395)

								throwChunk(v247, v251 * randomNumber40 + vector324, vector325, 0.22)
							end
						end)

						if math.random(1, 3) ~= 1 then
							continue
						end

						local clone = replicatedStorage.Characters.Physics.Rock:Clone()

						clone.Material = instance.Material
						clone.Color = instance.Color

						if clone:FindFirstChild("Trail") then
							clone.Trail.Color = ColorSequence.new(instance.Color)
						end

						clone.CFrame = CFrame.new(v242 + Vector3.new(0, 1, 0))
						clone.Parent = effects

						local randomNumber45 = math.random(-30, 30)
						local randomNumber46 = math.random(-30, 30)
						local vector326 = Vector3.new(randomNumber45 / 100, 0, randomNumber46 / 100)
						local n9 = v251 + vector326
						local v257 = n9.Magnitude > 0 and n9.Unit or v251
						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber47 = math.random(n6, n6 + 20)
						local randomNumber48 = math.random(n7 + 10, n7 + 25)
						local vector327 = Vector3.new(0, randomNumber48, 0)

						bodyVelocity.Velocity = v257 * randomNumber47 + vector327
						bodyVelocity.Parent = clone

						local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

						bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber49 = math.random(-1080, 1080)
						local v264 = math.rad(randomNumber49)
						local randomNumber50 = math.random(-1080, 1080)
						local v266 = math.rad(randomNumber50)
						local randomNumber51 = math.random(-1080, 1080)
						local v268 = math.rad(randomNumber51)

						bodyAngularVelocity.AngularVelocity = Vector3.new(v264, v266, v268)
						bodyAngularVelocity.Parent = clone
						debris:AddItem(bodyVelocity, 0.2)
						debris:AddItem(bodyAngularVelocity, 0.25)
						debris:AddItem(clone, 3)
					end
				end
			end)

			local n8: number = 14
			local n9: number = 8
			local n10: number = 1.5
			local n11: number = 2.8
			local n12: number = 42
			local n13: number = 42

			task.delay(0.06, function()
				if not p31 or not p31.Parent then
					return
				end

				for i = 1, n8 do
					local randomNumber52 = math.random(-8, 8)
					local v271 = math.rad(360 / n8 * i + randomNumber52)
					local cosine = math.cos(v271)
					local sine = math.sin(v271)
					local vector328 = Vector3.new(cosine, 0, sine)
					local randomNumber53 = math.random(-2, 2)
					local n1 = vector328 * (n9 + randomNumber53)
					local v277 = getGroundHit(p31.Position + n1, 12, 40)

					if v277 and v277.Instance and v277.Instance:IsA("BasePart") then
						local v278 = v277.Position
						local instance = v277.Instance
						local n2 = math.random(n10 * 10, n11 * 10) / 10
						local vector329 = Vector3.new(n2, n2, n2)
						local vector330 = Vector3.new(0, n2 * 0.35, 0)
						local v283 = makeImpactChunk(instance, v278 - vector330, vector329, 4)
						local randomNumber54 = math.random(2, 5)
						local tweenInfo6 = TweenInfo.new(0.08, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local vector331 = Vector3.new(0, randomNumber54, 0)

						tweenService:Create(v283, tweenInfo6, { Position = v278 + vector331 }):Play()

						local v287 = n1.Magnitude > 0 and n1.Unit or Vector3.new(0, 0, 1)

						task.delay(0.04, function()
							if v283 and v283.Parent then
								local randomNumber55 = math.random(n12 - 12, n12 + 12)
								local randomNumber56 = math.random(n13 - 8, n13 + 8)
								local vector332 = Vector3.new(0, randomNumber56, 0)
								local randomNumber57 = math.random(-720, 720)
								local v401 = math.rad(randomNumber57)
								local randomNumber58 = math.random(-720, 720)
								local v403 = math.rad(randomNumber58)
								local randomNumber59 = math.random(-720, 720)
								local v405 = math.rad(randomNumber59)
								local vector333 = Vector3.new(v401, v403, v405)

								throwChunk(v283, v287 * randomNumber55 + vector332, vector333, 0.22)
							end
						end)

						if math.random(1, 3) ~= 1 then
							continue
						end

						local clone = replicatedStorage.Characters.Physics.Rock:Clone()

						clone.Material = instance.Material
						clone.Color = instance.Color

						if clone:FindFirstChild("Trail") then
							clone.Trail.Color = ColorSequence.new(instance.Color)
						end

						clone.CFrame = CFrame.new(v278 + Vector3.new(0, 1, 0))
						clone.Parent = effects

						local randomNumber60 = math.random(-30, 30)
						local randomNumber61 = math.random(-30, 30)
						local vector334 = Vector3.new(randomNumber60 / 100, 0, randomNumber61 / 100)
						local n3 = v287 + vector334
						local v293 = n3.Magnitude > 0 and n3.Unit or v287
						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber62 = math.random(n12, n12 + 20)
						local randomNumber63 = math.random(n13 + 10, n13 + 25)
						local vector335 = Vector3.new(0, randomNumber63, 0)

						bodyVelocity.Velocity = v293 * randomNumber62 + vector335
						bodyVelocity.Parent = clone

						local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

						bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber64 = math.random(-1080, 1080)
						local v300 = math.rad(randomNumber64)
						local randomNumber65 = math.random(-1080, 1080)
						local v302 = math.rad(randomNumber65)
						local randomNumber66 = math.random(-1080, 1080)
						local v304 = math.rad(randomNumber66)

						bodyAngularVelocity.AngularVelocity = Vector3.new(v300, v302, v304)
						bodyAngularVelocity.Parent = clone
						debris:AddItem(bodyVelocity, 0.2)
						debris:AddItem(bodyAngularVelocity, 0.25)
						debris:AddItem(clone, 3)
					end
				end
			end)

			local n14: number = 18
			local n15: number = 13
			local n16: number = 1.2
			local n17: number = 2.2
			local n18: number = 52
			local n19: number = 36

			task.delay(0.1, function()
				if not p31 or not p31.Parent then
					return
				end

				for i = 1, n14 do
					local randomNumber67 = math.random(-8, 8)
					local v307 = math.rad(360 / n14 * i + randomNumber67)
					local cosine = math.cos(v307)
					local sine = math.sin(v307)
					local vector336 = Vector3.new(cosine, 0, sine)
					local randomNumber68 = math.random(-2, 2)
					local n1 = vector336 * (n15 + randomNumber68)
					local v313 = getGroundHit(p31.Position + n1, 12, 40)

					if v313 and v313.Instance and v313.Instance:IsA("BasePart") then
						local v314 = v313.Position
						local instance = v313.Instance
						local n2 = math.random(n16 * 10, n17 * 10) / 10
						local vector337 = Vector3.new(n2, n2, n2)
						local vector338 = Vector3.new(0, n2 * 0.35, 0)
						local v319 = makeImpactChunk(instance, v314 - vector338, vector337, 4)
						local randomNumber69 = math.random(2, 5)
						local tweenInfo7 = TweenInfo.new(0.08, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local vector339 = Vector3.new(0, randomNumber69, 0)

						tweenService:Create(v319, tweenInfo7, { Position = v314 + vector339 }):Play()

						local v323 = n1.Magnitude > 0 and n1.Unit or Vector3.new(0, 0, 1)

						task.delay(0.04, function()
							if v319 and v319.Parent then
								local randomNumber70 = math.random(n18 - 12, n18 + 12)
								local randomNumber71 = math.random(n19 - 8, n19 + 8)
								local vector340 = Vector3.new(0, randomNumber71, 0)
								local randomNumber72 = math.random(-720, 720)
								local v411 = math.rad(randomNumber72)
								local randomNumber73 = math.random(-720, 720)
								local v413 = math.rad(randomNumber73)
								local randomNumber74 = math.random(-720, 720)
								local v415 = math.rad(randomNumber74)
								local vector341 = Vector3.new(v411, v413, v415)

								throwChunk(v319, v323 * randomNumber70 + vector340, vector341, 0.22)
							end
						end)

						if math.random(1, 3) ~= 1 then
							continue
						end

						local clone = replicatedStorage.Characters.Physics.Rock:Clone()

						clone.Material = instance.Material
						clone.Color = instance.Color

						if clone:FindFirstChild("Trail") then
							clone.Trail.Color = ColorSequence.new(instance.Color)
						end

						clone.CFrame = CFrame.new(v314 + Vector3.new(0, 1, 0))
						clone.Parent = effects

						local randomNumber75 = math.random(-30, 30)
						local randomNumber76 = math.random(-30, 30)
						local vector342 = Vector3.new(randomNumber75 / 100, 0, randomNumber76 / 100)
						local n3 = v323 + vector342
						local v329 = n3.Magnitude > 0 and n3.Unit or v323
						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber77 = math.random(n18, n18 + 20)
						local randomNumber78 = math.random(n19 + 10, n19 + 25)
						local vector343 = Vector3.new(0, randomNumber78, 0)

						bodyVelocity.Velocity = v329 * randomNumber77 + vector343
						bodyVelocity.Parent = clone

						local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

						bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber79 = math.random(-1080, 1080)
						local v336 = math.rad(randomNumber79)
						local randomNumber80 = math.random(-1080, 1080)
						local v338 = math.rad(randomNumber80)
						local randomNumber81 = math.random(-1080, 1080)
						local v340 = math.rad(randomNumber81)

						bodyAngularVelocity.AngularVelocity = Vector3.new(v336, v338, v340)
						bodyAngularVelocity.Parent = clone
						debris:AddItem(bodyVelocity, 0.2)
						debris:AddItem(bodyAngularVelocity, 0.25)
						debris:AddItem(clone, 3)
					end
				end
			end)

			local n20: number = 22
			local n21: number = 18
			local n22: number = 0.9
			local n23: number = 1.8
			local n24: number = 58
			local n25: number = 28

			task.delay(0.15, function()
				if not p31 or not p31.Parent then
					return
				end

				for i = 1, n20 do
					local randomNumber82 = math.random(-8, 8)
					local v343 = math.rad(360 / n20 * i + randomNumber82)
					local cosine = math.cos(v343)
					local sine = math.sin(v343)
					local vector344 = Vector3.new(cosine, 0, sine)
					local randomNumber83 = math.random(-2, 2)
					local n1 = vector344 * (n21 + randomNumber83)
					local v349 = getGroundHit(p31.Position + n1, 12, 40)

					if v349 and v349.Instance and v349.Instance:IsA("BasePart") then
						local v350 = v349.Position
						local instance = v349.Instance
						local n2 = math.random(n22 * 10, n23 * 10) / 10
						local vector345 = Vector3.new(n2, n2, n2)
						local vector346 = Vector3.new(0, n2 * 0.35, 0)
						local v355 = makeImpactChunk(instance, v350 - vector346, vector345, 4)
						local randomNumber84 = math.random(2, 5)
						local tweenInfo8 = TweenInfo.new(0.08, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local vector347 = Vector3.new(0, randomNumber84, 0)

						tweenService:Create(v355, tweenInfo8, { Position = v350 + vector347 }):Play()

						local v359 = n1.Magnitude > 0 and n1.Unit or Vector3.new(0, 0, 1)

						task.delay(0.04, function()
							if v355 and v355.Parent then
								local randomNumber85 = math.random(n24 - 12, n24 + 12)
								local randomNumber86 = math.random(n25 - 8, n25 + 8)
								local vector348 = Vector3.new(0, randomNumber86, 0)
								local randomNumber87 = math.random(-720, 720)
								local v421 = math.rad(randomNumber87)
								local randomNumber88 = math.random(-720, 720)
								local v423 = math.rad(randomNumber88)
								local randomNumber89 = math.random(-720, 720)
								local v425 = math.rad(randomNumber89)
								local vector349 = Vector3.new(v421, v423, v425)

								throwChunk(v355, v359 * randomNumber85 + vector348, vector349, 0.22)
							end
						end)

						if math.random(1, 3) ~= 1 then
							continue
						end

						local clone = replicatedStorage.Characters.Physics.Rock:Clone()

						clone.Material = instance.Material
						clone.Color = instance.Color

						if clone:FindFirstChild("Trail") then
							clone.Trail.Color = ColorSequence.new(instance.Color)
						end

						clone.CFrame = CFrame.new(v350 + Vector3.new(0, 1, 0))
						clone.Parent = effects

						local randomNumber90 = math.random(-30, 30)
						local randomNumber91 = math.random(-30, 30)
						local vector350 = Vector3.new(randomNumber90 / 100, 0, randomNumber91 / 100)
						local n3 = v359 + vector350
						local v365 = n3.Magnitude > 0 and n3.Unit or v359
						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber92 = math.random(n24, n24 + 20)
						local randomNumber93 = math.random(n25 + 10, n25 + 25)
						local vector351 = Vector3.new(0, randomNumber93, 0)

						bodyVelocity.Velocity = v365 * randomNumber92 + vector351
						bodyVelocity.Parent = clone

						local bodyAngularVelocity: BodyAngularVelocity = Instance.new("BodyAngularVelocity")

						bodyAngularVelocity.MaxTorque = Vector3.new(1000000, 1000000, 1000000)

						local randomNumber94 = math.random(-1080, 1080)
						local v372 = math.rad(randomNumber94)
						local randomNumber95 = math.random(-1080, 1080)
						local v374 = math.rad(randomNumber95)
						local randomNumber96 = math.random(-1080, 1080)
						local v376 = math.rad(randomNumber96)

						bodyAngularVelocity.AngularVelocity = Vector3.new(v372, v374, v376)
						bodyAngularVelocity.Parent = clone
						debris:AddItem(bodyVelocity, 0.2)
						debris:AddItem(bodyAngularVelocity, 0.25)
						debris:AddItem(clone, 3)
					end
				end
			end)
		end

		finisher.OnClientEvent:Connect(function(p32, character)
			local v168 = p32:IsA("Model") and p32:FindFirstChildOfClass("Humanoid") and p32 or p32:IsA("Player") and (p32.Character or p32.CharacterAdded:Wait())

			if not v168 then
				warn("No Character from PLR")

				return
			end

			local v169 = v168:FindFirstChildOfClass("Humanoid") or v168:WaitForChild("Humanoid", 5)
			local v170 = character and (character:FindFirstChildOfClass("Humanoid") or character:WaitForChild("Humanoid", 5))
			local v171 = v168:FindFirstChild("HumanoidRootPart") or v168:WaitForChild("HumanoidRootPart", 5)

			if v169 and v170 and v171 then
				spawnMeteorImpact(v171)

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.Finisher", result)
	end
end)

return true
