-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.5)

		local debris: Debris = game:GetService("Debris")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local workspace: Workspace = game:GetService("Workspace")
		local flightStop: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("OmniMan"):WaitForChild("Remotes"):WaitForChild("FlightStop")
		local fxFlightStop: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("OmniMan"):WaitForChild("Fx"):WaitForChild("FlightStop")
		local v8 = workspace:FindFirstChild("Effects") or workspace

		local function setEmitterColor(p1, p2)
			if p1 and p1:IsA("ParticleEmitter") then
				p1.Color = ColorSequence.new(p2)
			end
		end
		local function getCurrentMap()
			local map: Instance = workspace:FindFirstChild("Map")

			if map and map.Parent == workspace then
				return map
			end

			return nil
		end
		local function getGroundData(p3)
			local v21 = p3 and (p3:FindFirstChild("LowerTorso") or p3:FindFirstChild("HumanoidRootPart"))

			if not v21 then
				return nil
			end

			local map: Instance = workspace:FindFirstChild("Map")
			local v23 = if map and map.Parent == workspace then map else nil
			local n1 = v21.Position + Vector3.new(0, 8, 0)
			local raycastParams = RaycastParams.new()

			raycastParams.IgnoreWater = false

			if v23 then
				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v23 }
			else
				raycastParams.FilterType = Enum.RaycastFilterType.Exclude
				raycastParams.FilterDescendantsInstances = { p3, v8 }
			end

			v23 = workspace:Raycast(n1, Vector3.new(0, -68, 0), raycastParams)

			if v23 then
				local instance = v23.Instance
				local v27 = instance and instance:IsA("BasePart") and instance.Color

				if not v27 then
					v27 = Color3.fromRGB(120, 120, 120)
				end

				return { position = v23.Position, normal = v23.Normal, color = v27 }
			end

			local n2 = v21.Position - Vector3.new(0, 3, 0)
			local color3 = Color3.fromRGB(120, 120, 120)

			return { normal = Vector3.new(0, 1, 0), position = n2, color = color3 }
		end

		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function Math(p4, p5, p6)
			return p4 + (p5 - p4) * p6
		end
		local function RockSpawn(p7, p8: number, p9, parent, p11, p12, p13, p14)
			if p8 > 180 or p8 <= 0 then
				warn("Invalid rock amount!")
				p8 = 15
			end

			local n1: number = if p14 then 2 else 1
			local n2: number = 1 * n1
			local n3: number = 0
			local map: Instance = workspace:FindFirstChild("Map")
			local v45 = if map and map.Parent == workspace then map else nil

			if not v45 then
				return
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v45 }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p8 do
				local v48 = p7.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v50 = math.rad(n3)
				local v51 = cFrameFromEulerAnglesXYZ(0, v50, 0)
				local cFrame = CFrame.new(0, 0, p11)
				local n4 = v48 * v51 * cFrame.Position
				local v54 = p7.CFrame
				local v55 = CFrame.fromEulerAnglesXYZ
				local v56 = math.rad(n3)
				local v57 = v55(0, v56, 0)
				local cFrame2 = CFrame.new(0, 0, -p11 / 1.25)
				local n5 = v54 * v57 * cFrame2.Position
				local vector3 = Vector3.new(0, -p11, 0)
				local v61 = workspace:Raycast(n4, n5 + vector3 - n4, raycastParams)

				n3 += p8

				if v61 then
					local instance = v61.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local flightStopRock: Part = Instance.new("Part")

					flightStopRock.Name = "FlightStopRock"
					flightStopRock.Anchored = true
					flightStopRock.CanCollide = false
					flightStopRock.CanTouch = false
					flightStopRock.CanQuery = false
					flightStopRock.CastShadow = true
					flightStopRock.Material = instance.Material
					flightStopRock.Color = instance.Color

					local v64 = p7.Position
					local magnitude = (p7.Position - v61.Position).Magnitude

					flightStopRock.CFrame = CFrame.new(v64 + (v61.Position - v64) * 0.2, p7.Position)

					for _, v in ipairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = flightStopRock
						end
					end

					if p13 then
						local v69 = mathRandom(p9.Min, p9.Max)
						local v70 = mathRandom(p9.Min, p9.Max)

						flightStopRock.Size = Vector3.new(v69, v70, mathRandom(p9.Min, p9.Max))
					else
						flightStopRock.Size = p9
					end

					flightStopRock.Parent = parent
					debris:AddItem(flightStopRock, 5 * n1 + n2 + 1)

					local v71 = math.max(magnitude / 75, 0.05)
					local t1

					if p12 == true then
						local v74 = mathRandom(-180, 180)
						local v75 = mathRandom(-180, 180)

						flightStopRock.Orientation = Vector3.new(v74, v75, mathRandom(-180, 180))
						t1 = { Position = v61.Position }
					elseif p12 == "Middle" then
						local cFrame3 = CFrame.new(v61.Position, p7.Position)
						local cFrameAngles = CFrame.Angles
						local v78 = mathRandom(-3.141592653589793, 3.141592653589793)
						local v79 = cFrameAngles(v78, 0, 0)
						t1 = { CFrame = cFrame3 * v79 }
					else
						local cFrame4 = CFrame.new(v61.Position, p7.Position)
						t1 = { CFrame = cFrame4 }
					end

					local v81 = tweenInfoNew(v71 * n1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(flightStopRock, v81, t1):Play()
					task.delay(4 * n1, function()
						if not flightStopRock.Parent then
							return
						end

						for _, v in ipairs(flightStopRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v103 = tweenInfoNew(0.5 * n1, Enum.EasingStyle.Linear)

								tweenService:Create(v, v103, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v104 = tweenInfoNew(n2, Enum.EasingStyle.Linear)
						local flightStopRockPosition: Vector3 = flightStopRock.Position
						local vector32 = Vector3.new(0, flightStopRock.Size.Y / 2, 0)

						tweenService:Create(flightStopRock, v104, {
							Size = Vector3.new(0, 0, 0),
							Position = flightStopRockPosition - vector32
						}):Play()
					end)
				end
			end
		end

		flightStop.OnClientEvent:Connect(function(player, p16)
			local Character = nil

			if typeof(player) == "Instance" then
				if player:IsA("Player") then
					Character = player.Character
				elseif player:IsA("Model") then
					Character = player
				end
			end

			if not Character then
				return
			end

			local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local v86 = getGroundData(Character)

			if not v86 then
				return
			end

			local n1: number = if p16 then 2 else 1
			local clone: Instance = fxFlightStop:Clone()

			clone.Parent = v8

			local v89 = humanoidRootPart.CFrame.LookVector

			if v89.Magnitude <= 0.001 then
				v89 = Vector3.new(0, 0, -1)
			end

			clone.CFrame = CFrame.lookAt(v86.position, v86.position + v89, v86.normal) + v86.normal * 0.05

			local groundSfx: Instance = clone:FindFirstChild("GroundSfx")

			if groundSfx and groundSfx:IsA("Sound") then
				groundSfx.PlaybackSpeed = if p16 then 0.5 else 1
				groundSfx:Play()
			end

			if Character:FindFirstChild("Mohawk") then
				local randomNumber = math.random(1, 3)
				local foundChild: Instance = clone:FindFirstChild("Slam" .. randomNumber)

				if foundChild and foundChild:IsA("Sound") then
					foundChild.PlaybackSpeed = if p16 then 0.5 else 1
					foundChild:Play()
				end
			end

			local smoke: Instance = clone:FindFirstChild("Smoke")
			local rocks: Instance = clone:FindFirstChild("Rocks")
			local color = v86.color

			if smoke and smoke:IsA("ParticleEmitter") then
				smoke.Color = ColorSequence.new(color)
			end

			local v96 = v86.color

			if rocks and rocks:IsA("ParticleEmitter") then
				rocks.Color = ColorSequence.new(v96)
			end

			if smoke and smoke:IsA("ParticleEmitter") then
				smoke.TimeScale = if p16 then 0.5 else 1
				smoke.Lifetime = NumberRange.new(smoke.Lifetime.Min * n1, smoke.Lifetime.Max * n1)
				smoke:Emit(30)
			end

			if rocks and rocks:IsA("ParticleEmitter") then
				rocks.TimeScale = if p16 then 0.5 else 1
				rocks.Lifetime = NumberRange.new(rocks.Lifetime.Min * n1, rocks.Lifetime.Max * n1)
				rocks:Emit(30)
			end

			debris:AddItem(clone, 8 * n1)

			local v97 = Character:FindFirstChild("LowerTorso") or humanoidRootPart
			local v98 = humanoidRootPart.CFrame.LookVector

			v98 = Vector3.new(v98.X, 0, v98.Z)

			local v99 = v97.Position
			local v100 = CFrame.lookAt(v97.Position, v97.Position + (if v98.Magnitude <= 0.001 then Vector3.new(0, 0, -1) else v98.Unit), Vector3.new(0, 1, 0))

			RockSpawn({ Position = v99, CFrame = v100 }, 40, NumberRange.new(0.5, 5), v8, 30, false, true, p16)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.FlightStop", result)
	end
end)

return true
