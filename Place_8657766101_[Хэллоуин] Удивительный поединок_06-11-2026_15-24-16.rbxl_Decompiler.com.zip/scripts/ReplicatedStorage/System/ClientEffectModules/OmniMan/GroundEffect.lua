-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local clap = game.ReplicatedStorage.Characters.OmniMan.Remotes.Clap
		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random
		local debris: Debris = game:GetService("Debris")

		local function Math(p1, p2, p3)
			return p1 + (p2 - p1) * p3
		end

		Math = function()
			local map: Instance = workspace:FindFirstChild("Map")

			if map and map.Parent == workspace then
				return map
			end

			return nil
		end

		local function makeMapRayParams()
			local map: Instance = workspace:FindFirstChild("Map")
			local v24 = if map and map.Parent == workspace then map else nil

			if not v24 then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v24 }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function isValidGroundPart(p4)
			return p4 and p4:IsA("BasePart") and p4.Parent and p4.CanCollide and p4.Transparency < 1
		end
		local function RockSpawn(p5, p6, p7, p8, p9, p10, p11)
			task.spawn(function()
				local function makeRock(p12, p13, p14, p15)
					if not p12 or not p12:IsA("BasePart") or not p12.Parent or not p12.CanCollide or not (p12.Transparency < 1) then
						return
					end

					local groundRock: Part = Instance.new("Part")

					groundRock.Anchored = true
					groundRock.CanCollide = false
					groundRock.CanTouch = false
					groundRock.CanQuery = false
					groundRock.Material = p12.Material
					groundRock.Color = p12.Color
					groundRock.Name = "GroundRock"
					groundRock.Parent = workspaceEffects

					for _, v in ipairs(p12:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = groundRock
						end
					end

					if u54 == true then
						local numberRangeMin = numberRange.Min
						local numberRangeMax = numberRange.Max

						if p15 then
							local v155 = math.max(1, numberRangeMin)
							local v156 = math.max(2, numberRangeMax + 1)
							local v157 = mathRandom(v155, v156)
							local floored = math.floor(numberRangeMax * 0.8)
							local v159 = math.max(1, floored)

							v155 = mathRandom(1, v159)
							v159 = math.max(1, numberRangeMin)

							local v160 = math.max(2, numberRangeMax + 1)

							groundRock.Size = Vector3.new(v157, v155, mathRandom(v159, v160))
						else
							local v161 = mathRandom(numberRangeMin, numberRangeMax)
							local v162 = mathRandom(numberRangeMin, numberRangeMax)

							groundRock.Size = Vector3.new(v161, v162, mathRandom(numberRangeMin, numberRangeMax))
						end
					else
						groundRock.Size = numberRange
					end

					if p15 then
						local vector3 = Vector3.new(0, groundRock.Size.Y * 0.35, 0)
						local n1 = p13 - vector3

						groundRock.Position = n1

						if u55 == true then
							local v165 = mathRandom(-25, 25)
							local v166 = mathRandom(-180, 180)

							groundRock.Orientation = Vector3.new(v165, v166, mathRandom(-25, 25))
						elseif u55 == "Middle" then
							local cFrame = CFrame.new(n1, n1 + p14)
							local cFrameAngles = CFrame.Angles
							local v169 = mathRandom(-20, 20)
							local v170 = math.rad(v169)
							local v171 = mathRandom(-20, 20)
							local v172 = math.rad(v171)
							local v173 = cFrameAngles(v170, 0, v172)

							groundRock.CFrame = cFrame * v173
						else
							groundRock.CFrame = CFrame.new(n1)
						end

						debris:AddItem(groundRock, 6.5)
						task.delay(4.75, function()
							if not groundRock or not groundRock.Parent then
								return
							end

							for _, v in ipairs(groundRock:GetChildren()) do
								if v:IsA("Texture") or v:IsA("Decal") then
									local v209 = tweenInfoNew(0.45, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

									tweenService:Create(v, v209, { Transparency = 1 }):Play()
								end
							end

							local v210 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
							local groundRockPosition: Vector3 = groundRock.Position
							local vector32 = Vector3.new(0, groundRock.Size.Y * 0.8, 0)

							tweenService:Create(groundRock, v210, {
								Size = Vector3.new(0, 0, 0),
								Position = groundRockPosition - vector32
							}):Play()
						end)

						return
					end

					local vector3 = Vector3.new(0, groundRock.Size.Y * 0.9, 0)
					local v175 = mathRandom(2, 6)
					local v176 = mathRandom(10, 18)
					local vector33 = Vector3.new(0, v176, 0)
					local n2 = p13 + p14 * v175 + vector33
					local v179 = mathRandom(1, 4)
					local vector34 = Vector3.new(0, groundRock.Size.Y * 0.35, 0)
					local n3 = p13 + p14 * v179 - vector34

					groundRock.Position = p13 - vector3

					if u55 == true then
						local v182 = mathRandom(-180, 180)
						local v183 = mathRandom(-180, 180)

						groundRock.Orientation = Vector3.new(v182, v183, mathRandom(-180, 180))
					end

					if u55 == true then
						local groundRockOrientation: Vector3 = groundRock.Orientation
						local v185 = mathRandom(60, 140)
						local v186 = mathRandom(60, 140)
						local vector35 = Vector3.new(v185, v186, mathRandom(60, 140))
						local n4 = groundRockOrientation + vector35
						local v189 = mathRandom(120, 220)

						v185 = mathRandom(120, 220)

						local vector36 = Vector3.new(v189, v185, mathRandom(120, 220))
						local n5 = n4 + vector36

						v186 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

						local v192: Tween = tweenService:Create(groundRock, v186, { Position = n2, Orientation = n4 })

						v192:Play()
						v192.Completed:Connect(function()
							if not groundRock or not groundRock.Parent then
								return
							end

							task.delay(0, function()
								if not groundRock or not groundRock.Parent then
									return
								end

								local v219 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

								tweenService:Create(groundRock, v219, { Position = n3, Orientation = n5 }):Play()
							end)
						end)
					elseif u55 == false then
						local cFrame = CFrame.new(n2, n2 + p14)
						local cFrame2 = CFrame.new(n3, n3 + p14)
						local v195 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						local v196: Tween = tweenService:Create(groundRock, v195, { CFrame = cFrame })

						v196:Play()
						v196.Completed:Connect(function()
							if not groundRock or not groundRock.Parent then
								return
							end

							task.delay(0, function()
								if not groundRock or not groundRock.Parent then
									return
								end

								local v220 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

								tweenService:Create(groundRock, v220, { CFrame = cFrame2 }):Play()
							end)
						end)
					elseif u55 == "Middle" then
						local cFrame = CFrame.new(n2, parent.Position)
						local angles = CFrame.Angles
						local v199 = mathRandom(-3.141592653589793, 3.141592653589793)
						local v200 = angles(v199, 0, 0)
						local cFrame3 = CFrame.new(n3, parent.Position)
						local v202 = CFrame.Angles
						local v203 = mathRandom(-3.141592653589793, 3.141592653589793)

						v199 = v202(v203, 0, 0)

						local n6 = cFrame3 * v199
						local v205 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						local v206: Tween = tweenService:Create(groundRock, v205, { CFrame = cFrame * v200 })

						v206:Play()
						v206.Completed:Connect(function()
							if not groundRock or not groundRock.Parent then
								return
							end

							task.delay(0, function()
								if not groundRock or not groundRock.Parent then
									return
								end

								local v221 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

								tweenService:Create(groundRock, v221, { CFrame = n6 }):Play()
							end)
						end)
					end

					debris:AddItem(groundRock, 6.5)
					task.delay(4.75, function()
						if not groundRock or not groundRock.Parent then
							return
						end

						for _, v in ipairs(groundRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v215 = tweenInfoNew(0.45, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v215, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v216 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
						local groundRockPosition: Vector3 = groundRock.Position
						local vector37 = Vector3.new(0, groundRock.Size.Y, 0)

						tweenService:Create(groundRock, v216, {
							Size = Vector3.new(0, 0, 0),
							Position = groundRockPosition - vector37
						}):Play()
					end)
				end

				local v60 = math.max(12, p6 * 0.4)
				local v61 = math.max(16, p6 * 0.4)
				local n1 = 0

				for _ = 1, math.floor(360 / v60) do
					local map: Instance = workspace:FindFirstChild("Map")
					local v65 = if map and map.Parent == workspace then map else nil
					local v67

					if not v65 then
						v67 = nil
					else
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { v65 }
						raycastParams.IgnoreWater = true
						v67 = raycastParams
					end

					if not v67 then
						break
					end

					local cFrame = p5.CFrame
					local cFrameAngles = CFrame.Angles
					local v71 = math.rad(n1)
					local v72 = cFrameAngles(0, v71, 0)
					local lookVector = (cFrame * v72).LookVector

					v72 = workspace:Raycast(p5.Position + lookVector * p9 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v67)

					if v72 then
						local instance = v72.Instance
						local v75 = instance

						if v75 then
							v75 = instance:IsA("BasePart") and instance.Parent and instance.CanCollide and instance.Transparency < 1
						end

						if v75 then
							makeRock(v72.Instance, v72.Position, lookVector, false)

							for _ = 1, mathRandom(0, 1) do
								local v77 = mathRandom(-10, 10)
								local v78 = mathRandom(-10, 10)
								local vector3 = Vector3.new(v77 / 20, 0, v78 / 20)
								local n2 = lookVector + vector3

								if n2.Magnitude > 0 then
									local v81 = v72.Instance
									local v82 = v72.Position
									local v83 = mathRandom(-2, 2)
									local vector38 = Vector3.new(v83, 0, mathRandom(-2, 2))

									makeRock(v81, v82 + vector38, n2.Unit, false)
								end
							end
						end
					end

					n1 += v60
				end

				n1 = 0

				for _ = 1, math.floor(360 / v61) do
					local map2: Instance = workspace:FindFirstChild("Map")
					local v87 = if map2 and map2.Parent == workspace then map2 else nil
					local v89

					if not v87 then
						v89 = nil
					else
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { v87 }
						raycastParams.IgnoreWater = true
						v89 = raycastParams
					end

					if not v89 then
						break
					end

					local v91 = p5.CFrame
					local angles = CFrame.Angles
					local v93 = math.rad(n1)
					local v94 = angles(0, v93, 0)
					local v95 = (v91 * v94).LookVector

					v94 = workspace:Raycast(p5.Position + v95 * (p9 * 0.75) + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v89)

					if v94 then
						local v96 = v94.Instance
						local v97 = v96

						if v97 then
							v97 = v96:IsA("BasePart") and v96.Parent and v96.CanCollide and v96.Transparency < 1
						end

						if v97 then
							makeRock(v94.Instance, v94.Position, v95, true)

							if mathRandom(1, 100) <= 25 then
								local v98 = v94.Instance
								local v99 = v94.Position
								local v100 = mathRandom(-2, 2)
								local vector3 = Vector3.new(v100, 0, mathRandom(-2, 2))

								makeRock(v98, v99 + vector3, v95, true)
							end
						end
					end

					n1 += v61
				end
			end)
		end

		local lungeCrack = game.ReplicatedStorage.Characters.Gigachad.Fx.LungeCrack
		local smoke = game.ReplicatedStorage.Characters.Gigachad.Fx.Smoke
		local rock = game.ReplicatedStorage.Characters.Gigachad.Fx.Rock
		local v17 = game.ReplicatedStorage.Characters.OmniMan.Fx.ClapShock.Clap
		local clapStop = game.ReplicatedStorage.Characters.OmniMan.Fx.ClapStop

		clap.OnClientEvent:Connect(function(player, parent)
			if not player:FindFirstChild("Humanoid") then
				local Character = player.Character
			end

			if not parent then
				return
			end

			local map: Instance = workspace:FindFirstChild("Map")
			local v38 = if map and map.Parent == workspace then map else nil
			local v40

			if not v38 then
				v40 = nil
			else
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v38 }
				raycastParams.IgnoreWater = true
				v40 = raycastParams
			end

			if not v40 then
				return
			end

			v38 = workspace:Raycast(parent.Position, parent.CFrame.UpVector * -6, v40)

			if v38 then
				local instance = v38.Instance
				local v43 = instance

				if v43 then
					v43 = instance:IsA("BasePart") and instance.Parent and instance.CanCollide and instance.Transparency < 1
				end

				if not v43 then
					return
				end

				v43 = v38.Instance.Color

				local clone = lungeCrack:Clone()

				clone.Parent = workspace
				clone.Size = clone.Size * 2
				clone.Position = v38.Position

				local randomNumber = math.random(-180, 180)

				clone.Orientation = Vector3.new(0, randomNumber, 0)
				debris:AddItem(clone, 10)

				if clone:FindFirstChild("Boom") then
					clone.Boom:Play()
				end

				local clone2 = smoke:Clone()

				clone2.Parent = clone
				clone2.Color = ColorSequence.new(v43)
				clone2:Emit(10)
				debris:AddItem(clone2, 7)

				local clone3 = rock:Clone()

				clone3.Parent = clone
				clone3.Color = ColorSequence.new(v43)
				clone3:Emit(30)
				debris:AddItem(clone3, 7)

				if clone:FindFirstChild("Decal") then
					tweenService:Create(clone.Decal, TweenInfo.new(5), { Transparency = 1 }):Play()
				end

				local clone4 = clapStop:Clone()

				clone4.Parent = workspace
				clone4.Position = v38.Position

				if clone4:IsA("BasePart") then
					local randomNumber2 = math.random(-180, 180)

					clone4.Orientation = Vector3.new(0, randomNumber2, 0)
				end

				debris:AddItem(clone4, 8)

				local smoke2 = clone4:FindFirstChild("Smoke")

				if smoke2 and smoke2:IsA("ParticleEmitter") then
					smoke2.Color = ColorSequence.new(v43)
					smoke2:Emit(10)
				end

				local rocks = clone4:FindFirstChild("Rocks")

				if rocks and rocks:IsA("ParticleEmitter") then
					rocks.Color = ColorSequence.new(v43)
					rocks:Emit(20)
				end

				if player.Character or player.CharacterAdded:Wait() then
					local numberRange = NumberRange.new(1, 3)
					local workspaceEffects = workspace.Effects
					local u54: boolean = true
					local u55: boolean = true
					local n1: number = 11
					local n2: number = 7.5

					task.spawn(function()
						local function makeRock(p12, p13, p14, p15)
							if not p12 or not p12:IsA("BasePart") or not p12.Parent or not p12.CanCollide or not (p12.Transparency < 1) then
								return
							end

							local groundRock: Part = Instance.new("Part")

							groundRock.Anchored = true
							groundRock.CanCollide = false
							groundRock.CanTouch = false
							groundRock.CanQuery = false
							groundRock.Material = p12.Material
							groundRock.Color = p12.Color
							groundRock.Name = "GroundRock"
							groundRock.Parent = workspaceEffects

							for _, v in ipairs(p12:GetChildren()) do
								if v:IsA("Decal") or v:IsA("Texture") then
									local clone = v:Clone()

									clone.Parent = groundRock
								end
							end

							if u54 == true then
								local numberRangeMin = numberRange.Min
								local numberRangeMax = numberRange.Max

								if p15 then
									local v155 = math.max(1, numberRangeMin)
									local v156 = math.max(2, numberRangeMax + 1)
									local v157 = mathRandom(v155, v156)
									local floored = math.floor(numberRangeMax * 0.8)
									local v159 = math.max(1, floored)

									v155 = mathRandom(1, v159)
									v159 = math.max(1, numberRangeMin)

									local v160 = math.max(2, numberRangeMax + 1)

									groundRock.Size = Vector3.new(v157, v155, mathRandom(v159, v160))
								else
									local v161 = mathRandom(numberRangeMin, numberRangeMax)
									local v162 = mathRandom(numberRangeMin, numberRangeMax)

									groundRock.Size = Vector3.new(v161, v162, mathRandom(numberRangeMin, numberRangeMax))
								end
							else
								groundRock.Size = numberRange
							end

							if p15 then
								local vector3 = Vector3.new(0, groundRock.Size.Y * 0.35, 0)
								local n1 = p13 - vector3

								groundRock.Position = n1

								if u55 == true then
									local v165 = mathRandom(-25, 25)
									local v166 = mathRandom(-180, 180)

									groundRock.Orientation = Vector3.new(v165, v166, mathRandom(-25, 25))
								elseif u55 == "Middle" then
									local cFrame = CFrame.new(n1, n1 + p14)
									local cFrameAngles = CFrame.Angles
									local v169 = mathRandom(-20, 20)
									local v170 = math.rad(v169)
									local v171 = mathRandom(-20, 20)
									local v172 = math.rad(v171)
									local v173 = cFrameAngles(v170, 0, v172)

									groundRock.CFrame = cFrame * v173
								else
									groundRock.CFrame = CFrame.new(n1)
								end

								debris:AddItem(groundRock, 6.5)
								task.delay(4.75, function()
									if not groundRock or not groundRock.Parent then
										return
									end

									for _, v in ipairs(groundRock:GetChildren()) do
										if v:IsA("Texture") or v:IsA("Decal") then
											local v209 = tweenInfoNew(0.45, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

											tweenService:Create(v, v209, { Transparency = 1 }):Play()
										end
									end

									local v210 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
									local groundRockPosition: Vector3 = groundRock.Position
									local vector32 = Vector3.new(0, groundRock.Size.Y * 0.8, 0)

									tweenService:Create(groundRock, v210, {
										Size = Vector3.new(0, 0, 0),
										Position = groundRockPosition - vector32
									}):Play()
								end)

								return
							end

							local vector3 = Vector3.new(0, groundRock.Size.Y * 0.9, 0)
							local v175 = mathRandom(2, 6)
							local v176 = mathRandom(10, 18)
							local vector33 = Vector3.new(0, v176, 0)
							local n2 = p13 + p14 * v175 + vector33
							local v179 = mathRandom(1, 4)
							local vector34 = Vector3.new(0, groundRock.Size.Y * 0.35, 0)
							local n3 = p13 + p14 * v179 - vector34

							groundRock.Position = p13 - vector3

							if u55 == true then
								local v182 = mathRandom(-180, 180)
								local v183 = mathRandom(-180, 180)

								groundRock.Orientation = Vector3.new(v182, v183, mathRandom(-180, 180))
							end

							if u55 == true then
								local groundRockOrientation: Vector3 = groundRock.Orientation
								local v185 = mathRandom(60, 140)
								local v186 = mathRandom(60, 140)
								local vector35 = Vector3.new(v185, v186, mathRandom(60, 140))
								local n4 = groundRockOrientation + vector35
								local v189 = mathRandom(120, 220)

								v185 = mathRandom(120, 220)

								local vector36 = Vector3.new(v189, v185, mathRandom(120, 220))
								local n5 = n4 + vector36

								v186 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

								local v192: Tween = tweenService:Create(groundRock, v186, { Position = n2, Orientation = n4 })

								v192:Play()
								v192.Completed:Connect(function()
									if not groundRock or not groundRock.Parent then
										return
									end

									task.delay(0, function()
										if not groundRock or not groundRock.Parent then
											return
										end

										local v219 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

										tweenService:Create(groundRock, v219, { Position = n3, Orientation = n5 }):Play()
									end)
								end)
							elseif u55 == false then
								local cFrame = CFrame.new(n2, n2 + p14)
								local cFrame2 = CFrame.new(n3, n3 + p14)
								local v195 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
								local v196: Tween = tweenService:Create(groundRock, v195, { CFrame = cFrame })

								v196:Play()
								v196.Completed:Connect(function()
									if not groundRock or not groundRock.Parent then
										return
									end

									task.delay(0, function()
										if not groundRock or not groundRock.Parent then
											return
										end

										local v220 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

										tweenService:Create(groundRock, v220, { CFrame = cFrame2 }):Play()
									end)
								end)
							elseif u55 == "Middle" then
								local cFrame = CFrame.new(n2, parent.Position)
								local angles = CFrame.Angles
								local v199 = mathRandom(-3.141592653589793, 3.141592653589793)
								local v200 = angles(v199, 0, 0)
								local cFrame3 = CFrame.new(n3, parent.Position)
								local v202 = CFrame.Angles
								local v203 = mathRandom(-3.141592653589793, 3.141592653589793)

								v199 = v202(v203, 0, 0)

								local n6 = cFrame3 * v199
								local v205 = tweenInfoNew(0.36, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
								local v206: Tween = tweenService:Create(groundRock, v205, { CFrame = cFrame * v200 })

								v206:Play()
								v206.Completed:Connect(function()
									if not groundRock or not groundRock.Parent then
										return
									end

									task.delay(0, function()
										if not groundRock or not groundRock.Parent then
											return
										end

										local v221 = tweenInfoNew(0.44, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

										tweenService:Create(groundRock, v221, { CFrame = n6 }):Play()
									end)
								end)
							end

							debris:AddItem(groundRock, 6.5)
							task.delay(4.75, function()
								if not groundRock or not groundRock.Parent then
									return
								end

								for _, v in ipairs(groundRock:GetChildren()) do
									if v:IsA("Texture") or v:IsA("Decal") then
										local v215 = tweenInfoNew(0.45, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

										tweenService:Create(v, v215, { Transparency = 1 }):Play()
									elseif v:IsA("ParticleEmitter") then
										v.Enabled = false
									end
								end

								local v216 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
								local groundRockPosition: Vector3 = groundRock.Position
								local vector37 = Vector3.new(0, groundRock.Size.Y, 0)

								tweenService:Create(groundRock, v216, {
									Size = Vector3.new(0, 0, 0),
									Position = groundRockPosition - vector37
								}):Play()
							end)
						end

						local v103 = math.max(12, n1 * 0.4)
						local v104 = math.max(16, n1 * 0.4)
						local n3 = 0

						for _ = 1, math.floor(360 / v103) do
							local map3: Instance = workspace:FindFirstChild("Map")
							local v108 = if map3 and map3.Parent == workspace then map3 else nil
							local v110

							if not v108 then
								v110 = nil
							else
								local raycastParams = RaycastParams.new()

								raycastParams.FilterType = Enum.RaycastFilterType.Include
								raycastParams.FilterDescendantsInstances = { v108 }
								raycastParams.IgnoreWater = true
								v110 = raycastParams
							end

							if not v110 then
								break
							end

							local cFrame = parent.CFrame
							local cFrameAngles = CFrame.Angles
							local v114 = math.rad(n3)
							local v115 = cFrameAngles(0, v114, 0)
							local lookVector = (cFrame * v115).LookVector

							v115 = workspace:Raycast(parent.Position + lookVector * n2 + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v110)

							if v115 then
								local instance = v115.Instance
								local v118 = instance

								if v118 then
									v118 = instance:IsA("BasePart") and instance.Parent and instance.CanCollide and instance.Transparency < 1
								end

								if v118 then
									makeRock(v115.Instance, v115.Position, lookVector, false)

									for _ = 1, mathRandom(0, 1) do
										local v120 = mathRandom(-10, 10)
										local v121 = mathRandom(-10, 10)
										local vector3 = Vector3.new(v120 / 20, 0, v121 / 20)
										local n4 = lookVector + vector3

										if n4.Magnitude > 0 then
											local v124 = v115.Instance
											local v125 = v115.Position
											local v126 = mathRandom(-2, 2)
											local vector39 = Vector3.new(v126, 0, mathRandom(-2, 2))

											makeRock(v124, v125 + vector39, n4.Unit, false)
										end
									end
								end
							end

							n3 += v103
						end

						n3 = 0

						for _ = 1, math.floor(360 / v104) do
							local map4: Instance = workspace:FindFirstChild("Map")
							local v130 = if map4 and map4.Parent == workspace then map4 else nil
							local v132

							if not v130 then
								v132 = nil
							else
								local raycastParams = RaycastParams.new()

								raycastParams.FilterType = Enum.RaycastFilterType.Include
								raycastParams.FilterDescendantsInstances = { v130 }
								raycastParams.IgnoreWater = true
								v132 = raycastParams
							end

							if not v132 then
								break
							end

							local parentCFrame = parent.CFrame
							local angles = CFrame.Angles
							local v136 = math.rad(n3)
							local v137 = angles(0, v136, 0)
							local v138 = (parentCFrame * v137).LookVector

							v137 = workspace:Raycast(parent.Position + v138 * (n2 * 0.75) + Vector3.new(0, 8, 0), Vector3.new(0, -30, 0), v132)

							if v137 then
								local v139 = v137.Instance
								local v140 = v139

								if v140 then
									v140 = v139:IsA("BasePart") and v139.Parent and v139.CanCollide and v139.Transparency < 1
								end

								if v140 then
									makeRock(v137.Instance, v137.Position, v138, true)

									if mathRandom(1, 100) <= 25 then
										local v141 = v137.Instance
										local v142 = v137.Position
										local v143 = mathRandom(-2, 2)
										local vector3 = Vector3.new(v143, 0, mathRandom(-2, 2))

										makeRock(v141, v142 + vector3, v138, true)
									end
								end
							end

							n3 += v104
						end
					end)

					local clone5 = v17:Clone()

					clone5.Parent = parent

					if clone5:FindFirstChild("Ring") then
						clone5.Ring:Emit(3)
					end

					if clone5:FindFirstChild("Ring2") then
						clone5.Ring2:Emit(1)
					end
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.GroundEffect", result)
	end
end)

return true
