-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local groundBreakDecal = game.ReplicatedStorage.Movement.Rocks.Fx.GroundBreakDecal
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local workspaceMap = workspace.Map
		local medBoom = game.ReplicatedStorage.Movement.Rocks.Sfx.MedBoom

		local function Rockfun(_, p2)
			task.spawn(function()
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspaceMap }

				local v22 = workspace:Raycast(p2.WorldPosition, p2.CFrame.UpVector * -6, raycastParams)

				if v22 ~= nil then
					local part: Part = Instance.new("Part")

					part.Position = v22.Position

					local randomNumber = math.random(-2, 2)
					local partCFrame: CFrame = part.CFrame
					local vector3 = Vector3.new(randomNumber, 0, 0)

					part.CFrame = partCFrame + vector3
					part.Parent = workspace
					part.Anchored = true
					part.Size = Vector3.new(0, 0, 0)
					part.CanCollide = false
					part.CanTouch = false
					game.Debris:AddItem(part, 3)

					local randomNumber2 = math.random(2, 2.5)
					local randomNumber3 = math.random(360)
					local v29 = math.rad(randomNumber3)
					local randomNumber4 = math.random(360)
					local v31 = math.rad(randomNumber4)
					local randomNumber5 = math.random(360)
					local v33 = math.rad(randomNumber5)
					local TweenService = game.TweenService
					local cFrame = CFrame.new(part.Position)
					local v36 = CFrame.Angles(v29, v31, v33)

					TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v36 }):Play()

					local TweenService2 = game.TweenService
					local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

					TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
					part.Material = v22.Material
					part.Color = v22.Instance.Color

					local clone = smoke:Clone()

					clone.Parent = part

					local colorSequenceNew = ColorSequence.new
					local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

					clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
					clone:Emit(2)

					if math.random(1, 3) == 1 then
						for _ = 1, 1 do
							local explosionPart: Part = Instance.new("Part")

							explosionPart.Anchored = false
							explosionPart.Name = "ExplosionPart"

							local randomNumber6 = math.random(1.5, 2.5)
							local randomNumber7 = math.random(1.5, 2.5)

							explosionPart.Size = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))
							explosionPart.Material = part.Material
							explosionPart.CanCollide = true
							explosionPart.CFrame = part.CFrame
							explosionPart.Color = v22.Instance.Color

							local randomNumber8 = math.random(-80, 80)
							local randomNumber9 = math.random(0, 80)

							explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

							local cFrame2 = CFrame.new(part.Position)
							local v49 = CFrame.Angles(v29, v31, v33)

							explosionPart.CFrame = cFrame2 * v49
							explosionPart.Parent = workspace
							game.Debris:AddItem(explosionPart, 3)

							local part2: Part = Instance.new("Part")

							part2.Anchored = false
							part2.Name = "ExplosionPart"
							part2.Size = Vector3.new(0, 0, 0)
							part2.Material = part.Material
							part2.CanCollide = true
							part2.CFrame = part.CFrame
							part2.Color = v22.Instance.Color
							game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

							local randomNumber10 = math.random(-40, 40)
							local randomNumber11 = math.random(0, 40)

							part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

							local cFrame3 = CFrame.new(part.Position)
							local v54 = CFrame.Angles(v29, v31, v33)

							part2.CFrame = cFrame3 * v54
							part2.Parent = workspace
							game.Debris:AddItem(part2, 3)
							task.delay(2, function()
								game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end)
						end
					end

					local randomNumber12 = math.random(2, 2.3)

					task.delay(randomNumber12, function()
						local randomNumber13 = math.random(360)
						local v127 = math.rad(randomNumber13)
						local randomNumber14 = math.random(360)
						local v129 = math.rad(randomNumber14)
						local randomNumber15 = math.random(360)
						local v131 = math.rad(randomNumber15)
						local TweenService3 = game.TweenService
						local cFrame4 = CFrame.new(part.Position)
						local v134 = CFrame.Angles(v127, v129, v131)

						TweenService3:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v134 }):Play()
						game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
						game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
					end)
				end
			end)
		end
		local function Force1(p3)
			local smallMoveVel: BodyVelocity = Instance.new("BodyVelocity", p3.HumanoidRootPart)

			smallMoveVel.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			smallMoveVel.Parent = p3.HumanoidRootPart

			local n1 = Vector3.new(1, 1, 1) * p3:WaitForChild("HumanoidRootPart").CFrame.LookVector
			local randomNumber = math.random(-2, 2)

			smallMoveVel.Velocity = n1 * randomNumber
			smallMoveVel.Name = "SmallMoveVel"
			game.Debris:AddItem(smallMoveVel, 0.3)
		end

		game.ReplicatedStorage.Characters.OmniMan.Remotes.Flight.OnClientEvent:Connect(function(player)
			local Character = nil

			if typeof(player) == "Instance" and player:IsA("Player") then
				Character = player.Character
			elseif typeof(player) == "Instance" and player:IsA("Model") then
				Character = player
			end

			if not Character then
				return
			end

			local humanoidRootPart = Character:WaitForChild("HumanoidRootPart", 5)

			if not humanoidRootPart then
				return
			end

			task.wait(1.5)

			local n1: number = 0

			while true do
				local at1 = humanoidRootPart:FindFirstChild("At1")
				local at2 = humanoidRootPart:FindFirstChild("At2")

				if at1 then
					task.spawn(function()
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspaceMap }

						local v57 = workspace:Raycast(at1.WorldPosition, at1.CFrame.UpVector * -6, raycastParams)

						if v57 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v57.Position

							local randomNumber = math.random(-2, 2)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber16 = math.random(2, 2.5)
							local randomNumber17 = math.random(360)
							local v64 = math.rad(randomNumber17)
							local randomNumber18 = math.random(360)
							local v66 = math.rad(randomNumber18)
							local randomNumber19 = math.random(360)
							local v68 = math.rad(randomNumber19)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v71 = CFrame.Angles(v64, v66, v68)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v71 }):Play()

							local TweenService4 = game.TweenService
							local vector33 = Vector3.new(randomNumber16, randomNumber16, randomNumber16)

							TweenService4:Create(part, TweenInfo.new(0.25), { Size = vector33 }):Play()
							part.Material = v57.Material
							part.Color = v57.Instance.Color

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"

									local randomNumber20 = math.random(1.5, 2.5)
									local randomNumber21 = math.random(1.5, 2.5)

									explosionPart.Size = Vector3.new(randomNumber20, randomNumber21, math.random(1.5, 2.5))
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v57.Instance.Color

									local randomNumber22 = math.random(-80, 80)
									local randomNumber23 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber22, randomNumber23, math.random(-80, 80))

									local cFrame5 = CFrame.new(part.Position)
									local v84 = CFrame.Angles(v64, v66, v68)

									explosionPart.CFrame = cFrame5 * v84
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part3: Part = Instance.new("Part")

									part3.Anchored = false
									part3.Name = "ExplosionPart"
									part3.Size = Vector3.new(0, 0, 0)
									part3.Material = part.Material
									part3.CanCollide = true
									part3.CFrame = part.CFrame
									part3.Color = v57.Instance.Color
									game.TweenService:Create(part3, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber24 = math.random(-40, 40)
									local randomNumber25 = math.random(0, 40)

									part3.Velocity = Vector3.new(randomNumber24, randomNumber25, math.random(-40, 40))

									local cFrame6 = CFrame.new(part.Position)
									local v89 = CFrame.Angles(v64, v66, v68)

									part3.CFrame = cFrame6 * v89
									part3.Parent = workspace
									game.Debris:AddItem(part3, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part3, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber26 = math.random(2, 2.3)

							task.delay(randomNumber26, function()
								local randomNumber27 = math.random(360)
								local v136 = math.rad(randomNumber27)
								local randomNumber28 = math.random(360)
								local v138 = math.rad(randomNumber28)
								local randomNumber29 = math.random(360)
								local v140 = math.rad(randomNumber29)
								local TweenService5 = game.TweenService
								local cFrame7 = CFrame.new(part.Position)
								local v143 = CFrame.Angles(v136, v138, v140)

								TweenService5:Create(part, TweenInfo.new(0.5), { CFrame = cFrame7 * v143 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end)
				end

				if at2 then
					task.spawn(function()
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspaceMap }

						local v92 = workspace:Raycast(at2.WorldPosition, at2.CFrame.UpVector * -6, raycastParams)

						if v92 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v92.Position

							local randomNumber = math.random(-2, 2)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber30 = math.random(2, 2.5)
							local randomNumber31 = math.random(360)
							local v99 = math.rad(randomNumber31)
							local randomNumber32 = math.random(360)
							local v101 = math.rad(randomNumber32)
							local randomNumber33 = math.random(360)
							local v103 = math.rad(randomNumber33)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v106 = CFrame.Angles(v99, v101, v103)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v106 }):Play()

							local TweenService6 = game.TweenService
							local vector34 = Vector3.new(randomNumber30, randomNumber30, randomNumber30)

							TweenService6:Create(part, TweenInfo.new(0.25), { Size = vector34 }):Play()
							part.Material = v92.Material
							part.Color = v92.Instance.Color

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"

									local randomNumber34 = math.random(1.5, 2.5)
									local randomNumber35 = math.random(1.5, 2.5)

									explosionPart.Size = Vector3.new(randomNumber34, randomNumber35, math.random(1.5, 2.5))
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v92.Instance.Color

									local randomNumber36 = math.random(-80, 80)
									local randomNumber37 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber36, randomNumber37, math.random(-80, 80))

									local cFrame8 = CFrame.new(part.Position)
									local v119 = CFrame.Angles(v99, v101, v103)

									explosionPart.CFrame = cFrame8 * v119
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part4: Part = Instance.new("Part")

									part4.Anchored = false
									part4.Name = "ExplosionPart"
									part4.Size = Vector3.new(0, 0, 0)
									part4.Material = part.Material
									part4.CanCollide = true
									part4.CFrame = part.CFrame
									part4.Color = v92.Instance.Color
									game.TweenService:Create(part4, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber38 = math.random(-40, 40)
									local randomNumber39 = math.random(0, 40)

									part4.Velocity = Vector3.new(randomNumber38, randomNumber39, math.random(-40, 40))

									local cFrame9 = CFrame.new(part.Position)
									local v124 = CFrame.Angles(v99, v101, v103)

									part4.CFrame = cFrame9 * v124
									part4.Parent = workspace
									game.Debris:AddItem(part4, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part4, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber40 = math.random(2, 2.3)

							task.delay(randomNumber40, function()
								local randomNumber41 = math.random(360)
								local v145 = math.rad(randomNumber41)
								local randomNumber42 = math.random(360)
								local v147 = math.rad(randomNumber42)
								local randomNumber43 = math.random(360)
								local v149 = math.rad(randomNumber43)
								local TweenService7 = game.TweenService
								local cFrame10 = CFrame.new(part.Position)
								local v152 = CFrame.Angles(v145, v147, v149)

								TweenService7:Create(part, TweenInfo.new(0.5), { CFrame = cFrame10 * v152 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end)
				end

				task.wait(0.1)

				if at1 then
					task.spawn(function()
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspaceMap }

						local v57 = workspace:Raycast(at1.WorldPosition, at1.CFrame.UpVector * -6, raycastParams)

						if v57 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v57.Position

							local randomNumber = math.random(-2, 2)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber16 = math.random(2, 2.5)
							local randomNumber17 = math.random(360)
							local v64 = math.rad(randomNumber17)
							local randomNumber18 = math.random(360)
							local v66 = math.rad(randomNumber18)
							local randomNumber19 = math.random(360)
							local v68 = math.rad(randomNumber19)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v71 = CFrame.Angles(v64, v66, v68)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v71 }):Play()

							local TweenService4 = game.TweenService
							local vector33 = Vector3.new(randomNumber16, randomNumber16, randomNumber16)

							TweenService4:Create(part, TweenInfo.new(0.25), { Size = vector33 }):Play()
							part.Material = v57.Material
							part.Color = v57.Instance.Color

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"

									local randomNumber20 = math.random(1.5, 2.5)
									local randomNumber21 = math.random(1.5, 2.5)

									explosionPart.Size = Vector3.new(randomNumber20, randomNumber21, math.random(1.5, 2.5))
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v57.Instance.Color

									local randomNumber22 = math.random(-80, 80)
									local randomNumber23 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber22, randomNumber23, math.random(-80, 80))

									local cFrame5 = CFrame.new(part.Position)
									local v84 = CFrame.Angles(v64, v66, v68)

									explosionPart.CFrame = cFrame5 * v84
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part3: Part = Instance.new("Part")

									part3.Anchored = false
									part3.Name = "ExplosionPart"
									part3.Size = Vector3.new(0, 0, 0)
									part3.Material = part.Material
									part3.CanCollide = true
									part3.CFrame = part.CFrame
									part3.Color = v57.Instance.Color
									game.TweenService:Create(part3, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber24 = math.random(-40, 40)
									local randomNumber25 = math.random(0, 40)

									part3.Velocity = Vector3.new(randomNumber24, randomNumber25, math.random(-40, 40))

									local cFrame6 = CFrame.new(part.Position)
									local v89 = CFrame.Angles(v64, v66, v68)

									part3.CFrame = cFrame6 * v89
									part3.Parent = workspace
									game.Debris:AddItem(part3, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part3, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber26 = math.random(2, 2.3)

							task.delay(randomNumber26, function()
								local randomNumber27 = math.random(360)
								local v136 = math.rad(randomNumber27)
								local randomNumber28 = math.random(360)
								local v138 = math.rad(randomNumber28)
								local randomNumber29 = math.random(360)
								local v140 = math.rad(randomNumber29)
								local TweenService5 = game.TweenService
								local cFrame7 = CFrame.new(part.Position)
								local v143 = CFrame.Angles(v136, v138, v140)

								TweenService5:Create(part, TweenInfo.new(0.5), { CFrame = cFrame7 * v143 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end)
				end

				if at2 then
					task.spawn(function()
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspaceMap }

						local v92 = workspace:Raycast(at2.WorldPosition, at2.CFrame.UpVector * -6, raycastParams)

						if v92 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v92.Position

							local randomNumber = math.random(-2, 2)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber30 = math.random(2, 2.5)
							local randomNumber31 = math.random(360)
							local v99 = math.rad(randomNumber31)
							local randomNumber32 = math.random(360)
							local v101 = math.rad(randomNumber32)
							local randomNumber33 = math.random(360)
							local v103 = math.rad(randomNumber33)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v106 = CFrame.Angles(v99, v101, v103)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v106 }):Play()

							local TweenService6 = game.TweenService
							local vector34 = Vector3.new(randomNumber30, randomNumber30, randomNumber30)

							TweenService6:Create(part, TweenInfo.new(0.25), { Size = vector34 }):Play()
							part.Material = v92.Material
							part.Color = v92.Instance.Color

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"

									local randomNumber34 = math.random(1.5, 2.5)
									local randomNumber35 = math.random(1.5, 2.5)

									explosionPart.Size = Vector3.new(randomNumber34, randomNumber35, math.random(1.5, 2.5))
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v92.Instance.Color

									local randomNumber36 = math.random(-80, 80)
									local randomNumber37 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber36, randomNumber37, math.random(-80, 80))

									local cFrame8 = CFrame.new(part.Position)
									local v119 = CFrame.Angles(v99, v101, v103)

									explosionPart.CFrame = cFrame8 * v119
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part4: Part = Instance.new("Part")

									part4.Anchored = false
									part4.Name = "ExplosionPart"
									part4.Size = Vector3.new(0, 0, 0)
									part4.Material = part.Material
									part4.CanCollide = true
									part4.CFrame = part.CFrame
									part4.Color = v92.Instance.Color
									game.TweenService:Create(part4, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber38 = math.random(-40, 40)
									local randomNumber39 = math.random(0, 40)

									part4.Velocity = Vector3.new(randomNumber38, randomNumber39, math.random(-40, 40))

									local cFrame9 = CFrame.new(part.Position)
									local v124 = CFrame.Angles(v99, v101, v103)

									part4.CFrame = cFrame9 * v124
									part4.Parent = workspace
									game.Debris:AddItem(part4, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part4, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber40 = math.random(2, 2.3)

							task.delay(randomNumber40, function()
								local randomNumber41 = math.random(360)
								local v145 = math.rad(randomNumber41)
								local randomNumber42 = math.random(360)
								local v147 = math.rad(randomNumber42)
								local randomNumber43 = math.random(360)
								local v149 = math.rad(randomNumber43)
								local TweenService7 = game.TweenService
								local cFrame10 = CFrame.new(part.Position)
								local v152 = CFrame.Angles(v145, v147, v149)

								TweenService7:Create(part, TweenInfo.new(0.5), { CFrame = cFrame10 * v152 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end)
				end

				n1 += 1

				if n1 == 15 then
					break
				end
			end

			Character:WaitForChild("Humanoid", 5):ChangeState(Enum.HumanoidStateType.Jumping)
			Force1(Character)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "OmniMan.Flight", result)
	end
end)

return true
