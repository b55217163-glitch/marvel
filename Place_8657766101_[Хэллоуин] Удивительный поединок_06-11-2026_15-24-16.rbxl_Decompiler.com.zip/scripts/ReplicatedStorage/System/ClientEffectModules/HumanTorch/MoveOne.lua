-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local moveOne = game.ReplicatedStorage.Characters.HumanTorch.Remotes.MoveOne
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		local function shouldStop(p1)
			if not p1 or not p1.Parent then
				return true
			end

			if p1:GetAttribute("StopRockFx") == true then
				return true
			end

			local f1 = p1:FindFirstChild("F1")

			if not f1 then
				return true
			end

			if f1:IsA("ParticleEmitter") and f1.Enabled == false then
				return true
			end

			return false
		end

		moveOne.OnClientEvent:Connect(function(p2)
			if shouldStop(p2) then
				return
			end

			for _ = 1, 40 do
				if shouldStop(p2) then
					break
				end

				for _, v in ipairs(p2:GetChildren()) do
					if shouldStop(p2) then
						break
					end

					if v.Name == "RockAt" then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v15 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v15 then
							local v16 = v15.Instance:IsA("BasePart") and v15.Instance.Color

							if not v16 then
								v16 = Color3.new(1, 1, 1)
							end

							local part: Part = Instance.new("Part")
							local randomNumber = math.random()
							local v19 = v15.Position
							local vector3 = Vector3.new(-0.1 + randomNumber * 0.2, 0, 0)

							part.Position = v19 + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							part.CanQuery = false
							part.Material = v15.Material
							part.Color = v16
							debris:AddItem(part, 3)

							local n1 = 2 + math.random() * 0.5
							local randomNumber2 = math.random(360)
							local v23 = math.rad(randomNumber2)
							local randomNumber3 = math.random(360)

							v19 = math.rad(randomNumber3)

							local randomNumber4 = math.random(360)
							local v26 = math.rad(randomNumber4)
							local cFrame = CFrame.new(part.Position)
							local v28 = CFrame.Angles(v23, v19, v26)

							tweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v28 }):Play()

							local vector32 = Vector3.new(n1, n1, n1)

							tweenService:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"
								explosionPart.Size = Vector3.new(0, 0, 0)
								explosionPart.Material = part.Material
								explosionPart.CanCollide = false
								explosionPart.CanTouch = false
								explosionPart.CanQuery = false

								local cFrame2 = CFrame.new(part.Position)
								local v35 = CFrame.Angles(v23, v19, v26)

								explosionPart.CFrame = cFrame2 * v35
								explosionPart.Color = v16
								explosionPart.Parent = workspace

								local randomNumber5 = math.random(-80, 80)
								local randomNumber6 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber5, randomNumber6, math.random(-80, 80))
								debris:AddItem(explosionPart, 3)

								local randomNumber7 = math.random()
								local randomNumber8 = math.random()
								local randomNumber9 = math.random()
								local vector33 = Vector3.new(1.5 + randomNumber7, 1.5 + randomNumber8, 1.5 + randomNumber9)

								tweenService:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

								local part2: Part = Instance.new("Part")

								part2.Anchored = false
								part2.Name = "ExplosionPart"
								part2.Size = Vector3.new(0, 0, 0)
								part2.Material = part.Material
								part2.CanCollide = false
								part2.CanTouch = false
								part2.CanQuery = false

								local cFrame3 = CFrame.new(part.Position)
								local v44 = CFrame.Angles(v23, v19, v26)

								part2.CFrame = cFrame3 * v44
								part2.Color = v16
								part2.Parent = workspace

								local randomNumber10 = math.random(-40, 40)
								local randomNumber11 = math.random(0, 40)

								part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))
								debris:AddItem(part2, 3)
								tweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()
								task.delay(2, function()
									if explosionPart and explosionPart.Parent then
										tweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end

									if part2 and part2.Parent then
										tweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end
								end)
							end

							local randomNumber12 = math.random()

							task.delay(2 + randomNumber12 * 0.3, function()
								if not part or not part.Parent then
									return
								end

								local randomNumber13 = math.random(360)
								local v49 = math.rad(randomNumber13)
								local randomNumber14 = math.random(360)
								local v51 = math.rad(randomNumber14)
								local randomNumber15 = math.random(360)
								local v53 = math.rad(randomNumber15)
								local cFrame4 = CFrame.new(part.Position + Vector3.new(0, -3, 0))
								local v55 = CFrame.Angles(v49, v51, v53)

								tweenService:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v55 }):Play()
								tweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end)
						end
					end
				end

				task.wait(0.1)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "HumanTorch.MoveOne", result)
	end
end)

return true
