-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local LocalPlayer: Player = game:GetService("Players").LocalPlayer
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local debris: Debris = game:GetService("Debris")
		local contentProvider: ContentProvider = game:GetService("ContentProvider")
		local CurrentCamera: Camera = game:GetService("Workspace").CurrentCamera
		local hitEffect: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat"):WaitForChild("Remotes"):WaitForChild("HitEffect")
		local localHitEffect = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat"):WaitForChild("Remotes"):FindFirstChild("LocalHitEffect")

		if not localHitEffect then
			localHitEffect = Instance.new("BindableEvent")
			localHitEffect.Name = "LocalHitEffect"
			localHitEffect.Parent = replicatedStorage.Characters.Combat.Remotes
		end

		local hitAt = replicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local hitAtKratos = replicatedStorage.Characters.Combat.Fx.CombatHit.HitAtKratos
		local hitSound = replicatedStorage.Characters.CombatFolder.Sounds.HitSound
		local hitSound2 = replicatedStorage.Characters.CombatFolder.Sounds.HitSound2
		local hitSound3 = replicatedStorage.Characters.CombatFolder.Sounds.HitSound3
		local saberHit = replicatedStorage.Characters.Combat.Fx.CombatHit.SaberHit
		local minecraftHits = replicatedStorage.Characters.Combat.Fx.CombatHit.MinecraftHits
		local bassHit = replicatedStorage.Characters.CombatFolder.Sounds.BassHit
		local knifeHitSound = replicatedStorage.Characters.Combat.Fx.CombatHit.KnifeHitSound
		local v20 = replicatedStorage.Characters.Combat.Fx.CombatHit.KnifeHitSound
		local pixelHit = replicatedStorage.Characters.Combat.Fx.CombatHit.PixelHit
		local paulSlash1 = replicatedStorage.Characters.Combat.Fx.CombatHit.PaulSlash1
		local paulSlash2 = replicatedStorage.Characters.Combat.Fx.CombatHit.PaulSlash2
		local spikeBatHitSound = replicatedStorage.Characters.Combat.Fx.CombatHit.SpikeBatHitSound
		local spikeBatHitSound2 = replicatedStorage.Characters.Combat.Fx.CombatHit.SpikeBatHitSound2
		local spikeBatHitSound3 = replicatedStorage.Characters.Combat.Fx.CombatHit.SpikeBatHitSound3
		local mSpear1 = replicatedStorage.Characters.Combat.Fx.CombatHit.MSpear1
		local mSpear2 = replicatedStorage.Characters.Combat.Fx.CombatHit.MSpear2
		local mSpear3 = replicatedStorage.Characters.Combat.Fx.CombatHit.MSpear3
		local wandaCombat = replicatedStorage.Characters.Combat.Fx.CombatHit.WandaCombat
		local bulletHit1 = replicatedStorage.Characters.Combat.Fx.CombatHit.BulletHit1
		local bulletHit2 = replicatedStorage.Characters.Combat.Fx.CombatHit.BulletHit2
		local bulletHit3 = replicatedStorage.Characters.Combat.Fx.CombatHit.BulletHit3
		local axeHitSound = replicatedStorage.Characters.Combat.Fx.CombatHit.AxeHitSound
		local hit1 = replicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = replicatedStorage.Characters.Combat.Animations.Hit2
		local t1: {[any]: any} = { mSpear1, mSpear2, mSpear3 }
		local t2: {[any]: any} = {
			replicatedStorage.Characters.Combat.Fx.CombatHit.Metal1,
			replicatedStorage.Characters.Combat.Fx.CombatHit.Metal2,
			replicatedStorage.Characters.Combat.Fx.CombatHit.Metal3
		}
		local t3: {[any]: any} = { spikeBatHitSound, spikeBatHitSound2, spikeBatHitSound3 }
		local t4: {[any]: any} = { bulletHit1, bulletHit2, bulletHit3 }
		local t5: {[any]: any} = { axeHitSound, axeHitSound, axeHitSound }
		local random = Random.new()
		local u43 = nil

		local function refreshMyHRP()
			local Character: Model = LocalPlayer.Character

			u43 = Character and Character:FindFirstChild("HumanoidRootPart") or nil
		end

		LocalPlayer.CharacterAdded:Connect(function()
			task.defer(refreshMyHRP)
		end)
		LocalPlayer.CharacterRemoving:Connect(function()
			u43 = nil
		end)

		local Character: Model = LocalPlayer.Character

		u43 = Character and Character:FindFirstChild("HumanoidRootPart") or nil

		local object = setmetatable({}, { __mode = "k" })
		local object2 = setmetatable({}, { __mode = "k" })

		local function shouldProcess(p1, p2)
			local v61 = os.clock()

			if v61 - (object[p1] or 0) < (p2 or 0.04) then
				return false
			end

			object[p1] = v61

			return true
		end
		local function sqrMag(p3, p4)
			local n1 = p3 - p4

			return n1:Dot(n1)
		end
		local function inHardRange(p5)
			if u43 and p5 then
				local n1 = u43.Position - p5.Position

				return n1:Dot(n1) <= 18496
			end

			if CurrentCamera and p5 then
				local n2 = CurrentCamera.CFrame.Position - p5.Position

				return n2:Dot(n2) <= 18496
			end

			return true
		end
		local function tooFarForHeavyFX(p6)
			if CurrentCamera and p6 then
				local n1 = CurrentCamera.CFrame.Position - p6.Position

				return n1:Dot(n1) > 14400
			end

			return false
		end

		task.spawn(function()
			pcall(function()
				contentProvider:PreloadAsync({
					hit1,
					hit2,
					hitAt,
					hitAtKratos,
					hitSound,
					hitSound2,
					hitSound3,
					saberHit,
					minecraftHits,
					bassHit,
					knifeHitSound,
					v20,
					pixelHit,
					paulSlash1,
					paulSlash2,
					spikeBatHitSound,
					spikeBatHitSound2,
					spikeBatHitSound3,
					mSpear1,
					mSpear2,
					mSpear3,
					wandaCombat,
					bulletHit1,
					bulletHit2,
					bulletHit3
				})
			end)
		end)

		local function playSound(p7, parent, playbackSpeed, p10)
			if p7 and parent then
				local clone = p7:Clone()

				clone.Parent = parent

				if playbackSpeed then
					clone.PlaybackSpeed = playbackSpeed
				end

				pcall(function()
					clone.RollOffMode = Enum.RollOffMode.Linear
					clone.RollOffMinDistance = 12
					clone.RollOffMaxDistance = 136
					clone.EmitterSize = 5
				end)
				clone:Play()
				debris:AddItem(clone, p10 or 2)

				return clone
			end

			return nil
		end
		local function playEffect(p11, parent, p13, p14)
			if p11 and parent then
				local clone = p11:Clone()

				clone.Parent = parent

				if p13 then
					for k, v in pairs(p13) do
						local foundChild = clone:FindFirstChild(k, true)

						if foundChild and foundChild:IsA("ParticleEmitter") then
							foundChild:Emit(v)
						end
					end
				end

				debris:AddItem(clone, p14 or 1)

				return clone
			end

			return nil
		end

		local object3 = setmetatable({}, { __mode = "k" })

		local function getTracks(parent)
			if not parent then
				return nil, nil
			end

			local animator = parent:FindFirstChildOfClass("Animator")

			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = parent
			end

			local t6 = object3[animator]

			local function valid(p16)
				return p16 and p16.Parent ~= nil
			end

			local t1 = t6.t1
			local t2 = t6.t2

			if not t6 or not t1 or t1.Parent == nil or not t2 or t2.Parent == nil then
				if hit1 and hit1:IsA("Animation") and hit1.AnimationId ~= "" then
					if hit2 and hit2:IsA("Animation") and hit2.AnimationId ~= "" then
						local v89 = animationService.GetTrack(animator, hit1)
						local v90 = animationService.GetTrack(animator, hit2)
						t6 = { t1 = v89, t2 = v90 }
						object3[animator] = t6

						return t6.t1, t6.t2
					end

					return nil, nil
				end

				return nil, nil
			end

			return t6.t1, t6.t2
		end
		local function playAnimation(p17, p18)
			if not p17 then
				return
			end

			p17:Play()

			if p18 then
				p17:AdjustSpeed(p18)
			end
		end
		local function randomPlayAnimation(p19, p20, p21)
			if random:NextNumber() < 0.5 then
				if not p19 then
					return
				end

				p19:Play()

				if p21 then
					p19:AdjustSpeed(p21)

					return
				end
			else
				if not p20 then
					return
				end

				p20:Play()

				if p21 then
					p20:AdjustSpeed(p21)
				end
			end
		end

		localHitEffect.Event:Connect(function(character, p23, p24)
			local Character2: Model = LocalPlayer.Character

			if not Character2 or not Character2:FindFirstChild("Values") then
				return
			end

			local humanoid = character and character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local u103

			if u43 and humanoidRootPart then
				local n1 = u43.Position - humanoidRootPart.Position

				u103 = n1:Dot(n1) <= 18496
			elseif CurrentCamera and humanoidRootPart then
				local n2 = CurrentCamera.CFrame.Position - humanoidRootPart.Position

				u103 = n2:Dot(n2) <= 18496
			else
				u103 = true
			end

			if not u103 then
				return
			end

			local v104 = os.clock()
			local u105

			if v104 - (object[humanoidRootPart] or 0) < 0.12 then
				u105 = false
			else
				object[humanoidRootPart] = v104
				u105 = true
			end

			if not u105 then
				return
			end

			object2[humanoidRootPart] = os.clock()

			local u106: boolean = character ~= Character2

			if u106 then
				if CurrentCamera and humanoidRootPart then
					local n3 = CurrentCamera.CFrame.Position - humanoidRootPart.Position

					u106 = n3:Dot(n3) > 14400
				else
					u106 = false
				end
			end

			local v108, v109 = getTracks(humanoid)

			if p24 then
				if not u106 then
					playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })
				end

				if not (random:NextNumber() < 0.5) then
					if v109 then
						v109:Play()
					end
				elseif v108 then
					v108:Play()
				end

				playSound(bassHit, humanoidRootPart)

				return
			end

			if p23:FindFirstChild("RageValue") and p23.RageValue.Value and p23:FindFirstChild("Kratos") then
				playSound(bassHit, humanoidRootPart)

				if not u106 then
					playEffect(hitAtKratos, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 1 })
				end
			elseif p23:FindFirstChild("TimeFrozen") then
				local v110 = not u106 and playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })

				if v110 then
					local sparks = v110:FindFirstChild("Sparks")
					local sparksCircle = v110:FindFirstChild("SparksCircle")
					local shock = v110:FindFirstChild("Shock")
					local shockwaveMiddle = v110:FindFirstChild("ShockwaveMiddle")

					if sparks then
						sparks.TimeScale = 0.25
					end

					if sparksCircle then
						sparksCircle.TimeScale = 0.25
					end

					if shock then
						shock.TimeScale = 0.25
					end

					if shockwaveMiddle then
						shockwaveMiddle.TimeScale = 0.25
					end
				end

				playSound(bassHit, humanoidRootPart, nil, 6)
			elseif not u106 then
				playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })
			end

			if p23:FindFirstChild("TimeFrozen") then
				if not (random:NextNumber() < 0.5) then
					if v109 then
						v109:Play()
						v109:AdjustSpeed(0.5)
					end
				elseif v108 then
					v108:Play()
					v108:AdjustSpeed(0.5)
				end
			elseif not (random:NextNumber() < 0.5) then
				if v109 then
					v109:Play()
				end
			elseif v108 then
				v108:Play()
			end

			if p23:FindFirstChild("DarthVader") then
				playSound(saberHit, humanoidRootPart)

				return
			end

			if p23:FindFirstChild("PurpleGuy") then
				playSound(pixelHit, humanoidRootPart, random:NextNumber(1, 1.5))

				return
			end

			if p23:FindFirstChild("Slasher") then
				if p23:FindFirstChild("Paul") then
					local v115 = random:NextNumber()

					playSound(v115 < 0.5 and paulSlash1 or paulSlash2, humanoidRootPart)

					return
				end

				local v116 = random:NextNumber()

				playSound(v116 < 0.5 and knifeHitSound or v20, humanoidRootPart, random:NextNumber(1, 1.5))

				return
			end

			if p23:FindFirstChild("SpearCombat") then
				local randomNumber = math.random(1, #t1)

				playSound(t1[randomNumber], humanoidRootPart)

				return
			end

			if p23:FindFirstChild("Robot") then
				local randomNumber = math.random(1, #t2)

				playSound(t2[randomNumber], humanoidRootPart)

				return
			end

			if p23:FindFirstChild("BatUser") then
				local randomNumber = math.random(1, #t3)

				playSound(t3[randomNumber], humanoidRootPart)

				return
			end

			if p23:FindFirstChild("AxeWeapon") then
				local randomNumber = math.random(1, #t5)

				playSound(t5[randomNumber], humanoidRootPart, random:NextNumber(1, 1.3))

				return
			end

			if p23.Values and p23.Values:FindFirstChild("Steve") then
				playSound(minecraftHits, humanoidRootPart)

				return
			end

			if p23:FindFirstChild("Wanda") and not p23:FindFirstChild("Olivia") then
				playSound(wandaCombat, humanoidRootPart, random:NextNumber(1, 1.2))

				return
			end

			if p23:FindFirstChild("Head") and p23.Head:FindFirstChild("CombatHit") then
				playSound(p23.Head.CombatHit, humanoidRootPart, random:NextNumber(1, 1.4))

				return
			end

			if p23:FindFirstChild("HandGunCombat") then
				local randomNumber = math.random(1, #t4)

				playSound(t4[randomNumber], humanoidRootPart)

				return
			end

			if p23:FindFirstChild("TimeFrozen") then
				local randomNumber = math.random(1, 2)

				playSound(randomNumber == 1 and hitSound or hitSound2 or hitSound3, humanoidRootPart, 0.25, 4.5)

				return
			end

			local randomNumber = math.random(1, 2)

			playSound(randomNumber == 1 and hitSound or hitSound2 or hitSound3, humanoidRootPart)
		end)
		hitEffect.OnClientEvent:Connect(function(character, p26, p27)
			local Character3: Model = LocalPlayer.Character

			if not Character3 or not Character3:FindFirstChild("Values") then
				return
			end

			local humanoid = character and character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local u131

			if u43 and humanoidRootPart then
				local n1 = u43.Position - humanoidRootPart.Position

				u131 = n1:Dot(n1) <= 18496
			elseif CurrentCamera and humanoidRootPart then
				local n2 = CurrentCamera.CFrame.Position - humanoidRootPart.Position

				u131 = n2:Dot(n2) <= 18496
			else
				u131 = true
			end

			if not u131 then
				return
			end

			if p26 == Character3 and object2[humanoidRootPart] and os.clock() - (p26 == Character3 and object2[humanoidRootPart]) < 0.75 then
				return
			end

			local v132 = os.clock()
			local u133

			if v132 - (object[humanoidRootPart] or 0) < 0.04 then
				u133 = false
			else
				object[humanoidRootPart] = v132
				u133 = true
			end

			if not u133 then
				return
			end

			local u134: boolean = character ~= Character3

			if u134 then
				if CurrentCamera and humanoidRootPart then
					local n3 = CurrentCamera.CFrame.Position - humanoidRootPart.Position

					u134 = n3:Dot(n3) > 14400
				else
					u134 = false
				end
			end

			local v136, v137 = getTracks(humanoid)

			if p27 then
				if not u134 then
					playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })
				end

				if not (random:NextNumber() < 0.5) then
					if v137 then
						v137:Play()
					end
				elseif v136 then
					v136:Play()
				end

				playSound(bassHit, humanoidRootPart)

				return
			end

			if p26:FindFirstChild("RageValue") and p26.RageValue.Value and p26:FindFirstChild("Kratos") then
				playSound(bassHit, humanoidRootPart)

				if not u134 then
					playEffect(hitAtKratos, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 1 })
				end
			elseif p26:FindFirstChild("TimeFrozen") then
				local v138 = not u134 and playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })

				if v138 then
					local sparks = v138:FindFirstChild("Sparks")
					local sparksCircle = v138:FindFirstChild("SparksCircle")
					local shock = v138:FindFirstChild("Shock")
					local shockwaveMiddle = v138:FindFirstChild("ShockwaveMiddle")

					if sparks then
						sparks.TimeScale = 0.25
					end

					if sparksCircle then
						sparksCircle.TimeScale = 0.25
					end

					if shock then
						shock.TimeScale = 0.25
					end

					if shockwaveMiddle then
						shockwaveMiddle.TimeScale = 0.25
					end
				end

				playSound(bassHit, humanoidRootPart, nil, 6)
			elseif not u134 then
				playEffect(hitAt, humanoidRootPart, { Shock = 2, ShockwaveMiddle = 2, SparksCircle = 15 })
			end

			if p26:FindFirstChild("TimeFrozen") then
				if not (random:NextNumber() < 0.5) then
					if v137 then
						v137:Play()
						v137:AdjustSpeed(0.5)
					end
				elseif v136 then
					v136:Play()
					v136:AdjustSpeed(0.5)
				end
			elseif not (random:NextNumber() < 0.5) then
				if v137 then
					v137:Play()
				end
			elseif v136 then
				v136:Play()
			end

			if p26:FindFirstChild("DarthVader") then
				playSound(saberHit, humanoidRootPart)

				return
			end

			if p26:FindFirstChild("PurpleGuy") then
				playSound(pixelHit, humanoidRootPart, random:NextNumber(1, 1.5))

				return
			end

			if p26:FindFirstChild("Slasher") then
				if p26:FindFirstChild("Paul") then
					local v143 = random:NextNumber()

					playSound(v143 < 0.5 and paulSlash1 or paulSlash2, humanoidRootPart)

					return
				end

				local v144 = random:NextNumber()

				playSound(v144 < 0.5 and knifeHitSound or v20, humanoidRootPart, random:NextNumber(1, 1.5))

				return
			end

			if p26:FindFirstChild("SpearCombat") then
				local randomNumber = math.random(1, #t1)

				playSound(t1[randomNumber], humanoidRootPart)

				return
			end

			if p26:FindFirstChild("Robot") then
				local randomNumber = math.random(1, #t2)

				playSound(t2[randomNumber], humanoidRootPart)

				return
			end

			if p26:FindFirstChild("BatUser") then
				local randomNumber = math.random(1, #t3)

				playSound(t3[randomNumber], humanoidRootPart)

				return
			end

			if p26:FindFirstChild("AxeWeapon") then
				local randomNumber = math.random(1, #t5)

				playSound(t5[randomNumber], humanoidRootPart, random:NextNumber(1, 1.3))

				return
			end

			if p26.Values and p26.Values:FindFirstChild("Steve") then
				playSound(minecraftHits, humanoidRootPart)

				return
			end

			if p26:FindFirstChild("Wanda") and not p26:FindFirstChild("Olivia") then
				playSound(wandaCombat, humanoidRootPart, random:NextNumber(1, 1.2))

				return
			end

			if p26:FindFirstChild("Head") and p26.Head:FindFirstChild("CombatHit") then
				playSound(p26.Head.CombatHit, humanoidRootPart, random:NextNumber(1, 1.4))

				return
			end

			if p26:FindFirstChild("HandGunCombat") then
				local randomNumber = math.random(1, #t4)

				playSound(t4[randomNumber], humanoidRootPart)

				return
			end

			if p26:FindFirstChild("TimeFrozen") then
				local randomNumber = math.random(1, 2)

				playSound(randomNumber == 1 and hitSound or hitSound2 or hitSound3, humanoidRootPart, 0.25, 4.5)

				return
			end

			local randomNumber = math.random(1, 2)

			playSound(randomNumber == 1 and hitSound or hitSound2 or hitSound3, humanoidRootPart)
		end)
	end)

	if not ok then
		warn("[OldClientEffects2Module] failed:", "Combat.ComboEffects", result)
	end
end)

return true
