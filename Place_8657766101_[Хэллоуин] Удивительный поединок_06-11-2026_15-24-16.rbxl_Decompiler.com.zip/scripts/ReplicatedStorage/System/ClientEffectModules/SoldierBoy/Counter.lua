-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local moveThree = game.ReplicatedStorage.Characters.SoldierBoy.Remotes.MoveThree
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1, _)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v19 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v21 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v21, 0)
				local n2 = v19 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v24 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v24 then
					local instance = v24.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v30 = mathRandom(-180, 180)
					local v31 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v30, v31, mathRandom(-180, 180))
					part.Position = p1.Position

					local v32 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v32, { Position = v24.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v77 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v77, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v78 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v78, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock2(p3, _)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v38 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v40 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v40, 0)
				local n2 = v38 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v43 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v43 then
					local instance = v43.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v49 = mathRandom(-180, 180)
					local v50 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v49, v50, mathRandom(-180, 180))
					part.Position = p3.Position

					local v51 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v51, { Position = v43.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v83 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v83, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v84 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v84, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p5)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v56 = p5.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v58 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v58, 0)
				local n2 = v56 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v61 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v61 then
					local instance = v61.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v67 = mathRandom(-180, 180)
					local v68 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v67, v68, mathRandom(-180, 180))
					part.Position = p5.Position

					local v69 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v69, { Position = v61.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v89 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v89, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v90 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v90, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local explosionEffect = game.ReplicatedStorage.Characters.SoldierBoy.Fx.ExplosionEffect

		moveThree.OnClientEvent:Connect(function(player, p7)
			local Character = player.Character
			local part: Part = Instance.new("Part")

			part.Parent = workspace
			part.Position = p7
			part.Transparency = 1
			game.Debris:AddItem(part, 0.5)
			TestRock(part, player)
			TestRock2(part, player)

			local clone = explosionEffect:Clone()

			clone.Parent = workspace
			clone.CFrame = part.CFrame
			game.Debris:AddItem(clone, 8)
			clone.At.Boom1:Emit(20)
			clone.At.Boom2:Emit(20)
			clone.At.Spark:Emit(50)
			clone.Rocks:Emit(50)
			clone.Smoke:Emit(50)
			clone.Sound:Play()
			clone.SoundDistance:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SoldierBoy.Counter", result)
	end
end)

return true
