-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local radiation2 = game.ReplicatedStorage.Characters.SoldierBoy.Remotes.Radiation2
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v15 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v17 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v17, 0)
				local n2 = v15 * cFrame * CFrame.new(0, 0, -110).Position + Vector3.new(0, 10, 0)
				local v20 = workspace:Raycast(n2, n2 - Vector3.new(0, 15, 0) - n2, raycastParams)

				n1 += 18

				if v20 then
					local instance = v20.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(40, 40, 40)

					local v26 = mathRandom(-180, 180)
					local v27 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v26, v27, mathRandom(-180, 180))
					part.Position = p1.Position

					local v28 = tweenInfoNew(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v28, { Position = v20.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 6)
					task.delay(5, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v45 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v45, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v46 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v46, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v33 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v35 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v37 = math.rad(randomNumber3)
						local v38 = cFrameAngles(v33, v35, v37)

						clone.CFrame = p1.CFrame * v38

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end

		radiation2.OnClientEvent:Connect(function(player)
			player.Character:WaitForChild("Humanoid", 5)
			TestRock(player.Character.HumanoidRootPart)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SoldierBoy.Nuke", result)
	end
end)

return true
