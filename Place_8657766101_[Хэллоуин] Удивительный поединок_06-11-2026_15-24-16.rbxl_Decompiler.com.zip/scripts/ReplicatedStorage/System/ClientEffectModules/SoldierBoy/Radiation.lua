-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.5)

		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local radiation = game.ReplicatedStorage.Characters.SoldierBoy.Remotes.Radiation
		local scriptParent: Instance = script.Parent
		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random
		local TweenService = game.TweenService

		game:GetService("Debris")

		local function Math(p1, p2, p3)
			return p1 + (p2 - p1) * p3
		end

		Random.new()

		local function RockSpawn(p4)
			if math.random(1, 2) == 2 then
				for _, v in ipairs(p4:GetChildren()) do
					if v.Name == "AtShockInvc" then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v22 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v22 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v22.Position

							local randomNumber = math.random(-1, 1)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0.3, 0.3, 0.3)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 10)

							local part2: Part = Instance.new("Part")

							part2.Position = v22.Position

							local randomNumber2 = math.random(-1, 1)
							local part2CFrame: CFrame = part2.CFrame
							local vector32 = Vector3.new(randomNumber2, 0, 0)

							part2.CFrame = part2CFrame + vector32
							part2.Parent = workspace
							part2.Anchored = true
							part2.Size = Vector3.new(3, 3, 3)
							part2.CanCollide = false
							part2.CanTouch = false
							part2.Material = v22.Material
							part2.Color = v22.Instance.Color
							game.Debris:AddItem(part2, 6)

							local randomNumber3 = math.random(-360, 360)
							local randomNumber4 = math.random(-360, 360)
							local randomNumber5 = math.random(-360, 360)
							local randomNumber6 = math.random(10, 30)
							local randomNumber7 = math.random(-4, 4)
							local partPosition: Vector3 = part.Position
							local vector33 = Vector3.new(randomNumber7, randomNumber6, randomNumber7)

							TweenService:Create(part, TweenInfo.new(0.5), { Position = partPosition + vector33 }):Play()

							local TweenService2 = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v40 = CFrame.Angles(-randomNumber3, -randomNumber4, -randomNumber5)

							TweenService2:Create(part, TweenInfo.new(0.5), { CFrame = cFrame * v40 }):Play()

							local TweenService3 = game.TweenService
							local cFrame2 = CFrame.new(part.Position)

							v40 = CFrame.Angles(-randomNumber3, -randomNumber4, -randomNumber5)
							TweenService3:Create(part2, TweenInfo.new(0.3), { CFrame = cFrame2 * v40 }):Play()
							part.Material = v22.Material
							part.Color = v22.Instance.Color
							task.delay(2, function()
								TweenService:Create(part2, TweenInfo.new(2), { Size = Vector3.new(0, 0, 0) }):Play()
							end)
							task.delay(0.5, function()
								part.Anchored = false
							end)
						end
					end
				end
			end
		end
		local function TestWhirl(p5, p6, p7)
			local num1 = p7.Num1
			local num2 = p7.Num2
			local clone = p5:Clone()

			game.Debris:AddItem(clone, 3)
			clone.Size = Vector3.new(5, 5, 5)
			TweenService:Create(clone.Light, TweenInfo.new(1), { Brightness = 0 }):Play()
			clone.Position = p6.WorldPosition

			local randomNumber = math.random(-170, 170)
			local randomNumber8 = math.random(-170, 170)

			clone.Orientation = Vector3.new(randomNumber, randomNumber8, math.random(-170, 170))
			clone.Parent = workspace
			clone.Attachment.SparksSlow:Emit(2)
			RockSpawn(clone)
			spawn(function()
				local v53 = tweenInfoNew(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0)
				local color3 = Color3.fromRGB(176, 164, 143)
				local n1 = clone.Size * 6
				local cloneCFrame = clone.CFrame
				local v57 = CFrame.Angles(0, 3.141592653589793, 0)

				tweenService:Create(clone, v53, {
					Transparency = 1,
					Color = color3,
					Size = n1,
					CFrame = cloneCFrame * v57
				}):Play()
				task.wait(3)
				clone:Destroy()
			end)
		end

		local blast = game.ReplicatedStorage.Characters.SoldierBoy.Fx.Blast

		radiation.OnClientEvent:Connect(function(p8)
			local n1: number = 0

			while true do
				if p8:FindFirstChild("Humanoid") and p8.Humanoid.Health > 0 then
					TestWhirl(blast, p8.HumanoidRootPart.At2, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At3, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At4, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At5, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At6, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At7, { Num1 = 1.5, Num2 = 0.5 })
					TestWhirl(blast, p8.HumanoidRootPart.At8, { Num1 = 1.5, Num2 = 0.5 })
					task.wait(0.1)
				end

				n1 += 1

				if n1 == 14 then
					break
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SoldierBoy.Radiation", result)
	end
end)

return true
