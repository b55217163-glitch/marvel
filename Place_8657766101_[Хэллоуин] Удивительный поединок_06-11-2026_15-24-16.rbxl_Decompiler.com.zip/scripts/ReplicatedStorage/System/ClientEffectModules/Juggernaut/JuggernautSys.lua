-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local textChatService: TextChatService = game:GetService("TextChatService")
		local LocalPlayer: Player = players.LocalPlayer
		local juggernaut: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Juggernaut")
		local remotesJuggernaut: Instance = juggernaut:WaitForChild("Remotes"):WaitForChild("Juggernaut")
		local juggernautdied: Instance = juggernaut:WaitForChild("Remotes"):WaitForChild("Juggernautdied")
		local crazyLanding: Instance = juggernaut:WaitForChild("AnimationsExtra"):WaitForChild("CrazyLanding")
		local landingPart: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("LandingPart")
		local effects = workspace:FindFirstChild("Effects") or Instance.new("Folder", workspace)

		effects.Name = "Effects"

		local map: Instance = workspace:WaitForChild("Map")
		local v17: Instance = textChatService:FindFirstChild("TextChannels") or textChatService:WaitForChild("TextChannels", 2)
		local v18: Instance = v17

		if v18 then
			v18 = v17:FindFirstChild("RBXSystem")
		end

		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function safeFindHumanoid(character)
			return character and character:FindFirstChildOfClass("Humanoid")
		end
		local function safeFindRoot(p2)
			return p2 and p2:FindFirstChild("HumanoidRootPart")
		end
		local function cloneSurfaceChildren(p3, parent)
			for _, v in ipairs(p3:GetChildren()) do
				if not v:IsA("SurfaceAppearance") then
					local ok2, result2 = pcall(function()
						return v:Clone()
					end)

					if ok2 and result2 then
						result2.Parent = parent
					end
				end
			end
		end
		local function TestRock_Generic(p5, p6, p7, p8)
			if not p5 or not p5.Parent then
				return
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				if not p5 or not p5.Parent then
					return
				end

				local v49 = p5.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v51 = math.rad(n1)
				local v52 = cFrameFromEulerAnglesXYZ(0, v51, 0)
				local cFrame = CFrame.new(0, 0, -p6)
				local n2 = (v49 * v52 * cFrame).Position + Vector3.new(0, 10, 0)
				local v55 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v55 then
					local instance = v55.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.CanQuery = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = p7

					local v58 = mathRandom(-180, 180)
					local v59 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v58, v59, mathRandom(-180, 180))
					part.Position = p5.Position
					cloneSurfaceChildren(instance, part)

					local v60 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v60, { Position = v55.Position }):Play()
					part.Parent = effects
					debris:AddItem(part, 2)
					task.delay(1, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v93 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v93, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v94 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v94, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					if not p8 then
						continue
					end

					local rock: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Physics"):FindFirstChild("Rock")

					if not rock then
						continue
					end

					local clone: Instance = rock:Clone()

					clone.Parent = effects
					pcall(function()
						clone.Material = instance.Material
						clone.Color = instance.Color
					end)

					local trail: Instance = clone:FindFirstChild("Trail")

					if trail and trail:IsA("Trail") then
						pcall(function()
							trail.Color = ColorSequence.new(instance.Color)
						end)
					end

					local cFrameAngles = CFrame.Angles
					local randomNumber = math.random(0, 360)
					local v66 = math.rad(randomNumber)
					local randomNumber2 = math.random(0, 360)
					local v68 = math.rad(randomNumber2)
					local randomNumber3 = math.random(0, 360)
					local v70 = math.rad(randomNumber3)

					v60 = cFrameAngles(v66, v68, v70)
					clone.CFrame = p5.CFrame * v60

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber4 = math.random(-2, 2)
					local randomNumber5 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
					bodyVelocity.Parent = clone
					debris:AddItem(clone, 3)
					debris:AddItem(bodyVelocity, 0.3)
				end
			end
		end
		local function TestRock(p9)
			TestRock_Generic(p9, 20, Vector3.new(10, 10, 10), true)
		end
		local function TestRock2(p10)
			TestRock_Generic(p10, 5, Vector3.new(3, 2, 3), false)
		end
		local function TestRock3(p11)
			TestRock_Generic(p11, 10, Vector3.new(5, 2, 5), false)
		end

		local n1: number = 0
		local connection = nil
		local u30 = nil
		local u31 = nil

		local function disconnectConn(p12)
			if p12 then
				p12:Disconnect()
			end
		end
		local function hookLocalDeathOnce()
			local v78 = connection

			if v78 then
				v78:Disconnect()
			end

			connection = nil

			local Character: Model = LocalPlayer.Character

			if not Character then
				return
			end

			local humanoid = Character and Character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			if humanoid:GetAttribute("JuggernautDeathHooked") then
				return
			end

			humanoid:SetAttribute("JuggernautDeathHooked", true)
			connection = humanoid.Died:Connect(function()
				juggernautdied:FireServer("died")
			end)
			humanoid.AncestryChanged:Connect(function(_, p14)
				if p14 == nil then
					juggernautdied:FireServer("char_removed")
				end
			end)
		end

		LocalPlayer.AncestryChanged:Connect(function(child: Instance, parent: Instance)
			if parent == nil then
				juggernautdied:FireServer("left")
			end
		end)
		remotesJuggernaut.OnClientEvent:Connect(function(player)
			n1 += 1

			local v84: number = n1
			local v85 = u30

			if v85 then
				v85:Disconnect()
			end

			u30 = nil
			v85 = u31

			if v85 then
				v85:Disconnect()
			end

			u31 = nil

			if not player then
				return
			end

			local v86 = player.Character or player.CharacterAdded:Wait()
			local humanoid = v86:WaitForChild("Humanoid", 3)
			local humanoidRootPart = v86:WaitForChild("HumanoidRootPart", 3)

			if humanoid and humanoidRootPart then
				local animator = humanoid:FindFirstChildOfClass("Animator")

				if not animator then
					animator = Instance.new("Animator")
					animator.Parent = humanoid
				end

				if not crazyLanding or not crazyLanding:IsA("Animation") then
					return
				end

				local v90 = animationService.LoadFresh(animator, crazyLanding)

				u31 = animationService.ConnectMarker(v90, "Start", function()
					if v84 ~= n1 then
						return
					end
				end)
				u30 = animationService.ConnectMarker(v90, "Landing", function()
					if v84 ~= n1 then
						return
					end

					if not v86 or not v86.Parent then
						return
					end

					if not humanoidRootPart or not humanoidRootPart.Parent then
						return
					end

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { map }
					raycastParams.IgnoreWater = true

					if v18 and v86 and v86.Name then
						local s1: string = v86.Name .. " has Plot Armor!"

						pcall(function()
							v18:DisplaySystemMessage("<font color=\"rgb(217,43,237)\">" .. s1 .. "</font>")
						end)
					end

					local v101 = workspace:Raycast(humanoidRootPart.Position, humanoidRootPart.CFrame.UpVector * -6, raycastParams)

					TestRock_Generic(humanoidRootPart, 20, Vector3.new(10, 10, 10), true)
					TestRock_Generic(humanoidRootPart, 5, Vector3.new(3, 2, 3), false)
					TestRock_Generic(humanoidRootPart, 10, Vector3.new(5, 2, 5), false)

					local function playSpawnVoiceline()
						local v109 = v86 and v86:FindFirstChild("Head") and v86.Head:FindFirstChild("SpawnVoiceline")

						if v109 and v109:IsA("Sound") then
							v109:Play()
						end
					end

					if v101 then
						local InstanceColor = v101.Instance.Color
						local clone: Instance = landingPart:Clone()

						clone.Parent = effects
						clone.Position = v101.Position

						local randomNumber = math.random(-180, 180)

						clone.Orientation = Vector3.new(0, randomNumber, 0)
						debris:AddItem(clone, 4)

						local smoke: Instance = clone:FindFirstChild("Smoke")

						if smoke and smoke:IsA("ParticleEmitter") then
							smoke.Color = ColorSequence.new(InstanceColor)

							local randomNumber6 = math.random(0, 360)

							clone.Orientation = Vector3.new(0, randomNumber6, 0)
							smoke:Emit(40)
						end

						local boom: Instance = clone:FindFirstChild("Boom")

						if boom and boom:IsA("Sound") then
							boom:Play()
						end

						task.delay(1, function()
							if v84 ~= n1 then
								return
							end

							local v110 = v86 and v86:FindFirstChild("Head") and v86.Head:FindFirstChild("SpawnVoiceline")

							if v110 and v110:IsA("Sound") then
								v110:Play()
							end

							local foundChild: Instance = clone:FindFirstChildWhichIsA("Decal", true)

							if foundChild then
								tweenService:Create(foundChild, TweenInfo.new(1), { Transparency = 1 }):Play()
							end
						end)

						return
					end

					task.delay(1, function()
						if v84 ~= n1 then
							return
						end

						local v112 = v86 and v86:FindFirstChild("Head") and v86.Head:FindFirstChild("SpawnVoiceline")

						if v112 and v112:IsA("Sound") then
							v112:Play()
						end
					end)
				end)
				v90:Stop(0)
				v90:Play()

				if player == LocalPlayer then
					hookLocalDeathOnce()
					LocalPlayer.CharacterAdded:Once(function()
						if v84 ~= n1 then
							return
						end

						hookLocalDeathOnce()
					end)
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Juggernaut.JuggernautSys", result)
	end
end)

return true
