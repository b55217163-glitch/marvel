-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local juggernautdied = game.ReplicatedStorage.Characters.Juggernaut.Remotes.Juggernautdied

		game:GetService("TweenService")

		local tweenService: TweenService = game:GetService("TweenService")
		local crazyLanding = game.ReplicatedStorage.Characters.Juggernaut.AnimationsExtra.CrazyLanding
		local landingPart = game.ReplicatedStorage.Characters.LandingPart
		local tweenService2: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new
		local rbxSystem: Instance = game:GetService("TextChatService"):WaitForChild("TextChannels"):FindFirstChild("RBXSystem")

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v24 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v26 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v26, 0)
				local n2 = v24 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v29 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v29 then
					local instance = v29.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v35 = mathRandom(-180, 180)
					local v36 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v35, v36, mathRandom(-180, 180))
					part.Position = p1.Position

					local v37 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v37, { Position = v29.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v115 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v115, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v116 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v116, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v42 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v44 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v46 = math.rad(randomNumber3)
						local v47 = cFrameAngles(v42, v44, v46)

						clone.CFrame = p1.CFrame * v47

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v55 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v57 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v57, 0)
				local n2 = v55 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v60 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v60 then
					local instance = v60.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v66 = mathRandom(-180, 180)
					local v67 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v66, v67, mathRandom(-180, 180))
					part.Position = p2.Position

					local v68 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v68, { Position = v60.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v121 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v121, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v122 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v122, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v73 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v75 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v75, 0)
				local n2 = v73 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v78 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v78 then
					local instance = v78.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v84 = mathRandom(-180, 180)
					local v85 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v84, v85, mathRandom(-180, 180))
					part.Position = p3.Position

					local v86 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v86, { Position = v78.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v127 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v127, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v128 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v128, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local explosionEffect = game.ReplicatedStorage.Characters.Juggernaut.Fx.ExplosionEffect

		local function findDescSound(p4, p5)
			if not p4 then
				return nil
			end

			local foundChild = p4:FindFirstChild(p5, true)

			if foundChild and foundChild:IsA("Sound") then
				return foundChild
			end

			return nil
		end
		local function playSoundSafe(p6)
			if not p6 or not p6:IsA("Sound") then
				return
			end

			if p6.SoundId == "" then
				return
			end

			if p6.IsLoaded then
				p6:Play()

				return
			end

			p6.Loaded:Once(function()
				p6:Play()
			end)
		end

		juggernautdied.OnClientEvent:Connect(function(p7)
			local player = p7 or Players.LocalPlayer
			local v93 = player.Character or player.CharacterAdded:Wait()
			local humanoidRootPart = v93:WaitForChild("HumanoidRootPart", 5)

			if not humanoidRootPart then
				return
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			if rbxSystem then
				rbxSystem:DisplaySystemMessage("<font color=\"rgb(217,43,237)\">The person with Plot Armor has been defeated!</font>")
			end

			local v96 = workspace:Raycast(v93.HumanoidRootPart.Position, v93.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)
			local clone = explosionEffect:Clone()

			clone.Parent = workspace
			clone.CFrame = humanoidRootPart.CFrame
			game.Debris:AddItem(clone, 8)

			local v98

			if not clone then
				v98 = nil
			else
				local foundChild = clone:FindFirstChild("SoundB", true)

				v98 = if foundChild and foundChild:IsA("Sound") then foundChild else nil
			end

			playSoundSafe(v98)

			local foundChild = clone:FindFirstChild("Explo", true)

			if foundChild and foundChild:IsA("ParticleEmitter") then
				foundChild:Emit(50)
			end

			local foundChild2 = clone:FindFirstChild("Rocks", true)

			if foundChild2 and foundChild2:IsA("ParticleEmitter") then
				foundChild2:Emit(50)
			end

			local foundChild3 = clone:FindFirstChild("Smoke", true)

			if foundChild3 and foundChild3:IsA("ParticleEmitter") then
				foundChild3:Emit(50)
			end

			if v96 == nil then
				TestRock(humanoidRootPart)
				TestRock2(humanoidRootPart)
				TestRock3(humanoidRootPart)
				task.wait(1)

				local v103

				if not clone then
					v103 = nil
				else
					local foundChild4 = clone:FindFirstChild("Sound", true)

					v103 = if foundChild4 and foundChild4:IsA("Sound") then foundChild4 else nil
				end

				playSoundSafe(v103)

				if v93.Head:FindFirstChild("SpawnVoiceline") then
					v93.Head.SpawnVoiceline:Play()

					return
				end
			else
				TestRock(humanoidRootPart)
				TestRock2(humanoidRootPart)
				TestRock3(humanoidRootPart)

				local InstanceColor = v96.Instance.Color
				local clone2 = landingPart:Clone()

				clone2.Parent = workspace.Effects
				clone2.Position = v96.Position

				local randomNumber = math.random(-180, 180)

				clone2.Orientation = Vector3.new(0, randomNumber, 0)
				game.Debris:AddItem(clone2, 4)

				local foundChild5 = clone2:FindFirstChild("Smoke", true)

				if foundChild5 and foundChild5:IsA("ParticleEmitter") then
					foundChild5.Color = ColorSequence.new(InstanceColor)
					foundChild5:Emit(40)
				end

				local randomNumber6 = math.random(0, 360)

				clone2.Orientation = Vector3.new(0, randomNumber6, 0)
				clone2.Boom:Play()
				task.wait(1)

				local v110

				if not clone then
					v110 = nil
				else
					local foundChild6 = clone:FindFirstChild("Sound", true)

					v110 = if foundChild6 and foundChild6:IsA("Sound") then foundChild6 else nil
				end

				playSoundSafe(v110)

				local decal = clone2:FindFirstChildWhichIsA("Decal")

				if decal then
					tweenService:Create(decal, TweenInfo.new(1), { Transparency = 1 }):Play()
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Juggernaut.JuggernautDeath", result)
	end
end)

return true
