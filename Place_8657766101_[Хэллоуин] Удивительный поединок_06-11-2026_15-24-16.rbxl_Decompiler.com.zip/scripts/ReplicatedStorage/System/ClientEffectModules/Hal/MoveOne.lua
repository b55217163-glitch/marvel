-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")
local hal: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Hal")
local moveOne: Instance = hal:WaitForChild("Remotes"):WaitForChild("MoveOne")
local fx: Instance = hal:WaitForChild("Fx")
local oneHitbox: Instance = fx:WaitForChild("OneHitbox")
local oneHitAt: Instance = fx:WaitForChild("OneHitAt")

local function getOrCreateEffectsFolder()
	local halMoveOneClientEffects = workspace:FindFirstChild("HalMoveOneClientEffects")

	if not halMoveOneClientEffects then
		halMoveOneClientEffects = Instance.new("Folder")
		halMoveOneClientEffects.Name = "HalMoveOneClientEffects"
		halMoveOneClientEffects.Parent = workspace
	end

	return halMoveOneClientEffects
end
local function GetRingAttachment(p1)
	if not p1 then
		return nil
	end

	local ring = p1:FindFirstChild("Ring")

	if not ring then
		return nil
	end

	local foundChild = ring:FindFirstChild("BaseAt", true)

	if foundChild and foundChild:IsA("Attachment") then
		return foundChild
	end

	return nil
end
local function SetRingFlares(p2, enabled)
	local v22

	if not p2 then
		v22 = nil
	else
		local ring = p2:FindFirstChild("Ring")

		if not ring then
			v22 = nil
		else
			local foundChild = ring:FindFirstChild("BaseAt", true)

			v22 = if foundChild and foundChild:IsA("Attachment") then foundChild else nil
		end
	end

	if not v22 then
		return
	end

	for _, v in ipairs({ "Flare", "Flare2" }) do
		local v = v22:FindFirstChild(v)

		if v and v:IsA("ParticleEmitter") then
			v.Enabled = enabled
		end
	end
end
local function FlashRing(p4)
	local v29

	if not p4 then
		v29 = nil
	else
		local ring = p4:FindFirstChild("Ring")

		if not ring then
			v29 = nil
		else
			local foundChild = ring:FindFirstChild("BaseAt", true)

			v29 = if foundChild and foundChild:IsA("Attachment") then foundChild else nil
		end
	end

	if not v29 then
		return
	end

	for _, v in ipairs({ "Flare", "Flare2" }) do
		local v = v29:FindFirstChild(v)

		if v and v:IsA("ParticleEmitter") then
			v:Emit(3)
		end
	end
end
local function CloneHitEffeect(p5)
	if not p5 then
		return
	end

	local parent = p5:FindFirstChild("UpperTorso") or p5:FindFirstChild("Torso")

	if not parent then
		return
	end

	local clone: Instance = oneHitAt:Clone()

	clone.Parent = parent
	clone.Ring:Emit(2)
	clone.Ring2:Emit(1)
	clone.Smoke:Emit(10)
	debris:AddItem(clone, 5)
end
local function PulseLight(p6)
	if not p6 or not p6:IsA("PointLight") then
		return
	end

	p6.Enabled = true
	p6.Range = 0

	local tweenInfo = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v40: Tween = tweenService:Create(p6, tweenInfo, { Range = 20 })

	v40.Completed:Once(function()
		if p6.Parent then
			local tweenInfo2 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

			tweenService:Create(p6, tweenInfo2, { Range = 0 }):Play()
		end
	end)
	v40:Play()
end
local function ShootEffects(p7, cFrame, p9)
	if typeof(cFrame) == "CFrame" then
		FlashRing(p7)

		local clone: Instance = oneHitbox:Clone()

		clone.Name = "HalMoveOneVisual"
		clone.Transparency = 1
		clone.Anchored = true
		clone.CanCollide = false
		clone.CanTouch = false
		clone.CanQuery = false
		clone.Massless = true
		clone.CFrame = cFrame

		local v45

		if not p7 then
			v45 = nil
		else
			local ring = p7:FindFirstChild("Ring")

			if not ring then
				v45 = nil
			else
				local foundChild = ring:FindFirstChild("BaseAt", true)

				v45 = if foundChild and foundChild:IsA("Attachment") then foundChild else nil
			end
		end

		local v48 = v45 and v45.WorldPosition or p9 or cFrame.Position
		local t1: {[any]: any} = {}
		local n1 = 3

		for _, v in ipairs(clone:GetDescendants()) do
			if v:IsA("ParticleEmitter") then
				n1 = math.max(n1, v.Lifetime.Max + 0.5)
			end
		end

		for i = 1, 6 do
			local foundChild: Instance = clone:FindFirstChild("At" .. i)

			if foundChild and foundChild:IsA("Attachment") then
				table.insert(t1, foundChild)

				for _, v in ipairs({ "RingGlow", "force_arc" }) do
					local v: Instance = foundChild:FindFirstChild(v)

					if v and v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local pointLight: Instance = foundChild:FindFirstChildOfClass("PointLight")

				if not pointLight then
					continue
				end

				pointLight.Range = 0
			end
		end

		local halMoveOneClientEffects = workspace:FindFirstChild("HalMoveOneClientEffects")

		if not halMoveOneClientEffects then
			halMoveOneClientEffects = Instance.new("Folder")
			halMoveOneClientEffects.Name = "HalMoveOneClientEffects"
			halMoveOneClientEffects.Parent = workspace
		end

		clone.Parent = halMoveOneClientEffects
		debris:AddItem(clone, n1)

		local at1: Instance = clone:FindFirstChild("At1")
		local spotLight: Instance = at1 and at1:FindFirstChild("SpotLight")

		if spotLight and spotLight:IsA("SpotLight") then
			spotLight.Enabled = true

			local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

			tweenService:Create(spotLight, tweenInfo, { Range = 35 }):Play()
			task.delay(0.2, function()
				if spotLight.Parent then
					local tweenInfo3 = TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

					tweenService:Create(spotLight, tweenInfo3, { Brightness = 0 }):Play()
				end
			end)
		end

		local shoot: Instance = at1 and at1:FindFirstChild("Shoot")

		if shoot and shoot:IsA("ParticleEmitter") then
			shoot:Emit(5)
		end

		table.sort(t1, function(p10, p11)
			return (p10.WorldPosition - v48).Magnitude < (p11.WorldPosition - v48).Magnitude
		end)

		for i, v in ipairs(t1) do
			task.delay((i - 1) * 0.025, function()
				if not clone.Parent or not v.Parent then
					return
				end

				local ringGlow = v:FindFirstChild("RingGlow")
				local force_arc = v:FindFirstChild("force_arc")
				local pointLight = v:FindFirstChildOfClass("PointLight")

				if ringGlow and ringGlow:IsA("ParticleEmitter") then
					ringGlow:Emit(1)
				end

				if force_arc and force_arc:IsA("ParticleEmitter") then
					force_arc:Emit(1)
				end

				PulseLight(pointLight)
			end)
		end

		return
	end
end

moveOne.OnClientEvent:Connect(function(p12, p13, p14, p15)
	if p12 == "Start" then
		if not p13 then
			return
		end

		SetRingFlares(p13, true)

		local head = p13:FindFirstChild("Head")
		local moveOne = head and head:FindFirstChild("MoveOne")

		if moveOne and moveOne:IsA("Sound") then
			moveOne:Stop()
			moveOne:Play()

			return
		end
	else
		if p12 == "Shoot" then
			ShootEffects(p13, p14, p15)

			return
		end

		if p12 == "Hit" then
			CloneHitEffeect(p13)

			return
		end

		if p12 == "End" then
			SetRingFlares(p13, false)

			if p14 == true then
				local v72 = p13 and p13:FindFirstChild("Head")
				local v73 = v72 and v72:FindFirstChild("MoveOne")

				if v73 and v73:IsA("Sound") then
					v73:Stop()
				end
			end
		end
	end
end)

return true
