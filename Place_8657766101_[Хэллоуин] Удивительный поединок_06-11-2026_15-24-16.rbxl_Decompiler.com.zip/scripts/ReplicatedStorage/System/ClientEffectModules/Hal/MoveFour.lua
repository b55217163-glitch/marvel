-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")
local hal: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Hal")
local moveFour: Instance = hal:WaitForChild("Remotes"):WaitForChild("MoveFour")
local fx: Instance = hal:WaitForChild("Fx")
local tornadoMod: Instance = fx:WaitForChild("TornadoMod")
local moveFourStartupSFX: Instance = fx:FindFirstChild("MoveFourStartupSFX")
local random = Random.new()

local function getEffectsParent()
	local effects: Instance = workspace:FindFirstChild("Effects")

	if effects then
		return effects
	end

	local effects: Folder = Instance.new("Folder")

	effects.Name = "Effects"
	effects.Parent = workspace

	return effects
end
local function playClonedSound(p1, parent)
	if p1 and p1:IsA("Sound") and parent then
		local clone = p1:Clone()

		clone.Parent = parent
		clone:Play()

		local v32 = math.max(clone.TimeLength, 2)

		debris:AddItem(clone, v32 + 0.5)

		return clone
	end

	return nil
end
local function playRingStartupSound(p3)
	local v34: Instance = moveFourStartupSFX
	local parent = p3 and p3:FindFirstChild("Ring") or p3 and p3:FindFirstChild("HumanoidRootPart")

	if not v34 or not v34:IsA("Sound") then
		return
	end

	if not parent then
		return
	end

	local clone: Instance = v34:Clone()

	clone.Parent = parent
	clone:Play()

	local v37 = math.max(clone.TimeLength, 2)

	debris:AddItem(clone, v37 + 0.5)
end
local function getTornadoFxData(p4)
	local t1: {[any]: any} = {
		parts = {},
		textures = {},
		sequenceEffects = {},
		lights = {}
	}

	for iterFirst, iterSecond in p4:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			table.insert(t1.parts, {
				Instance = iterSecond,
				OriginalTransparency = iterSecond.Transparency,
				TargetTransparency = if iterSecond.Name == "HoldHumanoidRootPart" then 1 else iterSecond.Transparency
			})
		elseif not iterSecond:IsA("Decal") and not iterSecond:IsA("Texture") then
			if iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail") or iterSecond:IsA("Beam") then
				local v42 = iterSecond:IsA("ParticleEmitter")

				if v42 then
					v42 = false

					if iterSecond.Name == "Smoke" then
						v42 = iterSecond:FindFirstAncestor("HoldHumanoidRootPart") ~= nil
					end
				end

				local v43 = iterSecond.Enabled

				if v42 then
					v43 = false
					iterSecond.Enabled = false
				end

				table.insert(t1.sequenceEffects, {
					Instance = iterSecond,
					OriginalEnabled = v43,
					OriginalTransparency = iterSecond.Transparency,
					IsDelayedHoldSmoke = v42
				})
			elseif iterSecond:IsA("Light") then
				table.insert(t1.lights, {
					Instance = iterSecond,
					OriginalBrightness = iterSecond.Brightness,
					OriginalEnabled = iterSecond.Enabled
				})
			end
		else
			local t2: {[any]: any} = {
				Instance = iterSecond,
				OriginalTransparency = iterSecond.Transparency
			}

			if iterSecond:IsA("Texture") then
				t2.OriginalOffsetStudsU = iterSecond.OffsetStudsU
				t2.OriginalOffsetStudsV = iterSecond.OffsetStudsV
			end

			table.insert(t1.textures, t2)
		end
	end

	return t1
end
local function blendNumberSequenceToVisibility(p5, p6)
	local t3: {[any]: any} = {}

	for iterFirst, iterSecond in p5.Keypoints, nil, nil do
		table.insert(t3, NumberSequenceKeypoint.new(iterSecond.Time, 1 + (iterSecond.Value - 1) * p6, iterSecond.Envelope))
	end

	return NumberSequence.new(t3)
end
local function applyTornadoVisibility(p7, p8)
	for iterFirst, iterSecond in p7.parts, nil, nil do
		local instance = iterSecond.Instance

		if instance.Parent then
			instance.Transparency = 1 + (iterSecond.TargetTransparency - 1) * p8

			if instance.Name == "HoldHumanoidRootPart" then
				instance.Transparency = 1
			end
		end
	end

	for iterFirst2, iterSecond2 in p7.textures, nil, nil do
		local v57 = iterSecond2.Instance

		if v57.Parent then
			v57.Transparency = 1 + (iterSecond2.OriginalTransparency - 1) * p8
		end
	end

	for iterFirst3, iterSecond3 in p7.sequenceEffects, nil, nil do
		local v60 = iterSecond3.Instance

		if v60.Parent then
			if not iterSecond3.IsDelayedHoldSmoke then
				v60.Enabled = iterSecond3.OriginalEnabled and p8 > 0.02
			end

			if v60:IsA("Trail") or v60:IsA("Beam") then
				v60.Transparency = blendNumberSequenceToVisibility(iterSecond3.OriginalTransparency, p8)
			end
		end
	end

	for iterFirst4, iterSecond4 in p7.lights, nil, nil do
		local v63 = iterSecond4.Instance

		if v63.Parent then
			v63.Enabled = iterSecond4.OriginalEnabled and p8 > 0.02
			v63.Brightness = iterSecond4.OriginalBrightness * p8
		end
	end
end
local function tweenTornadoVisibility(p9, value, value2, p12)
	local numberValue: NumberValue = Instance.new("NumberValue")

	numberValue.Value = value
	applyTornadoVisibility(p9, value)

	local connection = numberValue:GetPropertyChangedSignal("Value"):Connect(function()
		applyTornadoVisibility(p9, numberValue.Value)
	end)

	local tweenInfo = TweenInfo.new(p12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v71: Tween = tweenService:Create(numberValue, tweenInfo, { Value = value2 })

	v71:Play()
	v71.Completed:Connect(function()
		applyTornadoVisibility(p9, value2)

		if connection then
			connection:Disconnect()
		end

		numberValue.Parent = nil
	end)

	return v71
end
local function animateTornadoScale(p13, value, value2, p16, p17, p18)
	p13:ScaleTo(value)

	local numberValue: NumberValue = Instance.new("NumberValue")

	numberValue.Value = value

	local connection = numberValue:GetPropertyChangedSignal("Value"):Connect(function()
		if p13.Parent then
			p13:ScaleTo(numberValue.Value)
		end
	end)

	local tweenInfo = TweenInfo.new(p16, p17 or Enum.EasingStyle.Quad, p18 or Enum.EasingDirection.Out)
	local v81: Tween = tweenService:Create(numberValue, tweenInfo, { Value = value2 })

	v81:Play()
	v81.Completed:Connect(function()
		if p13.Parent then
			p13:ScaleTo(value2)
		end

		if connection then
			connection:Disconnect()
		end

		numberValue.Parent = nil
	end)

	return v81
end
local function applyParticleColor(p19, p20)
	if p19 and p19.Parent and p19:IsA("ParticleEmitter") then
		p19.Color = ColorSequence.new(p20)
	end
end
local function applyTornadoSmokeRenderFix(p21, zOffset)
	if p21 and p21.Parent and p21:IsA("ParticleEmitter") then
		p21.ZOffset = zOffset
		p21.Orientation = Enum.ParticleOrientation.VelocityParallel
	end
end
local function getGroundInfoBelow(p23)
	local map: Instance = workspace:FindFirstChild("Map")
	local color3 = Color3.fromRGB(105, 105, 105)
	local v89 = Enum.Material.Rock
	local v90 = p23

	if not map then
		return color3, v89, v90, nil
	end

	local raycastParams = RaycastParams.new()

	raycastParams.FilterType = Enum.RaycastFilterType.Include
	raycastParams.FilterDescendantsInstances = { map }
	raycastParams.IgnoreWater = false

	local v92 = workspace:Raycast(p23 + Vector3.new(0, 60, 0), Vector3.new(0, -500, 0), raycastParams)

	if v92 then
		v90 = v92.Position
		v89 = v92.Material

		if v92.Instance and v92.Instance:IsA("Terrain") then
			color3 = workspace.Terrain:GetMaterialColor(v92.Material)
		elseif v92.Instance and v92.Instance:IsA("BasePart") then
			color3 = v92.Instance.Color
		end
	end

	return color3, v89, v90, v92
end
local function colorTornadoGroundParticles(p24, p25)
	local foundChild = p24:FindFirstChild("HoldHumanoidRootPart", true)

	if foundChild then
		for iterFirst, iterSecond in foundChild:GetDescendants() do
			if iterSecond:IsA("ParticleEmitter") and iterSecond.Name == "Smoke" then
				if iterSecond and iterSecond.Parent and iterSecond:IsA("ParticleEmitter") then
					iterSecond.Color = ColorSequence.new(p25)
				end

				if iterSecond and iterSecond.Parent and iterSecond:IsA("ParticleEmitter") then
					iterSecond.ZOffset = -6
					iterSecond.Orientation = Enum.ParticleOrientation.VelocityParallel
				end
			end
		end
	end

	local foundChild2 = p24:FindFirstChild("TornadoBase", true)

	if foundChild2 then
		for iterFirst2, iterSecond2 in foundChild2:GetDescendants() do
			if iterSecond2:IsA("ParticleEmitter") and iterSecond2.Name == "Smoke2" then
				if iterSecond2 and iterSecond2.Parent and iterSecond2:IsA("ParticleEmitter") then
					iterSecond2.Color = ColorSequence.new(p25)
				end

				if iterSecond2 and iterSecond2.Parent and iterSecond2:IsA("ParticleEmitter") then
					iterSecond2.ZOffset = -5
					iterSecond2.Orientation = Enum.ParticleOrientation.VelocityParallel
				end
			elseif iterSecond2:IsA("ParticleEmitter") and iterSecond2.Name == "Rocks" and iterSecond2 and iterSecond2.Parent and iterSecond2:IsA("ParticleEmitter") then
				iterSecond2.Color = ColorSequence.new(p25)
			end
		end
	end
end
local function setHoldSmokeEnabled(p26, enabled)
	local foundChild = p26:FindFirstChild("HoldHumanoidRootPart", true)

	if not foundChild then
		return
	end

	for iterFirst, iterSecond in foundChild:GetDescendants() do
		if iterSecond:IsA("ParticleEmitter") and iterSecond.Name == "Smoke" then
			iterSecond.Enabled = enabled
		end
	end
end
local function spawnSuckedGroundRock(parent, p29, p30, p31, p32, p33, p34)
	local tornadoSuckedRock: Part = Instance.new("Part")

	tornadoSuckedRock.Name = "TornadoSuckedRock"
	tornadoSuckedRock.Anchored = true
	tornadoSuckedRock.CanCollide = false
	tornadoSuckedRock.CanTouch = false
	tornadoSuckedRock.CanQuery = false
	tornadoSuckedRock.Material = p33 == Enum.Material.Air and Enum.Material.Rock or p33
	tornadoSuckedRock.Color = p32

	local v114 = random:NextNumber(0.56, 1.5)
	local v115 = random:NextNumber(0.36, 1.15)

	tornadoSuckedRock.Size = Vector3.new(v114, v115, random:NextNumber(0.56, 1.5))
	tornadoSuckedRock.Parent = parent

	local v116 = random:NextNumber(0, 6.283185307179586)
	local v117 = math.max(0.06, p31 * 0.75)
	local v118 = math.max(0.08, p31 * 1.85)
	local v119 = random:NextNumber(v117, v118)
	local v120 = random:NextNumber(16, 34)
	local v121 = random:NextNumber(5.2, 9)
	local v122 = os.clock()

	task.spawn(function()
		while tornadoSuckedRock.Parent do
			local v163 = os.clock()
			local v164 = math.clamp((v163 - v122) / p34, 0, 1)
			local n1 = 1 - (1 - v164) * (1 - v164)
			local n2 = v116 + v121 * n1

			v163 = v119 * (1 - n1 * 0.82)

			local x = p30.X
			local cosine = math.cos(n2)
			local n3 = p29.Y + 0.2 + v120 * n1
			local z = p30.Z
			local sine = math.sin(n2)
			local vector3 = Vector3.new(x + cosine * v163, n3, z + sine * v163)

			tornadoSuckedRock.Transparency = math.clamp((v164 - 0.72) / 0.28, 0, 1)

			local cFrame = CFrame.new(vector3)
			local v174 = CFrame.Angles(v164 * 9, n2, v164 * 13)

			tornadoSuckedRock.CFrame = cFrame * v174

			if v164 >= 1 then
				break
			end

			task.wait()
		end

		tornadoSuckedRock.Parent = nil
	end)
end
local function startSuckedGroundRocks(parent, p36, p37, p38, p39)
	local suckedGroundRocks: Folder = Instance.new("Folder")

	suckedGroundRocks.Name = "SuckedGroundRocks"
	suckedGroundRocks.Parent = parent

	local v129 = p36 and p36:IsA("BasePart") and p36.Size or Vector3.new(24, 60, 24)
	local n1 = math.max(v129.X, v129.Z) * 0.5
	local floored = math.floor(n1 * 1.05)
	local v132 = math.clamp(floored, 12, 28)
	local v133 = os.clock()

	task.spawn(function()
		for _ = 1, v132 do
			if not parent.Parent then
				break
			end

			local pivot = parent:GetPivot()

			spawnSuckedGroundRock(suckedGroundRocks, p37, pivot.Position, n1, p38, p39, random:NextNumber(0.85, 1.35))
			task.wait(random:NextNumber(0.04, 0.11))
		end

		while parent.Parent and os.clock() - v133 < 2.8 do
			local pivot2 = parent:GetPivot()

			spawnSuckedGroundRock(suckedGroundRocks, p37, pivot2.Position, n1, p38, p39, random:NextNumber(0.9, 1.45))
			task.wait(random:NextNumber(0.16, 0.26))
		end
	end)
end
local function stopTornadoEmitters(p40)
	for iterFirst, iterSecond in p40:GetDescendants() do
		if not iterSecond:IsA("ParticleEmitter") and not iterSecond:IsA("Trail") and not iterSecond:IsA("Beam") then
			if iterSecond:IsA("BasePart") then
				iterSecond.Transparency = 1
			elseif not iterSecond:IsA("Texture") and not iterSecond:IsA("Decal") then
				if iterSecond:IsA("Light") then
					iterSecond.Enabled = false
				end
			else
				iterSecond.Transparency = 1
			end
		else
			iterSecond.Enabled = false
		end
	end
end
local function playTornadoVisual(p41)
	if typeof(p41) == "CFrame" then
		local clone: Instance = tornadoMod:Clone()

		clone:PivotTo(p41)

		local foundChild: Instance = clone:FindFirstChild("MoveFourTornadoSFX", true)
		local parent: Instance = clone:FindFirstChild("TornadoBase", true) or clone:FindFirstChild("HoldHumanoidRootPart", true) or clone:FindFirstChild("TornadoSpin", true)

		if foundChild and foundChild:IsA("Sound") then
			foundChild:Stop()
			foundChild.TimePosition = 0

			if parent and parent:IsA("BasePart") then
				foundChild.Parent = parent
			end
		end

		local effects: Instance = workspace:FindFirstChild("Effects")
		local v142

		if effects then
			v142 = effects
		else
			local effects: Folder = Instance.new("Folder")

			effects.Name = "Effects"
			effects.Parent = workspace
			v142 = effects
		end

		clone.Parent = v142

		if foundChild and foundChild:IsA("Sound") then
			foundChild:Play()
		end

		local v144 = getTornadoFxData(clone)

		for iterFirst, iterSecond in v144.parts, nil, nil do
			local instance = iterSecond.Instance

			instance.CanCollide = false
			instance.CanTouch = false
			instance.CanQuery = false
		end

		applyTornadoVisibility(v144, 0)

		local foundChild3: Instance = clone:FindFirstChild("TornadoSpin", true)
		local foundChild4: Instance = clone:FindFirstChild("TornadoBase", true)
		local foundChild5: Instance = clone:FindFirstChild("HoldHumanoidRootPart", true)
		local v151 = os.clock()
		local u152: boolean = true
		local v153 = foundChild5 and foundChild5:IsA("BasePart") and foundChild5.Position

		if not v153 then
			v153 = clone:GetPivot().Position
		end

		local v154, v155, v156 = getGroundInfoBelow(v153)

		colorTornadoGroundParticles(clone, v154)
		startSuckedGroundRocks(clone, foundChild4, v156, v154, v155)
		animateTornadoScale(clone, 1.3, 1, 0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		tweenTornadoVisibility(v144, 0, 1, 0.3)
		task.delay(0.22, function()
			if clone.Parent then
				setHoldSmokeEnabled(clone, true)
			end
		end)
		task.spawn(function()
			local v178 = os.clock()

			while clone.Parent and u152 do
				local v179 = os.clock()
				local n1 = v179 - v178

				v178 = v179

				local n2 = v179 - v151

				if foundChild3 and foundChild3:IsA("BasePart") then
					local foundChild3CFrame = foundChild3.CFrame
					local cFrameAngles = CFrame.Angles
					local v184 = math.rad(820 * n1)
					local cFrame = cFrameAngles(0, v184, 0)

					foundChild3.CFrame = foundChild3CFrame * cFrame
				end

				if foundChild4 and foundChild4:IsA("BasePart") then
					local foundChild4CFrame = foundChild4.CFrame
					local angles = CFrame.Angles
					local v188 = math.rad(-300 * n1)
					local v189 = angles(0, v188, 0)

					foundChild4.CFrame = foundChild4CFrame * v189
				end

				if (not foundChild3 or not foundChild3:IsA("BasePart")) and (not foundChild4 or not foundChild4:IsA("BasePart")) then
					local pivot = clone:GetPivot()
					local v191 = CFrame.Angles
					local v192 = math.rad(720 * n1)
					local v193 = v191(0, v192, 0)

					clone:PivotTo(pivot * v193)
				end

				for iterFirst, iterSecond in v144.textures, nil, nil do
					local instance = iterSecond.Instance

					if instance.Parent and instance:IsA("Texture") then
						instance.OffsetStudsU = iterSecond.OriginalOffsetStudsU + n2 * 0.8
						instance.OffsetStudsV = iterSecond.OriginalOffsetStudsV - n2 * 1.4
					end
				end

				task.wait()
			end
		end)
		task.delay(3, function()
			if not clone.Parent then
				return
			end

			setHoldSmokeEnabled(clone, false)
			tweenTornadoVisibility(v144, 1, 0, 0.8)

			local cFrameValue: CFrameValue = Instance.new("CFrameValue")

			cFrameValue.Value = clone:GetPivot()

			local v198 = clone:GetScale()
			local v199 = animateTornadoScale(clone, v198, 1.5, 0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			local connection = cFrameValue:GetPropertyChangedSignal("Value"):Connect(function()
				if clone.Parent then
					clone:PivotTo(cFrameValue.Value)
				end
			end)

			local tweenInfo = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			v198 = tweenService:Create(cFrameValue, tweenInfo, { Value = cFrameValue.Value + Vector3.new(0, 12, 0) })
			v198:Play()
			v198.Completed:Connect(function()
				if connection then
					connection:Disconnect()
				end

				cFrameValue.Parent = nil
			end)
			v199.Completed:Connect(function()
				task.delay(0.05, function()
					u152 = false

					if clone.Parent then
						stopTornadoEmitters(clone)
					end
				end)
			end)
		end)
		debris:AddItem(clone, 7)

		return
	end
end

moveFour.OnClientEvent:Connect(function(p42, ...)
	if p42 == "Startup" then
		local v158 = ...
		local v159: Instance = moveFourStartupSFX
		local parent = v158 and v158:FindFirstChild("Ring") or v158 and v158:FindFirstChild("HumanoidRootPart")

		if v159 and v159:IsA("Sound") then
			if not parent then
				return
			end

			local clone: Instance = v159:Clone()

			clone.Parent = parent
			clone:Play()

			local v162 = math.max(clone.TimeLength, 2)

			debris:AddItem(clone, v162 + 0.5)

			return
		end
	elseif p42 == "Tornado" then
		playTornadoVisual(...)
	end
end)

return true
