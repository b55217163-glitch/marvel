-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")
local finisher: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Hal"):WaitForChild("Remotes"):WaitForChild("Finisher")
local fx: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Hal"):WaitForChild("Fx")
local object = setmetatable({}, { __mode = "k" })

local function hasGuyVariant(p1)
	if not p1 then
		return false
	end

	for iterFirst, iterSecond in p1:GetChildren() do
		if iterSecond.Name:lower() == "guy" then
			return true
		end
	end

	return false
end
local function getForceShieldTemplate(p2)
	local v28 = hasGuyVariant(p2)

	return fx:FindFirstChild(if v28 then "ForceShieldGuy" else "ForceShield") or fx:FindFirstChild("ForceShield")
end
local function getBodyPart(p3, p4)
	if not p3 then
		return nil
	end

	local v31 = p4 and p3:FindFirstChild(p4)

	if v31 and v31:IsA("BasePart") then
		return v31
	end

	local humanoidRootPart = p3:FindFirstChild("HumanoidRootPart")

	if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
		return humanoidRootPart
	end

	v31 = p3:FindFirstChild("UpperTorso") or p3:FindFirstChild("Torso")

	if v31 and v31:IsA("BasePart") then
		return v31
	end

	return nil
end
local function getEffectsParent()
	local effects = workspace:FindFirstChild("Effects")

	if not effects then
		effects = Instance.new("Folder")
		effects.Name = "Effects"
		effects.Parent = workspace
	end

	return effects
end
local function tween(p5, p6, p7)
	local v37: Tween = tweenService:Create(p5, p6, p7)

	v37:Play()

	return v37
end
local function stripRockParticles(p8)
	for iterFirst, iterSecond in p8:GetDescendants() do
		if iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail") or iterSecond:IsA("Beam") or iterSecond:IsA("Smoke") or iterSecond:IsA("Fire") or iterSecond:IsA("Sparkles") then
			iterSecond.Parent = nil
		end
	end
end
local function getGroundResult(p9, p10)
	local map: Instance = workspace:FindFirstChild("Map")
	local raycastParams = RaycastParams.new()

	if map then
		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.FilterDescendantsInstances = { map }
	else
		raycastParams.FilterType = Enum.RaycastFilterType.Exclude
		raycastParams.FilterDescendantsInstances = if p10 then { p10 } else {}
	end

	raycastParams.IgnoreWater = true

	return workspace:Raycast(p9 + Vector3.new(0, 8, 0), Vector3.new(0, -100, 0), raycastParams), raycastParams
end
local function applyGroundAppearance(p11, p12)
	if not p11 or not p12 or not p11:IsA("BasePart") then
		return
	end

	p11.Material = p12.Material

	if p12.Instance and p12.Instance:IsA("BasePart") then
		p11.Color = p12.Instance.Color

		return
	end

	if p12.Instance and p12.Instance:IsA("Terrain") then
		p11.Color = workspace.Terrain:GetMaterialColor(p12.Material)
	end
end
local function prepareShieldVisuals(p13)
	for iterFirst, iterSecond in p13:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			iterSecond:SetAttribute("OriginalTransparency", iterSecond.Transparency)
			iterSecond.Transparency = 1
			iterSecond.CanCollide = false
			iterSecond.CanTouch = false
			iterSecond.CanQuery = false
		elseif not iterSecond:IsA("Texture") and not iterSecond:IsA("Decal") then
			if not iterSecond:IsA("PointLight") and not iterSecond:IsA("SpotLight") and not iterSecond:IsA("SurfaceLight") then
				if iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail") or iterSecond:IsA("Beam") then
					iterSecond.Enabled = false
				end
			else
				iterSecond:SetAttribute("OriginalBrightness", iterSecond.Brightness)
				iterSecond:SetAttribute("OriginalRange", iterSecond.Range)
				iterSecond.Brightness = 0
				iterSecond.Range = 0
				iterSecond.Enabled = true
			end
		else
			iterSecond:SetAttribute("OriginalTransparency", iterSecond.Transparency)
			iterSecond.Transparency = 1
		end
	end

	if p13:IsA("BasePart") then
		p13:SetAttribute("OriginalTransparency", p13.Transparency)
		p13.Transparency = 1
		p13.CanCollide = false
		p13.CanTouch = false
		p13.CanQuery = false
	end
end
local function fadeShield(p14, p15)
	local tweenInfo = TweenInfo.new(if p15 then 0.25 else 0.75, Enum.EasingStyle.Sine, p15 and Enum.EasingDirection.Out or Enum.EasingDirection.In)

	for iterFirst, iterSecond in p14:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			local v55 = if p15 then iterSecond:GetAttribute("OriginalTransparency") or 0 else 1

			tweenService:Create(iterSecond, tweenInfo, { Transparency = v55 }):Play()
		elseif not iterSecond:IsA("Texture") and not iterSecond:IsA("Decal") then
			if iterSecond:IsA("PointLight") or iterSecond:IsA("SpotLight") or iterSecond:IsA("SurfaceLight") then
				tweenService:Create(iterSecond, tweenInfo, {
					Brightness = p15 and (iterSecond:GetAttribute("OriginalBrightness") or iterSecond.Brightness) or 0,
					Range = p15 and (iterSecond:GetAttribute("OriginalRange") or iterSecond.Range) or 0
				}):Play()
			end
		else
			local v56 = if p15 then iterSecond:GetAttribute("OriginalTransparency") or 0 else 1

			tweenService:Create(iterSecond, tweenInfo, { Transparency = v56 }):Play()
		end
	end

	if p14:IsA("BasePart") then
		local v57 = if p15 then p14:GetAttribute("OriginalTransparency") or 0 else 1

		tweenService:Create(p14, tweenInfo, { Transparency = v57 }):Play()
	end
end
local function emitFromMainAt(p16, p17)
	local mainAt = p16 and p16:FindFirstChild("MainAt", true)

	if not mainAt then
		return
	end

	for iterFirst, iterSecond in p17 do
		local foundChild = mainAt:FindFirstChild(iterSecond)

		if foundChild and foundChild:IsA("ParticleEmitter") then
			foundChild:Emit(1)
		end
	end
end
local function setIdleParticles(p18, p19)
	local mainAt = p18 and p18:FindFirstChild("MainAt", true)

	for iterFirst, value in { "IdleParticle", "IdleParticleB" }, nil, nil do
		local v69 = mainAt and mainAt:FindFirstChild(value)

		if v69 and v69:IsA("ParticleEmitter") then
			v69.Enabled = p19 == true
		end
	end
end
local function massEmitShield(p20)
	if not p20 then
		return
	end

	for iterFirst, iterSecond in p20:GetDescendants() do
		if iterSecond:IsA("ParticleEmitter") then
			iterSecond.Enabled = false

			local emitCount = iterSecond:GetAttribute("EmitCount")

			iterSecond:Emit(emitCount or 25)
		end
	end
end
local function spawnShieldRocks(p21, _)
	local v76 = getBodyPart(p21, "HumanoidRootPart")

	if not v76 then
		return {}
	end

	local v77, v78 = getGroundResult(v76.Position, p21)

	if not v77 then
		return {}
	end

	local physics = replicatedStorage.Characters:FindFirstChild("Physics")
	local v80 = physics and (physics:FindFirstChild("RockBlue") or physics:FindFirstChild("Rock"))
	v76 = {}
	local v81 = v77.Position

	for i = 1, 18 do
		local n1 = 6.283185307179586 * (i / 18)
		local n2 = math.random(38, 62) / 10
		local cosine = math.cos(n1)
		local sine = math.sin(n1)
		local vector3 = Vector3.new(cosine, 0, sine)
		local v88 = workspace:Raycast(v81 + vector3 * n2 + Vector3.new(0, 8, 0), Vector3.new(0, -100, 0), v78) or v77

		n1 = v88.Position + Vector3.new(0, 0.45, 0)

		local v89 = math.max(n2 - 1.2, 1.5)
		local v90 = v80 and v80:IsA("BasePart") and v80:Clone()

		if not v90 then
			v90 = Instance.new("Part")
		end

		stripRockParticles(v90)
		applyGroundAppearance(v90, v88)
		v90.Name = "HalFinisherShieldRockClient"
		v90.Size = Vector3.new(0, 0, 0)
		v90.Anchored = true
		v90.CanCollide = false
		v90.CanTouch = false
		v90.CanQuery = false
		v90.Transparency = 1

		local cFrame = CFrame.new(v81 + vector3 * v89 + Vector3.new(0, 0.15, 0))
		local cFrameAngles = CFrame.Angles
		local randomNumber = math.random()
		local randomNumber2 = math.random()

		v89 = cFrameAngles(randomNumber, randomNumber2, math.random())
		v90.CFrame = cFrame * v89

		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		v90.Parent = effects

		local randomNumber3 = math.random(12, 26)
		local randomNumber4 = math.random(8, 18)
		local randomNumber5 = math.random(12, 26)
		local vector32 = Vector3.new(randomNumber3 / 10, randomNumber4 / 10, randomNumber5 / 10)
		local tweenInfo = TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local cFrame2 = CFrame.new(n1)
		local angles = CFrame.Angles
		local randomNumber6 = math.random()
		local randomNumber7 = math.random()
		local v105 = angles(randomNumber6, randomNumber7, math.random())

		tweenService:Create(v90, tweenInfo, { Transparency = 0, Size = vector32, CFrame = cFrame2 * v105 }):Play()
		v76[#v76 + 1] = v90
		debris:AddItem(v90, 5)
	end

	return v76
end
local function fadeOutRocks(p23)
	for iterFirst, iterSecond in p23 or {}, nil, nil do
		if iterSecond and iterSecond.Parent then
			local tweenInfo = TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.In)

			tweenService:Create(iterSecond, tweenInfo, { Size = Vector3.new(0, 0, 0), Transparency = 1 }):Play()
			debris:AddItem(iterSecond, 0.65)
		end
	end
end
local function spawnShieldVisual(p24, p25)
	local v112 = getBodyPart(p24, "HumanoidRootPart")
	local v113 = hasGuyVariant(p25 or p24)
	local foundChild: Instance = fx:FindFirstChild(if v113 then "ForceShieldGuy" else "ForceShield")

	if not foundChild then
		foundChild = fx:FindFirstChild("ForceShield")
	end

	if v112 and foundChild then
		local v115 = object[p24]

		if v115 then
			if v115.Shield and v115.Shield.Parent then
				v115.Shield:Destroy()
			end

			fadeOutRocks(v115.Rocks)
		end

		local clone: Instance = foundChild:Clone()

		clone.Name = "HalFinisherForceShieldClient"
		prepareShieldVisuals(clone)

		local cFrame = v112.CFrame

		if clone:IsA("BasePart") then
			clone.CFrame = cFrame * CFrame.new(0, 0.45, -1.15)
			clone.Anchored = true
		end

		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		clone.Parent = effects
		emitFromMainAt(clone, { "Bubble", "Form", "Gloss" })
		setIdleParticles(clone, true)
		fadeShield(clone, true)

		local v119 = spawnShieldRocks(p24, clone)

		object[p24] = { Shield = clone, Rocks = v119 }
		debris:AddItem(clone, 8)

		return
	end
end
local function explodeShieldVisual(p26)
	local v121 = object[p26]

	if not v121 then
		return
	end

	object[p26] = nil

	local shield = v121.Shield

	if shield and shield.Parent then
		massEmitShield(shield)
		setIdleParticles(shield, false)
		fadeShield(shield, false)
		debris:AddItem(shield, 1.5)
	end

	fadeOutRocks(v121.Rocks)
end

finisher.OnClientEvent:Connect(function(p27, p28, p29)
	if p27 == "ShieldSpawn" then
		spawnShieldVisual(p28, p29)
	elseif p27 == "ShieldExplosion" then
		explodeShieldVisual(p28)
	end
end)

return true
