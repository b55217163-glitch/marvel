-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")

local function getEffectsParent()
	local effects = workspace:FindFirstChild("Effects")

	if not effects then
		effects = Instance.new("Folder")
		effects.Name = "Effects"
		effects.Parent = workspace
	end

	return effects
end
local function makeHandRocks(p1, p2)
	local t1: {[any]: any} = {}
	local effects = workspace:FindFirstChild("Effects")

	if not effects then
		effects = Instance.new("Folder")
		effects.Name = "Effects"
		effects.Parent = workspace
	end

	local raycastParams = RaycastParams.new()
	local map: Instance = workspace:FindFirstChild("Map")

	if map then
		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.FilterDescendantsInstances = { map }
	else
		raycastParams.FilterType = Enum.RaycastFilterType.Exclude
		raycastParams.FilterDescendantsInstances = {}
	end

	raycastParams.IgnoreWater = true

	for _ = 1, 20 do
		local n1 = math.random() * 3.141592653589793 * 2
		local randomNumber = math.random()
		local squareRoot = math.sqrt(randomNumber)
		local randomNumber2 = math.random(8, 60)
		local n2 = squareRoot * randomNumber2 / 10
		local cosine = math.cos(n1)
		local sine = math.sin(n1)
		local vector3 = Vector3.new(cosine * n2, 0, sine * n2)
		local randomNumber3 = math.random(-10, 18)

		n1 = workspace:Raycast(p1 + p2 * randomNumber3 / 10 + vector3 + Vector3.new(0, 10, 0), Vector3.new(0, -30, 0), raycastParams)

		if n1 then
			local randomNumber4 = math.random(5, 20)
			local randomNumber5 = math.random(4, 15)
			local randomNumber6 = math.random(5, 20)
			local vector32 = Vector3.new(randomNumber4 / 10, randomNumber5 / 10, randomNumber6 / 10)
			local v26 = n1.Position
			local vector33 = Vector3.new(0, vector32.Y * 0.45, 0)
			local v28 = n1.Position
			local vector32Y = vector32.Y
			local randomNumber7 = math.random(18, 45)
			local vector34 = Vector3.new(0, vector32Y * randomNumber7 / 100, 0)
			local giantHandRock_Client: Part = Instance.new("Part")

			giantHandRock_Client.Name = "GiantHandRock_Client"
			giantHandRock_Client.Anchored = true
			giantHandRock_Client.CanCollide = false
			giantHandRock_Client.CanTouch = false
			giantHandRock_Client.CanQuery = false
			giantHandRock_Client.Material = n1.Material
			giantHandRock_Client.Color = if n1.Instance and n1.Instance:IsA("BasePart") then n1.Instance.Color else Color3.fromRGB(80, 80, 80)
			giantHandRock_Client.Size = Vector3.new(0.05, 0.05, 0.05)

			local cFrame = CFrame.new(v26 - vector33)
			local cFrameAngles = CFrame.Angles
			local randomNumber8 = math.random()
			local randomNumber9 = math.random()
			local v37 = cFrameAngles(randomNumber8, randomNumber9, math.random())

			giantHandRock_Client.CFrame = cFrame * v37
			giantHandRock_Client.Parent = effects

			local tweenInfoNew = TweenInfo.new
			local randomNumber10 = math.random(20, 36)
			local tweenInfo = tweenInfoNew(randomNumber10 / 100, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
			local cFrame2 = CFrame.new(v28 + vector34)
			local angles = CFrame.Angles
			local randomNumber11 = math.random()
			local randomNumber12 = math.random()
			local v45 = angles(randomNumber11, randomNumber12, math.random())

			tweenService:Create(giantHandRock_Client, tweenInfo, { Size = vector32, CFrame = cFrame2 * v45 }):Play()
			t1[#t1 + 1] = giantHandRock_Client
		end
	end

	return t1
end

return {
	Play = function(p3, _, ...)
		if p3 == "GuyHandRocks" then
			local v48, v49 = ...

			if typeof(v48) == "Vector3" and typeof(v49) == "Vector3" then
				local v50 = makeHandRocks(v48, v49)

				task.delay(1.45, function()
					for iterFirst, iterSecond in v50 do
						if iterSecond and iterSecond.Parent then
							local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.In)

							tweenService:Create(iterSecond, tweenInfo, { Size = Vector3.new(0, 0, 0), Transparency = 1 }):Play()
							debris:AddItem(iterSecond, 0.5)
						end
					end
				end)

				return
			end

			return
		end
	end
}
