-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local debris: Debris = game:GetService("Debris")
local hal: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Hal")
local moveThree: Instance = hal:WaitForChild("Remotes"):WaitForChild("MoveThree")
local forceShield: Instance = hal:WaitForChild("Fx"):WaitForChild("ForceShield")
local forceShieldGuy: Instance = hal:WaitForChild("Fx"):FindFirstChild("ForceShieldGuy")

local function hasGuyVariant(p1)
	if not p1 then
		return false
	end

	for iterFirst, iterSecond in p1:GetChildren() do
		if iterSecond.Name:lower() == "guy" then
			return true
		end
	end

	return false
end
local function getForceShieldTemplate(p2)
	if hasGuyVariant(p2) and forceShieldGuy then
		return forceShieldGuy
	end

	return forceShield
end

local t1: {[any]: any} = {}

local function getShieldParent()
	local map: Instance = workspace:FindFirstChild("Map")

	if map then
		return map
	end

	return workspace:FindFirstChild("Effects") or workspace
end
local function tween(p3, p4, p5)
	local v31: Tween = tweenService:Create(p3, p4, p5)

	v31:Play()

	return v31
end
local function fadeShield(p6, enabled)
	if not p6 or not p6.Parent then
		return
	end

	local tweenInfo = TweenInfo.new(if enabled then 0.25 else 0.3, Enum.EasingStyle.Sine, enabled and Enum.EasingDirection.Out or Enum.EasingDirection.In)

	for iterFirst, iterSecond in p6:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			local v37 = if enabled then iterSecond:GetAttribute("OriginalTransparency") or 0 else 1

			tweenService:Create(iterSecond, tweenInfo, { Transparency = v37 }):Play()
		elseif not iterSecond:IsA("Texture") and not iterSecond:IsA("Decal") then
			if iterSecond:IsA("PointLight") or iterSecond:IsA("SpotLight") or iterSecond:IsA("SurfaceLight") then
				local v38 = enabled and (iterSecond:GetAttribute("OriginalBrightness") or iterSecond.Brightness) or 0
				local v39 = enabled and (iterSecond:GetAttribute("OriginalRange") or iterSecond.Range) or 0

				iterSecond.Enabled = true
				tweenService:Create(iterSecond, tweenInfo, { Brightness = v38, Range = v39 }):Play()
			elseif iterSecond:IsA("Beam") or iterSecond:IsA("Trail") then
				iterSecond.Enabled = enabled
			end
		else
			local v40 = if enabled then iterSecond:GetAttribute("OriginalTransparency") or 0 else 1

			tweenService:Create(iterSecond, tweenInfo, { Transparency = v40 }):Play()
		end
	end

	if p6:IsA("BasePart") then
		local v41 = if enabled then p6:GetAttribute("OriginalTransparency") or 0 else 1

		tweenService:Create(p6, tweenInfo, { Transparency = v41 }):Play()
	end
end
local function prepareShieldVisuals(p8)
	for iterFirst, iterSecond in p8:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			iterSecond:SetAttribute("OriginalTransparency", iterSecond.Transparency)
			iterSecond.Transparency = 1
			iterSecond.CanCollide = false
			iterSecond.CanTouch = false
			iterSecond.CanQuery = false
			iterSecond.Massless = true
		elseif not iterSecond:IsA("Texture") and not iterSecond:IsA("Decal") then
			if iterSecond:IsA("PointLight") or iterSecond:IsA("SpotLight") or iterSecond:IsA("SurfaceLight") then
				iterSecond:SetAttribute("OriginalBrightness", iterSecond.Brightness)
				iterSecond:SetAttribute("OriginalRange", iterSecond.Range)
				iterSecond.Brightness = 0
				iterSecond.Range = 0
				iterSecond.Enabled = true
			elseif iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Beam") or iterSecond:IsA("Trail") then
				iterSecond.Enabled = false
			end
		else
			iterSecond:SetAttribute("OriginalTransparency", iterSecond.Transparency)
			iterSecond.Transparency = 1
		end
	end

	if p8:IsA("BasePart") then
		p8:SetAttribute("OriginalTransparency", p8.Transparency)
		p8.Transparency = 1
		p8.CanCollide = false
		p8.CanTouch = false
		p8.CanQuery = false
		p8.Massless = true
	end
end
local function emitFromMainAt(p9, p10)
	local mainAt = p9 and p9:FindFirstChild("MainAt", true)

	if not mainAt then
		return
	end

	for iterFirst, iterSecond in p10 do
		local foundChild = mainAt:FindFirstChild(iterSecond)

		if foundChild and foundChild:IsA("ParticleEmitter") then
			foundChild:Emit(1)
		end
	end
end
local function setIdleParticle(p11, p12)
	local mainAt = p11 and p11:FindFirstChild("MainAt", true)
	local idleParticle = mainAt and mainAt:FindFirstChild("IdleParticle")

	if idleParticle and idleParticle:IsA("ParticleEmitter") then
		idleParticle.Enabled = p12 == true
	end
end
local function playEquipSound(p13)
	local v56 = p13:FindFirstChild("EquipSfx", true) or p13:FindFirstChild("Equip", true)

	if v56 and v56:IsA("Sound") then
		v56:Stop()
		v56.TimePosition = 0
		v56:Play()
	end

	return v56
end
local function createShieldHealthGui(p14)
	if not p14 then
		return nil
	end

	local LocalPlayer: Player = game:GetService("Players").LocalPlayer
	local v59 = LocalPlayer

	if v59 then
		v59 = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	end

	if not v59 then
		return nil
	end

	local halShieldHealthGui: ScreenGui = Instance.new("ScreenGui")

	debris:AddItem(halShieldHealthGui, 7)
	halShieldHealthGui.Name = "HalShieldHealthGui"
	halShieldHealthGui.IgnoreGuiInset = true
	halShieldHealthGui.ResetOnSpawn = false
	halShieldHealthGui.Enabled = false
	halShieldHealthGui.Parent = v59

	local background: Frame = Instance.new("Frame")

	background.Name = "Background"
	background.AnchorPoint = Vector2.new(0.5, 0.5)
	background.Position = UDim2.new(0.5, 0, 0.78, 0)
	background.Size = UDim2.new(0, 210, 0, 12)
	background.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	background.BackgroundTransparency = 0.5
	background.BorderSizePixel = 0
	background.Parent = halShieldHealthGui

	local fill: Frame = Instance.new("Frame")

	fill.Name = "Fill"
	fill.Size = UDim2.new(1, 0, 1, 0)
	fill.BackgroundColor3 = Color3.fromRGB(23, 222, 99)
	fill.BorderSizePixel = 0
	fill.Parent = background

	local title: TextLabel = Instance.new("TextLabel")

	title.Name = "Title"
	title.BackgroundTransparency = 1
	title.AnchorPoint = Vector2.new(0.5, 1)
	title.Position = UDim2.new(0.5, 0, 0, -13)
	title.Size = UDim2.new(1.2, 0, 0, 20)
	title.Font = Enum.Font.Arcade
	title.Text = "BUBBLE SHIELD"
	title.TextColor3 = Color3.fromRGB(23, 222, 99)
	title.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
	title.TextStrokeTransparency = 0
	title.TextScaled = true
	title.Parent = background

	local label: TextLabel = Instance.new("TextLabel")

	label.Name = "Label"
	label.BackgroundTransparency = 1
	label.AnchorPoint = Vector2.new(0.5, 0.5)
	label.Position = UDim2.new(0.5, 0, 0.5, 0)
	label.Size = UDim2.new(1, 0, 1.6, 0)
	label.Font = Enum.Font.Arcade
	label.TextColor3 = Color3.fromRGB(255, 255, 255)
	label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
	label.TextStrokeTransparency = 0
	label.TextScaled = true
	label.Text = "100%"
	label.Parent = background

	return halShieldHealthGui
end
local function updateShieldHealthGui(p15, p16, p17)
	if not p15 then
		return
	end

	local maxDamage = tonumber(p17) or p15.MaxDamage or 40
	local numberValue: number? = tonumber(p16)
	local remainingDamage = math.clamp(numberValue or maxDamage, 0, maxDamage)

	p15.MaxDamage = maxDamage
	p15.RemainingDamage = remainingDamage

	local healthGui = p15.HealthGui

	if not healthGui or not healthGui.Parent then
		return
	end

	local background = healthGui:FindFirstChild("Background")
	local fill = background and background:FindFirstChild("Fill")
	local label = background and background:FindFirstChild("Label")
	local n2 = maxDamage > 0 and remainingDamage / maxDamage or 0

	healthGui.Enabled = remainingDamage < maxDamage

	if fill then
		local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local uDim2 = UDim2.new(n2, 0, 1, 0)
		local color3 = Color3.fromRGB(23, 222, 99)

		tweenService:Create(fill, tweenInfo, { Size = uDim2, BackgroundColor3 = color3 }):Play()
	end

	if label then
		local stringFormat = string.format
		local roundedUp = math.ceil(n2 * 100)

		label.Text = stringFormat("%d%%", roundedUp)
	end
end
local function playImpactEffects(p18, p19)
	if not p18 or not p18.Shield or not p18.Shield.Parent then
		return
	end

	if p19 then
		updateShieldHealthGui(p18, p19.RemainingDamage, p19.MaxDamage)
	end

	if p18.IsLocalPlayer then
		local lastImpactCameraAt = os.clock()

		if not p18.LastImpactCameraAt or lastImpactCameraAt - p18.LastImpactCameraAt >= 0.35 then
			p18.LastImpactCameraAt = lastImpactCameraAt
		end
	end

	local shield = p18.Shield
	local foundChild = shield:FindFirstChild("ImpactEffect", true)

	if foundChild and foundChild:IsA("ParticleEmitter") then
		foundChild:Emit(3)
	end

	local foundChild2 = shield:FindFirstChild("ImpactSparks", true)

	if foundChild2 and foundChild2:IsA("ParticleEmitter") then
		foundChild2:Emit(3)
	end

	local v87 = shield:FindFirstChild("ImpactSfx", true) or shield:FindFirstChild("Impact", true)

	if v87 and v87:IsA("Sound") then
		local clone = v87:Clone()

		clone.Name = "HalShieldImpactSfx"
		clone.PlaybackSpeed = math.random(85, 120) / 100
		clone.Parent = shield
		clone:Play()

		local cloneTimeLength = clone.TimeLength
		local v90 = math.max(clone.PlaybackSpeed, 0.05)
		local v91 = math.max(cloneTimeLength / v90, 0.2)

		debris:AddItem(clone, v91 + 0.25)
	end
end
local function endVisual(p20, p21)
	local v94 = t1[p20]

	if not v94 then
		return
	end

	t1[p20] = nil

	if v94.Connection then
		v94.Connection:Disconnect()
	end

	local shield = v94.Shield
	local equipSound = v94.EquipSound

	if v94.HealthGui and v94.HealthGui.Parent then
		v94.HealthGui.Parent = nil
		v94.HealthGui = nil
	end

	if p21 and equipSound and equipSound.Parent then
		pcall(function()
			if equipSound.TimeLength > 0 then
				local v127 = math.max(equipSound.TimeLength - 0.05, 0)

				equipSound.TimePosition = math.min(5, v127)

				return
			end

			equipSound.TimePosition = 5
		end)
	end

	if shield and shield.Parent then
		local v97 = shield

		if v97 then
			v97 = shield:FindFirstChild("MainAt", true)
		end

		local idleParticle = v97 and v97:FindFirstChild("IdleParticle")

		if idleParticle and idleParticle:IsA("ParticleEmitter") then
			idleParticle.Enabled = false
		end

		emitFromMainAt(shield, { "Pop" })
		fadeShield(shield, false)
		debris:AddItem(shield, 1.55)
	end
end
local function startVisual(character, p23, p24, p25, p26)
	if character and p23 then
		endVisual(p23, false)

		local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

		if not humanoidRootPart then
			return
		end

		local clone = (if hasGuyVariant(character) and forceShieldGuy then forceShieldGuy else forceShield):Clone()

		clone.Name = "HalForceShield"
		clone:SetAttribute("ShieldToken", p23)
		prepareShieldVisuals(clone)

		if clone:IsA("BasePart") then
			clone.CFrame = humanoidRootPart.CFrame
			clone.Anchored = false
		end

		local map: Instance = workspace:FindFirstChild("Map")

		clone.Parent = if map then map else workspace:FindFirstChild("Effects") or workspace

		if clone:IsA("BasePart") then
			local humanoidRootPartWeld: WeldConstraint = Instance.new("WeldConstraint")

			humanoidRootPartWeld.Name = "HumanoidRootPartWeld"
			humanoidRootPartWeld.Part0 = clone
			humanoidRootPartWeld.Part1 = humanoidRootPart
			humanoidRootPartWeld.Parent = clone
		end

		local players: Players = game:GetService("Players")
		local v109 = players.LocalPlayer and character == players.LocalPlayer.Character

		emitFromMainAt(clone, { "Bubble", "Form", "Gloss" })

		local v110 = clone

		if v110 then
			v110 = clone:FindFirstChild("MainAt", true)
		end

		local idleParticle = v110 and v110:FindFirstChild("IdleParticle")

		if idleParticle and idleParticle:IsA("ParticleEmitter") then
			idleParticle.Enabled = true
		end

		local v112 = playEquipSound(clone)

		fadeShield(clone, true)

		local v113 = p26 and p26.MaxDamage or 40
		local v114 = p26 and p26.RemainingDamage or v113
		local v115 = createShieldHealthGui(v109)
		local t2 = {
			LastImpactCameraAt = 0,
			Character = character,
			Shield = clone,
			EquipSound = v112,
			HealthGui = v115,
			MaxDamage = v113,
			RemainingDamage = v114,
			IsLocalPlayer = v109
		}

		t1[p23] = t2
		updateShieldHealthGui(t2, v114, v113)
		v115 = clone.Parent

		local map2: Instance = workspace:FindFirstChild("Map")

		if v115 == map2 then
			t2.Connection = v115.AncestryChanged:Connect(function(_, p28)
				if p28 == nil then
					endVisual(p23, true)
				end
			end)
		end

		t2 = 0

		if typeof(p25) == "number" then
			local v118: number = workspace:GetServerTimeNow()

			t2 = math.max(0, v118 - p25)
		end

		local numberValue: number? = tonumber(p24)
		local v120 = math.max(0.2, (numberValue or 5) - t2 + 1.2)
		local taskDelay = task.delay
		local v122 = math.min(v120, 6.5)

		taskDelay(v122, function()
			endVisual(p23, false)
		end)

		return
	end
end

moveThree.OnClientEvent:Connect(function(p29, p30, p31, p32)
	if p29 == "StartVisual" then
		startVisual(p30, p31, p32 and p32.HoldTime or 5, p32 and p32.StartedAt or nil, p32)
	elseif p29 == "ImpactVisual" then
		playImpactEffects(t1[p31], p32)
	elseif p29 == "EndVisual" then
		endVisual(p31, p32 and p32.EarlyDisable == true)
	end
end)

return true
