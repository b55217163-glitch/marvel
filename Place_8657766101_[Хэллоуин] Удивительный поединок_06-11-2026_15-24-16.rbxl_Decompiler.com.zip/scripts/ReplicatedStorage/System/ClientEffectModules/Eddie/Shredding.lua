-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.1)

		local moveE = game.ReplicatedStorage.Characters.Eddie.Remotes.MoveE
		local tweenService: TweenService = game:GetService("TweenService")
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		moveE.OnClientEvent:Connect(function(p1)
			for _ = 1, 2 do
				for _, v in ipairs(p1:GetChildren()) do
					if v:IsA("Attachment") then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v11 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v11 ~= nil then
							local part: Part = Instance.new("Part")

							part.Anchored = true
							part.CanCollide = false
							part.CanTouch = false
							part.Size = Vector3.new(0, 0, 0)
							part.Parent = workspace
							game.Debris:AddItem(part, 3)
							part.Material = v11.Material
							part.Color = v11.Instance.Color

							local vWorldCFrame = v.WorldCFrame
							local vWorldCFrameRightVector = vWorldCFrame.RightVector
							local vWorldCFrameLookVector = vWorldCFrame.LookVector
							local randomNumber = math.random()
							local randomNumber2 = math.random()
							local randomNumber3 = math.random()
							local randomNumber4 = math.random()
							local randomNumber5 = math.random()
							local n1 = v11.Position + (vWorldCFrameRightVector * ((randomNumber2 * 2 - 1) * (0.4 + randomNumber4)) + vWorldCFrameLookVector * ((randomNumber3 * 2 - 1) * (0.2 + randomNumber5))) * (randomNumber * 5.5)
							local randomNumber6 = math.random()
							local vector3 = Vector3.new(0, randomNumber6 * 0.35, 0)
							local n2 = n1 + vector3

							part.CFrame = CFrame.new(n2)

							local randomNumber7 = math.random(0, 360)
							local v26 = math.rad(randomNumber7)
							local randomNumber8 = math.random(0, 360)

							n1 = math.rad(randomNumber8)

							local randomNumber9 = math.random(0, 360)
							local v29 = math.rad(randomNumber9)
							local randomNumber10 = math.random()
							local n3 = if randomNumber10 < 0.65 then 0.35 + math.random() * 1.15 else if randomNumber10 < 0.92 then 1.2 + math.random() * 1.4 else 2.4 + math.random() * 2.2
							local tweenInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
							local cFrame = CFrame.new(n2)
							local v34 = CFrame.Angles(v26, n1, v29)
							local vector32 = Vector3.new(n3, n3, n3)

							tweenService:Create(part, tweenInfo, { CFrame = cFrame * v34, Size = vector32 }):Play()

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(math.random(1, 3))

							if math.random(1, 3) == 1 then
								local function spawnChunk(p2, p3, p4, p5)
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"
									explosionPart.Size = Vector3.new(0, 0, 0)
									explosionPart.Material = part.Material
									explosionPart.CanCollide = false
									explosionPart.CanTouch = false
									explosionPart.Color = part.Color

									local partCFrame: CFrame = part.CFrame
									local randomNumber11 = math.random()
									local randomNumber12 = math.random()
									local randomNumber13 = math.random()
									local vector33 = Vector3.new((randomNumber11 * 2 - 1) * 0.8, randomNumber12 * 0.6, (randomNumber13 * 2 - 1) * 0.8)

									explosionPart.CFrame = partCFrame + vector33
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local randomNumber14 = math.random()
									local randomNumber15 = math.random()
									local randomNumber16 = math.random()
									local tweenInfo2 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
									local vector34 = Vector3.new(p2 + randomNumber14 * (p3 - p2), p2 + randomNumber15 * (p3 - p2), p2 + randomNumber16 * (p3 - p2))

									tweenService:Create(explosionPart, tweenInfo2, { Size = vector34 }):Play()

									local randomNumber17 = math.random(p4, p5)
									local randomNumber18 = math.random(0, p5)

									explosionPart.Velocity = Vector3.new(randomNumber17, randomNumber18, math.random(p4, p5))
									task.delay(2, function()
										tweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end

								spawnChunk(0.25, 0.55, -35, 35)
								spawnChunk(0.25, 0.55, -35, 35)

								if math.random() < 0.35 then
									spawnChunk(0.8, 1.7, -65, 65)
								end
							end

							local randomNumber19 = math.random()
							local n4 = 1.5 + math.random() * 3.5

							task.delay(1.6 + randomNumber19 * 1.2, function()
								local randomNumber20 = math.random(0, 360)
								local v60 = math.rad(randomNumber20)
								local randomNumber21 = math.random(0, 360)
								local v62 = math.rad(randomNumber21)
								local randomNumber22 = math.random(0, 360)
								local v64 = math.rad(randomNumber22)
								local tweenInfo3 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
								local cFrame2 = CFrame.new(part.Position)
								local v67 = CFrame.Angles(v60, v62, v64)

								tweenService:Create(part, tweenInfo3, { CFrame = cFrame2 * v67 }):Play()

								local tweenInfo4 = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
								local partCFrame: CFrame = part.CFrame
								local vector35 = Vector3.new(0, -n4, 0)

								tweenService:Create(part, tweenInfo4, { Size = Vector3.new(0, 0, 0), CFrame = partCFrame + vector35 }):Play()
							end)
						end
					end
				end

				task.wait(0.1)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Eddie.Shredding", result)
	end
end)

return true
