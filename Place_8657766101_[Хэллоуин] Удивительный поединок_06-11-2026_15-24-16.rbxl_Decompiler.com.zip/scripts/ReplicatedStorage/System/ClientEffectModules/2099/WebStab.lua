-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local webSpike = game.ReplicatedStorage.Characters["2099"].Fx.WebSpike
		local webTrap = game.ReplicatedStorage.Characters["2099"].Fx.WebTrap
		local TweenService = game.TweenService

		game.ReplicatedStorage.Characters["2099"].Remotes.WebSpikes.OnClientEvent:Connect(function(player, p2, p3)
			if not p3 then
				local clone = webSpike:Clone()

				clone.Parent = workspace
				clone.CharHand.CFrame = player.Character.RightHand.CFrame
				clone.HitPart.CFrame = player.Character.RightHand.CFrame
				TweenService:Create(clone.HitPart, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width0 = 2 }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width1 = 2 }):Play()
				game.Debris:AddItem(clone, 2)
				clone.CharHand.SparksCircle:Emit(15)
				clone.CharHand.Sparks:Emit(15)
				clone.HitPart.WebShoot.PlaybackSpeed = math.random(1, 1.2)
				clone.HitPart.WebShoot:Play()
				task.wait(0.1)
				clone.HitPart.SparksCircle:Emit(30)
				clone.HitPart.Sparks:Emit(30)

				local clone2 = webTrap:Clone()

				clone2.Parent = workspace
				game.Debris:AddItem(clone2, 5)

				for _, v in pairs(clone2:GetChildren()) do
					if v:IsA("Beam") then
						task.spawn(function()
							task.wait(2)
							TweenService:Create(v, TweenInfo.new(0.3), { Width0 = 0 }):Play()
							TweenService:Create(v, TweenInfo.new(0.3), { Width1 = 0 }):Play()
							task.wait(0.3)
							v:Destroy()
						end)
					else
						task.spawn(function()
							task.wait(2.15)
							v:Destroy()
						end)
					end
				end

				for _, v in pairs(clone2:GetChildren()) do
					if v:IsA("Beam") then
						TweenService:Create(v, TweenInfo.new(0.15), { Width0 = 2 }):Play()
						TweenService:Create(v, TweenInfo.new(0.15), { Width1 = 2 }):Play()
					end
				end

				for _, v in pairs(clone2:GetChildren()) do
					v.Parent = p2.LowerTorso
				end

				task.wait(0.15)
				TweenService:Create(clone.CharHand, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				task.wait(1.4)
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.5), { Width0 = 0 }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.5), { Width1 = 0 }):Play()
				task.wait(1)

				return
			end

			if math.random(1, 2) == 1 then
				local clone = webSpike:Clone()

				clone.Parent = workspace
				clone.CharHand.CFrame = player.Character.RightHand.CFrame
				clone.HitPart.CFrame = player.Character.RightHand.CFrame
				TweenService:Create(clone.HitPart, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width0 = 2 }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width1 = 2 }):Play()
				game.Debris:AddItem(clone, 2)
				clone.CharHand.SparksCircle:Emit(15)
				clone.CharHand.Sparks:Emit(15)
				clone.HitPart.WebShoot.PlaybackSpeed = math.random(1, 1.2)
				clone.HitPart.WebShoot:Play()
				task.wait(0.1)
				clone.HitPart.SparksCircle:Emit(30)
				clone.HitPart.Sparks:Emit(30)
				task.wait(0.15)
				TweenService:Create(clone.CharHand, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				task.wait(1.4)

				local charHand = clone:FindFirstChild("CharHand")

				if charHand then
					TweenService:Create(charHand.CrazyWeb, TweenInfo.new(0.5), { Width0 = 0 }):Play()
					TweenService:Create(charHand.CrazyWeb, TweenInfo.new(0.5), { Width1 = 0 }):Play()

					return
				end
			else
				local clone = webSpike:Clone()

				clone.Parent = workspace
				clone.CharHand.CFrame = player.Character.LeftHand.CFrame
				clone.HitPart.CFrame = player.Character.LeftHand.CFrame
				TweenService:Create(clone.HitPart, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width0 = 2 }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.1), { Width1 = 2 }):Play()
				game.Debris:AddItem(clone, 2)
				clone.HitPart.WebShoot.PlaybackSpeed = math.random(1, 1.2)
				clone.HitPart.WebShoot:Play()
				task.wait(0.1)
				clone.HitPart.SparksCircle:Emit(30)
				clone.HitPart.Sparks:Emit(30)

				local clone3 = webTrap:Clone()

				clone3.Parent = workspace

				for _, v in pairs(clone3:GetChildren()) do
					if v:IsA("Beam") then
						task.spawn(function()
							task.wait(2)
							TweenService:Create(v, TweenInfo.new(0.3), { Width0 = 0 }):Play()
							TweenService:Create(v, TweenInfo.new(0.3), { Width1 = 0 }):Play()
							task.wait(0.3)
							v:Destroy()
						end)
					else
						task.spawn(function()
							task.wait(2.15)
							v:Destroy()
						end)
					end
				end

				for _, v in pairs(clone3:GetChildren()) do
					if v:IsA("Beam") then
						TweenService:Create(v, TweenInfo.new(0.15), { Width0 = 2 }):Play()
						TweenService:Create(v, TweenInfo.new(0.15), { Width1 = 2 }):Play()
					end
				end

				for _, v in pairs(clone3:GetChildren()) do
					v.Parent = p2.LowerTorso
				end

				task.wait(0.15)
				TweenService:Create(clone.CharHand, TweenInfo.new(0.15), { CFrame = p2.HumanoidRootPart.CFrame }):Play()
				task.wait(1.4)
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.5), { Width0 = 0 }):Play()
				TweenService:Create(clone.CharHand.CrazyWeb, TweenInfo.new(0.5), { Width1 = 0 }):Play()
				task.wait(1)
				game.Debris:AddItem(clone3, 1)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "2099.WebStab", result)
	end
end)

return true
