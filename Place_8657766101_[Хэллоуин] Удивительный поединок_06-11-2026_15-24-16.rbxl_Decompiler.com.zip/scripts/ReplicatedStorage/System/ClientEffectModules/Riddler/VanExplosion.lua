-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local moveESpecial = game.ReplicatedStorage.Characters.Riddler.Remotes.MoveESpecial
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function copySurface(p1, parent)
			for _, v in ipairs(p1:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh")) then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeRock(p3)
			for _, v in ipairs(p3:GetChildren()) do
				if v:IsA("Texture") or v:IsA("Decal") then
					local v25 = tweenInfoNew(0.45, Enum.EasingStyle.Linear)

					tweenService:Create(v, v25, { Transparency = 1 }):Play()
				end
			end

			local v26 = tweenInfoNew(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			local v27 = p3.Position
			local vector3 = Vector3.new(0, p3.Size.Y * 0.8, 0)

			tweenService:Create(p3, v26, {
				Transparency = 1,
				Size = Vector3.new(0.05, 0.05, 0.05),
				Position = v27 - vector3
			}):Play()
		end
		local function CreateCraterRocks(p4, p5, p6, p7, p8)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for i = 1, p5 do
				local v36 = mathRandom(-8, 8)
				local v37 = math.rad(360 / p5 * i + v36)

				v36 = mathRandom(-3, 3)

				local cosine = math.cos(v37)
				local sine = math.sin(v37)
				local vector3 = Vector3.new(cosine, 0, sine)

				vector3 = workspace:Raycast(p4.Position + vector3 * ((p6 + v36) * 2) + Vector3.new(0, 25, 0), Vector3.new(0, -60, 0), raycastParams)

				if vector3 then
					local vector3Instance = vector3.Instance

					if not vector3Instance or not vector3Instance:IsA("BasePart") then
						continue
					end

					local craterRock: Part = Instance.new("Part")

					craterRock.Name = "CraterRock"
					craterRock.Anchored = true
					craterRock.CanCollide = false
					craterRock.CanTouch = false
					craterRock.CanQuery = false
					craterRock.Material = vector3Instance.Material
					craterRock.Color = vector3Instance.Color
					craterRock.TopSurface = Enum.SurfaceType.Smooth
					craterRock.BottomSurface = Enum.SurfaceType.Smooth

					local n1 = mathRandom(p7 * 100, p8 * 100) / 100
					local v44 = mathRandom(90, 140)
					local v45 = mathRandom(45, 85)
					local v46 = mathRandom(90, 140)

					craterRock.Size = Vector3.new(n1 * v44 / 100, n1 * v45 / 100, n1 * v46 / 100) * 2
					copySurface(vector3Instance, craterRock)
					n1 = p4.Position + Vector3.new(0, -1.5, 0)

					local vector3Position = vector3.Position
					local vector32 = Vector3.new(0, craterRock.Size.Y / 2 - 0.15, 0)
					local cFrame = CFrame.new(n1)
					local cFrameAngles = CFrame.Angles

					v45 = mathRandom(-18, 18)
					v44 = math.rad(v45)
					v46 = mathRandom(-180, 180)
					v45 = math.rad(v46)

					local v51 = mathRandom(-18, 18)

					v46 = math.rad(v51)

					local v52 = cFrameAngles(v44, v45, v46)

					craterRock.CFrame = cFrame * v52
					craterRock.Parent = workspace.Effects
					debris:AddItem(craterRock, 4)
					v44 = tweenInfoNew(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

					local cFrame2 = CFrame.new(vector3Position + vector32)
					local angles = CFrame.Angles
					local v55 = mathRandom(-25, 25)
					local v56 = math.rad(v55)
					local v57 = mathRandom(-180, 180)

					v55 = math.rad(v57)

					local v58 = mathRandom(-25, 25)

					v57 = math.rad(v58)

					local v59 = angles(v56, v55, v57)

					tweenService:Create(craterRock, v44, { CFrame = cFrame2 * v59 }):Play()

					local taskDelay = task.delay

					v45 = mathRandom(0, 40)
					taskDelay(2.2 + v45 / 100, function()
						if craterRock and craterRock.Parent then
							fadeRock(craterRock)
						end
					end)
				end
			end
		end
		local function CreateExplosionDebris(p9, p10, p11)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for i = 1, p10 do
				task.delay(i * 0.01, function()
					if not p9 or not p9.Parent then
						return
					end

					local v72 = mathRandom(0, 360)
					local v73 = math.rad(v72)
					local v74 = mathRandom(5, p11)
					local cosine = math.cos(v73)
					local sine = math.sin(v73)
					local vector3 = Vector3.new(cosine, 0, sine)

					v72 = workspace:Raycast(p9.Position + vector3 * (v74 * 2) + Vector3.new(0, 25, 0), Vector3.new(0, -60, 0), raycastParams)

					if not v72 then
						return
					end

					v73 = v72.Instance

					if not v73 or not v73:IsA("BasePart") then
						return
					end

					local explosionDebris: Part = Instance.new("Part")

					explosionDebris.Name = "ExplosionDebris"
					explosionDebris.Anchored = true
					explosionDebris.CanCollide = false
					explosionDebris.CanTouch = false
					explosionDebris.CanQuery = false
					explosionDebris.Material = v73.Material
					explosionDebris.Color = v73.Color
					explosionDebris.TopSurface = Enum.SurfaceType.Smooth
					explosionDebris.BottomSurface = Enum.SurfaceType.Smooth

					local n1 = mathRandom(35, 95) / 100
					local v80 = mathRandom(70, 130)
					local v81 = mathRandom(50, 110)
					local v82 = mathRandom(70, 130)

					explosionDebris.Size = Vector3.new(n1 * v80 / 100, n1 * v81 / 100, n1 * v82 / 100) * 2
					copySurface(v73, explosionDebris)

					local v83 = p9.Position
					local v84 = mathRandom(0, 2)
					local vector33 = Vector3.new(0, v84, 0)

					n1 = v83 + vector33
					v83 = v72.Position

					local vector34 = Vector3.new(0, explosionDebris.Size.Y / 2, 0)
					local v87 = mathRandom(6, 16)

					v84 = mathRandom(2, 6)

					local vector35 = Vector3.new(0, v84, 0)
					local cFrame = CFrame.new(n1)
					local cFrameAngles = CFrame.Angles

					v80 = mathRandom(-180, 180)
					v84 = math.rad(v80)
					v81 = mathRandom(-180, 180)
					v80 = math.rad(v81)
					v82 = mathRandom(-180, 180)
					v81 = math.rad(v82)

					local v91 = cFrameAngles(v84, v80, v81)

					explosionDebris.CFrame = cFrame * v91
					explosionDebris.Parent = workspace.Effects
					debris:AddItem(explosionDebris, 3)
					v91 = tweenInfoNew(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					local cFrame3 = CFrame.new(n1 + vector3 * v87 + vector35)
					local angles = CFrame.Angles
					local v94 = mathRandom(-220, 220)
					local v95 = math.rad(v94)
					local v96 = mathRandom(-220, 220)

					v94 = math.rad(v96)

					local v97 = mathRandom(-220, 220)

					v96 = math.rad(v97)
					v82 = angles(v95, v94, v96)
					n1 = tweenService:Create(explosionDebris, v91, { CFrame = cFrame3 * v82 })
					v84 = tweenInfoNew(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

					local cFrame4 = CFrame.new(v83 + vector34)
					local v99 = CFrame.Angles

					v96 = mathRandom(-260, 260)
					v94 = math.rad(v96)
					v97 = mathRandom(-260, 260)
					v96 = math.rad(v97)

					local v100 = mathRandom(-260, 260)

					v97 = math.rad(v100)
					v95 = v99(v94, v96, v97)

					local v101: Tween = tweenService:Create(explosionDebris, v84, { CFrame = cFrame4 * v95 })

					n1:Play()
					n1.Completed:Once(function()
						if explosionDebris and explosionDebris.Parent then
							v101:Play()
						end
					end)
					v101.Completed:Once(function()
						if explosionDebris and explosionDebris.Parent then
							local taskDelay = task.delay
							local v103 = mathRandom(0, 40)

							taskDelay(1.1 + v103 / 100, function()
								if explosionDebris and explosionDebris.Parent then
									fadeRock(explosionDebris)
								end
							end)
						end
					end)
				end)
			end
		end
		local function RealisticExplosionRocks(p12)
			CreateCraterRocks(p12, 20, 8, 1.1, 2.3)
			CreateCraterRocks(p12, 16, 15, 0.8, 1.7)
			CreateExplosionDebris(p12, 18, 17)
		end

		local slamModel = game.ReplicatedStorage.Characters.SlamModel
		local explosion = game.ReplicatedStorage.Characters.Riddler.Fx.Explosion

		moveESpecial.OnClientEvent:Connect(function(player, p14)
			local Character = player.Character
			local part: Part = Instance.new("Part")

			part.Parent = workspace
			part.Position = p14
			part.Transparency = 1
			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.CanQuery = false
			game.Debris:AddItem(part, 1)
			CreateCraterRocks(part, 20, 8, 1.1, 2.3)
			CreateCraterRocks(part, 16, 15, 0.8, 1.7)
			CreateExplosionDebris(part, 18, 17)

			local clone = explosion:Clone()

			clone.Parent = workspace
			clone.CFrame = part.CFrame
			game.Debris:AddItem(clone, 8)
			clone.Flames:Emit(15)
			clone.Smoke:Emit(20)
			clone.Sparks:Emit(40)
			clone.SoundRid.PlaybackSpeed = math.random(90, 130) / 100
			clone.SoundDistance.PlaybackSpeed = math.random(90, 130) / 100
			clone.SoundRid:Play()
			clone.SoundDistance:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Riddler.VanExplosion", result)
	end
end)

return true
