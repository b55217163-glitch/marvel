-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local finisher = replicatedStorage.Characters.AtomEve.Remotes.Finisher
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random
		local v9 = workspace:FindFirstChild("Effects") or workspace
		local lungeCrack = replicatedStorage.Characters.Gigachad.Fx.LungeCrack
		local smoke = replicatedStorage.Characters.Gigachad.Fx.Smoke
		local rock = replicatedStorage.Characters.Gigachad.Fx.Rock

		local function getMap()
			local map: Instance = workspace:FindFirstChild("Map")
			local timestamp = tick()

			while not map and tick() - timestamp < 5 do
				task.wait(0.1)
				map = workspace:FindFirstChild("Map")
			end

			if map and map.Parent == workspace then
				return map
			end

			return nil
		end
		local function makeMapRayParams(_)
			local v28 = getMap()

			if not v28 then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v28 }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function isValidGroundPart(p2)
			return p2 and p2:IsA("BasePart") and p2.Parent and p2.CanCollide and p2.Transparency < 1
		end
		local function getGroundFromFakeUpperTorso(p3)
			if not p3 then
				return nil
			end

			local fakeUpperTorso = p3:FindFirstChild("FakeUpperTorso")

			if not fakeUpperTorso then
				return nil
			end

			local v33 = getMap()
			local v35

			if not v33 then
				v35 = nil
			else
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v33 }
				raycastParams.IgnoreWater = true
				v35 = raycastParams
			end

			if not v35 then
				return nil
			end

			v33 = workspace:Raycast(fakeUpperTorso.Position + Vector3.new(0, 4, 0), Vector3.new(0, -100, 0), v35)

			if not v33 then
				return nil
			end

			local instance = v33.Instance
			local v38 = instance

			if v38 then
				v38 = instance:IsA("BasePart") and instance.Parent and instance.CanCollide and instance.Transparency < 1
			end

			if not v38 then
				return nil
			end

			return v33
		end
		local function cloneSurfaceLook(p4, parent)
			parent.Material = p4.Material
			parent.Color = p4.Color

			for _, v in ipairs(p4:GetChildren()) do
				if v:IsA("Decal") or v:IsA("Texture") then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function createGroundRock(p6, p7, cFrame, parent)
			local finisherRock: Part = Instance.new("Part")

			finisherRock.Name = "FinisherRock"
			finisherRock.Anchored = true
			finisherRock.CanCollide = false
			finisherRock.CanTouch = false
			finisherRock.CanQuery = false
			finisherRock.TopSurface = Enum.SurfaceType.Smooth
			finisherRock.BottomSurface = Enum.SurfaceType.Smooth
			finisherRock.Size = p7
			finisherRock.CFrame = cFrame
			cloneSurfaceLook(p6, finisherRock)
			finisherRock.Parent = parent

			return finisherRock
		end
		local function fadeAndSink(p10, p11, p12, p13)
			task.delay(p11, function()
				if not p10 or not p10.Parent then
					return
				end

				for _, v in ipairs(p10:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v173 = tweenInfoNew(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

						tweenService:Create(v, v173, { Transparency = 1 }):Play()
					end
				end

				local v174 = tweenInfoNew(p13, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				local v175 = p10.CFrame
				local cFrame = CFrame.new(0, -p12, 0)

				tweenService:Create(p10, v174, {
					Transparency = 1,
					Size = Vector3.new(0.05, 0.05, 0.05),
					CFrame = v175 * cFrame
				}):Play()
			end)
			debris:AddItem(p10, p11 + p13 + 0.2)
		end
		local function spawnCraterPlates(p14, _, p16, p17, p18)
			for i = 1, p16 do
				local v59 = mathRandom(-8, 8)
				local v60 = math.rad(360 / p16 * i + v59)
				local randomNumber = math.random()
				local n1 = p17 + randomNumber * (p18 - p17)
				local cosine = math.cos(v60)
				local sine = math.sin(v60)

				sine = Vector3.new(cosine * n1, 0, sine * n1)

				local v65 = getMap()
				local v67

				if not v65 then
					v67 = nil
				else
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { v65 }
					raycastParams.IgnoreWater = true
					v67 = raycastParams
				end

				if not v67 then
					break
				end

				local v69 = workspace:Raycast(p14 + sine + Vector3.new(0, 12, 0), Vector3.new(0, -40, 0), v67)

				if v69 then
					local v70 = v69.Instance
					local v71 = v70

					if v71 then
						v71 = v70:IsA("BasePart") and v70.Parent and v70.CanCollide and v70.Transparency < 1
					end

					if not v71 then
						continue
					end

					v70 = mathRandom(4, 9)

					local v72 = mathRandom(1, 3)
					local vector3 = Vector3.new(v70, v72, mathRandom(4, 9))

					v71 = v69.Position

					local vector32 = Vector3.new(0, vector3.Y * 0.35, 0)

					vector32 = CFrame.new(v71 - vector32)

					local cFrameAngles = CFrame.Angles
					local v76 = mathRandom(-18, 18)
					local v77 = math.rad(v76)
					local v78 = mathRandom(-180, 180)

					v76 = math.rad(v78)

					local v79 = mathRandom(-18, 18)

					v78 = math.rad(v79)
					v72 = cFrameAngles(v77, v76, v78)
					v70 = v69.Instance

					local vector33 = Vector3.new(vector3.X * 0.35, 0.1, vector3.Z * 0.35)
					local finisherRock: Part = Instance.new("Part")

					finisherRock.Name = "FinisherRock"
					finisherRock.Anchored = true
					finisherRock.CanCollide = false
					finisherRock.CanTouch = false
					finisherRock.CanQuery = false
					finisherRock.TopSurface = Enum.SurfaceType.Smooth
					finisherRock.BottomSurface = Enum.SurfaceType.Smooth
					finisherRock.Size = vector33
					finisherRock.CFrame = vector32 * v72
					cloneSurfaceLook(v70, finisherRock)
					finisherRock.Parent = v9
					finisherRock.Transparency = 1
					v76 = tweenInfoNew(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					tweenService:Create(finisherRock, v76, { Transparency = 0, Size = vector3 }):Play()
					v70 = 1.3 + math.random() * 0.35

					local n2 = vector3.Y * 0.9
					local n3: number = 0.45

					task.delay(v70, function()
						if not finisherRock or not finisherRock.Parent then
							return
						end

						for _, v in ipairs(finisherRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v179 = tweenInfoNew(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v179, { Transparency = 1 }):Play()
							end
						end

						local v180 = tweenInfoNew(n3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						local finisherRockCFrame: CFrame = finisherRock.CFrame
						local cFrame = CFrame.new(0, -n2, 0)

						tweenService:Create(finisherRock, v180, {
							Transparency = 1,
							Size = Vector3.new(0.05, 0.05, 0.05),
							CFrame = finisherRockCFrame * cFrame
						}):Play()
					end)
					debris:AddItem(finisherRock, v70 + 0.45 + 0.2)
				end
			end
		end
		local function spawnCraterWall(p19, _, p21, p22)
			for i = 1, p21 do
				local v89 = mathRandom(-6, 6)
				local v90 = math.rad(360 / p21 * i + v89)
				local cosine = math.cos(v90)
				local sine = math.sin(v90)

				sine = Vector3.new(cosine * p22, 0, sine * p22)

				local v93 = getMap()
				local v95

				if not v93 then
					v95 = nil
				else
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { v93 }
					raycastParams.IgnoreWater = true
					v95 = raycastParams
				end

				if not v95 then
					break
				end

				v89 = workspace:Raycast(p19 + sine + Vector3.new(0, 14, 0), Vector3.new(0, -50, 0), v95)

				if v89 then
					local v97 = v89.Instance
					local v98 = v97

					if v98 then
						v98 = v97:IsA("BasePart") and v97.Parent and v97.CanCollide and v97.Transparency < 1
					end

					if not v98 then
						continue
					end

					v97 = mathRandom(4, 8)

					local v99 = mathRandom(6, 12)
					local vector3 = Vector3.new(v97, v99, mathRandom(4, 8))
					local n1 = Vector3.new(v89.Position.X, p19.Y, v89.Position.Z) - p19

					n1 = if n1.Magnitude <= 0 then Vector3.new(0, 0, -1) else n1.Unit
					v97 = v89.Position

					local vector34 = Vector3.new(0, vector3.Y, 0)
					local v103 = v89.Position
					local v104 = mathRandom(1, 4)
					local v105 = mathRandom(5, 9)
					local vector35 = Vector3.new(0, v105, 0)
					local v107 = v89.Position
					local v108 = mathRandom(2, 5)
					local vector36 = Vector3.new(0, vector3.Y * 0.25, 0)
					local n2 = v107 + n1 * v108 - vector36
					local instance = v89.Instance
					local cFrame = CFrame.new(v97 - vector34)
					local finisherRock: Part = Instance.new("Part")

					finisherRock.Name = "FinisherRock"
					finisherRock.Anchored = true
					finisherRock.CanCollide = false
					finisherRock.CanTouch = false
					finisherRock.CanQuery = false
					finisherRock.TopSurface = Enum.SurfaceType.Smooth
					finisherRock.BottomSurface = Enum.SurfaceType.Smooth
					finisherRock.Size = vector3
					finisherRock.CFrame = cFrame
					cloneSurfaceLook(instance, finisherRock)
					finisherRock.Parent = v9
					v107 = mathRandom(-90, 90)
					v105 = mathRandom(-180, 180)
					finisherRock.Orientation = Vector3.new(v107, v105, mathRandom(-90, 90))

					local finisherRockOrientation: Vector3 = finisherRock.Orientation

					v105 = mathRandom(70, 150)
					v108 = mathRandom(70, 150)

					local vector37 = Vector3.new(v105, v108, mathRandom(70, 150))

					v98 = finisherRockOrientation + vector37
					v105 = mathRandom(120, 240)
					v108 = mathRandom(120, 240)

					local vector38 = Vector3.new(v105, v108, mathRandom(120, 240))
					local n3 = v98 + vector38
					local v118 = tweenInfoNew(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					v107 = tweenService:Create(finisherRock, v118, { Position = v103 + n1 * v104 + vector35, Orientation = v98 })
					v107:Play()
					v107.Completed:Connect(function()
						if not finisherRock or not finisherRock.Parent then
							return
						end

						local v183 = tweenInfoNew(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

						tweenService:Create(finisherRock, v183, { Position = n2, Orientation = n3 }):Play()
					end)
					v105 = 1.5 + math.random() * 0.35

					local vector3Y = vector3.Y
					local n4: number = 0.5

					task.delay(v105, function()
						if not finisherRock or not finisherRock.Parent then
							return
						end

						for _, v in ipairs(finisherRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v186 = tweenInfoNew(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v186, { Transparency = 1 }):Play()
							end
						end

						local v187 = tweenInfoNew(n4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						local finisherRockCFrame: CFrame = finisherRock.CFrame
						local cFrame2 = CFrame.new(0, -vector3Y, 0)

						tweenService:Create(finisherRock, v187, {
							Transparency = 1,
							Size = Vector3.new(0.05, 0.05, 0.05),
							CFrame = finisherRockCFrame * cFrame2
						}):Play()
					end)
					debris:AddItem(finisherRock, v105 + 0.5 + 0.2)
				end
			end
		end
		local function spawnInnerBurst(p23, _, p25)
			for _ = 1, p25 do
				local v125 = mathRandom(0, 360)
				local v126 = math.rad(v125)

				v125 = mathRandom(0, 5)

				local cosine = math.cos(v126)
				local sine = math.sin(v126)

				sine = Vector3.new(cosine * v125, 0, sine * v125)

				local v129 = getMap()
				local v131

				if not v129 then
					v131 = nil
				else
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { v129 }
					raycastParams.IgnoreWater = true
					v131 = raycastParams
				end

				if not v131 then
					break
				end

				local v133 = workspace:Raycast(p23 + sine + Vector3.new(0, 12, 0), Vector3.new(0, -45, 0), v131)

				if v133 then
					local v134 = v133.Instance
					local v135 = v134

					if v135 then
						v135 = v134:IsA("BasePart") and v134.Parent and v134.CanCollide and v134.Transparency < 1
					end

					if not v135 then
						continue
					end

					v134 = mathRandom(2, 6)

					local v136 = mathRandom(2, 7)
					local vector3 = Vector3.new(v134, v136, mathRandom(2, 6))
					local n1 = v133.Position - p23

					n1 = if n1.Magnitude <= 0 then Vector3.new(0, 0, -1) else n1.Unit
					v134 = v133.Position

					local vector39 = Vector3.new(0, vector3.Y * 0.8, 0)
					local v140 = v133.Position
					local v141 = mathRandom(3, 7)
					local v142 = mathRandom(12, 20)
					local vector310 = Vector3.new(0, v142, 0)
					local v144 = v133.Position
					local v145 = mathRandom(2, 4)
					local vector311 = Vector3.new(0, vector3.Y * 0.3, 0)
					local n2 = v144 + n1 * v145 - vector311
					local instance = v133.Instance
					local cFrame = CFrame.new(v134 - vector39)
					local finisherRock: Part = Instance.new("Part")

					finisherRock.Name = "FinisherRock"
					finisherRock.Anchored = true
					finisherRock.CanCollide = false
					finisherRock.CanTouch = false
					finisherRock.CanQuery = false
					finisherRock.TopSurface = Enum.SurfaceType.Smooth
					finisherRock.BottomSurface = Enum.SurfaceType.Smooth
					finisherRock.Size = vector3
					finisherRock.CFrame = cFrame
					cloneSurfaceLook(instance, finisherRock)
					finisherRock.Parent = v9
					v144 = mathRandom(-180, 180)
					v142 = mathRandom(-180, 180)
					finisherRock.Orientation = Vector3.new(v144, v142, mathRandom(-180, 180))

					local finisherRockOrientation: Vector3 = finisherRock.Orientation

					v142 = mathRandom(120, 240)
					v145 = mathRandom(120, 240)

					local vector312 = Vector3.new(v142, v145, mathRandom(120, 240))

					v135 = finisherRockOrientation + vector312
					v142 = mathRandom(180, 300)
					v145 = mathRandom(180, 300)

					local vector313 = Vector3.new(v142, v145, mathRandom(180, 300))
					local n3 = v135 + vector313
					local v155 = tweenInfoNew(0.24, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					v144 = tweenService:Create(finisherRock, v155, { Position = v140 + n1 * v141 + vector310, Orientation = v135 })
					v144:Play()
					v144.Completed:Connect(function()
						if not finisherRock or not finisherRock.Parent then
							return
						end

						local v190 = tweenInfoNew(0.32, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

						tweenService:Create(finisherRock, v190, { Position = n2, Orientation = n3 }):Play()
					end)
					v142 = 1.2 + math.random() * 0.35

					local vector3Y = vector3.Y
					local n4: number = 0.45

					task.delay(v142, function()
						if not finisherRock or not finisherRock.Parent then
							return
						end

						for _, v in ipairs(finisherRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v193 = tweenInfoNew(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v193, { Transparency = 1 }):Play()
							end
						end

						local v194 = tweenInfoNew(n4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						local finisherRockCFrame: CFrame = finisherRock.CFrame
						local cFrame3 = CFrame.new(0, -vector3Y, 0)

						tweenService:Create(finisherRock, v194, {
							Transparency = 1,
							Size = Vector3.new(0.05, 0.05, 0.05),
							CFrame = finisherRockCFrame * cFrame3
						}):Play()
					end)
					debris:AddItem(finisherRock, v142 + 0.45 + 0.2)
				end
			end
		end
		local function spawnExplosionFX(p26, p27)
			local clone = lungeCrack:Clone()

			clone.Parent = workspace
			clone.Position = p26

			local v161 = mathRandom(-180, 180)

			clone.Orientation = Vector3.new(0, v161, 0)
			clone.Size = clone.Size * 2.6
			debris:AddItem(clone, 8)

			if clone:FindFirstChild("Boom") then
				clone.Boom:Play()
			end

			if clone:FindFirstChild("Decal") then
				local cloneDecal = clone.Decal
				local v163 = tweenInfoNew(3.5)

				tweenService:Create(cloneDecal, v163, { Transparency = 1 }):Play()
			end

			local clone2 = smoke:Clone()

			clone2.Parent = clone
			clone2.Color = ColorSequence.new(p27)
			clone2:Emit(22)
			debris:AddItem(clone2, 5)

			local clone3 = rock:Clone()

			clone3.Parent = clone
			clone3.Color = ColorSequence.new(p27)
			clone3:Emit(50)
			debris:AddItem(clone3, 5)
		end
		local function doCircularExplosion(p28)
			local v167 = getGroundFromFakeUpperTorso(p28)

			if not v167 then
				return
			end

			local v168 = v167.Position
			local instance = v167.Instance

			spawnExplosionFX(v168, instance.Color)
			spawnCraterPlates(v168, instance, 24, 2, 11)
			spawnCraterWall(v168, instance, 22, 10)
			spawnInnerBurst(v168, instance, 30)
		end

		finisher.OnClientEvent:Connect(function(p29)
			if typeof(p29) == "Instance" then
				if p29:IsA("Player") then
					p29 = p29.Character
				end

				if not p29 or not p29:IsA("Model") then
					return
				end

				doCircularExplosion(p29)

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "AtomEve.Finisher", result)
	end
end)

return true
