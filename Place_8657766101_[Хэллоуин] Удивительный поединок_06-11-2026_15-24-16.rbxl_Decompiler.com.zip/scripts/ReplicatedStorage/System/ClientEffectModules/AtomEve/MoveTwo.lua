-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local workspace: Workspace = game:GetService("Workspace")
		local moveTwo = replicatedStorage.Characters.AtomEve.Remotes.MoveTwo
		local effects: Instance = workspace:WaitForChild("Effects")
		local rock = replicatedStorage.Characters.Physics:WaitForChild("Rock")
		local flightStop = replicatedStorage.Characters.OmniMan.Fx:WaitForChild("FlightStop")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function getMap()
			local map: Instance = workspace:FindFirstChild("Map")

			if map and map.Parent == workspace then
				return map
			end

			return nil
		end
		local function makeMapRayParams()
			local map: Instance = workspace:FindFirstChild("Map")
			local v24 = if map and map.Parent == workspace then map else nil

			if not v24 then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v24 }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function cloneSurfaceLook(p1, parent)
			for _, v in ipairs(p1:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh")) then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeAndShrinkRock(p3, p4, p5)
			task.delay(p4, function()
				if not p3 or not p3.Parent then
					return
				end

				for _, v in ipairs(p3:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v111 = tweenInfoNew(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

						tweenService:Create(v, v111, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local v112 = tweenInfoNew(p5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local v113 = p3.Position
				local v114 = math.max(p3.Size.Y * 0.6, 0.1)
				local vector3 = Vector3.new(0, v114, 0)

				tweenService:Create(p3, v112, {
					Size = Vector3.new(0.05, 0.05, 0.05),
					Transparency = 1,
					Position = v113 - vector3
				}):Play()
			end)
		end
		local function emitSmokeAt(p6, p7, _)
			local clone = flightStop:Clone()

			clone.Parent = effects

			if clone:IsA("BasePart") then
				clone.CFrame = CFrame.new(p6)
				clone.Anchored = true
				clone.CanCollide = false
				clone.CanTouch = false
			end

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					if p7 then
						v.Color = ColorSequence.new(p7)
					end

					if v.Name == "Rocks" then
						v:Emit(20)
					elseif v.Name == "Smoke" then
						v:Emit(30)
					end
				elseif v:IsA("BasePart") then
					v.CanCollide = false
					v.CanTouch = false
					v.Anchored = true
				end
			end

			debris:AddItem(clone, 7)
		end
		local function launchFlyingShard(p9, p10, p11, p12, p13, p14, p15, p16)
			local clone = rock:Clone()

			clone.Parent = effects
			clone.Material = p10.Material
			clone.Color = p10.Color

			if clone:FindFirstChild("Trail") then
				clone.Trail.Color = ColorSequence.new(p10.Color)
			end

			local v49 = mathRandom(0, 360)
			local v50 = math.rad(v49)
			local v51 = mathRandom(0, 360)

			v49 = math.rad(v51)

			local v52 = mathRandom(0, 360)

			v51 = math.rad(v52)

			local v53 = CFrame.Angles(v50, v49, v51)

			clone.CFrame = p9 * v53

			if clone:IsA("BasePart") then
				local n1 = mathRandom(p13 * 10, p14 * 10) / 10

				clone.Size = Vector3.new(n1, n1, n1)
				clone.Anchored = false
				clone.CanCollide = false
				clone.CanTouch = false
			end

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

			local v56 = mathRandom(-100, 100)
			local v57 = mathRandom(p15 * 100, (p15 + 1.6) * 100)
			local v58 = mathRandom(-100, 100)
			local unit = Vector3.new(v56 / 100, v57 / 100, v58 / 100).Unit
			local v60 = mathRandom(p11, p12)

			bodyVelocity.Velocity = unit * v60
			bodyVelocity.Parent = clone
			debris:AddItem(bodyVelocity, 0.3)
			debris:AddItem(clone, p16 or 4)
		end
		local function spawnImpactRing(p17, p18, p19, p20, p21, p22, p23)
			local map: Instance = workspace:FindFirstChild("Map")
			local v69 = if map and map.Parent == workspace then map else nil
			local v71

			if not v69 then
				v71 = nil
			else
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v69 }
				raycastParams.IgnoreWater = true
				v71 = raycastParams
			end

			if not v71 then
				return
			end

			local n1 = 0

			for _ = 1, p19 do
				local cFrame = CFrame.new(p17)
				local cFrameAngles = CFrame.Angles
				local v77 = math.rad(n1)
				local v78 = cFrameAngles(0, v77, 0)
				local cFrame2 = CFrame.new(0, p22, -p18)
				local v80 = workspace:Raycast((cFrame * v78 * cFrame2).Position, Vector3.new(0, -30, 0), v71)

				n1 += 360 / p19

				if v80 then
					local instance = v80.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local impactRock: Part = Instance.new("Part")

					impactRock.Name = "ImpactRock"
					impactRock.Anchored = true
					impactRock.CanCollide = false
					impactRock.CanTouch = false
					impactRock.CastShadow = true
					impactRock.Material = instance.Material
					impactRock.Color = instance.Color
					impactRock.Size = p20
					impactRock.Transparency = 1

					local v83 = mathRandom(-180, 180)
					local v84 = mathRandom(-180, 180)

					impactRock.Orientation = Vector3.new(v83, v84, mathRandom(-180, 180))

					local vector3 = Vector3.new(0, p21, 0)

					impactRock.Position = p17 + vector3
					cloneSurfaceLook(instance, impactRock)
					impactRock.Parent = effects

					local v86 = tweenInfoNew(0.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(impactRock, v86, { Transparency = 0, Position = v80.Position }):Play()
					debris:AddItem(impactRock, (p23 or 2.8) + 1.2)

					local n2: number = 0.8

					task.delay(p23 or 2.2, function()
						if not impactRock or not impactRock.Parent then
							return
						end

						for _, v in ipairs(impactRock:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v118 = tweenInfoNew(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v118, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v119 = tweenInfoNew(n2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						local impactRockPosition: Vector3 = impactRock.Position
						local v121 = math.max(impactRock.Size.Y * 0.6, 0.1)
						local vector32 = Vector3.new(0, v121, 0)

						tweenService:Create(impactRock, v119, {
							Size = Vector3.new(0.05, 0.05, 0.05),
							Transparency = 1,
							Position = impactRockPosition - vector32
						}):Play()
					end)
				end
			end
		end
		local function getSlamPointFromCharacter(p24)
			local humanoidRootPart = p24 and p24:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return nil
			end

			local map: Instance = workspace:FindFirstChild("Map")
			local v91 = if map and map.Parent == workspace then map else nil
			local v93

			if not v91 then
				v93 = nil
			else
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v91 }
				raycastParams.IgnoreWater = true
				v93 = raycastParams
			end

			if not v93 then
				return nil
			end

			v91 = workspace:Raycast(humanoidRootPart.Position + humanoidRootPart.CFrame.LookVector * 30 + Vector3.new(0, 25, 0), Vector3.new(0, -30, 0), v93)

			if not v91 then
				return nil
			end

			return v91.Position, v91.Instance
		end
		local function spawnMainSlamEffect(p25)
			local v96, v97 = getSlamPointFromCharacter(p25)

			if v96 and v97 then
				local v98 = v97.Color

				spawnImpactRing(v96, 4.5, 14, Vector3.new(2.8, 2.8, 2.8), 7, 10, 2.8)
				task.delay(0.04, function()
					spawnImpactRing(v96, 8.5, 20, Vector3.new(2.1, 2.1, 2.1), 5, 9, 3.2)
				end)
				task.delay(0.08, function()
					spawnImpactRing(v96, 13, 28, Vector3.new(1.5, 1.5, 1.5), 3.5, 8, 3.8)
				end)

				for _ = 1, 30 do
					local cFrame = CFrame.new(v96 + Vector3.new(0, 1, 0))

					launchFlyingShard(cFrame, v97, 80, 145, 0.9, 2.8, 1.25, 4.5)
				end

				for _ = 1, 12 do
					local v102 = mathRandom(-60, 60)
					local v103 = mathRandom(0, 15)
					local v104 = mathRandom(-60, 60)
					local vector3 = Vector3.new(v102 / 10, v103 / 10, v104 / 10)
					local cFrame3 = CFrame.new(v96 + vector3)

					launchFlyingShard(cFrame3, v97, 55, 105, 0.8, 2.1, 0.95, 4.2)
				end

				emitSmokeAt(v96 - Vector3.new(0, 2.5, 0), v98, 2)

				return
			end
		end

		moveTwo.OnClientEvent:Connect(function(player)
			if not player then
				return
			end

			local Character = player.Character

			if not Character then
				return
			end

			spawnMainSlamEffect(Character)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "AtomEve.MoveTwo", result)
	end
end)

return true
