-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local counter = replicatedStorage.Characters.AtomEve.Remotes.Counter
		local glassSquare = replicatedStorage.Characters.AtomEve.Fx.GlassSquare
		local v7 = workspace:FindFirstChild("Effects") or workspace

		local function setSquareState(p1, transparency, p3, enabled)
			p1.Transparency = transparency

			for _, v in ipairs(p1:GetDescendants()) do
				if v:IsA("Decal") then
					v.Transparency = p3
				elseif v:IsA("Trail") then
					v.Enabled = enabled
				end
			end
		end
		local function randomUnitVector()
			local randomNumber = math.random(-100, 100)
			local randomNumber2 = math.random(-100, 100)
			local randomNumber3 = math.random(-100, 100)

			randomNumber3 = Vector3.new(randomNumber / 100, randomNumber2 / 100, randomNumber3 / 100)

			if randomNumber3.Magnitude == 0 then
				return Vector3.new(0, 1, 0)
			end

			return randomNumber3.Unit
		end
		local function getRandomOffset(p5, p6)
			local v23 = randomUnitVector()
			local randomNumber = math.random(p5 * 100, p6 * 100)

			return v23 * (randomNumber / 100)
		end
		local function makeSquare(p7)
			local clone = glassSquare:Clone()

			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Parent = v7

			local n1 = math.random(65, 155) / 100

			clone.Size = Vector3.new(clone.Size.X * n1, clone.Size.Y * n1, clone.Size.Z * n1)

			local randomNumber = math.random(-300, 300)
			local randomNumber4 = math.random(-300, 300)
			local randomNumber5 = math.random(-300, 300)
			local vector3 = Vector3.new(randomNumber / 100, randomNumber4 / 100, randomNumber5 / 100)
			local v32 = p7.CFrame
			local cFrame = CFrame.new(vector3)
			local cFrameAngles = CFrame.Angles
			local randomNumber6 = math.random(0, 360)
			local v36 = math.rad(randomNumber6)
			local randomNumber7 = math.random(0, 360)
			local v38 = math.rad(randomNumber7)
			local randomNumber8 = math.random(0, 360)
			local v40 = math.rad(randomNumber8)
			local v41 = cFrameAngles(v36, v38, v40)

			clone.CFrame = v32 * cFrame * v41
			setSquareState(clone, 0.5, 0.5, false)

			local v42 = randomUnitVector()
			local randomNumber9 = math.random(800, 1800)
			local n2 = v42 * (randomNumber9 / 100)
			local v45 = p7.CFrame
			local cFrame2 = CFrame.new(n2)
			local angles = CFrame.Angles
			local randomNumber10 = math.random(-180, 180)

			v38 = math.rad(randomNumber10)

			local randomNumber11 = math.random(-180, 180)

			v40 = math.rad(randomNumber11)

			local randomNumber12 = math.random(-180, 180)
			local v51 = math.rad(randomNumber12)

			v36 = angles(v38, v40, v51)

			local n3 = v45 * cFrame2 * v36
			local randomNumber13 = math.random(125, 210)
			local v54 = p7.CFrame
			local cFrame3 = CFrame.new(n2 * (randomNumber13 / 100))
			local v56 = CFrame.Angles
			local randomNumber14 = math.random(-180, 180)

			v51 = math.rad(randomNumber14)

			local randomNumber15 = math.random(-180, 180)
			local v59 = math.rad(randomNumber15)
			local randomNumber16 = math.random(-180, 180)
			local v61 = math.rad(randomNumber16)

			v40 = v56(v51, v59, v61)
			v41 = v54 * cFrame3 * v40

			local v62 = p7.CFrame
			local cFrame4 = CFrame.new(vector3)
			local v64 = CFrame.Angles
			local randomNumber17 = math.random(-180, 180)

			v51 = math.rad(randomNumber17)

			local randomNumber18 = math.random(-180, 180)

			v59 = math.rad(randomNumber18)

			local randomNumber19 = math.random(-180, 180)

			v61 = math.rad(randomNumber19)
			v40 = v64(v51, v59, v61)
			v36 = v62 * cFrame4 * v40
			task.spawn(function()
				local taskWait = task.wait
				local randomNumber20 = math.random(0, 18)

				taskWait(randomNumber20 / 100)

				if not clone.Parent or not p7.Parent then
					clone:Destroy()

					return
				end

				for _, v in ipairs(clone:GetDescendants()) do
					if v:IsA("Trail") then
						v.Enabled = true
					end
				end

				local tweenInfo = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local v77: Tween = tweenService:Create(clone, tweenInfo, { CFrame = n3 })

				v77:Play()
				v77.Completed:Wait()
				clone.Transparency = 0
				tweenService:Create(clone, TweenInfo.new(0.7), { Transparency = 0.5 }):Play()

				if not clone.Parent or not p7.Parent then
					clone:Destroy()

					return
				end

				if not clone.Parent or not p7.Parent then
					clone:Destroy()

					return
				end

				local tweenInfo2 = TweenInfo.new(1, Enum.EasingStyle.Quart, Enum.EasingDirection.In)

				v77 = tweenService:Create(clone, tweenInfo2, { CFrame = p7.CFrame })
				v77:Play()
				v77.Completed:Wait()

				if clone.Parent then
					setSquareState(clone, 1, 1, false)
					task.wait(1)
				end

				if clone then
					clone:Destroy()
				end
			end)
		end

		counter.OnClientEvent:Connect(function(player)
			local Character = player.Character

			if not Character then
				return
			end

			local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			for _ = 1, 50 do
				makeSquare(humanoidRootPart)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "AtomEve.Counter", result)
	end
end)

return true
