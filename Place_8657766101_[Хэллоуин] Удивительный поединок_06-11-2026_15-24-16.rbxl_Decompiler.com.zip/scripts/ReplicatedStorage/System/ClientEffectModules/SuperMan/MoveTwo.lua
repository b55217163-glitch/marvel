-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local moveTwo = ReplicatedStorage.Characters.SuperMan.Remotes.MoveTwo
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local v8 = workspace:FindFirstChild("Effects") or workspace
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new
		local waterDrip = game.ReplicatedFirst.Effects.Blood.Fx.WaterDrip
		local waterSplash = game.ReplicatedFirst.Effects.Blood.Fx.WaterSplash

		local function WaterDrops(p1, p2)
			for _ = 1, p2 do
				task.spawn(function()
					local boolValue: BoolValue = Instance.new("BoolValue")

					boolValue.Parent = p1
					game.Debris:AddItem(boolValue, 5)

					local clone = waterDrip:Clone()

					clone.Parent = workspace.Effects
					clone.Position = p1.Position + Vector3.new(0, 0, 0)

					local randomNumber = math.random(-30, 30)
					local randomNumber2 = math.random(6, 35)

					clone.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-30, 30))
					game.Debris:AddItem(clone, 5)
					clone.CFrame = p1.CFrame
					game.Debris:AddItem(clone, 6)
					task.spawn(function()
						local connection = game:GetService("RunService").Heartbeat:Connect(function()
							local raycastParams = RaycastParams.new()

							raycastParams.FilterType = Enum.RaycastFilterType.Include
							raycastParams.FilterDescendantsInstances = { workspace.Map }

							local v137 = workspace:Raycast(clone.Position, Vector3.new(-0.5, -0.5, -0.5), raycastParams)

							if v137 and v137.Instance.Anchored == true and v137.Instance.CanCollide == true then
								local v138 = CFrame.lookAt(v137.Position, v137.Position + v137.Normal)
								local v139 = CFrame.Angles(-1.5707963267948966, 0, 0)

								boolValue:Destroy()

								local clone2 = waterSplash:Clone()

								game.Debris:AddItem(clone2, 10)
								clone2.Parent = game.Workspace.Effects

								local clone2Size = clone2.Size

								clone2.Size = Vector3.new(0, 0, 0)
								math.random(0.5, 1)
								clone2.CFrame = v138 * v139
								clone.Anchored = true
								clone.Transparency = 1
								task.spawn(function()
									local randomNumber3 = math.random(1, 3)

									if randomNumber3 == 1 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(2.5, 0.2, 2.5) }):Play()
									elseif randomNumber3 == 2 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(3.8, 0.2, 3.8) }):Play()
									elseif randomNumber3 == 3 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(4, 0.2, 4) }):Play()
									end

									if clone2:FindFirstChild("BloodSFX") then
										clone2.BloodSFX.PlaybackSpeed = math.random(0.9, 1.2)
										clone2.BloodSFX:Play()
									end

									task.wait(math.random(3, 5))
									game:GetService("TweenService"):Create(clone2, TweenInfo.new(2), { Size = Vector3.new(0, 0, 0) }):Play()
									game.Debris:AddItem(clone2, 2)
									task.wait(0.2)
									clone:Destroy()
									task.wait(2)
									clone2:Destroy()
								end)
							end
						end)

						task.spawn(function()
							boolValue.Destroying:Connect(function()
								connection:Disconnect()
							end)
						end)
					end)
				end)
			end
		end
		local function c3(p3)
			local vector3 = Vector3.new(p3, p3, p3)

			return vector3
		end

		c3 = function(p4, p5, p6)
			local v32: Tween = tweenService:Create(p4, p5, p6)

			v32:Play()

			return v32
		end

		local function spawnMessyChunk(p7, p8, p9, p10, p11)
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.Material = p7.Material
			part.Color = p7.Color

			local n1 = 1 + mathRandom(-12, 12) * 0.01
			local vector3 = Vector3.new(p8.X * n1, p8.Y * n1, p8.Z * n1)

			part.Size = vector3

			local v41 = mathRandom(-3, 3)
			local v42 = mathRandom(-1, 2)
			local vector32 = Vector3.new(v41, v42, mathRandom(-3, 3))

			part.Position = p9 + vector32

			local cFrameAngles = CFrame.Angles

			v42 = mathRandom(-180, 180)
			v41 = math.rad(v42)

			local v45 = mathRandom(-180, 180)

			v42 = math.rad(v45)

			local v46 = mathRandom(-180, 180)

			v45 = math.rad(v46)

			local cFrame = cFrameAngles(v41, v42, v45)
			local v48 = CFrame.lookAt(Vector3.new(0, 0, 0), p11)

			part.CFrame = part.CFrame * (v48.Rotation * cFrame)

			for _, v in ipairs(p7:GetChildren()) do
				if not v:IsA("SurfaceAppearance") then
					local ok2, result2 = pcall(function()
						return v:Clone()
					end)

					if ok2 and result2 then
						result2.Parent = part
					end
				end
			end

			part.Parent = v8
			v41 = mathRandom(-2, 2)

			local vector33 = Vector3.new(v41, 0, mathRandom(-2, 2))
			local n2 = p10 + vector33

			v48 = mathRandom(0, 10) * 0.02
			task.delay(v48, function()
				local v117 = mathRandom(0, 10)
				local v118 = tweenInfoNew(0.45 + v117 * 0.01, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

				tweenService:Create(part, v118, { Position = n2 }):Play()

				local vector3Value: Vector3Value = Instance.new("Vector3Value")

				vector3Value.Value = Vector3.new(0, 0, 0)
				vector3Value.Parent = part

				local v120 = tweenInfoNew(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0)
				local v121 = mathRandom(-6, 6)

				v117 = math.rad(v121)

				local v122 = mathRandom(-12, 12)

				v121 = math.rad(v122)

				local v123 = mathRandom(-6, 6)

				v122 = math.rad(v123)

				local vector34 = Vector3.new(v117, v121, v122)

				v118 = tweenService:Create(vector3Value, v120, { Value = vector34 })
				v118:Play()
				v118.Completed:Connect(function()
					local vector3X = vector3.X
					local v128 = mathRandom(0, 20)
					local v129 = mathRandom(0, 10)
					local v130 = tweenInfoNew(0.85 + v129 * 0.05, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
					local vector35 = Vector3.new(0, vector3X * (0.35 + v128 * 0.01), 0)
					local vector36 = Vector3.new(vector3.X * 0.1, vector3.Y * 0.1, vector3.Z * 0.1)

					tweenService:Create(part, v130, { Position = n2 - vector35, Size = vector36 }):Play()
				end)

				local taskDelay = task.delay

				v121 = mathRandom(0, 6)
				taskDelay(0.6 + v121 * 0.05, function()
					for _, v in ipairs(part:GetChildren()) do
						if v:IsA("Texture") or v:IsA("Decal") then
							local v135 = tweenInfoNew(0.5, Enum.EasingStyle.Linear)

							tweenService:Create(v, v135, { Transparency = 1 }):Play()
						elseif v:IsA("ParticleEmitter") then
							v.Enabled = false
						end
					end
				end)
			end)
			debris:AddItem(part, 2.5 + v48)
		end
		local function spawnRockRing(p12, p13, p14, p15, p16)
			local n1 = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace:FindFirstChild("Map") or workspace }
			raycastParams.IgnoreWater = true

			local n2 = 360 / p15

			for _ = 1, p15 do
				if mathRandom(1, 100) <= 78 then
					local v64 = mathRandom(-45, 45)
					local v65 = math.rad(n1 + n2 * (v64 / 100))

					v64 = mathRandom(-p13 * 0.25, p13 * 0.25)

					local v66 = p12.CFrame
					local v67 = CFrame.fromEulerAnglesXYZ(0, v65, 0)
					local cFrame = CFrame.new(0, 0, -(p13 + v64))
					local v69 = (v66 * v67 * cFrame).Position
					local vector3 = Vector3.new(0, p16, 0)
					local v71 = workspace:Raycast(v69 + vector3, Vector3.new(0, -1, 0) * (p16 * 2), raycastParams)

					if v71 then
						local v72 = p12.Position
						local v73 = mathRandom(-4, 4)
						local v74 = mathRandom(0, 3)
						local vector37 = Vector3.new(v73, v74, mathRandom(-4, 4))

						spawnMessyChunk(v71.Instance, p14, v72 + vector37, v71.Position, v71.Normal)
					end
				end

				n1 += n2
			end
		end
		local function flingSingleRock(p17, material, p19)
			local clone = ReplicatedStorage.Characters.Physics.Rock:Clone()

			clone.Parent = workspace.Effects
			clone.Material = material
			clone.Color = p19

			if clone:FindFirstChild("Trail") then
				clone.Trail.Color = ColorSequence.new(p19)
			end

			local cFrameAngles = CFrame.Angles
			local v81 = mathRandom(0, 360)
			local v82 = math.rad(v81)
			local v83 = mathRandom(0, 360)

			v81 = math.rad(v83)

			local v84 = mathRandom(0, 360)

			v83 = math.rad(v84)

			local cFrame = cFrameAngles(v82, v81, v83)

			clone.CFrame = p17 * cFrame

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)
			v81 = mathRandom(-8, 8)
			v83 = mathRandom(3, 12)

			local unit = Vector3.new(v81, v83, mathRandom(-8, 8)).Unit

			v81 = mathRandom(35, 80)
			bodyVelocity.Velocity = unit * v81
			bodyVelocity.Parent = clone
			debris:AddItem(clone, 3)
			debris:AddItem(bodyVelocity, 0.25)
		end
		local function TestRock(p20)
			spawnRockRing(p20, 20, Vector3.new(10, 10, 10), 20, 10)
		end
		local function TestRock2(p21)
			spawnRockRing(p21, 5, Vector3.new(3, 2, 3), 20, 10)
		end
		local function TestRock3(p22)
			spawnRockRing(p22, 10, Vector3.new(5, 2, 5), 20, 10)
		end

		local moveTwoPart = game.ReplicatedStorage.Characters.SuperMan.Fx.MoveTwoPart
		local debris2: Debris = game:GetService("Debris")

		local function SpawnGroundEffect(p23)
			if not p23 or not p23:FindFirstChild("HumanoidRootPart") then
				return
			end

			local HumanoidRootPartPosition = p23.HumanoidRootPart.Position
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace:FindFirstChild("Map") }
			raycastParams.IgnoreWater = true

			local v94 = workspace:Raycast(HumanoidRootPartPosition, Vector3.new(0, -10, 0), raycastParams)
			local clone = moveTwoPart:Clone()

			clone.Parent = workspace:FindFirstChild("Effects") or workspace
			debris2:AddItem(clone, 6)

			if v94 then
				local cFrame = CFrame.new(v94.Position)
				local cFrameAngles = CFrame.Angles
				local randomNumber = math.random(0, 360)
				local v99 = math.rad(randomNumber)
				local v100 = cFrameAngles(0, v99, 0)

				clone.CFrame = cFrame * v100

				local instance = v94.Instance

				if instance and instance:IsA("BasePart") then
					local instanceColor = instance.Color

					if clone:FindFirstChild("GroundLand") then
						clone.GroundLand.Color = ColorSequence.new(instanceColor)
					end

					if clone:FindFirstChild("TwoAt") then
						for _, v in ipairs(clone.TwoAt:GetChildren()) do
							if v:IsA("ParticleEmitter") then
								v.Color = ColorSequence.new(instanceColor)
							end
						end
					end
				end

				if clone:FindFirstChild("GroundLand") then
					clone.GroundLand:Emit(30)
				end

				if clone:FindFirstChild("TwoAt") then
					if p23.Brutality.Value == false then
						local cloneTwoAt = clone.TwoAt

						if cloneTwoAt:FindFirstChild("Shock") then
							cloneTwoAt.Shock:Emit(2)
						end

						if cloneTwoAt:FindFirstChild("Shock2") then
							cloneTwoAt.Shock2:Emit(2)
						end

						if cloneTwoAt:FindFirstChild("ShockwaveMiddle") then
							cloneTwoAt.ShockwaveMiddle:Emit(2)
						end

						if cloneTwoAt:FindFirstChild("SparksCircle") then
							cloneTwoAt.SparksCircle:Emit(12)

							return
						end
					else
						local cloneTwoAtBrut = clone.TwoAtBrut

						WaterDrops(p23.HumanoidRootPart, 15)

						if cloneTwoAtBrut:FindFirstChild("Shock") then
							cloneTwoAtBrut.Shock:Emit(2)
						end

						if cloneTwoAtBrut:FindFirstChild("Shock2") then
							cloneTwoAtBrut.Shock2:Emit(2)
						end

						if cloneTwoAtBrut:FindFirstChild("ShockwaveMiddle") then
							cloneTwoAtBrut.ShockwaveMiddle:Emit(2)
						end

						if cloneTwoAtBrut:FindFirstChild("Water") then
							cloneTwoAtBrut.Water:Emit(50)
						end

						if cloneTwoAtBrut:FindFirstChild("Water2") then
							cloneTwoAtBrut.Water2:Emit(50)
						end

						if cloneTwoAtBrut:FindFirstChild("Water3") then
							cloneTwoAtBrut.Water3:Emit(50)

							return
						end
					end

					return
				end

				return
			end
		end

		moveTwo.OnClientEvent:Connect(function(player)
			local Character = player.Character

			if not Character then
				return
			end

			local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			SpawnGroundEffect(Character)
			spawnRockRing(humanoidRootPart, 20, Vector3.new(10, 10, 10), 20, 10)
			spawnRockRing(humanoidRootPart, 5, Vector3.new(3, 2, 3), 20, 10)
			spawnRockRing(humanoidRootPart, 10, Vector3.new(5, 2, 5), 20, 10)

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace:FindFirstChild("Map") or workspace }
			raycastParams.IgnoreWater = true

			local v111 = workspace:Raycast(humanoidRootPart.Position + Vector3.new(0, 10, 0), Vector3.new(0, -20, 0), raycastParams)

			if v111 then
				for _ = 1, mathRandom(2, 4) do
					flingSingleRock(humanoidRootPart.CFrame, v111.Instance.Material, v111.Instance.Color)
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SuperMan.MoveTwo", result)
	end
end)

return true
