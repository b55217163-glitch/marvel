-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local counter = game.ReplicatedStorage.Characters.SuperMan.Remotes.Counter

		game:GetService("TweenService")

		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceTerrain: Terrain = workspace.Terrain
		local random = Random.new()

		local function getHitBelow(p1, filterDescendantsInstances)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = filterDescendantsInstances

			local v15 = workspace:Raycast(p1 + Vector3.new(0, 50, 0), Vector3.new(0, -500, 0), raycastParams)

			if v15 then
				return v15
			end

			return workspace:Raycast(p1 + Vector3.new(0, -10, 0), Vector3.new(0, 30, 0), raycastParams)
		end
		local function colorFromHit(p3)
			if p3.Instance and p3.Instance:IsA("Terrain") then
				local ok2, result2 = pcall(function()
					return workspaceTerrain:GetMaterialColor(p3.Material)
				end)

				return ok2 and result2 or Color3.new(0.45, 0.45, 0.45)
			end

			return p3.Instance and p3.Instance.Color or Color3.new(0.45, 0.45, 0.45)
		end
		local function ObjectRocks(p4)
			local t1: {[any]: any} = {}

			if workspace:FindFirstChild("Map") then
				table.insert(t1, workspace.Map)
			end

			table.insert(t1, workspaceTerrain)

			for _ = 1, 50 do
				local v22 = getHitBelow(p4.WorldPosition, t1)

				if v22 then
					local n1 = v22.Position + v22.Normal * 0.05
					local v24 = random:NextNumber(-0.1, 0.1)
					local v25 = random:NextNumber(-0.1, 0.1)
					local vector3 = Vector3.new(v24, 0, v25)
					local rockPebble: Part = Instance.new("Part")

					rockPebble.Name = "RockPebble"
					rockPebble.Anchored = true
					rockPebble.CanCollide = false
					rockPebble.CanTouch = false
					rockPebble.Size = Vector3.new(0, 0, 0)
					rockPebble.Material = v22.Material
					rockPebble.Color = colorFromHit(v22)
					rockPebble.CFrame = CFrame.new(n1 + vector3)
					rockPebble.Parent = workspace
					debris:AddItem(rockPebble, 3)

					local v28 = random:NextInteger(0, 360)
					local v29 = math.rad(v28)
					local v30 = random:NextInteger(0, 360)

					n1 = math.rad(v30)
					v30 = random:NextInteger(0, 360)

					local v31 = math.rad(v30)

					v28 = random:NextNumber(2, 2.5)

					local cFrame = CFrame.new(rockPebble.Position)
					local v33 = CFrame.Angles(v29, n1, v31)

					tweenService:Create(rockPebble, TweenInfo.new(0.25), { CFrame = cFrame * v33 }):Play()

					local vector32 = Vector3.new(v28, v28, v28)

					tweenService:Create(rockPebble, TweenInfo.new(0.25), { Size = vector32 }):Play()

					if smoke then
						local clone = smoke:Clone()

						clone.Parent = rockPebble

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, rockPebble.Color)

						clone.Color = colorSequenceNew({
							colorSequenceKeypoint,
							ColorSequenceKeypoint.new(1, rockPebble.Color)
						})
						clone:Emit(2)
					end

					if random:NextInteger(1, 3) == 1 then
						local explosionPart: Part = Instance.new("Part")

						explosionPart.Name = "ExplosionPart"
						explosionPart.Anchored = false
						explosionPart.CanCollide = true
						explosionPart.Material = rockPebble.Material
						explosionPart.Color = rockPebble.Color
						explosionPart.Size = Vector3.new(0, 0, 0)

						local rockPebbleCFrame: CFrame = rockPebble.CFrame
						local v40 = CFrame.Angles(v29, n1, v31)

						explosionPart.CFrame = rockPebbleCFrame * v40
						explosionPart.Parent = workspace
						debris:AddItem(explosionPart, 3)

						local v41 = random:NextNumber(1.5, 2.5)
						local v42 = random:NextNumber(1.5, 2.5)
						local vector33 = Vector3.new(v41, v42, random:NextNumber(1.5, 2.5))

						tweenService:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

						local v44 = random:NextNumber(-80, 80)

						v40 = random:NextNumber(0, 80)
						explosionPart.AssemblyLinearVelocity = Vector3.new(v44, v40, random:NextNumber(-80, 80))
						task.delay(2, function()
							if explosionPart.Parent then
								tweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end
						end)

						local part: Part = Instance.new("Part")

						part.Name = "ExplosionPart"
						part.Anchored = false
						part.CanCollide = true
						part.Material = rockPebble.Material
						part.Color = rockPebble.Color
						part.Size = Vector3.new(0, 0, 0)

						local v46: CFrame = rockPebble.CFrame

						v40 = CFrame.Angles(v29, n1, v31)
						part.CFrame = v46 * v40
						part.Parent = workspace
						debris:AddItem(part, 3)
						tweenService:Create(part, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()
						v44 = random:NextNumber(-40, 40)
						v40 = random:NextNumber(0, 40)
						part.AssemblyLinearVelocity = Vector3.new(v44, v40, random:NextNumber(-40, 40))
						task.delay(2, function()
							if part.Parent then
								tweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end
						end)
					end

					v30 = random:NextNumber(2, 2.3)
					task.delay(v30, function()
						if not rockPebble or not rockPebble.Parent then
							return
						end

						local v50 = random:NextInteger(0, 360)
						local v51 = math.rad(v50)
						local v52 = random:NextInteger(0, 360)

						v50 = math.rad(v52)

						local v53 = random:NextInteger(0, 360)

						v52 = math.rad(v53)

						local cFrame2 = CFrame.new(rockPebble.Position)
						local v55 = CFrame.Angles(v51, v50, v52)

						tweenService:Create(rockPebble, TweenInfo.new(0.5), { CFrame = cFrame2 * v55 }):Play()
						tweenService:Create(rockPebble, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
						tweenService:Create(rockPebble, TweenInfo.new(0.5), { CFrame = rockPebble.CFrame + Vector3.new(0, -3, 0) }):Play()
					end)
				end

				task.wait(0.05)
			end
		end

		counter.OnClientEvent:Connect(function(player, p6)
			local Character = player.Character

			ObjectRocks(p6)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SuperMan.Counter", result)
	end
end)

return true
