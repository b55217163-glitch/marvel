-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Vigilante.Remotes.Finisher
		local finish = game.ReplicatedStorage.Characters.Vigilante.AnimationsExtra.Finish
		local finisherHit = game.ReplicatedStorage.Characters.Vigilante.AnimationsExtra.FinisherHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local explosionBlur = game.ReplicatedStorage.Characters.Physics.ExplosionBlur
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v24 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v26 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v26, 0)
				local n2 = v24 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v29 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v29 then
					local instance = v29.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v35 = mathRandom(-180, 180)
					local v36 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v35, v36, mathRandom(-180, 180))
					part.Position = p1.Position

					local v37 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v37, { Position = v29.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v95 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v95, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v96 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v96, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v42 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v44 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v46 = math.rad(randomNumber3)
						local v47 = cFrameAngles(v42, v44, v46)

						clone.CFrame = p1.CFrame * v47

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						bodyVelocity.Parent = clone
						clone.Parent = workspace.Effects
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
						clone.Flame.Enabled = true
						clone.Sparks.Enabled = true
						clone.PointLight.Enabled = true
						clone.Glow.Enabled = true
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v55 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v57 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v57, 0)
				local n2 = v55 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v60 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v60 then
					local instance = v60.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v66 = mathRandom(-180, 180)
					local v67 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v66, v67, mathRandom(-180, 180))
					part.Position = p2.Position

					local v68 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v68, { Position = v60.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v101 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v101, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v102 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v102, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v73 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v75 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v75, 0)
				local n2 = v73 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v78 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v78 then
					local instance = v78.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v84 = mathRandom(-180, 180)
					local v85 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v84, v85, mathRandom(-180, 180))
					part.Position = p3.Position

					local v86 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v86, { Position = v78.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v107 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v107, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v108 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v108, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local explosionEffect = game.ReplicatedStorage.Characters.TheBatman.Fx.ExplosionEffect

		finisher.OnClientEvent:Connect(function(p4, p5)
			local n1: number = 1
			local v90 = animationService.GetTrack(p4.Humanoid, finisherHit)
			local v91 = animationService.LoadFresh(p5.Humanoid, finish)
			local clone = p5.Head.ThroatAt:Clone()

			clone.Parent = p4.Head
			p5.P90.Transparency = 0
			v91.KeyframeReached:Connect(function(p6)
				if p6 == "StartShooting" then
					p5.Head.FinisherSfx:Play()

					if p4.Head:FindFirstChild("LongScream") then
						p4.Head.LongScream:Play()
					end

					while true do
						n1 += 1
						p5.P90.FsAt.Flash:Emit(1)
						p5.P90.FsAt.Smoke:Emit(30)
						p5.P90.BulletAt.Bullet:Emit(1)
						p5.P90.Light.Enabled = true
						clone.Blood2:Emit(4)
						clone.Blood3:Emit(4)
						clone.Blood4:Emit(4)

						for _ = 1, 4 do
							local randomNumber = math.random(5, 10)
							local clone2 = bloodDrip:Clone()

							clone2.Parent = workspace

							local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

							clone2.Parent = p5
							clone2.CFrame = p4.UpperTorso.CFrame
							clone2.LocalScript.Disabled = false
							bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

							local randomNumber6 = math.random(-2, 2)
							local randomNumber7 = math.random(-2, 2)

							bodyVelocity.Velocity = Vector3.new(randomNumber6, randomNumber7, math.random(-2, 2)) * randomNumber
							game.Debris:AddItem(clone2, 3)
							game.Debris:AddItem(bodyVelocity, 0.15)
						end

						task.wait(0.1)
						p5.P90.Light.Enabled = false
						p5.P90.FsAt.Flash:Emit(1)
						p5.P90.FsAt.Smoke:Emit(30)
						p5.P90.BulletAt.Bullet:Emit(1)
						clone.Blood2:Emit(3)
						clone.Blood3:Emit(3)
						clone.Blood4:Emit(3)

						for _ = 1, 4 do
							local randomNumber8 = math.random(5, 10)
							local clone3 = bloodDrip:Clone()

							clone3.Parent = workspace

							local bodyVelocity2: BodyVelocity = Instance.new("BodyVelocity", clone3)

							clone3.Parent = p5
							clone3.CFrame = p4.UpperTorso.CFrame
							clone3.LocalScript.Disabled = false
							bodyVelocity2.MaxForce = Vector3.new(inf, inf, inf) * math.huge

							local randomNumber9 = math.random(-2, 2)
							local randomNumber10 = math.random(-2, 2)

							bodyVelocity2.Velocity = Vector3.new(randomNumber9, randomNumber10, math.random(-2, 2)) * randomNumber8
							game.Debris:AddItem(clone3, 3)
							game.Debris:AddItem(bodyVelocity2, 0.15)
						end

						if n1 == 8 then
							break
						end
					end
				end

				if p6 == "StopShooting" then
					p5.Grenade.Transparency = 0

					if p4.Head:FindFirstChild("LongScream") then
						game.TweenService:Create(p4.Head.LongScream, TweenInfo.new(0.2), { Volume = 0 }):Play()
					end
				end

				if p6 == "GrenadeGrab" then
					p5.P90.Transparency = 1
					p5.Grenade.GlideTrail.Enabled = true
				end

				if p6 == "GrenadeHitGround" then
					p5.Grenade.GlideTrail.Enabled = false
				end

				if p6 == "Explosion" then
					p5.P90.Transparency = 1
					p5.Grenade.Transparency = 1
					TestRock(p4.HumanoidRootPart)
					TestRock2(p4.HumanoidRootPart)

					local clone4 = explosionEffect:Clone()

					clone4.Parent = workspace
					clone4.Position = p4.HumanoidRootPart.Position
					clone4.Smoke:Emit(30)
					clone4.Sparks:Emit(60)
					clone4.Attachment.Explo:Emit(60)
					game.Debris:AddItem(clone4, 3)

					local clone5 = explosionBlur:Clone()

					clone5.Parent = p5
					game.Debris:AddItem(clone5, 4)

					local clone6 = explosionBlur:Clone()

					clone6.Parent = p4
					game.Debris:AddItem(clone6, 4)
					task.wait(1.5)
				end
			end)
			v90:Play()
			v91:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Vigilante.Finisher", result)
	end
end)

return true
