-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gunshot = game.ReplicatedStorage.Characters.Vigilante.Fx.Gunshot
		local sniperShot = game.ReplicatedStorage.Characters.Vigilante.Fx.SniperShot

		game.ReplicatedStorage.Characters.Vigilante.Remotes.GunshotCombat.OnClientEvent:Connect(function(p1)
			local clone = gunshot:Clone()

			clone.Parent = p1.Head
			clone.PlaybackSpeed = math.random(1, 1.2)
			clone:Play()
			game.Debris:AddItem(clone, 2.3)

			local clone2 = p1.Gun.GunParticleHolder.BulletAt.Bullet:Clone()

			clone2.Parent = p1.Gun.GunParticleHolder.BulletAt
			clone2:emit(1)
			game.Debris:AddItem(clone2, 1)

			local clone3 = p1.Gun.GunParticleHolder.FsAt.Flash:Clone()

			clone3.Parent = p1.Gun.GunParticleHolder.FsAt
			clone3:emit(1)
			game.Debris:AddItem(clone3, 1)

			local clone4 = p1.Gun.GunParticleHolder.FsAt.Smoke:Clone()

			clone4.Parent = p1.Gun.GunParticleHolder.FsAt
			clone4:emit(10)
			game.Debris:AddItem(clone4, 2)

			local clone5 = p1.Gun.GunParticleHolder.Light:Clone()

			clone5.Parent = p1.Gun.GunParticleHolder
			clone5.Enabled = true
			game.Debris:AddItem(clone5, 0.35)
			game.TweenService:Create(clone5, TweenInfo.new(0.3), { Brightness = 0 }):Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Vigilante.Combat", result)
	end
end)

return true
