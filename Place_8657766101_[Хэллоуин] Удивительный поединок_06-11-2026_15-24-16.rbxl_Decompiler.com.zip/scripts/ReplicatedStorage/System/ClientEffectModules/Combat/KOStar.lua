-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local ReplicatedStorage = game.ReplicatedStorage
		local combat = ReplicatedStorage.Characters.Combat
		local koStar = combat.Remotes.KoStar
		local finalTrailEffect = combat.Fx.FinalTrailEffect
		local kOStar = combat.Animations.KOStar
		local mediumRock = ReplicatedStorage.Movement.Rocks.Fx.MediumRock
		local smoke = ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local strongBoom = ReplicatedStorage.Movement.Rocks.Sfx.StrongBoom

		game:GetService("Debris")

		local runService: RunService = game:GetService("RunService")
		local koStarRequest = combat.Remotes:WaitForChild("KoStarRequest")

		local function GetRoot(p1)
			if typeof(p1) ~= "Instance" or not p1:IsA("Model") or not p1.Parent then
				return nil
			end

			local humanoidRootPart = p1:FindFirstChild("HumanoidRootPart")

			if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
				return humanoidRootPart
			end

			if p1.PrimaryPart and p1.PrimaryPart:IsA("BasePart") then
				return p1.PrimaryPart
			end

			local v26 = p1:FindFirstChild("UpperTorso") or p1:FindFirstChild("Torso")

			return v26 and v26:IsA("BasePart") and v26 or nil
		end
		local function PreKnockbackReset(p2)
			if not p2 then
				return
			end

			for _, v in ipairs(p2:GetDescendants()) do
				if v.Name ~= "KOStarBodyPos" and (v:IsA("BodyMover") or v:IsA("LinearVelocity") or v:IsA("AngularVelocity") or v:IsA("VectorForce") or v:IsA("AlignPosition") or v:IsA("AlignOrientation")) then
					v:Destroy()
				end
			end

			for _, v in ipairs(p2:GetDescendants()) do
				if v:IsA("BasePart") then
					v.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
					v.Velocity = Vector3.new(0, 0, 0)
					v.RotVelocity = Vector3.new(0, 0, 0)
				end
			end
		end
		local function ArcShootForward(p3, p4)
			task.spawn(function()
				local humanoidRootPart = p3:FindFirstChild("HumanoidRootPart")
				local humanoidRootPart2 = p4:FindFirstChild("HumanoidRootPart")

				if humanoidRootPart and humanoidRootPart2 then
					PreKnockbackReset(p3)

					local humanoid = p3:FindFirstChildOfClass("Humanoid")

					if humanoid then
						humanoid:ChangeState(Enum.HumanoidStateType.Physics)
						humanoid.AutoRotate = false
					end

					local humanoidRootPartAnchored = humanoidRootPart.Anchored

					humanoidRootPart.Anchored = true
					humanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)

					local humanoidRootPartPosition = humanoidRootPart.Position
					local v123 = (humanoidRootPart2.CFrame * CFrame.new(0, 0, -500)).Position
					local n1 = (humanoidRootPartPosition + v123) * 0.5 + Vector3.new(0, 300, 0)
					local v125 = os.clock()

					while true do
						local n2 = (os.clock() - v125) / 4

						if n2 >= 1 then
							break
						end

						local v127 = humanoidRootPartPosition:Lerp(n1, n2)
						local v128 = n1:Lerp(v123, n2)
						local v129 = v127:Lerp(v128, n2)

						p3:PivotTo(CFrame.new(v129, v129 + humanoidRootPart2.CFrame.LookVector))
						runService.Heartbeat:Wait()
					end

					p3:PivotTo(CFrame.new(v123, v123 + humanoidRootPart2.CFrame.LookVector))
					humanoidRootPart.Anchored = humanoidRootPartAnchored

					if humanoid then
						humanoid.AutoRotate = true
						humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
					end

					return
				end
			end)
		end

		ArcShootForward = function(p5, parent)
			local clone = p5:Clone()

			clone.Parent = parent

			return clone
		end

		local function PlayAnimation(p7)
			local humanoid = p7:WaitForChild("Humanoid", 6)

			if not humanoid then
				return
			end

			local animator = humanoid:FindFirstChildOfClass("Animator")

			if not animator then
			elseif humanoid and animator then
				local ok2, result2 = pcall(function()
					animationService.GetTrack(animator, kOStar):Play()
				end)

				if not ok2 then
					print(result2)
				end
			end
		end
		local function PlaySound(p8, parent)
			if p8 and parent then
				local clone = p8:Clone()

				clone.Parent = parent
				clone:Play()
			end
		end
		local function PlayLongScream(p10, p11)
			if p10 and p11 then
				if p10:FindFirstChild("Head") and p10.Head:FindFirstChild("LongScream") then
					local longScream = p10.Head.LongScream

					if not longScream.Playing then
						longScream.RollOffMaxDistance = 500
						longScream.Volume = 1
						longScream.Looped = false
						longScream.TimePosition = 0

						local reverbSoundEffect: ReverbSoundEffect = Instance.new("ReverbSoundEffect", longScream)

						reverbSoundEffect.DecayTime = 2
						reverbSoundEffect.Density = 1
						reverbSoundEffect.WetLevel = 0.8

						local echoSoundEffect: EchoSoundEffect = Instance.new("EchoSoundEffect", longScream)

						echoSoundEffect.Delay = 0.3
						echoSoundEffect.WetLevel = 0.7
						Instance.new("DistortionSoundEffect", longScream).Level = 0.5
						longScream:Play()
					end
				end

				if p11:FindFirstChild("Head") and p11.Head:FindFirstChild("CombatKill") then
					task.spawn(function()
						task.wait(1)

						if not p11.Head.CombatKill.IsPlaying then
							p11.Head.CombatKill:Play()
						end
					end)
				end

				return
			end

			warn("PlayLongScream: 'm' or 'Character' is nil.")
		end
		local function FadeOutLongScream(p12)
			local head = p12:FindFirstChild("Head")

			if head and head:FindFirstChild("LongScream") then
				game.TweenService:Create(p12.Head.LongScream, TweenInfo.new(1), { Volume = 0 }):Play()
			end
		end
		local function ShrinkAndDestroyModel(p13)
			if typeof(p13) ~= "Instance" or not p13:IsA("Model") or not p13.Parent then
				return
			end

			local v53 = GetRoot(p13)

			if v53 then
				v53.Anchored = true
			end

			for _, v in ipairs(p13:GetDescendants()) do
				if not v:IsA("BasePart") and not v:IsA("UnionOperation") and not v:IsA("MeshPart") then
					if v:IsA("SpecialMesh") then
						game.TweenService:Create(v, TweenInfo.new(0.25), { Scale = Vector3.new(0, 0, 0) }):Play()
					elseif not v:IsA("ParticleEmitter") and not v:IsA("Beam") and not v:IsA("BillboardGui") then
						if v:IsA("Bone") then
							v:Destroy()
						end
					else
						v.Enabled = false
					end
				else
					game.TweenService:Create(v, TweenInfo.new(0.25), { Size = Vector3.new(0, 0, 0) }):Play()
				end
			end
		end
		local function HandleImpact(parent, p15, p16)
			local v59 = GetRoot(parent)
			local v60 = GetRoot(p15)

			if v59 and v60 then
				if parent:FindFirstChild("CD") then
					return
				end

				local cd: BoolValue = Instance.new("BoolValue")

				cd.Name = "CD"
				cd.Parent = parent

				local v62 = p16 and v59 or v60
				local clone = finalTrailEffect.Attachment:Clone()

				clone.Parent = v59

				local clone2 = finalTrailEffect.Attachment1:Clone()

				clone2.Parent = v59

				local clone3 = finalTrailEffect.Attachment0:Clone()

				clone3.Parent = v59

				local clone4 = finalTrailEffect.Clouds:Clone()

				clone4.Parent = v59

				local clone5 = finalTrailEffect.Trail:Clone()

				clone5.Parent = v59

				local t1: {[any]: any} = { clone, clone2, clone3, clone4, clone5 }

				t1[5].Attachment1 = t1[2]
				t1[5].Attachment0 = t1[3]
				PlayAnimation(parent)

				local finalTrailEffectSfx = finalTrailEffect.Sfx

				if finalTrailEffectSfx and v62 then
					local clone6 = finalTrailEffectSfx:Clone()

					clone6.Parent = v62
					clone6:Play()
				end

				PlayLongScream(parent, p15)
				koStarRequest:FireServer("StartArc", parent, p15)
				task.wait(1)
				FadeOutLongScream(parent)
				task.wait(0.5)

				if t1[1]:FindFirstChild("Spark") and t1[1]:FindFirstChild("Spark2") then
					t1[1].Spark:Emit(3)
					t1[1].Spark2:Emit(3)
				end

				ShrinkAndDestroyModel(parent)

				return
			end
		end
		local function RockShotEffect(p17)
			local v72 = GetRoot(p17)

			if not v72 then
				return
			end

			local clone = mediumRock:Clone()

			clone.CFrame = v72.CFrame
			clone.Parent = workspace
			game.Debris:AddItem(clone, 2)

			for _, v in ipairs(clone:GetChildren()) do
				if v:IsA("Attachment") and v.Name ~= "ShockEffect" then
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v77 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

					if v77 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v77.Position

						local randomNumber = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber2 = math.random(2, 2.5)
						local randomNumber3 = math.random(360)
						local v84 = math.rad(randomNumber3)
						local randomNumber4 = math.random(360)
						local v86 = math.rad(randomNumber4)
						local randomNumber5 = math.random(360)
						local v88 = math.rad(randomNumber5)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v91 = CFrame.Angles(v84, v86, v88)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v91 }):Play()

						local TweenService2 = game.TweenService
						local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

						TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
						part.Material = v77.Material
						part.Color = v77.Instance.Color

						local clone7 = smoke:Clone()

						clone7.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone7.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone7:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"
								explosionPart.Size = Vector3.new(0, 0, 0)
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v77.Instance.Color

								local TweenService3 = game.TweenService
								local randomNumber6 = math.random(1.5, 2.5)
								local randomNumber7 = math.random(1.5, 2.5)
								local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))

								TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

								local randomNumber8 = math.random(-80, 80)
								local randomNumber9 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

								local cFrame2 = CFrame.new(part.Position)
								local v106 = CFrame.Angles(v84, v86, v88)

								explosionPart.CFrame = cFrame2 * v106
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part2: Part = Instance.new("Part")

								part2.Anchored = false
								part2.Name = "ExplosionPart"
								part2.Size = Vector3.new(0, 0, 0)
								part2.Material = part.Material
								part2.CanCollide = true
								part2.CFrame = part.CFrame
								part2.Color = v77.Instance.Color
								game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber10 = math.random(-40, 40)
								local randomNumber11 = math.random(0, 40)

								part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

								local cFrame3 = CFrame.new(part.Position)
								local v111 = CFrame.Angles(v84, v86, v88)

								part2.CFrame = cFrame3 * v111
								part2.Parent = workspace
								game.Debris:AddItem(part2, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber12 = math.random(2, 2.3)

						task.delay(randomNumber12, function()
							local randomNumber13 = math.random(360)
							local v131 = math.rad(randomNumber13)
							local randomNumber14 = math.random(360)
							local v133 = math.rad(randomNumber14)
							local randomNumber15 = math.random(360)
							local v135 = math.rad(randomNumber15)
							local TweenService4 = game.TweenService
							local cFrame4 = CFrame.new(part.Position)
							local v138 = CFrame.Angles(v131, v133, v135)

							TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v138 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end
			end

			for _, v in ipairs(clone:GetChildren()) do
				if v.Name == "ShockEffect" then
					v.Ring:Emit(3)
					v.Shock:Emit(3)
				end
			end
		end

		koStar.OnClientEvent:Connect(function(p18, p19, p20)
			if GetRoot(p19) then
				RockShotEffect(p19)
			end

			if GetRoot(p18) and GetRoot(p19) then
				HandleImpact(p18, p19, p20)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Combat.KOStar", result)
	end
end)

return true
