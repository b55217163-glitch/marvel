-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local debris: Debris = game:GetService("Debris")
		local LocalPlayer: Player = players.LocalPlayer
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local knockback = replicatedStorage.Characters.Combat.Remotes:WaitForChild("Knockback")
		local knockbackPush = replicatedStorage.Characters.Combat.Remotes:WaitForChild("KnockbackPush")
		local trailEffect = replicatedStorage.Characters.Combat.Fx:WaitForChild("TrailEffect")
		local v11 = replicatedStorage.Characters.CombatFolder.Sounds:WaitForChild("Launched back")
		local throwBackHit = replicatedStorage.Characters.Wanda.AnimationsExtra:WaitForChild("ThrowBackHit")
		local knockbackSfx = replicatedStorage.Characters.Combat.Fx:WaitForChild("KnockbackSfx")
		local object = setmetatable({}, { __mode = "k" })

		local function canDoFX(p1, p2)
			local v23 = os.clock()

			if p2 > v23 - (object[p1] or 0) then
				return false
			end

			object[p1] = v23

			return true
		end
		local function createEffects(p3, p4)
			local upperTorso = p3 and p3:FindFirstChild("UpperTorso")

			if not upperTorso then
				return
			end

			local n1 = (p4 or 0.2) + 1
			local clone = trailEffect.Attachment0:Clone()

			clone.Parent = upperTorso
			debris:AddItem(clone, n1)

			local clone2 = trailEffect.Attachment1:Clone()

			clone2.Parent = upperTorso
			debris:AddItem(clone2, n1)

			local clone3 = trailEffect.Trail:Clone()

			clone3.Parent = upperTorso
			clone3.Attachment0 = clone2
			clone3.Attachment1 = clone
			debris:AddItem(clone3, n1)

			local clone4 = trailEffect.Attachment:Clone()

			clone4.Parent = upperTorso

			if clone4:FindFirstChild("Ring") then
				clone4.Ring:Emit(3)
			end

			if clone4:FindFirstChild("Shock") then
				clone4.Shock:Emit(3)
			end

			if clone4:FindFirstChild("Spark") then
				clone4.Spark:Emit(1)
			end

			debris:AddItem(clone4, 1)
		end

		local object2 = setmetatable({}, { __mode = "k" })

		local function getKbTrack(parent)
			local animator = parent:FindFirstChildOfClass("Animator")

			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = parent
			end

			local v34 = object2[animator]

			if not v34 or v34.Parent == nil then
				v34 = animationService.GetTrack(animator, throwBackHit)
				object2[animator] = v34
			end

			return v34
		end
		local function PlayLaunchEffects(character, p7, p8)
			local humanoid = character and character:FindFirstChildOfClass("Humanoid")
			local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")

			if humanoid and humanoidRootPart then
				if p8 then
					local animator = humanoid:FindFirstChildOfClass("Animator")

					if not animator then
						animator = Instance.new("Animator")
						animator.Parent = humanoid
					end

					local v41 = object2[animator]

					if not v41 or v41.Parent == nil then
						v41 = animationService.GetTrack(animator, throwBackHit)
						object2[animator] = v41
					end

					if v41 then
						if v41.IsPlaying then
							v41:Stop(0)
						end

						v41:Play()
					end
				end

				local clone = v11:Clone()

				clone.Parent = humanoidRootPart
				clone:Play()
				debris:AddItem(clone, 2)
				task.wait(p7 or 0.2)

				local clone5 = knockbackSfx:Clone()

				clone5.Parent = humanoidRootPart
				clone5:Play()
				debris:AddItem(clone5, 2)

				return
			end
		end
		local function iAmDesignatedCaller(p9)
			local humanoidRootPart = p9 and p9:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return false
			end

			local Character: Model = LocalPlayer.Character
			local characterHumanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")

			if not characterHumanoidRootPart then
				return false
			end

			if (characterHumanoidRootPart.Position - humanoidRootPart.Position).Magnitude > 160 then
				return false
			end

			local v48 = (characterHumanoidRootPart.Position - humanoidRootPart.Position).Magnitude
			local v49 = LocalPlayer.UserId

			for _, v in ipairs(players:GetPlayers()) do
				if v ~= LocalPlayer then
					local Character2 = v.Character
					local character2HumanoidRootPart = Character2 and Character2:FindFirstChild("HumanoidRootPart")

					if character2HumanoidRootPart then
						local magnitude = (character2HumanoidRootPart.Position - humanoidRootPart.Position).Magnitude

						if v48 > magnitude then
							v48 = magnitude
							v49 = v.UserId
						elseif math.abs(magnitude - v48) < 0.5 and v49 > v.UserId then
							v49 = v.UserId
						end
					end
				end
			end

			return v49 == LocalPlayer.UserId
		end

		knockback.OnClientEvent:Connect(function(p10, p11, p12, p13, p14)
			if not p10 then
				return
			end

			local humanoidRootPart = p10:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			if iAmDesignatedCaller(p10) then
				if p14 then
					knockbackPush:FireServer(p11, p10, p12, p13, p11)
				else
					knockbackPush:FireServer(p11, p10, p12, p13)
				end
			end

			local v61 = os.clock()
			local u62

			if v61 - (object[humanoidRootPart] or 0) < 0.08 then
				u62 = false
			else
				object[humanoidRootPart] = v61
				u62 = true
			end

			if not u62 then
				return
			end

			task.spawn(function()
				createEffects(p10, p13)
				PlayLaunchEffects(p10, p13, if p14 then true else false)
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Combat.Knockback", result)
	end
end)

return true
