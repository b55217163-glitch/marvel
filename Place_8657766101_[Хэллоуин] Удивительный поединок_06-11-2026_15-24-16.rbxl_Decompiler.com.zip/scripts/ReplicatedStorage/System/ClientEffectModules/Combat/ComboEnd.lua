-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local debris: Debris = game:GetService("Debris")
		local contentProvider: ContentProvider = game:GetService("ContentProvider")
		local workspace: Workspace = game:GetService("Workspace")
		local LocalPlayer: Player = players.LocalPlayer
		local hitEffectEnd = replicatedStorage.Characters.Combat.Remotes:WaitForChild("HitEffectEnd")
		local hitAt = replicatedStorage.Characters.Combat.Fx.CombatHit:WaitForChild("HitAt")
		local hitAtKratos = replicatedStorage.Characters.Combat.Fx.CombatHit:WaitForChild("HitAtKratos")
		local hitCombo4 = replicatedStorage.Characters.CombatFolder.Animations:WaitForChild("HitCombo4")
		local hitSound = replicatedStorage.Characters.CombatFolder.Sounds:WaitForChild("HitSound")
		local saberHit = replicatedStorage.Characters.Combat.Fx.CombatHit:WaitForChild("SaberHit")
		local spikeBatHitSound3 = replicatedStorage.Characters.Combat.Fx.CombatHit:WaitForChild("SpikeBatHitSound3")
		local heavyPunch = replicatedStorage.Characters.Combat.Fx.CombatHit:WaitForChild("HeavyPunch")
		local dashBack = replicatedStorage.Characters.CombatFolder.Sounds:WaitForChild("DashBack")
		local CurrentCamera: Camera = workspace.CurrentCamera
		local object = setmetatable({}, { __mode = "k" })

		local function shouldProcess(p1, p2)
			local v32 = os.clock()

			if v32 - (object[p1] or 0) < (p2 or 0.04) then
				return false
			end

			object[p1] = v32

			return true
		end
		local function sqrDist(p3, p4)
			local n1 = p3 - p4

			return n1:Dot(n1)
		end
		local function inHardRange(p5)
			local v37: Camera = CurrentCamera

			if v37 and p5 then
				local n1 = v37.CFrame.Position - p5.Position

				return n1:Dot(n1) <= 19600
			end

			return true
		end
		local function tooFarForFX(p6)
			local v40: Camera = CurrentCamera

			if v40 and p6 then
				local n1 = v40.CFrame.Position - p6.Position

				return n1:Dot(n1) > 14400
			end

			return false
		end

		local t1: {[any]: any} = {
			PunchHit = hitSound,
			SaberHit = saberHit,
			BatHit = spikeBatHitSound3,
			HeavyHit = heavyPunch,
			DashBack = dashBack
		}

		task.spawn(function()
			pcall(function()
				contentProvider:PreloadAsync({
					hitCombo4,
					hitAt,
					hitAtKratos,
					t1.PunchHit,
					t1.SaberHit,
					t1.BatHit,
					t1.HeavyHit,
					t1.DashBack
				})
			end)
		end)

		local object2 = setmetatable({}, { __mode = "k" })

		local function getHit4Track(parent)
			if not parent or not hitCombo4 then
				return nil
			end

			local animator = parent:FindFirstChildOfClass("Animator")

			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = parent
			end

			local v44 = object2[animator]

			if not v44 or v44.Parent == nil then
				v44 = animationService.GetTrack(animator, hitCombo4)
				object2[animator] = v44
			end

			return v44
		end
		local function playSound(p8, parent, p10)
			if p8 and parent then
				local clone = p8:Clone()

				clone.Parent = parent
				clone:Play()
				debris:AddItem(clone, p10 or 2)

				return
			end
		end
		local function createHitEffect(p11, parent, p13, p14)
			if p11 and parent then
				local clone = p11:Clone()

				clone.Parent = parent

				local v54 = p14 or 1
				local sparks = clone:FindFirstChild("Sparks")

				if sparks and sparks:IsA("ParticleEmitter") then
					local floored = math.floor(v54 * 15)

					sparks:Emit(floored)
				end

				local shock = clone:FindFirstChild("Shock")

				if shock and shock:IsA("ParticleEmitter") then
					local floored = math.floor(v54 * 2)

					shock:Emit(floored)
				end

				local sparksCircle = clone:FindFirstChild("SparksCircle")

				if sparksCircle and sparksCircle:IsA("ParticleEmitter") then
					local floored = math.floor(v54 * 15)

					sparksCircle:Emit(floored)
				end

				local shockwaveMiddle = clone:FindFirstChild("ShockwaveMiddle")

				if shockwaveMiddle and shockwaveMiddle:IsA("ParticleEmitter") then
					local floored = math.floor(v54 * 1)

					shockwaveMiddle:Emit(floored)
				end

				debris:AddItem(clone, p13 or 1)

				return
			end
		end

		hitEffectEnd.OnClientEvent:Connect(function(character, p16, p17)
			local Character: Model = LocalPlayer.Character

			if not Character or not Character:FindFirstChild("Values") then
				return
			end

			if not character then
				return
			end

			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local v69 = CurrentCamera
			local u71

			if v69 and humanoidRootPart then
				local n1 = v69.CFrame.Position - humanoidRootPart.Position

				u71 = n1:Dot(n1) <= 19600
			else
				u71 = true
			end

			if not u71 then
				return
			end

			v69 = os.clock()

			local u72

			if v69 - (object[humanoidRootPart] or 0) < 0.04 then
				u72 = false
			else
				object[humanoidRootPart] = v69
				u72 = true
			end

			if not u72 then
				return
			end

			local u73 = character ~= Character

			if u73 then
				local v74: Camera = CurrentCamera

				if v74 and humanoidRootPart then
					local n2 = v74.CFrame.Position - humanoidRootPart.Position

					u73 = n2:Dot(n2) > 14400
				else
					u73 = false
				end
			end

			local u76: boolean = false

			if p17 then
				if not u73 then
					createHitEffect(hitAt, humanoidRootPart, 1, 1)
				end

				local heavyHit = t1.HeavyHit

				if heavyHit and humanoidRootPart then
					local clone = heavyHit:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				local dashBack = t1.DashBack

				if dashBack and humanoidRootPart then
					local clone = dashBack:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				u76 = true
			elseif p16 and p16:FindFirstChild("RageValue") and p16.RageValue.Value and p16:FindFirstChild("Kratos") then
				if not u73 then
					createHitEffect(hitAtKratos, humanoidRootPart, 1, 1)
				end

				local v81 = t1.HeavyHit

				if v81 and humanoidRootPart then
					local clone = v81:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				u76 = true
			elseif p16 and p16:FindFirstChild("TimeFrozen") then
				if not u73 then
					createHitEffect(hitAt, humanoidRootPart, 4, 0.25)
				end

				local v83 = t1.HeavyHit

				if v83 and humanoidRootPart then
					local clone = v83:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 6)
				end

				u76 = true
			elseif not u73 then
				createHitEffect(hitAt, humanoidRootPart, 1, 1)
			end

			u73 = getHit4Track(humanoid)

			if u73 then
				u73:Play()
			end

			local helmetBump = nil

			if p16 and p16:FindFirstChild("Head") then
				helmetBump = p16.Head:FindFirstChild("HelmetBump")
			end

			if p16 and p16:FindFirstChild("DarthVader") then
				local saberHit = t1.SaberHit

				if saberHit and humanoidRootPart then
					local clone = saberHit:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				local v88 = t1.DashBack

				if v88 and humanoidRootPart then
					local clone = v88:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end
			elseif p16 and p16:FindFirstChild("Bat") then
				local batHit = t1.BatHit

				if batHit and humanoidRootPart then
					local clone = batHit:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				local v92 = t1.DashBack

				if v92 and humanoidRootPart then
					local clone = v92:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end
			elseif p16 and p16:FindFirstChild("Peacemaker") and helmetBump then
				if humanoidRootPart then
					local clone = helmetBump:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				local v95 = t1.DashBack

				if v95 and humanoidRootPart then
					local clone = v95:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end
			elseif not u76 then
				local v97 = t1.HeavyHit

				if v97 and humanoidRootPart then
					local clone = v97:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 2)
				end

				local v99 = t1.DashBack

				if not v99 then
					return
				end

				if not humanoidRootPart then
					return
				end

				local clone = v99:Clone()

				clone.Parent = humanoidRootPart
				clone:Play()
				debris:AddItem(clone, 2)

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Combat.ComboEnd", result)
	end
end)

return true
