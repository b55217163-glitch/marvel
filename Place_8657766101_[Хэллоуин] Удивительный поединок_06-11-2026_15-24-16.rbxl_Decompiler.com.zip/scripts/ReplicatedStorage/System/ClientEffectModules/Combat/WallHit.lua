-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local LocalPlayer: Player = players.LocalPlayer
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local knockbackVall = replicatedStorage.Characters.Combat.Remotes:WaitForChild("KnockbackVall")
		local slamModel = replicatedStorage.Characters:WaitForChild("SlamModel")
		local wallHit = replicatedStorage.Characters.Values:WaitForChild("WallHit")
		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		local map = nil

		local function refreshMap()
			map = workspace:FindFirstChild("Map")
		end

		map = workspace:FindFirstChild("Map")
		workspace.ChildAdded:Connect(function(child: Instance)
			if child.Name == "Map" then
				map = child
			end
		end)
		workspace.ChildRemoved:Connect(function(child: Instance)
			if child == map then
				map = nil
			end
		end)

		local raycastParams = RaycastParams.new()

		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.IgnoreWater = false

		local object = setmetatable({}, { __mode = "k" })

		local function canProcess(p3, p4)
			local v23 = os.clock()

			if p4 > v23 - (object[p3] or 0) then
				return false
			end

			object[p3] = v23

			return true
		end
		local function placeAndPlaySlam(p5, p6, p7)
			if not p5 then
				return
			end

			local instance = p5.Instance

			if not instance or not instance:IsA("BasePart") then
				return
			end

			local instanceColor = instance.Color
			local v29 = p5.Position
			local normal = p5.Normal
			local clone = slamModel:Clone()

			clone.Parent = effects

			local slamwall = clone:FindFirstChild("Slamwall")

			if not slamwall or not slamwall:IsA("BasePart") then
				debris:AddItem(clone, 0)

				return
			end

			local v33 = CFrame.lookAt(v29, v29 + normal)
			local cFrame = CFrame.new(0, 0, -slamwall.Size.Z * 0.5)

			slamwall.CFrame = v33 * cFrame

			local smoke = slamwall:FindFirstChild("Smoke")
			local rocks = slamwall:FindFirstChild("Rocks")

			if smoke and smoke:IsA("ParticleEmitter") then
				smoke.Color = ColorSequence.new(instanceColor)
			end

			if rocks and rocks:IsA("ParticleEmitter") then
				rocks.Color = ColorSequence.new(instanceColor)
			end

			if rocks and rocks:IsA("ParticleEmitter") then
				rocks:Emit(20)
			end

			if smoke and smoke:IsA("ParticleEmitter") then
				smoke:Emit(30)
			end

			local sparks = slamwall:FindFirstChild("Sparks")

			if sparks and sparks:IsA("ParticleEmitter") then
				sparks:Emit(15)
			end

			local sparksCircle = slamwall:FindFirstChild("SparksCircle")

			if sparksCircle and sparksCircle:IsA("ParticleEmitter") then
				sparksCircle:Emit(15)
			end

			local at = slamwall:FindFirstChild("At")

			if at then
				local ring = at:FindFirstChild("Ring")
				local ring2 = at:FindFirstChild("Ring2")
				local ring3 = at:FindFirstChild("Ring3")

				if ring and ring:IsA("ParticleEmitter") then
					ring:Emit(2)
				end

				if ring2 and ring2:IsA("ParticleEmitter") then
					ring2:Emit(2)
				end

				if ring3 and ring3:IsA("ParticleEmitter") then
					ring3:Emit(2)
				end
			end

			local boom = slamwall:FindFirstChild("Boom")

			if boom and boom:IsA("Sound") then
				boom:Play()
			end

			local instanceParent = instance.Parent

			if instanceParent and instanceParent.Name == "TreeModel" then
				local animationController = instanceParent:FindFirstChildOfClass("AnimationController")
				local shake = instanceParent:FindFirstChild("Shake")

				if animationController and shake and shake:IsA("Animation") then
					local ok2, result2 = pcall(function()
						return animationService.GetTrack(animationController, shake)
					end)

					if ok2 and result2 then
						result2:Play()
					end
				end

				local primary = instanceParent:FindFirstChild("Primary")

				if primary then
					local bushA = primary:FindFirstChild("BushA")
					local bushB = primary:FindFirstChild("BushB")

					if bushA and bushA:IsA("ParticleEmitter") then
						bushA:Emit(40)
					end

					if bushB and bushB:IsA("ParticleEmitter") then
						bushB:Emit(40)
					end
				end
			end

			if p7 == LocalPlayer.Character then
				wallHit:FireServer(p6)
			end

			task.delay(3, function()
				if slamwall and slamwall.Parent then
					local decal = slamwall:FindFirstChild("Decal")

					if decal and decal:IsA("Decal") then
						tweenService:Create(decal, TweenInfo.new(1), { Transparency = 1 }):Play()
					end
				end

				if clone and clone.Parent then
					for _, v in ipairs(clone:GetDescendants()) do
						if v:IsA("BasePart") and v.Name == "PartBreak" then
							tweenService:Create(v, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
						end
					end
				end
			end)
			debris:AddItem(clone, 4)
		end

		knockbackVall.OnClientEvent:Connect(function(p8, p9)
			if not p9 or not p9.Parent then
				return
			end

			local v54 = os.clock()
			local u55

			if v54 - (object[p9] or 0) < 0.8 then
				u55 = false
			else
				object[p9] = v54
				u55 = true
			end

			if not u55 then
				return
			end

			local humanoidRootPart = p9:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			v54 = map

			if not v54 then
				return
			end

			local v57 = p8 and p8:FindFirstChild("HumanoidRootPart")
			local u58 = if v57 then v57.CFrame.LookVector else humanoidRootPart.CFrame.LookVector

			raycastParams.FilterDescendantsInstances = { v54 }
			task.spawn(function()
				for _ = 1, 8 do
					if not p9 or not p9.Parent then
						return
					end

					local humanoidRootPart2 = p9:FindFirstChild("HumanoidRootPart")

					if not humanoidRootPart2 then
						return
					end

					local v64 = map

					if not v64 then
						return
					end

					raycastParams.FilterDescendantsInstances = { v64 }
					v64 = workspace:Raycast(humanoidRootPart2.Position, u58 * 5, raycastParams)

					if v64 then
						placeAndPlaySlam(v64, p9, p8)

						return
					end

					task.wait(0.1)
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Combat.WallHit", result)
	end
end)

return true
