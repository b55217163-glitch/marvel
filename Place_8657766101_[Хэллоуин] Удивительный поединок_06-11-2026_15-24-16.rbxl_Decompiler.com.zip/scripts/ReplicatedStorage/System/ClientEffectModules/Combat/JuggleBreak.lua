-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local lightingEffects = require(replicatedStorage:WaitForChild("LightingEffects"))
		local juggleBreakEffect = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat").Remotes:WaitForChild("JuggleBreakEffect")
		local n1: number = 0

		juggleBreakEffect.OnClientEvent:Connect(function(p1)
			local u8 = p1 or 2.5

			n1 += 1

			local v9: number = n1

			lightingEffects.ApplyColor({
				Brightness = 0.12,
				Contrast = 1.4,
				Saturation = -0.45,
				TintColor = Color3.new(1, 1, 1)
			}, 0.08, "ColorCorrection_Flash")
			lightingEffects.SetBlur(18, 0.08)
			task.spawn(function()
				local n2 = os.clock() + u8
				local u11: boolean = false

				while v9 == n1 and n2 > os.clock() do
					u11 = not u11

					if u11 then
						lightingEffects.ApplyColor({ Brightness = 0.08, Contrast = 1.3, Saturation = -0.35 }, 0.16, "ColorCorrection_Flash")
						lightingEffects.SetBlur(16, 0.16)
					else
						lightingEffects.ApplyColor({ Brightness = -0.03, Contrast = 0.65, Saturation = -0.15 }, 0.16, "ColorCorrection_Flash")
						lightingEffects.SetBlur(7, 0.16)
					end

					task.wait(0.16)
				end

				if v9 ~= n1 then
					return
				end

				lightingEffects.ResetColorCorrection("ColorCorrection_Flash", 0.25)
				lightingEffects.SetBlur(0, 0.25)
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Combat.JuggleBreak", result)
	end
end)

return true
