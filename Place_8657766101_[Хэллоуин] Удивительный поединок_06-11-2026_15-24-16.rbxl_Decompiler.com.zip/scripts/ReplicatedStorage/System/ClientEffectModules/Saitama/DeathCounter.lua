-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local deathCounter = game.ReplicatedStorage.Characters.Saitama.AnimationsExtra.DeathCounter
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local groundhit = game.ReplicatedStorage.Characters.Saitama.Fx.Groundhit
		local death = game.ReplicatedStorage.Characters.Saitama.Other.Death
		local smokeBig = game.ReplicatedStorage.Characters.Saitama.Fx.SmokeBig
		local u11 = nil
		local u12 = nil
		local u13 = nil
		local u14 = nil
		local u15 = nil

		local function clearConnections()
			if u11 then
				u11:Disconnect()
			end

			if u12 then
				u12:Disconnect()
			end

			if u13 then
				u13:Disconnect()
			end

			if u14 then
				u14:Disconnect()
			end

			if u15 then
				u15:Disconnect()
			end
		end

		game.ReplicatedStorage.Characters.Saitama.Remotes.DeathCounter.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			if not Character then
				return
			end

			local humanoid = Character:WaitForChild("Humanoid", 5)
			local v21 = animationService.LoadFresh(humanoid, deathCounter)

			if u11 then
				u11:Disconnect()
			end

			if u12 then
				u12:Disconnect()
			end

			if u13 then
				u13:Disconnect()
			end

			if u14 then
				u14:Disconnect()
			end

			if u15 then
				u15:Disconnect()
			end

			u11 = animationService.ConnectMarker(v21, "Start", function()
				Character.Head.DeathCounter:Play()

				for _, v in ipairs(p2.Humanoid:GetPlayingAnimationTracks()) do
					v:AdjustSpeed(0.01)
				end
			end)
			u12 = animationService.ConnectMarker(v21, "Teleport", function()
				Character.Head.Normal.Transparency = 1

				local clone = game.ReplicatedStorage.Characters.Saitama.Fx.DeathHead:Clone()

				clone.Parent = workspace
				game.Debris:AddItem(clone, 4.5)

				local motor6D: Motor6D = Instance.new("Motor6D", p2)

				motor6D.Part0 = Character.Head
				motor6D.Part1 = clone.LHead

				local v26 = CFrame.Angles(0, 0, 0)

				motor6D.C0 = CFrame.new(0, 0, 0) * v26
				Character.Head.Color = Color3.new(0.506279, 0.439048, 0.3935)
				Character.UpperTorso.Color = Color3.new(0.506279, 0.439048, 0.3935)
				Character.Cape.Color = Color3.new(0.478202, 0.482933, 0.482933)
				Character.Shirt.Color3 = Color3.new(0.478202, 0.482933, 0.482933)
				Character.Pants.Color3 = Color3.new(0.478202, 0.482933, 0.482933)

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v28 = workspace:Raycast(p2.HumanoidRootPart.Position, p2.HumanoidRootPart.CFrame.UpVector * -10, raycastParams)

				if v28 == nil then
					return
				end

				local InstanceColor = v28.Instance.Color
				local clone2 = groundhit:Clone()

				clone2.Parent = workspace
				clone2.Rocks.Color = ColorSequence.new(InstanceColor)
				clone2.Smoke.Color = ColorSequence.new(InstanceColor)
				clone2.Rocks:Emit(15)
				clone2.Smoke:Emit(15)
				clone2.Position = v28.Position
				game.Debris:AddItem(clone2, 8)
			end)
			u13 = animationService.ConnectMarker(v21, "Death", function()
				local clone = death:Clone()

				clone.Parent = Character
				clone.Disabled = false
				game.Debris:AddItem(clone, 7)
			end)
			u14 = animationService.ConnectMarker(v21, "Giant", function()
			end)
			u15 = animationService.ConnectMarker(v21, "Boom", function()
				if p2 and p2:FindFirstChild("Humanoid") then
					for _, v in ipairs(p2.Humanoid:GetPlayingAnimationTracks()) do
						v:AdjustSpeed(1)
					end
				end

				Character.Head.DeathCounterDistance:Play()
				Character.Head.Normal.Transparency = 0
				Character.Head.Color = Color3.new(0.983963, 0.827115, 0.778683)
				Character.UpperTorso.Color = Color3.new(0.983963, 0.827115, 0.778683)
				Character.Cape.Color = Color3.new(0.909911, 0.918914, 0.918914)
				Character.Shirt.Color3 = Color3.new(1, 1, 1)
				Character.Pants.Color3 = Color3.new(1, 1, 1)

				local characterFakeUpperTorso = Character.FakeUpperTorso

				for _, v in ipairs(characterFakeUpperTorso:GetChildren()) do
					if v:IsA("Attachment") and v.Name ~= "ShockEffect" then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v38 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v38 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v38.Position

							local randomNumber = math.random(-4, 4)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 7)

							local randomNumber2 = math.random(4, 6.5)
							local randomNumber3 = math.random(360)
							local v45 = math.rad(randomNumber3)
							local randomNumber4 = math.random(360)
							local v47 = math.rad(randomNumber4)
							local randomNumber5 = math.random(360)
							local v49 = math.rad(randomNumber5)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v52 = CFrame.Angles(v45, v47, v49)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v52 }):Play()

							local TweenService2 = game.TweenService
							local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

							TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
							part.Material = v38.Material
							part.Color = v38.Instance.Color

							local clone = smokeBig:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"
									explosionPart.Size = Vector3.new(0, 0, 0)
									explosionPart.Material = part.Material
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v38.Instance.Color

									local TweenService3 = game.TweenService
									local randomNumber6 = math.random(4.5, 6.5)
									local randomNumber7 = math.random(4.5, 6.5)
									local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(4.5, 6.5))

									TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

									local randomNumber8 = math.random(-80, 80)
									local randomNumber9 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

									local cFrame2 = CFrame.new(part.Position)
									local v67 = CFrame.Angles(v45, v47, v49)

									explosionPart.CFrame = cFrame2 * v67
									explosionPart.Parent = workspace
									explosionPart.CanCollide = true
									game.Debris:AddItem(explosionPart, 7)

									local part2: Part = Instance.new("Part")

									part2.Name = "ExplosionPart"
									part2.Size = Vector3.new(0, 0, 0)
									part2.Material = part.Material
									part2.CFrame = part.CFrame
									explosionPart.CanCollide = false
									part2.Color = v38.Instance.Color
									game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber10 = math.random(-40, 40)
									local randomNumber11 = math.random(0, 40)

									part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

									local cFrame3 = CFrame.new(part.Position)
									local v72 = CFrame.Angles(v45, v47, v49)

									part2.CFrame = cFrame3 * v72
									part2.Parent = workspace
									game.Debris:AddItem(part2, 7)
									task.delay(6, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber12 = math.random(4, 5.3)

							task.delay(randomNumber12, function()
								local randomNumber13 = math.random(360)
								local v77 = math.rad(randomNumber13)
								local randomNumber14 = math.random(360)
								local v79 = math.rad(randomNumber14)
								local randomNumber15 = math.random(360)
								local v81 = math.rad(randomNumber15)
								local TweenService4 = game.TweenService
								local cFrame4 = CFrame.new(part.Position)
								local v84 = CFrame.Angles(v77, v79, v81)

								TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v84 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end
				end

				for _, v in ipairs(characterFakeUpperTorso:GetChildren()) do
					if v.Name == "ShockEffect" then
						v.Ring:Emit(3)
						v.Shock:Emit(3)
					end
				end
			end)
			v21:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Saitama.DeathCounter", result)
	end
end)

return true
