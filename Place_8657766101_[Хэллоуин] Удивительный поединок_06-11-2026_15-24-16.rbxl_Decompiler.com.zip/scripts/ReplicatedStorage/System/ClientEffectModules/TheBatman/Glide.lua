-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Debris")
		game:GetService("ReplicatedStorage")
		game:GetService("ReplicatedStorage")
		game:GetService("TweenService")

		local t1: {[any]: any} = { Transparency = 0 }

		TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

		local Players = game.Players
		local glideLocal = game.ReplicatedStorage.Characters.GlideLocal

		game.ReplicatedStorage.Characters.TheBatman.Remotes.Skydive.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if Character.LeftFoot:FindFirstChild("GlideTrail") then
				if Character.LeftFoot.GlideTrail.Enabled == false then
					local clone = game.ReplicatedStorage.Characters.Combat.Fx.FlyLoopSfx:Clone()

					clone.Parent = Character.Head
					clone:Play()
					game.Debris:AddItem(clone, 3)

					local woosh: Instance = script:FindFirstChild("Woosh")

					if woosh and Character and Character:FindFirstChild("HumanoidRootPart") then
						local v10: Instance = woosh and woosh:Clone()

						v10.PlaybackSpeed = math.random(1, 1.4)
						v10.Parent = Character.HumanoidRootPart
						v10:Play()
						game.Debris:AddItem(v10, 3)
					end

					TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
					Character.LeftFoot.GlideTrail.Enabled = true
					Character.RightFoot.GlideTrail.Enabled = true
					Character.LeftHand.GlideTrail.Enabled = true
					Character.RightHand.GlideTrail.Enabled = true

					if Character:FindFirstChild("2099") then
						game.TweenService:Create(Character.Cape.Cape, TweenInfo.new(0.5), { Transparency = 0 }):Play()
						Character.Head.CapeSfx:Play()

						for _, v in pairs(Character.Cape.Cape:GetChildren()) do
							if v:IsA("Texture") then
								task.spawn(function()
									game.TweenService:Create(v, TweenInfo.new(0.3), { Transparency = 0.2 }):Play()
								end)
							end
						end
					end

					if Character.Head:FindFirstChild("StartGlide") and not Character.Head.StartGlide.IsPlaying then
						Character.Head.StartGlide:Play()

						return
					end
				else
					TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

					local woosh: Instance = script:FindFirstChild("Woosh")

					if woosh then
						local clone: Instance = woosh:Clone()

						clone.PlaybackSpeed = math.random(1, 1.4)
						clone.Parent = Character.HumanoidRootPart
						clone:Play()
						game.Debris:AddItem(clone, 3)
					end

					Character:FindFirstChild("2099")
					Character.LeftFoot.GlideTrail.Enabled = false
					Character.RightFoot.GlideTrail.Enabled = false
					Character.LeftHand.GlideTrail.Enabled = false
					Character.RightHand.GlideTrail.Enabled = false

					if Character:findFirstChild("FlyLoopSfx") then
						Character.FlyLoopSfx:Destroy()
					end

					if Character:FindFirstChild("2099") then
						game.TweenService:Create(Character.Cape.Cape, TweenInfo.new(0.5), { Transparency = 1 }):Play()
						Character.Head.CapeSfx:Play()

						for _, v in pairs(Character.Cape.Cape:GetChildren()) do
							if v:IsA("Texture") then
								task.spawn(function()
									game.TweenService:Create(v, TweenInfo.new(0.3), { Transparency = 1 }):Play()
								end)
							end
						end
					end

					task.wait(0.5)
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.Glide", result)
	end
end)

return true
