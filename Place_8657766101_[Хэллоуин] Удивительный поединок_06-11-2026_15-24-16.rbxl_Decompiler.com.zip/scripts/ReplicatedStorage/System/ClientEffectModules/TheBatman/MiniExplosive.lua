-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local miniExplosive = game.ReplicatedStorage.Characters.TheBatman.Remotes.MiniExplosive
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function copySurface(p1, parent)
			for _, v in ipairs(p1:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh")) then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeRock(p3)
			for _, v in ipairs(p3:GetChildren()) do
				if v:IsA("Texture") or v:IsA("Decal") then
					local v26 = tweenInfoNew(0.45, Enum.EasingStyle.Linear)

					tweenService:Create(v, v26, { Transparency = 1 }):Play()
				end
			end

			local v27 = tweenInfoNew(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			local v28 = p3.Position
			local vector3 = Vector3.new(0, p3.Size.Y * 0.8, 0)

			tweenService:Create(p3, v27, {
				Transparency = 1,
				Size = Vector3.new(0.05, 0.05, 0.05),
				Position = v28 - vector3
			}):Play()
		end
		local function CreateCraterRocks(p4, p5, p6, p7, p8)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for i = 1, p5 do
				local v37 = mathRandom(-8, 8)
				local v38 = math.rad(360 / p5 * i + v37)
				local v39 = mathRandom(-3, 3)
				local cosine = math.cos(v38)
				local sine = math.sin(v38)
				local vector3 = Vector3.new(cosine, 0, sine)

				vector3 = workspace:Raycast(p4.Position + vector3 * (p6 + v39) + Vector3.new(0, 25, 0), Vector3.new(0, -60, 0), raycastParams)

				if vector3 then
					local vector3Instance = vector3.Instance

					if not vector3Instance or not vector3Instance:IsA("BasePart") then
						continue
					end

					local craterRock: Part = Instance.new("Part")

					craterRock.Name = "CraterRock"
					craterRock.Anchored = true
					craterRock.CanCollide = false
					craterRock.CanTouch = false
					craterRock.CanQuery = false
					craterRock.Material = vector3Instance.Material
					craterRock.Color = vector3Instance.Color
					craterRock.TopSurface = Enum.SurfaceType.Smooth
					craterRock.BottomSurface = Enum.SurfaceType.Smooth

					local n1 = mathRandom(p7 * 100, p8 * 100) / 100
					local v46 = mathRandom(90, 140)
					local v47 = mathRandom(45, 85)
					local v48 = mathRandom(90, 140)

					craterRock.Size = Vector3.new(n1 * v46 / 100, n1 * v47 / 100, n1 * v48 / 100)
					copySurface(vector3Instance, craterRock)
					n1 = p4.Position + Vector3.new(0, -1.5, 0)

					local vector3Position = vector3.Position
					local vector32 = Vector3.new(0, craterRock.Size.Y / 2 - 0.15, 0)
					local cFrame = CFrame.new(n1)
					local cFrameAngles = CFrame.Angles

					v48 = mathRandom(-18, 18)
					v47 = math.rad(v48)

					local v53 = mathRandom(-180, 180)

					v48 = math.rad(v53)

					local v54 = mathRandom(-18, 18)

					v53 = math.rad(v54)
					v46 = cFrameAngles(v47, v48, v53)
					craterRock.CFrame = cFrame * v46
					craterRock.Parent = workspace.Effects
					debris:AddItem(craterRock, 4)
					v47 = tweenInfoNew(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

					local cFrame2 = CFrame.new(vector3Position + vector32)
					local angles = CFrame.Angles
					local v57 = mathRandom(-25, 25)
					local v58 = math.rad(v57)
					local v59 = mathRandom(-180, 180)

					v57 = math.rad(v59)

					local v60 = mathRandom(-25, 25)

					v59 = math.rad(v60)

					local v61 = angles(v58, v57, v59)

					tweenService:Create(craterRock, v47, { CFrame = cFrame2 * v61 }):Play()

					local taskDelay = task.delay

					v48 = mathRandom(0, 40)
					taskDelay(2.2 + v48 / 100, function()
						if craterRock and craterRock.Parent then
							fadeRock(craterRock)
						end
					end)
				end
			end
		end
		local function CreateExplosionDebris(p9, p10, p11)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for i = 1, p10 do
				task.delay(i * 0.01, function()
					if not p9 or not p9.Parent then
						return
					end

					local v74 = mathRandom(0, 360)
					local v75 = math.rad(v74)

					v74 = mathRandom(5, p11)

					local cosine = math.cos(v75)
					local sine = math.sin(v75)
					local vector3 = Vector3.new(cosine, 0, sine)
					local v79 = workspace:Raycast(p9.Position + vector3 * v74 + Vector3.new(0, 25, 0), Vector3.new(0, -60, 0), raycastParams)

					if not v79 then
						return
					end

					v75 = v79.Instance

					if not v75 or not v75:IsA("BasePart") then
						return
					end

					local explosionDebris: Part = Instance.new("Part")

					explosionDebris.Name = "ExplosionDebris"
					explosionDebris.Anchored = true
					explosionDebris.CanCollide = false
					explosionDebris.CanTouch = false
					explosionDebris.CanQuery = false
					explosionDebris.Material = v75.Material
					explosionDebris.Color = v75.Color
					explosionDebris.TopSurface = Enum.SurfaceType.Smooth
					explosionDebris.BottomSurface = Enum.SurfaceType.Smooth

					local n1 = mathRandom(35, 95) / 100
					local v82 = mathRandom(70, 130)
					local v83 = mathRandom(50, 110)
					local v84 = mathRandom(70, 130)

					explosionDebris.Size = Vector3.new(n1 * v82 / 100, n1 * v83 / 100, n1 * v84 / 100)
					copySurface(v75, explosionDebris)

					local v85 = p9.Position

					v82 = mathRandom(0, 2)

					local vector33 = Vector3.new(0, v82, 0)

					n1 = v85 + vector33
					v85 = v79.Position

					local vector34 = Vector3.new(0, explosionDebris.Size.Y / 2, 0)
					local v88 = mathRandom(3, 8)

					v82 = mathRandom(2, 6)

					local vector35 = Vector3.new(0, v82, 0)
					local cFrame = CFrame.new(n1)
					local cFrameAngles = CFrame.Angles

					v83 = mathRandom(-180, 180)
					v82 = math.rad(v83)
					v84 = mathRandom(-180, 180)
					v83 = math.rad(v84)

					local v92 = mathRandom(-180, 180)

					v84 = math.rad(v92)

					local v93 = cFrameAngles(v82, v83, v84)

					explosionDebris.CFrame = cFrame * v93
					explosionDebris.Parent = workspace.Effects
					debris:AddItem(explosionDebris, 3)
					v93 = tweenInfoNew(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					local cFrame3 = CFrame.new(n1 + vector3 * v88 + vector35)
					local angles = CFrame.Angles
					local v96 = mathRandom(-220, 220)
					local v97 = math.rad(v96)
					local v98 = mathRandom(-220, 220)

					v96 = math.rad(v98)

					local v99 = mathRandom(-220, 220)

					v98 = math.rad(v99)
					v92 = angles(v97, v96, v98)
					n1 = tweenService:Create(explosionDebris, v93, { CFrame = cFrame3 * v92 })
					v82 = tweenInfoNew(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

					local cFrame4 = CFrame.new(v85 + vector34)
					local v101 = CFrame.Angles

					v98 = mathRandom(-260, 260)
					v96 = math.rad(v98)
					v99 = mathRandom(-260, 260)
					v98 = math.rad(v99)

					local v102 = mathRandom(-260, 260)

					v99 = math.rad(v102)
					v97 = v101(v96, v98, v99)

					local v103: Tween = tweenService:Create(explosionDebris, v82, { CFrame = cFrame4 * v97 })

					n1:Play()
					n1.Completed:Once(function()
						if explosionDebris and explosionDebris.Parent then
							v103:Play()
						end
					end)
					v103.Completed:Once(function()
						if explosionDebris and explosionDebris.Parent then
							local taskDelay = task.delay
							local v106 = mathRandom(0, 40)

							taskDelay(1.1 + v106 / 100, function()
								if explosionDebris and explosionDebris.Parent then
									fadeRock(explosionDebris)
								end
							end)
						end
					end)
				end)
			end
		end
		local function RealisticExplosionRocks(p12)
			CreateCraterRocks(p12, 20, 8, 1.1, 2.3)
			CreateCraterRocks(p12, 16, 15, 0.8, 1.7)
			CreateExplosionDebris(p12, 14, 17)
		end

		local explosionEffect = game.ReplicatedStorage.Characters.TheBatman.Fx.ExplosionEffect
		local slamModel = game.ReplicatedStorage.Characters.SlamModel
		local explosionMethNightwing = game.ReplicatedStorage.Characters.Walter.Fx.ExplosionMethNightwing

		miniExplosive.OnClientEvent:Connect(function(player, p14)
			local Character = player.Character
			local part: Part = Instance.new("Part")

			part.Parent = workspace
			part.Position = p14
			part.Transparency = 1
			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.CanQuery = false
			game.Debris:AddItem(part, 1)
			CreateCraterRocks(part, 20, 8, 1.1, 2.3)
			CreateCraterRocks(part, 16, 15, 0.8, 1.7)
			CreateExplosionDebris(part, 14, 17)

			local clone = explosionMethNightwing:Clone()

			clone.Parent = workspace
			clone.CFrame = part.CFrame
			game.Debris:AddItem(clone, 8)

			if Character:FindFirstChild("Riddler") then
				clone.Flames:Emit(15)
				clone.Smoke:Emit(20)
				clone.Sparks:Emit(20)
				clone.SoundRid:Play()
				clone.SoundDistance:Play()

				return
			end

			if Character:FindFirstChild("FireExp") then
				clone.At.Flames:Emit(7)
				clone.At.FlamesSmoke:Emit(100)
				clone.SoundGrenade:Play()
				clone.SoundDistance:Play()

				return
			end

			clone.At.Flare:Emit(30)
			clone.At.Smoke:Emit(100)
			clone.At.Smoke.Enabled = true
			clone.Sound:Play()
			clone.SoundDistance:Play()
			task.delay(3, function(_)
				if clone:FindFirstChild("At") then
					clone.At.Smoke.Enabled = false
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.MiniExplosive", result)
	end
end)

return true
