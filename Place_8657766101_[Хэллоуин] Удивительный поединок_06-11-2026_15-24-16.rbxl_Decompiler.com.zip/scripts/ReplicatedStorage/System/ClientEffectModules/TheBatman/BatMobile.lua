-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.1)

		local batMobile = game.ReplicatedStorage.Characters.TheBatman.Remotes.BatMobile

		game:GetService("TweenService")

		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		batMobile.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			if p2:IsA("Attachment") then
				for _ = 1, 60 do
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v10 = workspace:Raycast(p2.WorldPosition, p2.CFrame.UpVector * -6, raycastParams)

					if v10 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v10.Position

						local randomNumber = math.random(-0.1, 0.1)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber2 = math.random(2, 2.5)
						local randomNumber3 = math.random(360)
						local v17 = math.rad(randomNumber3)
						local randomNumber4 = math.random(360)
						local v19 = math.rad(randomNumber4)
						local randomNumber5 = math.random(360)
						local v21 = math.rad(randomNumber5)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v24 = CFrame.Angles(v17, v19, v21)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v24 }):Play()

						local TweenService2 = game.TweenService
						local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

						TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
						part.Material = v10.Material
						part.Color = v10.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"
								explosionPart.Size = Vector3.new(0, 0, 0)
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v10.Instance.Color

								local TweenService3 = game.TweenService
								local randomNumber6 = math.random(1.5, 2.5)
								local randomNumber7 = math.random(1.5, 2.5)
								local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))

								TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

								local randomNumber8 = math.random(-80, 80)
								local randomNumber9 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

								local cFrame2 = CFrame.new(part.Position)
								local v39 = CFrame.Angles(v17, v19, v21)

								explosionPart.CFrame = cFrame2 * v39
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part2: Part = Instance.new("Part")

								part2.Anchored = false
								part2.Name = "ExplosionPart"
								part2.Size = Vector3.new(0, 0, 0)
								part2.Material = part.Material
								part2.CanCollide = true
								part2.CFrame = part.CFrame
								part2.Color = v10.Instance.Color
								game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber10 = math.random(-40, 40)
								local randomNumber11 = math.random(0, 40)

								part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

								local cFrame3 = CFrame.new(part.Position)
								local v44 = CFrame.Angles(v17, v19, v21)

								part2.CFrame = cFrame3 * v44
								part2.Parent = workspace
								game.Debris:AddItem(part2, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber12 = math.random(2, 2.3)

						task.delay(randomNumber12, function()
							local randomNumber13 = math.random(360)
							local v89 = math.rad(randomNumber13)
							local randomNumber14 = math.random(360)
							local v91 = math.rad(randomNumber14)
							local randomNumber15 = math.random(360)
							local v93 = math.rad(randomNumber15)
							local TweenService4 = game.TweenService
							local cFrame4 = CFrame.new(part.Position)
							local v96 = CFrame.Angles(v89, v91, v93)

							TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v96 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end

					task.wait(0.1)
				end
			else
				for _ = 1, 60 do
					for _, v in ipairs(p2:GetChildren()) do
						if v.Name == "RockAt" then
							local raycastParams = RaycastParams.new()

							raycastParams.FilterType = Enum.RaycastFilterType.Include
							raycastParams.FilterDescendantsInstances = { workspace.Map }

							local v50 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

							if v50 ~= nil then
								local part: Part = Instance.new("Part")

								part.Position = v50.Position

								local randomNumber = math.random(-0.1, 0.1)
								local v53: CFrame = part.CFrame
								local vector3 = Vector3.new(randomNumber, 0, 0)

								part.CFrame = v53 + vector3
								part.Parent = workspace
								part.Anchored = true
								part.Size = Vector3.new(0, 0, 0)
								part.CanCollide = false
								part.CanTouch = false
								game.Debris:AddItem(part, 3)

								local randomNumber16 = math.random(2, 2.5)
								local randomNumber17 = math.random(360)
								local v57 = math.rad(randomNumber17)
								local randomNumber18 = math.random(360)
								local v59 = math.rad(randomNumber18)
								local randomNumber19 = math.random(360)
								local v61 = math.rad(randomNumber19)
								local TweenService = game.TweenService
								local cFrame = CFrame.new(part.Position)
								local v64 = CFrame.Angles(v57, v59, v61)

								TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v64 }):Play()

								local TweenService5 = game.TweenService
								local vector34 = Vector3.new(randomNumber16, randomNumber16, randomNumber16)

								TweenService5:Create(part, TweenInfo.new(0.25), { Size = vector34 }):Play()
								part.Material = v50.Material
								part.Color = v50.Instance.Color

								local clone = smoke:Clone()

								clone.Parent = part

								local v68 = ColorSequence.new
								local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

								clone.Color = v68({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
								clone:Emit(2)

								if math.random(1, 3) == 1 then
									for _ = 1, 1 do
										local part3: Part = Instance.new("Part")

										part3.Anchored = false
										part3.Name = "ExplosionPart"
										part3.Size = Vector3.new(0, 0, 0)
										part3.Material = part.Material
										part3.CanCollide = true
										part3.CFrame = part.CFrame
										part3.Color = v50.Instance.Color

										local TweenService6 = game.TweenService
										local randomNumber20 = math.random(1.5, 2.5)
										local randomNumber21 = math.random(1.5, 2.5)
										local vector35 = Vector3.new(randomNumber20, randomNumber21, math.random(1.5, 2.5))

										TweenService6:Create(part3, TweenInfo.new(0.15), { Size = vector35 }):Play()

										local randomNumber22 = math.random(-80, 80)
										local randomNumber23 = math.random(0, 80)

										part3.Velocity = Vector3.new(randomNumber22, randomNumber23, math.random(-80, 80))

										local cFrame5 = CFrame.new(part.Position)
										local v79 = CFrame.Angles(v57, v59, v61)

										part3.CFrame = cFrame5 * v79
										part3.Parent = workspace
										game.Debris:AddItem(part3, 3)

										local part4: Part = Instance.new("Part")

										part4.Anchored = false
										part4.Name = "ExplosionPart"
										part4.Size = Vector3.new(0, 0, 0)
										part4.Material = part.Material
										part4.CanCollide = true
										part4.CFrame = part.CFrame
										part4.Color = v50.Instance.Color
										game.TweenService:Create(part4, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

										local randomNumber24 = math.random(-40, 40)
										local randomNumber25 = math.random(0, 40)

										part4.Velocity = Vector3.new(randomNumber24, randomNumber25, math.random(-40, 40))

										local cFrame6 = CFrame.new(part.Position)
										local v84 = CFrame.Angles(v57, v59, v61)

										part4.CFrame = cFrame6 * v84
										part4.Parent = workspace
										game.Debris:AddItem(part4, 3)
										task.delay(2, function()
											game.TweenService:Create(part3, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
											game.TweenService:Create(part4, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										end)
									end
								end

								local randomNumber26 = math.random(2, 2.3)

								task.delay(randomNumber26, function()
									local randomNumber27 = math.random(360)
									local v98 = math.rad(randomNumber27)
									local randomNumber28 = math.random(360)
									local v100 = math.rad(randomNumber28)
									local randomNumber29 = math.random(360)
									local v102 = math.rad(randomNumber29)
									local TweenService7 = game.TweenService
									local cFrame7 = CFrame.new(part.Position)
									local v105 = CFrame.Angles(v98, v100, v102)

									TweenService7:Create(part, TweenInfo.new(0.5), { CFrame = cFrame7 * v105 }):Play()
									game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
								end)
							end
						end
					end

					for _, v in ipairs(p2:GetChildren()) do
						if v.Name == "ShockEffect" then
							v.Ring:Emit(3)
							v.Shock:Emit(3)
						end
					end

					task.wait(0.1)
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.BatMobile", result)
	end
end)

return true
