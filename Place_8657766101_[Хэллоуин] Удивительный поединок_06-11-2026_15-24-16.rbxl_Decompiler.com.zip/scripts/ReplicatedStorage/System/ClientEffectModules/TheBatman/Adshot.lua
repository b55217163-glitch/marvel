-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local tweenService: TweenService = game:GetService("TweenService")

		task.wait(0.1)

		local debris: Debris = game:GetService("Debris")

		game:GetService("ReplicatedStorage")
		game:GetService("ReplicatedStorage")

		local Players = game.Players
		local glassShot = game.ReplicatedStorage.Characters.TheBatman.Fx.GlassShot
		local adShot = game.ReplicatedStorage.Characters.TheBatman.AnimationsExtra.AdShot
		local hitHighlight = game.ReplicatedStorage.Characters.TheBatman.Fx.HitHighlight

		game.ReplicatedStorage.Characters.TheBatman.Remotes.AdShotRemote.OnClientEvent:Connect(function(player)
			local Character = player.Character

			if not Character then
				return
			end

			local humanoid = Character:WaitForChild("Humanoid", 5)

			if not humanoid then
				return
			end

			local v13 = animationService.LoadFresh(humanoid, adShot)
			local u14: boolean = not Character:FindFirstChild("Game")

			if u14 then
				u14 = not Character:FindFirstChild("Robert")
			end

			animationService.ConnectMarker(v13, "Start", function()
				local clone = (if Character:FindFirstChild("Game") then script.Sfx2 else if Character:FindFirstChild("Robert") then script.Sfx else script.SfxBase):Clone()

				clone.Parent = Character.Head
				clone:Play()
				debris:AddItem(clone, 10)
				Character.Shot.Greenl.Transparency = 0
				Character.Shot.GlassShot.Transparency = 0
				tweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.1), { Transparency = 0 }):Play()
				tweenService:Create(Character.FakeHead.FaceScream, TweenInfo.new(0.1), { Transparency = 1 }):Play()
				tweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 1 }):Play()
			end)
			animationService.ConnectMarker(v13, "Hit", function()
				tweenService:Create(Character.Shot.Greenl, TweenInfo.new(0.5), { Transparency = 1 }):Play()

				local clone = hitHighlight:Clone()

				clone.Parent = Character
				tweenService:Create(clone, TweenInfo.new(0.5), { OutlineTransparency = 0 }):Play()
				task.wait(1)
				tweenService:Create(clone, TweenInfo.new(1), { OutlineTransparency = 1 }):Play()
				debris:AddItem(clone, 2)
			end)
			animationService.ConnectMarker(v13, "Scream", function()
				Character.FakeHead.FaceScream.Transparency = 0
				tweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 1 }):Play()
				tweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.3), { Transparency = 1 }):Play()

				if u14 and Character.Head:FindFirstChild("LongScream") then
					local clone = Character.Head.LongScream:Clone()

					clone.Parent = Character.Head

					local distortionSoundEffect: DistortionSoundEffect = Instance.new("DistortionSoundEffect")

					distortionSoundEffect.Level = 0.45
					distortionSoundEffect.Parent = clone

					local reverbSoundEffect: ReverbSoundEffect = Instance.new("ReverbSoundEffect")

					reverbSoundEffect.DecayTime = 2.5
					reverbSoundEffect.Density = 0.8
					reverbSoundEffect.Diffusion = 0.85
					reverbSoundEffect.DryLevel = -2
					reverbSoundEffect.WetLevel = -5
					reverbSoundEffect.Parent = clone
					clone.PlaybackSpeed = 0.85
					clone.TimePosition = 1
					clone:Play()
					task.delay(2, function()
						if clone.Parent then
							local tweenInfo = TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
							local v22: Tween = tweenService:Create(clone, tweenInfo, { Volume = 0 })

							v22:Play()
							v22.Completed:Wait()
							clone:Destroy()
						end
					end)
					debris:AddItem(clone, 3)
				end
			end)
			animationService.ConnectMarker(v13, "End", function()
				local clone = glassShot:Clone()

				clone.Parent = workspace
				clone.CFrame = Character.Shot.GlassShot.CFrame
				debris:AddItem(clone, 7)
				Character.Shot.GlassShot.Transparency = 1
				tweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.1), { Transparency = 0 }):Play()
				tweenService:Create(Character.FakeHead.FaceScream, TweenInfo.new(0.1), { Transparency = 1 }):Play()
				tweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.1), { Transparency = 1 }):Play()
			end)
			v13:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.Adshot", result)
	end
end)

return true
