-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local smackDown = game.ReplicatedStorage.Characters.MoonKnight.Remotes.SmackDown

		game:GetService("TweenService")

		local bandage = game.ReplicatedStorage.Characters.MoonKnight.Fx.Bandage
		local stretch = game.ReplicatedStorage.Characters.MoonKnight.Fx.Stretch
		local v9 = game.ReplicatedStorage.Characters.MoonKnight.AnimationsExtra.SmackDown
		local counterSlam = game.ReplicatedStorage.Characters.SoldierBoy.AnimationsExtra.CounterSlam
		local hitSlamCounter = game.ReplicatedStorage.Characters.TheBatman.AnimationsExtra.HitSlamCounter
		local attachment = game.ReplicatedStorage.Characters.LandPart.Attachment
		local rocks = game.ReplicatedStorage.Characters.LandPart.Rocks
		local v14 = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.Attachment
		local bloodUpperTorso = game.ReplicatedStorage.Characters.Peacemaker.Fx.BloodUpperTorso
		local counter = game.ReplicatedStorage.Characters.HitAnimations.TheBatman.Counter
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock2(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v29 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v31 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v31, 0)
				local n2 = v29 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v34 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v34 then
					local instance = v34.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v40 = mathRandom(-180, 180)
					local v41 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v40, v41, mathRandom(-180, 180))
					part.Position = p1.Position

					local v42 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v42, { Position = v34.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v71 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v71, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v72 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v72, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v47 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v49 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v49, 0)
				local n2 = v47 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v52 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v52 then
					local instance = v52.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v58 = mathRandom(-180, 180)
					local v59 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v58, v59, mathRandom(-180, 180))
					part.Position = p2.Position

					local v60 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v60, { Position = v52.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v77 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v77, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v78 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v78, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local groundhit = game.ReplicatedStorage.Characters.Wanda.Fx.Groundhit

		smackDown.OnClientEvent:Connect(function(p3, player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local v64 = animationService.GetTrack(p3.Humanoid, hitSlamCounter)
			local v65 = animationService.LoadFresh(player.Character.Humanoid, counterSlam)
			local v66 = animationService.LoadFresh(player.Character.Humanoid, v9)

			if not Character:FindFirstChild("SoldierBoy") then
				v66.KeyframeReached:Connect(function(p5)
					if p5 == "Slam" then
						TestRock2(Character.HumanoidRootPart)
						TestRock3(Character.HumanoidRootPart)
						Character.HumanoidRootPart.GroundSlam:Play()
						Character.Head.HeavyHit:Play()

						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v83 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -8, raycastParams)

						if v83 == nil then
							return
						end

						local InstanceColor = v83.Instance.Color
						local clone = groundhit:Clone()

						clone.Parent = workspace
						clone.Rocks.Color = ColorSequence.new(InstanceColor)
						clone.Smoke.Color = ColorSequence.new(InstanceColor)
						clone.Rocks:Emit(10)
						clone.Smoke:Emit(10)
						clone.Position = v83.Position
						game.Debris:AddItem(clone, 5)

						return
					end
				end)
				v66.KeyframeReached:Connect(function(p6)
					if p6 == "Scream" then
						Character.HumanoidRootPart.Grab:Play()
						game.TweenService:Create(Character.FakeHead.FaceScream, TweenInfo.new(0.2), { Transparency = 1 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 1 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.3), { Transparency = 0 }):Play()

						if Character:FindFirstChild("Bale") then
							Character.Head.Scream:Play()
						end

						task.wait(0.5)

						if not Character:FindFirstChild("Bale") then
							Character.Head.Scream:Play()
						end

						task.wait(0.15)
						game.TweenService:Create(Character.FakeHead.FaceScream, TweenInfo.new(0.2), { Transparency = 0 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 1 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.3), { Transparency = 1 }):Play()
						task.wait(0.7)
						game.TweenService:Create(Character.FakeHead.FaceScream, TweenInfo.new(0.2), { Transparency = 1 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 0 }):Play()
						game.TweenService:Create(Character.FakeHead.FaceAngry, TweenInfo.new(0.3), { Transparency = 1 }):Play()
					end
				end)
				v66:Play()
				v64:Play()

				return
			end

			v65.KeyframeReached:Connect(function(p7)
				if p7 == "Slam" then
					TestRock2(Character.HumanoidRootPart)
					TestRock3(Character.HumanoidRootPart)
					Character.HumanoidRootPart.GroundSlam:Play()
					Character.Head.HeavyHit:Play()

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v89 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -8, raycastParams)

					if v89 == nil then
						return
					end

					local v90 = v89.Instance.Color
					local clone = groundhit:Clone()

					clone.Parent = workspace
					clone.Rocks.Color = ColorSequence.new(v90)
					clone.Smoke.Color = ColorSequence.new(v90)
					clone.Rocks:Emit(10)
					clone.Smoke:Emit(10)
					clone.Position = v89.Position
					game.Debris:AddItem(clone, 5)

					return
				end
			end)
			v65.KeyframeReached:Connect(function(p8)
				if p8 == "Scream" then
					Character.Head.Strong:Play()
				end
			end)

			for _, v in pairs(Character.Humanoid:GetPlayingAnimationTracks()) do
				v:Stop()
			end

			v65:Play()
			v64:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.Counter", result)
	end
end)

return true
