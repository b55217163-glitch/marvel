-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.5)

		local LocalPlayer = game.Players.LocalPlayer
		local ReplicatedStorage = game.ReplicatedStorage
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local vengeanceFinish = game.ReplicatedStorage.Characters.TheBatman.AnimationsExtra.VengeanceFinish
		local vegeanceFinishHit = game.ReplicatedStorage.Characters.TheBatman.AnimationsExtra.VegeanceFinishHit
		local omniFinish = game.ReplicatedStorage.Characters.TheBatman.AnimationsExtra.OmniFinish
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local basicCircle = game.ReplicatedStorage.Movement.Rocks.Fx.BasicCircle
		local groundBreakDecal = game.ReplicatedStorage.Movement.Rocks.Fx.GroundBreakDecal
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		local function loadanim(parent, p2, _, p4)
			for _ = 1, 8 do
				local randomNumber = math.random(15, 30)
				local clone = bloodDrip:Clone()

				clone.Parent = workspace

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

				clone.Parent = parent
				clone.CFrame = p2.Head.CFrame
				clone.LocalScript.Disabled = false
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber2 = math.random(-2, 2)
				local randomNumber3 = math.random(0, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
				game.Debris:AddItem(clone, 3)
				game.Debris:AddItem(bodyVelocity, 0.15)
			end

			local clone2 = hitAt:Clone()

			clone2.Parent = p2.Head
			clone2.Sparks:Emit(15)
			clone2.Shock:Emit(2)
			clone2.SparksCircle:Emit(15)
			clone2.ShockwaveMiddle:Emit(1)
			game.Debris:AddItem(clone2, 1)

			local clone3 = basicCircle:Clone()

			clone3.CFrame = p2.HumanoidRootPart.CFrame
			clone3.Parent = workspace
			game.Debris:AddItem(clone3, 2)

			for _, v in ipairs(clone3:GetChildren()) do
				if v:IsA("Attachment") and v.Name ~= "ShockEffect" then
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { p4 }

					local v30 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

					if v30 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v30.Position

						local randomNumber4 = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber4, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber5 = math.random(2, 2.5)
						local randomNumber6 = math.random(360)
						local v37 = math.rad(randomNumber6)
						local randomNumber7 = math.random(360)
						local v39 = math.rad(randomNumber7)
						local randomNumber8 = math.random(360)
						local v41 = math.rad(randomNumber8)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v44 = CFrame.Angles(v37, v39, v41)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v44 }):Play()

						local TweenService2 = game.TweenService
						local vector32 = Vector3.new(randomNumber5, randomNumber5, randomNumber5)

						TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
						part.Material = v30.Material
						part.Color = v30.Instance.Color

						local clone4 = smoke:Clone()

						clone4.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone4.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone4:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"
								explosionPart.Size = Vector3.new(0, 0, 0)
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v30.Instance.Color

								local TweenService3 = game.TweenService
								local randomNumber9 = math.random(1.5, 2.5)
								local randomNumber10 = math.random(1.5, 2.5)
								local vector33 = Vector3.new(randomNumber9, randomNumber10, math.random(1.5, 2.5))

								TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

								local randomNumber11 = math.random(-80, 80)
								local randomNumber12 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber11, randomNumber12, math.random(-80, 80))

								local cFrame2 = CFrame.new(part.Position)
								local v59 = CFrame.Angles(v37, v39, v41)

								explosionPart.CFrame = cFrame2 * v59
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part2: Part = Instance.new("Part")

								part2.Anchored = false
								part2.Name = "ExplosionPart"
								part2.Size = Vector3.new(0, 0, 0)
								part2.Material = part.Material
								part2.CanCollide = true
								part2.CFrame = part.CFrame
								part2.Color = v30.Instance.Color
								game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber13 = math.random(-40, 40)
								local randomNumber14 = math.random(0, 40)

								part2.Velocity = Vector3.new(randomNumber13, randomNumber14, math.random(-40, 40))

								local cFrame3 = CFrame.new(part.Position)
								local v64 = CFrame.Angles(v37, v39, v41)

								part2.CFrame = cFrame3 * v64
								part2.Parent = workspace
								game.Debris:AddItem(part2, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber15 = math.random(2, 2.3)

						task.delay(randomNumber15, function()
							local randomNumber16 = math.random(360)
							local v75 = math.rad(randomNumber16)
							local randomNumber17 = math.random(360)
							local v77 = math.rad(randomNumber17)
							local randomNumber18 = math.random(360)
							local v79 = math.rad(randomNumber18)
							local TweenService4 = game.TweenService
							local cFrame4 = CFrame.new(part.Position)
							local v82 = CFrame.Angles(v75, v77, v79)

							TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v82 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end
			end

			for _, v in ipairs(clone3:GetChildren()) do
				if v.Name == "ShockEffect" then
					v.Ring:Emit(3)
					v.Shock:Emit(3)
				end
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { p4 }

			local v69 = workspace:Raycast(p2.HumanoidRootPart.Position, p2.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

			if v69 ~= nil then
				local clone5 = groundBreakDecal:Clone()

				clone5.Parent = workspace
				clone5.Position = v69.Position
				game.Debris:AddItem(clone5, 3)
				task.delay(2, function()
					game.TweenService:Create(clone5.GroundDecal, TweenInfo.new(1), { Transparency = 1 }):Play()
				end)
			end
		end

		game.ReplicatedStorage.Characters.TheBatman.Remotes.VengeanceCombo.OnClientEvent:Connect(function(player, p6)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)
			loadanim(Character, p6, player, workspace.Map)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheBatman.Finisher", result)
	end
end)

return true
