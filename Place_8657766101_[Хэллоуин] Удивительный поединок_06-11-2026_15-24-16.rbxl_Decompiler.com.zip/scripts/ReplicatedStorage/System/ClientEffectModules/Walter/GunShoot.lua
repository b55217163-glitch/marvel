-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gunCounter = game.ReplicatedStorage.Characters.Walter.Remotes.GunCounter
		local tweenService: TweenService = game:GetService("TweenService")

		gunCounter.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if Character:FindFirstChild("MrBeast") then
				local clone = Character.Gun.BulletAt.Bullet:Clone()

				clone.Parent = Character.Gun.BulletAt
				clone:emit(1)
				game.Debris:AddItem(clone, 1)

				local clone2 = Character.Gun.FsAt.Flash:Clone()

				clone2.Parent = Character.Gun.FsAt
				clone2:emit(1)
				game.Debris:AddItem(clone2, 1)

				local clone3 = Character.Gun.FsAt.Smoke:Clone()

				clone3.Parent = Character.Gun.FsAt
				clone3:emit(10)
				game.Debris:AddItem(clone3, 2)

				local clone4 = Character.Gun.Light:Clone()

				clone4.Parent = Character.Gun
				clone4.Enabled = true
				game.Debris:AddItem(clone4, 0.35)
				tweenService:Create(clone4, TweenInfo.new(0.3), { Brightness = 0 }):Play()

				local clone5 = script.Money:Clone()

				clone5.Parent = Character.HumanoidRootPart
				clone5:Play()
				game.Debris:AddItem(clone5, 2)
				task.wait(0.5)

				local clone6 = script.Reload:Clone()

				clone6.Parent = Character.HumanoidRootPart
				clone6:Play()
				game.Debris:AddItem(clone6, 2)
				Character.Head.ChainsawScream:Stop()
				Character.Head.Simply:Stop()
				Character.Head.Escape:Play()

				return
			end

			if Character:FindFirstChild("Vigilante") then
				local clone = Character.Gun.GunParticleHolder.BulletAt.Bullet:Clone()

				clone.Parent = Character.Gun.GunParticleHolder.BulletAt
				clone:emit(1)
				game.Debris:AddItem(clone, 1)

				local clone7 = Character.Gun.GunParticleHolder.FsAt.Flash:Clone()

				clone7.Parent = Character.Gun.GunParticleHolder.FsAt
				clone7:emit(1)
				game.Debris:AddItem(clone7, 1)

				local clone8 = Character.Gun.GunParticleHolder.FsAt.Smoke:Clone()

				clone8.Parent = Character.Gun.GunParticleHolder.FsAt
				clone8:emit(10)
				game.Debris:AddItem(clone8, 2)

				local clone9 = Character.Gun.GunParticleHolder.Light:Clone()

				clone9.Parent = Character.Gun.GunParticleHolder
				clone9.Enabled = true
				game.Debris:AddItem(clone9, 0.35)
				tweenService:Create(clone9, TweenInfo.new(0.3), { Brightness = 0 }):Play()

				local clone10 = script.GunShotSfx:Clone()

				clone10.Parent = Character.HumanoidRootPart
				clone10:Play()
				game.Debris:AddItem(clone10, 2)
				task.wait(0.5)

				local clone11 = script.Reload:Clone()

				clone11.Parent = Character.HumanoidRootPart
				clone11:Play()
				game.Debris:AddItem(clone11, 2)

				return
			end

			local clone = Character.Gun.BulletAt.Bullet:Clone()

			clone.Parent = Character.Gun.BulletAt
			clone:emit(1)
			game.Debris:AddItem(clone, 1)

			local clone12 = Character.Gun.FsAt.Flash:Clone()

			clone12.Parent = Character.Gun.FsAt
			clone12:emit(1)
			game.Debris:AddItem(clone12, 1)

			local clone13 = Character.Gun.FsAt.Smoke:Clone()

			clone13.Parent = Character.Gun.FsAt
			clone13:emit(10)
			game.Debris:AddItem(clone13, 2)

			local clone14 = Character.Gun.Light:Clone()

			clone14.Parent = Character.Gun
			clone14.Enabled = true
			game.Debris:AddItem(clone14, 0.35)
			tweenService:Create(clone14, TweenInfo.new(0.3), { Brightness = 0 }):Play()

			if Character.Values:FindFirstChild("Patrick") then
				Character.Gun.Shoot:Play()
			else
				local clone15 = script.GunShotSfx:Clone()

				clone15.Parent = Character.HumanoidRootPart
				clone15:Play()
				game.Debris:AddItem(clone15, 2)
			end

			task.wait(0.5)

			local clone16 = script.Reload:Clone()

			clone16.Parent = Character.HumanoidRootPart
			clone16:Play()
			game.Debris:AddItem(clone16, 2)

			if Character.Head:FindFirstChild("ChainsawScream") then
				Character.Head.ChainsawScream:Stop()
				Character.Head.Simply:Stop()
				Character.Head.Escape:Play()
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Walter.GunShoot", result)
	end
end)

return true
