-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local gunHitSfx = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.GunHitSfx
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2

		game.ReplicatedStorage.Characters.Walter.Remotes.GunCounterHit.OnClientEvent:Connect(function(p1, _, p3)
			if p3 then
				local clone = game.ReplicatedStorage.Characters.Walter.Fx.GunPoint:Clone()

				clone.Parent = p1.UpperTorso
				game.Debris:AddItem(clone, 2)

				if script:FindFirstChild("Bass") then
					local clone2 = script.Bass:Clone()

					clone2.Parent = p1.HumanoidRootPart
					clone2:Play()
					game.Debris:AddItem(clone2, 2)
				end

				game.TweenService:Create(clone, TweenInfo.new(0.3), { Size = UDim2.new(5, 0, 3, 0) }):Play()
				task.wait(0.5)

				if script:FindFirstChild("GunShotSfx2") then
					local clone3 = script.GunShotSfx2:Clone()

					clone3.PlaybackSpeed = math.random(1, 1.5)
					clone3.Parent = p1.HumanoidRootPart
					clone3:Play()
					game.Debris:AddItem(clone3, 2)
				end

				local v16 = animationService.GetTrack(p1.Humanoid, hit1)
				local v17 = animationService.GetTrack(p1.Humanoid, hit2)
				local randomNumber = math.random(1, 2)

				if randomNumber == 1 then
					v16:Play()
				elseif randomNumber == 2 then
					v17:Play()
				end

				local clone4 = gunHitSfx:Clone()

				clone4.PlaybackSpeed = math.random(1, 1.3)
				clone4.Parent = p1.HumanoidRootPart
				clone4:Play()
				game.Debris:AddItem(clone4, 2)
				game.TweenService:Create(clone, TweenInfo.new(0.3), { Size = UDim2.new(0, 0, 0, 0) }):Play()

				return
			end

			local v20 = animationService.GetTrack(p1.Humanoid, hit1)
			local v21 = animationService.GetTrack(p1.Humanoid, hit2)
			local randomNumber = math.random(1, 2)

			if randomNumber == 1 then
				v20:Play()
			elseif randomNumber == 2 then
				v21:Play()
			end

			local clone = gunHitSfx:Clone()

			clone.PlaybackSpeed = math.random(1, 1.3)
			clone.Parent = p1.HumanoidRootPart
			clone:Play()
			game.Debris:AddItem(clone, 2)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Walter.GuncounterHit/Graymatter", result)
	end
end)

return true
