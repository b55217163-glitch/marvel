-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local explosion = game.ReplicatedStorage.Characters.Walter.Remotes.Explosion
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function IsGoodRockPart(p1)
			if not p1 then
				return false
			end

			if not p1:IsA("BasePart") then
				return false
			end

			if not p1.Parent then
				return false
			end

			if p1.Transparency >= 0.95 then
				return false
			end

			if p1.LocalTransparencyModifier >= 0.95 then
				return false
			end

			if p1.CanCollide == false and p1.CanQuery == false then
				return false
			end

			return true
		end
		local function TestRock(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v22 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v24 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v24, 0)
				local n2 = v22 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v27 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v27 then
					local instance = v27.Instance

					if not (if not instance then false else if not instance:IsA("BasePart") then false else if not instance.Parent then false else if instance.Transparency >= 0.95 then false else if instance.LocalTransparencyModifier >= 0.95 then false else instance.CanCollide ~= false or instance.CanQuery ~= false) then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") then
							if (v:IsA("Decal") or v:IsA("Texture")) and v.Transparency < 0.95 or v:IsA("DataModelMesh") or v:IsA("Attachment") or v:IsA("ParticleEmitter") then
								local clone = v:Clone()

								clone.Parent = part
							end
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v33 = mathRandom(-180, 180)
					local v34 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v33, v34, mathRandom(-180, 180))
					part.Position = p2.Position

					local v35 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v35, { Position = v27.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v93 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v93, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v94 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v94, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Size = Vector3.new(3, 3, 3)
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v40 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v42 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v44 = math.rad(randomNumber3)
						local v45 = cFrameAngles(v40, v42, v44)

						clone.CFrame = p2.CFrame * v45

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p2.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v53 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v55 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v55, 0)
				local n2 = v53 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v58 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v58 then
					local instance = v58.Instance

					if not (if not instance then false else if not instance:IsA("BasePart") then false else if not instance.Parent then false else if instance.Transparency >= 0.95 then false else if instance.LocalTransparencyModifier >= 0.95 then false else instance.CanCollide ~= false or instance.CanQuery ~= false) then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") then
							if (v:IsA("Decal") or v:IsA("Texture")) and v.Transparency < 0.95 or v:IsA("DataModelMesh") or v:IsA("Attachment") or v:IsA("ParticleEmitter") then
								local clone = v:Clone()

								clone.Parent = part
							end
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v64 = mathRandom(-180, 180)
					local v65 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v64, v65, mathRandom(-180, 180))
					part.Position = p3.Position

					local v66 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v66, { Position = v58.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v99 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v99, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v100 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v100, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p4)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Exclude
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v71 = p4.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v73 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v73, 0)
				local n2 = v71 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v76 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v76 then
					local instance = v76.Instance

					if not (if not instance then false else if not instance:IsA("BasePart") then false else if not instance.Parent then false else if instance.Transparency >= 0.95 then false else if instance.LocalTransparencyModifier >= 0.95 then false else instance.CanCollide ~= false or instance.CanQuery ~= false) then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") then
							if (v:IsA("Decal") or v:IsA("Texture")) and v.Transparency < 0.95 or v:IsA("DataModelMesh") or v:IsA("Attachment") or v:IsA("ParticleEmitter") then
								local clone = v:Clone()

								clone.Parent = part
							end
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v82 = mathRandom(-180, 180)
					local v83 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v82, v83, mathRandom(-180, 180))
					part.Position = p4.Position

					local v84 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v84, { Position = v76.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v105 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v105, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v106 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v106, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local explosionMeth = game.ReplicatedStorage.Characters.Walter.Fx.ExplosionMeth
		local explosionMethMrBeast = game.ReplicatedStorage.Characters.Walter.Fx.ExplosionMethMrBeast
		local explosionMethNightwing = game.ReplicatedStorage.Characters.Walter.Fx.ExplosionMethNightwing

		explosion.OnClientEvent:Connect(function(player, _)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if Character:FindFirstChild("MrBeast") then
				local clone = explosionMethMrBeast:Clone()

				clone.Parent = workspace
				clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -6)
				game.Debris:AddItem(clone, 3)
				clone.At.Flare:Emit(30)
				clone.At.Sparks:Emit(50)
				clone.At.Smoke:Emit(50)
				TestRock(clone)
				TestRock2(clone)
				TestRock3(clone)
				clone.Sound:Play()

				return
			end

			if Character:FindFirstChild("Nightwing") then
				local clone = explosionMethNightwing:Clone()

				clone.Parent = workspace
				clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -6)
				game.Debris:AddItem(clone, 6)
				clone.At.Flare:Emit(30)
				clone.At.Smoke.Enabled = true
				clone.Sound:Play()
				task.delay(2, function(_)
					clone.At.Smoke.Enabled = false
				end)
				TestRock(clone)
				TestRock2(clone)
				TestRock3(clone)

				return
			end

			local clone = explosionMeth:Clone()

			clone.Parent = workspace
			clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -6)
			game.Debris:AddItem(clone, 3)
			clone.At.Flare:Emit(30)
			clone.At.Sparks:Emit(50)
			clone.At.Smoke:Emit(50)
			TestRock(clone)
			TestRock2(clone)
			TestRock3(clone)
			clone.Sound:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Walter.Math", result)
	end
end)

return true
