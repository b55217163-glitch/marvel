-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local death = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.Death

		game.ReplicatedStorage.Characters.Joe.Remotes.Death.OnClientEvent:Connect(function(p1)
			animationService.GetTrack(p1.Humanoid, death):Play()
			p1.Head.DeathLine:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Joe.Death", result)
	end
end)

return true
