-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.FinisherHit
		local cough = game.ReplicatedStorage.Characters.Joe.Fx.Mouth.Cough
		local putIn = game.ReplicatedStorage.Characters.Joe.Fx.Mouth.PutIn
		local TweenService = game.TweenService

		game.ReplicatedStorage.Characters.Joe.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)
			local v15 = p2:WaitForChild("Humanoid", 5)
			local HumanoidRootPart = Character.HumanoidRootPart
			local v17 = animationService.LoadFresh(humanoid, finisher)
			local v18 = animationService.GetTrack(v15, finisherHit)
			local clone = cough:Clone()

			clone.Parent = p2.Head

			local clone2 = putIn:Clone()

			clone2.Parent = p2.Head
			animationService.ConnectMarker(v17, "Start", function(_)
				Character.Book.Transparency = 0
				v18:Play()

				if p2:FindFirstChild("Love") then
					Character.Head.FinisherLineLove:Play()

					return
				end

				if p2:FindFirstChild("WebArm1") then
					Character.Head.FinisherLineSpider:Play()

					return
				end

				if p2:FindFirstChild("Joe") then
					Character.Head.FinisherLineMe:Play()

					return
				end

				if p2:FindFirstChild("Beck") then
					Character.Head.FinisherLineBeck:Play()

					return
				end

				Character.Head.FinisherLine:Play()
			end)
			animationService.ConnectMarker(v17, "BookRips", function(_)
				Character.Book.Paper1:Emit(12)
				Character.Book.Paper2:Emit(12)
				Character.Book.Paper3:Emit(12)
				Character.Book.Paper4:Emit(12)
			end)
			animationService.ConnectMarker(v17, "Prop", function(_)
				Character.Paper.Transparency = 0
				Character.Paper.Spit1.Enabled = true
				Character.Paper.Spit2.Enabled = true
				Character.Paper.Spit3.Enabled = true

				if not p2:FindFirstChild("Love") and p2.Head:FindFirstChild("LongScream") then
					p2.Head.LongScream:Play()
				end
			end)
			animationService.ConnectMarker(v17, "PropOff", function(_)
				Character.Paper.Transparency = 1
				Character.Paper.Spit1.Enabled = false
				Character.Paper.Spit2.Enabled = false
				Character.Paper.Spit3.Enabled = false
				clone2.Paper1:Emit(3)
				clone2.Paper2:Emit(3)
				clone2.Spit1:Emit(12)
				clone2.Spit2:Emit(12)
				clone2.Spit3:Emit(12)

				if p2.Head:FindFirstChild("LongScream") then
					game.TweenService:Create(p2.Head.LongScream, TweenInfo.new(0.3), { Volume = 0 }):Play()
				end
			end)
			animationService.ConnectMarker(v17, "Cough", function(_)
				clone.Blood1:Emit(30)
				clone.Blood2:Emit(30)
				clone.Blood3:Emit(30)
				clone.Blood4:Emit(30)
				clone.Paper1:Emit(3)
				clone.Paper2:Emit(3)
				clone.Paper3:Emit(3)
				clone.Paper4:Emit(3)
				clone.Spit1:Emit(12)
				clone.Spit2:Emit(12)
				clone.Spit3:Emit(12)
			end)
			v17:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Joe.Finisher", result)
	end
end)

return true
