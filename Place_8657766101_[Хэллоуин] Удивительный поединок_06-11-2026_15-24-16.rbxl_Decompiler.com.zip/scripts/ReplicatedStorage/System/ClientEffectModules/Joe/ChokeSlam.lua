-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local basicCircle = game.ReplicatedStorage.Movement.Rocks.Fx.BasicCircle
		local groundBreakDecal = game.ReplicatedStorage.Movement.Rocks.Fx.GroundBreakDecal
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local medBoom = game.ReplicatedStorage.Movement.Rocks.Sfx.MedBoom
		local choke = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.Choke
		local chokeHit = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.ChokeHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local bloodAt = game.ReplicatedStorage.Characters.OmniMan.Fx.BloodSpurt.BloodAt
		local bloodAt2 = game.ReplicatedStorage.Characters.OmniMan.Fx.BloodSpurt.BloodAt2

		local function Lock(parent, p2)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 70000
			bodyPosition.D = 6000
			bodyPosition.Position = (parent.CFrame * CFrame.new(0, 0, 0)).Position
			bodyPosition.Parent = parent
			game.Debris:AddItem(bodyPosition, p2)
		end

		game.ReplicatedStorage.Characters.Joe.Remotes.ChokeSlam.OnClientEvent:Connect(function(p3, p4, _)
			local v21 = animationService.LoadFresh(p3.Humanoid, choke)
			local v22 = animationService.GetTrack(p4.Humanoid, chokeHit)
			local workspaceMap = workspace.Map

			animationService.ConnectMarker(v21, "Start", function(_)
				p3.Head.ChokeVC:Play()
				v22:Play()
				p3.Humanoid.WalkSpeed = 20
			end)
			animationService.ConnectMarker(v21, "Slam", function(_)
				Lock(p3.HumanoidRootPart, 1)

				local clone = basicCircle:Clone()

				clone.CFrame = p3.HumanoidRootPart.CFrame
				clone.Parent = workspace
				game.Debris:AddItem(clone, 2)

				for _, v in ipairs(clone:GetChildren()) do
					if v:IsA("Attachment") and v.Name ~= "ShockEffect" then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspaceMap }

						local v30 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v30 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v30.Position

							local randomNumber = math.random(-2, 2)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber2 = math.random(2, 2.5)
							local randomNumber3 = math.random(360)
							local v37 = math.rad(randomNumber3)
							local randomNumber4 = math.random(360)
							local v39 = math.rad(randomNumber4)
							local randomNumber5 = math.random(360)
							local v41 = math.rad(randomNumber5)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v44 = CFrame.Angles(v37, v39, v41)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v44 }):Play()

							local TweenService2 = game.TweenService
							local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

							TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
							part.Material = v30.Material
							part.Color = v30.Instance.Color

							local clone2 = smoke:Clone()

							clone2.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone2.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone2:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"
									explosionPart.Size = Vector3.new(0, 0, 0)
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v30.Instance.Color

									local TweenService3 = game.TweenService
									local randomNumber6 = math.random(1.5, 2.5)
									local randomNumber7 = math.random(1.5, 2.5)
									local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))

									TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

									local randomNumber8 = math.random(-80, 80)
									local randomNumber9 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

									local cFrame2 = CFrame.new(part.Position)
									local v59 = CFrame.Angles(v37, v39, v41)

									explosionPart.CFrame = cFrame2 * v59
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part2: Part = Instance.new("Part")

									part2.Anchored = false
									part2.Name = "ExplosionPart"
									part2.Size = Vector3.new(0, 0, 0)
									part2.Material = part.Material
									part2.CanCollide = true
									part2.CFrame = part.CFrame
									part2.Color = v30.Instance.Color
									game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber10 = math.random(-40, 40)
									local randomNumber11 = math.random(0, 40)

									part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

									local cFrame3 = CFrame.new(part.Position)
									local v64 = CFrame.Angles(v37, v39, v41)

									part2.CFrame = cFrame3 * v64
									part2.Parent = workspace
									game.Debris:AddItem(part2, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber12 = math.random(2, 2.3)

							task.delay(randomNumber12, function()
								local randomNumber13 = math.random(360)
								local v74 = math.rad(randomNumber13)
								local randomNumber14 = math.random(360)
								local v76 = math.rad(randomNumber14)
								local randomNumber15 = math.random(360)
								local v78 = math.rad(randomNumber15)
								local TweenService4 = game.TweenService
								local cFrame4 = CFrame.new(part.Position)
								local v81 = CFrame.Angles(v74, v76, v78)

								TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v81 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end
				end

				for _, v in ipairs(clone:GetChildren()) do
					if v.Name == "ShockEffect" then
						v.Ring:Emit(3)
						v.Shock:Emit(3)
					end
				end

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspaceMap }

				local v69 = workspace:Raycast(p3.HumanoidRootPart.Position, p3.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

				if v69 ~= nil then
					local clone3 = groundBreakDecal:Clone()

					clone3.Parent = workspace
					clone3.Position = v69.Position
					game.Debris:AddItem(clone3, 3)
					task.delay(2, function()
						game.TweenService:Create(clone3.GroundDecal, TweenInfo.new(1), { Transparency = 1 }):Play()
					end)
				end

				local clone4 = medBoom:Clone()

				clone4.Parent = clone
				clone4.PlaybackSpeed = math.random(1, 1.2)
				clone4:Play()
				p3.Humanoid.JumpPower = 0
				p3.Humanoid.WalkSpeed = 0
			end)
			animationService.ConnectMarker(v21, "Release", function(_)
				p3.Humanoid.WalkSpeed = 10
				p3.Humanoid.JumpPower = 30
			end)
			v21:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Joe.ChokeSlam", result)
	end
end)

return true
