-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage

		game:GetService("TweenService")

		local groundhit = game.ReplicatedStorage.Characters.Wanda.Fx.Groundhit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local counter = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.Counter
		local counterHit = game.ReplicatedStorage.Characters.Joe.AnimationsExtra.CounterHit
		local at = game.ReplicatedStorage.Characters.Joe.Fx.Fake.At

		game.ReplicatedStorage.Characters.Joe.Remotes.StabCounter.OnClientEvent:Connect(function(p1, player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if player.Character:FindFirstChild("Values") then
				local v15 = animationService.LoadFresh(player.Character.Humanoid, counter)
				local v16 = animationService.GetTrack(p1.Humanoid, counterHit)

				animationService.ConnectMarker(v15, "Start", function(_)
					v16:Play()
					Character.Knife.Transparency = 0
					Character.Knife.Transparency = 0
					Character.Head.CounterVC:Play()
				end)
				animationService.ConnectMarker(v15, "Stab", function(_)
					Character.FakeUpperTorso.Hit1.Blood1:Emit(30)
					Character.FakeUpperTorso.Hit1.Blood2:Emit(8)
					Character.FakeUpperTorso.Hit1.Blood3:Emit(8)
					Character.FakeUpperTorso.Hit1.Blood4:Emit(8)

					local clone = at:Clone()

					clone.Parent = p1.UpperTorso
					clone.GroundBlood:Emit(8)
					game.Debris:AddItem(clone, 7)
				end)
				v15:Play()
			end

			task.wait(3.5)
			Character.Knife.Transparency = 1
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Joe.Counter", result)
	end
end)

return true
