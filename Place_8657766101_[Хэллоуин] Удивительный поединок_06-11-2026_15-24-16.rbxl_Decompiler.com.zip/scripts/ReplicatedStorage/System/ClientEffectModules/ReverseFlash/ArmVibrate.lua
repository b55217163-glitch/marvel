-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local vibrateArm = game.ReplicatedStorage.Characters.TheFlashCw.Remotes.VibrateArm

		game:GetService("TweenService")
		game:GetService("TweenService")
		vibrateArm.OnClientEvent:Connect(function(player)
			local Character = player.Character

			if Character:FindFirstChild("GreenGhost") then
				Character.Head.VibHand:Play()
				task.wait(0.2)
				Character.RightUpperLeg.Transparency = 0.5
				Character.RightLowerLeg.Transparency = 0.5
				Character.RightFoot.Transparency = 0.5
				Character.RightFoot.ShakeAt.Shock.Enabled = true
				task.wait(0.8)
				Character.RightUpperLeg.Transparency = 0
				Character.RightLowerLeg.Transparency = 0
				Character.RightFoot.Transparency = 0
				Character.RightFoot.ShakeAt.Shock.Enabled = false

				return
			end

			Character.Head.VibHand:Play()
			task.wait(0.2)
			Character.RightUpperArm.Transparency = 0.5
			Character.RightLowerArm.Transparency = 0.5
			Character.RightHand.Transparency = 0.5
			Character.RightHand.ShakeAt.Shock.Enabled = true
			task.wait(0.8)
			Character.RightUpperArm.Transparency = 0
			Character.RightLowerArm.Transparency = 0
			Character.RightHand.Transparency = 0
			Character.RightHand.ShakeAt.Shock.Enabled = false
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "ReverseFlash.ArmVibrate", result)
	end
end)

return true
