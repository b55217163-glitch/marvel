-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Steve_H.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Steve_H.AnimationsExtra.FinisherHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.Steve_H.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if Character:FindFirstChild("Bat") then
				Character.Bat.Trail.Enabled = false
			end

			if Character:FindFirstChild("Spike1") then
				Character.Spike1.Transparency = 1
				Character.Spike2.Transparency = 1
				Character.Spike3.Transparency = 1
				Character.Spike4.Transparency = 1
				Character.Spike5.Transparency = 1
				Character.Spike6.Transparency = 1
				Character.Spike7.Transparency = 1
				Character.Spike8.Transparency = 1
				Character.Spike9.Transparency = 1
				Character.Spike10.Transparency = 1
				Character.Spike11.Transparency = 1
				Character.Bat.Transparency = 1
			end

			if Character:FindFirstChild("Paddle") then
				Character.Paddle.Transparency = 1
			end

			if Character:FindFirstChild("Axe") then
				Character.Axe.Transparency = 1
			end

			Character.Head.GetOut:Play()

			local v13 = animationService.LoadFresh(Character.Humanoid, finisher)
			local v14 = animationService.GetTrack(p2.Humanoid, finisherHit)

			v13.KeyframeReached:Connect(function(p3)
				if p3 == "Push" then
					Character.Head.Push:Play()
				end

				if p3 == "Jump" then
					Character.Head.Jump:Play()
				end

				if p3 == "Hit" then
					Character.Head.Hit:Play()
				end

				if p3 == "Land" then
					Character.Head.Land:Play()
				end

				if p3 == "HitPunch1" then
					Character.Head.HitPunch1:Play()

					local clone = neckExplode:Clone()

					clone.Parent = p2.Head
					clone.Bl1:Emit(3)
					clone.Bl2:Emit(8)

					for _ = 1, 5 do
						local randomNumber = math.random(5, 10)
						local clone2 = bloodDrip:Clone()

						clone2.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

						clone2.Parent = Character
						clone2.CFrame = p2.UpperTorso.CFrame
						clone2.LocalScript.Disabled = false
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber2 = math.random(-2, 2)
						local randomNumber3 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone2, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					game.Debris:AddItem(clone, 3)
				end

				if p3 == "HitPunch2" then
					Character.Head.HitPunch2:Play()

					local clone = neckExplode:Clone()

					clone.Parent = p2.Head
					clone.Bl1:Emit(3)
					clone.Bl2:Emit(8)

					for _ = 1, 5 do
						local randomNumber = math.random(5, 10)
						local clone3 = bloodDrip:Clone()

						game.Debris:AddItem(clone3, 3)
						clone3.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

						clone3.Parent = Character
						clone3.CFrame = p2.UpperTorso.CFrame
						clone3.LocalScript.Disabled = false
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone3, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					game.Debris:AddItem(clone, 3)
				end

				if p3 == "Grab" then
					Character.Head.Grab:Play()
				end

				if p3 == "HitPunch3" then
					Character.Head.HitPunch3:Play()

					local clone = neckExplode:Clone()

					clone.Parent = p2.Head
					clone.Bl1:Emit(5)
					clone.Bl2:Emit(15)

					for _ = 1, 5 do
						local randomNumber = math.random(15, 30)
						local clone4 = bloodDrip:Clone()

						game.Debris:AddItem(clone4, 3)
						clone4.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone4)

						clone4.Parent = Character
						clone4.CFrame = p2.UpperTorso.CFrame
						clone4.LocalScript.Disabled = false
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber6 = math.random(-2, 2)
						local randomNumber7 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber6, randomNumber7, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone4, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					game.Debris:AddItem(clone, 3)
				end

				if p3 == "Standup" then
					Character.Head.Standup:Play()
				end

				if p3 == "CleanShirt" then
					Character.Head.CleanShirt:Play()
				end

				if p3 == "CleanShirt2" then
					Character.Head.CleanShirt2:Play()
					task.wait(0.4)

					if Character:FindFirstChild("Spike1") then
						Character.Spike1.Transparency = 0
						Character.Spike2.Transparency = 0
						Character.Spike3.Transparency = 0
						Character.Spike4.Transparency = 0
						Character.Spike5.Transparency = 0
						Character.Spike6.Transparency = 0
						Character.Spike7.Transparency = 0
						Character.Spike8.Transparency = 0
						Character.Spike9.Transparency = 0
						Character.Spike10.Transparency = 0
						Character.Spike11.Transparency = 0
						Character.Bat.Transparency = 0
					end

					if Character:FindFirstChild("Paddle") then
						Character.Paddle.Transparency = 0
					end

					if Character:FindFirstChild("Axe") then
						Character.Axe.Transparency = 0
					end

					if Character:FindFirstChild("Bat") then
						Character.Bat.Trail.Enabled = true
					end
				end
			end)
			v13:Play()
			v14:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Finisher", result)
	end
end)

return true
