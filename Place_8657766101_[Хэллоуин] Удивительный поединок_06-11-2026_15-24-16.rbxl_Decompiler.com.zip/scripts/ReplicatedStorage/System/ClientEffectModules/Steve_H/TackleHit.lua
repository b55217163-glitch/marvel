-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local hitCombo4 = game.ReplicatedStorage.Characters.CombatFolder.Animations.HitCombo4
		local heavyPunch = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HeavyPunch
		local dashBack = game.ReplicatedStorage.Characters.CombatFolder.Sounds.DashBack
		local hitAtKratos = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAtKratos

		game.ReplicatedStorage.Characters.Steve_H.Remotes.Hard.OnClientEvent:Connect(function(p1, p2)
			local clone = hitAt:Clone()

			clone.Parent = p1.HumanoidRootPart
			clone.Sparks:Emit(15)
			clone.Shock:Emit(2)
			clone.SparksCircle:Emit(15)
			clone.ShockwaveMiddle:Emit(1)
			game.Debris:AddItem(clone, 1)
			animationService.GetTrack(p1.Humanoid, hitCombo4):Play()
			p2.HumanoidRootPart.Tackle:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.TackleHit", result)
	end
end)

return true
