-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.Steve_H.Remotes.Bruised.OnClientEvent:Connect(function(parent)
			parent.Head.Impact:Play()

			local clone = neckExplode:Clone()

			clone.Parent = parent.Head
			clone.Bl1:Emit(3)
			clone.Bl2:Emit(8)

			for _ = 1, 4 do
				local randomNumber = math.random(3, 25)
				local clone2 = bloodDrip:Clone()

				clone2.Parent = workspace

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

				clone2.Parent = parent
				clone2.CFrame = parent.UpperTorso.CFrame
				clone2.LocalScript.Disabled = false
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber2 = math.random(-2, 2)
				local randomNumber3 = math.random(-2, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
				game.Debris:AddItem(clone2, 3)
				game.Debris:AddItem(bodyVelocity, 0.15)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Bruised", result)
	end
end)

return true
