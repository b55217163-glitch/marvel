-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local masterRemote = game.ReplicatedStorage.Characters.Steve_H.Remotes.MasterRemote
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v17 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v19 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v19, 0)
				local n2 = v17 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v22 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v22 then
					local instance = v22.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v28 = mathRandom(-180, 180)
					local v29 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v28, v29, mathRandom(-180, 180))
					part.Position = p1.Position

					local v30 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v30, { Position = v22.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v84 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v84, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v85 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v85, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v35 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v37 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v39 = math.rad(randomNumber3)
						local v40 = cFrameAngles(v35, v37, v39)

						clone.CFrame = p1.CFrame * v40

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v48 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v50 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v50, 0)
				local n2 = v48 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v53 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v53 then
					local instance = v53.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v59 = mathRandom(-180, 180)
					local v60 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v59, v60, mathRandom(-180, 180))
					part.Position = p2.Position

					local v61 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v61, { Position = v53.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v90 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v90, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v91 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v91, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v66 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v68 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v68, 0)
				local n2 = v66 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v71 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v71 then
					local instance = v71.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v77 = mathRandom(-180, 180)
					local v78 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v77, v78, mathRandom(-180, 180))
					part.Position = p3.Position

					local v79 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v79, { Position = v71.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v96 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v96, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v97 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v97, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		masterRemote.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)
			Character.Head.MoveTwo:Play()
			task.wait(0.5)
			Character.Head.MoveTwoDistance:Play()
			TestRock(Character.HumanoidRootPart)
			TestRock2(Character.HumanoidRootPart)
			TestRock3(Character.HumanoidRootPart)
			Character.Guitar.SonicBoom.Flying:Emit(50)
			Character.Guitar.SonicBoom.Ring:Emit(10)
			Character.Guitar.SonicBoom.Ring2:Emit(10)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Master", result)
	end
end)

return true
