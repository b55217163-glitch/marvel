-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local LocalPlayer: Player = players.LocalPlayer
		local steveDeathDustin = replicatedStorage.Characters.Steve_H.AnimationsExtra.SteveDeathDustin
		local deathDustin = replicatedStorage.Characters.Steve_H.Fx.DeathDustin

		replicatedStorage.Characters.Steve_H.Remotes.Death.OnClientEvent:Connect(function(parent, p2, _)
			if parent:FindFirstChild("Dustin") then
				parent.Dustin:Destroy()
			end

			local clone = deathDustin:Clone()

			clone.Name = "Dustin"
			clone.Parent = parent

			local head = clone:FindFirstChild("Head")
			local goodFight = head and head:FindFirstChild("GoodFight")

			if goodFight and goodFight:IsA("Sound") then
				goodFight:Play()
			end

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					local vTransparency = v.Transparency

					v.Transparency = 1
					task.delay(0.1, function()
						if v and v.Parent then
							tweenService:Create(v, TweenInfo.new(0.1), { Transparency = vTransparency }):Play()
						end
					end)
				end
			end

			local humanoid = clone:FindFirstChildOfClass("Humanoid")
			local humanoidRootPart = clone:FindFirstChild("HumanoidRootPart")

			if humanoid and humanoidRootPart then
				local v22 = p2:PointToWorldSpace(Vector3.new(-2, 5, 0.5))
				local raycastParams = RaycastParams.new()

				raycastParams.FilterDescendantsInstances = { workspace.Map }
				raycastParams.FilterType = Enum.RaycastFilterType.Include

				local v24 = workspace:Raycast(v22, Vector3.new(0, -15, 0), raycastParams)

				v24 = Vector3.new(v22.X, (v24 and v24.Position.Y or p2.Position.Y - 3) + 1.8, v22.Z)

				local lookVector = p2.LookVector
				local cFrameNew = CFrame.new
				local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)

				humanoidRootPart.CFrame = cFrameNew(v24, v24 + vector3)
				humanoidRootPart.Anchored = true
				v24 = humanoid:FindFirstChildOfClass("Animator") or Instance.new("Animator", humanoid)
				animationService.GetTrack(v24, steveDeathDustin):Play()
				task.delay(6, function()
					for _, v in ipairs(clone:GetDescendants()) do
						if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
							tweenService:Create(v, TweenInfo.new(0.4), { Transparency = 1 }):Play()
						end
					end

					local taserStick = clone:FindFirstChild("TaserStick")

					if taserStick and taserStick:FindFirstChild("SparkAt") then
						local taserStickSparkAt = taserStick.SparkAt

						if taserStickSparkAt:FindFirstChild("Flare") then
							taserStickSparkAt.Flare.Enabled = false
						end

						if taserStickSparkAt:FindFirstChild("Sparks") then
							taserStickSparkAt.Sparks.Enabled = false
						end

						if taserStickSparkAt:FindFirstChild("PointLight") then
							taserStickSparkAt.PointLight.Enabled = false
						end
					end

					task.delay(0.4, function()
						if clone and clone.Parent then
							clone:Destroy()
						end
					end)
				end)
				debris:AddItem(clone, 10)

				return
			end

			clone:Destroy()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Death", result)
	end
end)

return true
