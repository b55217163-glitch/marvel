-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gameDebris = game.Debris

		game.ReplicatedStorage.Characters.Steve_H.Remotes.ShieldCounter.OnClientEvent:Connect(function(p1)
			p1.Shield.Metal:Play()
			p1.Shield.Bass:Play()
			p1.Shield.HitAt.Shock:Emit(2)
			p1.Shield.HitAt.ShockwaveMiddle:Emit(1)
			p1.Shield.HitAt.Sparks:Emit(15)
			p1.Shield.HitAt.SparksCircle:Emit(15)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.ShieldCounter", result)
	end
end)

return true
