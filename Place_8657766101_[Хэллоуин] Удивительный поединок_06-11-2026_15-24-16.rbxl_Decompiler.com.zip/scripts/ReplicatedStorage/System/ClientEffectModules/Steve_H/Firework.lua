-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local fireworkThrow = game.ReplicatedStorage.Characters.Steve_H.Remotes.FireworkThrow
		local attachment = game.ReplicatedStorage.Characters.LandPart.Attachment
		local rocks = game.ReplicatedStorage.Characters.LandPart.Rocks
		local v8 = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.Attachment
		local smallGroundCrack = game.ReplicatedStorage.Characters.Physics.SmallGroundCrack

		game:GetService("TweenService")

		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new
		local mathRandomseed = math.randomseed
		local v15 = os.clock()

		mathRandomseed(v15 * 1000000 % 1000000000)

		for _ = 1, 3 do
			math.random()
		end

		local function TestRock(p1)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 24 do
				local randomNumber = math.random(0, 359)
				local v31 = math.rad(randomNumber)
				local randomNumber2 = math.random(60, 220)
				local randomNumber3 = math.random(-30, 30)
				local randomNumber4 = math.random(-30, 30)
				local vector3 = Vector3.new(randomNumber3 / 10, 0, randomNumber4 / 10)
				local cosine = math.cos(v31)
				local sine = math.sin(v31)
				local vector32 = Vector3.new(cosine, 0, sine)
				local v39 = workspace:Raycast(p1.Position + (vector32 * (randomNumber2 / 10) + vector3) + Vector3.new(0, 10, 0), Vector3.new(0, -35, 0), raycastParams)

				if v39 then
					local instance = v39.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Texture") or not not v:IsA("Decal") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					local n1 = math.random(25, 55) / 10

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(n1, n1, n1)

					local v46 = v39.Position
					local randomNumber5 = math.random(-10, 10)
					local randomNumber6 = math.random(-10, 10)
					local vector33 = Vector3.new(randomNumber5 / 10, 0, randomNumber6 / 10)
					local randomNumber7 = math.random(-180, 180)
					local randomNumber8 = math.random(-180, 180)

					part.Orientation = Vector3.new(randomNumber7, randomNumber8, math.random(-180, 180))

					local v52 = p1.Position
					local randomNumber9 = math.random(2, 6)
					local vector34 = Vector3.new(0, randomNumber9, 0)

					part.Position = v52 + vector34
					part.Parent = workspaceEffects

					local randomNumber10 = math.random(25, 65)
					local v56 = tweenInfoNew(randomNumber10 / 100, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v56, { Position = v46 + vector33 }):Play()
					game.Debris:AddItem(part, 2.5)
					task.delay(1, function()
						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v68 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

								tweenService:Create(v, v68, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v69 = tweenInfoNew(0.9, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
						local partPosition: Vector3 = part.Position
						local vector35 = Vector3.new(0, part.Size.Y / 2, 0)

						tweenService:Create(part, v69, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector35 }):Play()
					end)
				end
			end
		end

		local eLandPart = game.ReplicatedStorage.Characters.Steve_H.Fx.ELandPart
		local fireworkMove = game.ReplicatedStorage.Characters.Steve_H.Fx.FireworkMove
		local color3 = Color3.fromRGB(255, 80, 80)
		local color32 = Color3.fromRGB(255, 140, 40)
		local color33 = Color3.fromRGB(255, 220, 80)
		local color34 = Color3.fromRGB(80, 160, 255)
		local n1 = 0
		local t1: {[any]: any} = { color3, color32, color33, color34, Color3.fromRGB(180, 90, 255) }

		local function pickColor()
			local randomNumber = math.random(1, #t1)

			if #t1 > 1 and randomNumber == n1 then
				randomNumber = randomNumber % #t1 + 1
			end

			n1 = randomNumber

			return t1[randomNumber]
		end

		fireworkThrow.OnClientEvent:Connect(function(player, _, cFrame)
			if not player.Character then
				return
			end

			local clone = eLandPart:Clone()

			clone.Parent = workspace.Effects
			clone.CFrame = cFrame

			local fireWorkBoom = clone:FindFirstChild("FireWorkBoom")

			if fireWorkBoom and fireWorkBoom:IsA("Sound") then
				if fireWorkBoom.SoundId == "" then
					local soundId = fireWorkBoom:GetAttribute("LazySoundId") or fireWorkBoom:GetAttribute("OriginalSoundId")

					if typeof(soundId) == "string" and soundId ~= "" then
						fireWorkBoom.SoundId = soundId
					end
				end

				fireWorkBoom:Play()
			end

			game.Debris:AddItem(clone, 3)

			local randomNumber = math.random(1, #t1)

			if #t1 > 1 and randomNumber == n1 then
				randomNumber = randomNumber % #t1 + 1
			end

			n1 = randomNumber

			local v65 = t1[randomNumber]

			task.spawn(function()
				for _ = 1, 30 do
					local clone2 = fireworkMove:Clone()

					clone2.Parent = workspace.Effects
					clone2.CFrame = cFrame

					local v74 = mathRandom(-170, 170)
					local v75 = mathRandom(-170, 170)

					clone2.Orientation = Vector3.new(v74, v75, mathRandom(-170, 170))

					if clone2:IsA("BasePart") then
						clone2.Color = v65
					end

					if clone2:FindFirstChild("Glow") then
						clone2.Glow.Color = v65
					end

					local at = clone2:FindFirstChild("At")

					if at then
						local glow = at:FindFirstChild("Glow")

						if glow then
							glow.Color = ColorSequence.new(v65)
						end

						local sparks = at:FindFirstChild("Sparks")

						if sparks then
							sparks.Color = ColorSequence.new(v65)
						end
					end

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

					local randomNumber11 = math.random(-3, 3)
					local randomNumber12 = math.random(-3, 3)

					bodyVelocity.Velocity = Vector3.new(randomNumber11, randomNumber12, math.random(-3, 3)) * 15
					bodyVelocity.Parent = clone2
					game.Debris:AddItem(clone2, 4)
					game.Debris:AddItem(bodyVelocity, 0.5)
					task.delay(1, function()
						if not clone2 then
							return
						end

						if clone2:FindFirstChild("Glow") then
							clone2.Glow.Enabled = false
						end

						local at2 = clone2:FindFirstChild("At")

						if at2 then
							if at2:FindFirstChild("Glow") then
								at2.Glow.Enabled = false
							end

							if at2:FindFirstChild("Sparks") then
								at2.Sparks.Enabled = false
							end

							if at2:FindFirstChild("Smoke") then
								at2.Smoke.Enabled = false
							end
						end
					end)
				end
			end)
			TestRock(clone)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Firework", result)
	end
end)

return true
