-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local LocalPlayer: Player = players.LocalPlayer
		local dustin = replicatedStorage.Characters.Steve_H.AnimationsExtra.Dustin
		local v10 = replicatedStorage.Characters.Steve_H.Fx.Dustin

		replicatedStorage.Characters.Steve_H.Remotes.Dustin.OnClientEvent:Connect(function(p1, p2, _)
			if not p1 then
				return
			end

			local clone = v10:Clone()

			clone.Parent = workspace.Effects
			debris:AddItem(clone, 4)

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					local vTransparency = v.Transparency

					v.Transparency = 1
					tweenService:Create(v, TweenInfo.new(0.1), { Transparency = vTransparency }):Play()
				end
			end

			clone.HumanoidRootPart.CFrame = p2
			clone.HumanoidRootPart.Anchored = true

			local cloneTaserStick = clone.TaserStick

			cloneTaserStick.Land:Play()

			if p1:FindFirstChild("SpearUser") then
				cloneTaserStick.AboardVol3:Play()
			else
				cloneTaserStick.Aboard:Play()
			end

			task.delay(0.1, function()
				cloneTaserStick.SparkAt.Flare.Enabled = true
				cloneTaserStick.SparkAt.Sparks.Enabled = true
				cloneTaserStick.Taser:Play()
				cloneTaserStick.Shock:Play()
			end)
			animationService.GetTrack(clone.Humanoid, dustin):Play()
			task.delay(1.5, function()
				for _, v in ipairs(clone:GetDescendants()) do
					if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
						tweenService:Create(v, TweenInfo.new(0.4), { Transparency = 1 }):Play()
					end
				end

				local foundChild = cloneTaserStick:FindFirstChild("SparkAt", true)

				if foundChild then
					if foundChild:FindFirstChild("Flare") then
						foundChild.Flare.Enabled = false
					end

					if foundChild:FindFirstChild("Sparks") then
						foundChild.Sparks.Enabled = false
					end

					if foundChild:FindFirstChild("PointLight") then
						foundChild.PointLight.Enabled = false
					end
				end

				task.delay(0.4, function()
					clone:Destroy()
				end)
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve_H.Dustin", result)
	end
end)

return true
