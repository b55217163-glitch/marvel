-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(1)

		local LocalPlayer: Player = game:GetService("Players").LocalPlayer
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local workspace: Workspace = game:GetService("Workspace")
		local characters: Instance = replicatedStorage:WaitForChild("Characters", 5)

		if not characters then
			return
		end

		local combat: Instance = characters:WaitForChild("Combat", 5)

		if not combat then
			return
		end

		local remotes: Instance = combat:FindFirstChild("Remotes")
		local blocking: Instance = remotes and remotes:FindFirstChild("Blocking")

		if not blocking or not blocking:IsA("RemoteEvent") then
			return
		end

		local v12 = combat.Fx

		if v12 then
			v12 = combat.Fx:FindFirstChild("ShieldEffect")
		end

		local guard = replicatedStorage.Characters.Combat.Fx:FindFirstChild("Guard")
		local guardOff = replicatedStorage.Characters.Combat.Fx:FindFirstChild("GuardOff")
		local CurrentCamera: Camera = workspace.CurrentCamera
		local object = setmetatable({}, { __mode = "k" })

		local function canRun(p1)
			local v21 = os.clock()

			if v21 - (object[p1] or 0) < 0.25 then
				return false
			end

			object[p1] = v21

			return true
		end
		local function inRange(p2)
			if not p2 then
				return false
			end

			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v25 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position

			if not v25 then
				return true
			end

			local n1 = p2.Position - v25

			return n1:Dot(n1) <= 14400
		end
		local function Guard(p3)
			local u28
			local humanoidRootPart = p3 and p3:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local Character: Model = LocalPlayer.Character
			local characterHumanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v32 = characterHumanoidRootPart and characterHumanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position

			if not v32 then
				u28 = true
			else
				local n1 = humanoidRootPart.Position - v32

				u28 = n1:Dot(n1) <= 14400
			end

			if not u28 then
				return
			end

			v32 = os.clock()

			local u34

			if v32 - (object[humanoidRootPart] or 0) < 0.25 then
				u34 = false
			else
				object[humanoidRootPart] = v32
				u34 = true
			end

			if not u34 then
				return
			end

			task.spawn(function()
				local clone = nil

				if v12 then
					clone = v12:Clone()

					if p3:FindFirstChild("Hal") then
						clone.Image.ImageColor3 = Color3.new(0.338613, 1, 0.637964)
					end

					clone.Parent = humanoidRootPart

					local image = clone:FindFirstChild("Image")

					if image then
						image.ImageTransparency = 1
						tweenService:Create(image, TweenInfo.new(0.1), { ImageTransparency = 0 }):Play()
					end

					debris:AddItem(clone, 1)
				end

				if guard then
					local clone = guard:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 1.2)
				end

				task.wait(0.8)

				local v39 = clone and clone.Parent and clone:FindFirstChild("Image")

				if v39 then
					tweenService:Create(v39, TweenInfo.new(0.3), { ImageTransparency = 1 }):Play()
				end

				task.wait(0.1)

				if guardOff then
					local clone = guardOff:Clone()

					clone.Parent = humanoidRootPart
					clone:Play()
					debris:AddItem(clone, 1.2)
				end
			end)
		end

		blocking.OnClientEvent:Connect(function(p4)
			Guard(p4)
		end)
	end)

	if not ok then
		warn("[OldClientEffects2Module] failed:", "Combat.Blocking", result)
	end
end)

return true
