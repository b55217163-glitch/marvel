-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local userInputService: UserInputService = game:GetService("UserInputService")
		local guiService: GuiService = game:GetService("GuiService")
		local LocalPlayer: Player = game:GetService("Players").LocalPlayer
		local evfx = replicatedStorage.Characters.TomSpider.Fx.EVFX
		local beam = evfx:WaitForChild("Beam")
		local moveEVFX = replicatedStorage.Characters.TomSpider.Remotes:WaitForChild("MoveEVFX")
		local t1: {[any]: any} = {}
		local n1: number = 28

		if userInputService.TouchEnabled then
			n1 = 20
		elseif guiService:IsTenFootInterface() then
			n1 = 24
		end

		local function getVisibleWebBudget(p1, p2)
			local v28 = math.min(p2, n1)

			if p1 == LocalPlayer.Character then
				return v28
			end

			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v31 = p1

			if v31 then
				v31 = p1:FindFirstChild("HumanoidRootPart")
			end

			if humanoidRootPart and v31 then
				local magnitude = (humanoidRootPart.Position - v31.Position).Magnitude

				if magnitude > 170 then
					return 0
				end

				if magnitude > 110 then
					return (math.min(v28, 8))
				end

				if magnitude > 70 then
					return (math.min(v28, 16))
				end

				return v28
			end

			return v28
		end
		local function tweenBeam(p3, p4, p5, p6, p7)
			if not p3 or not p3.Parent then
				return nil
			end

			local tweenInfo = TweenInfo.new(p4, p6 or Enum.EasingStyle.Sine, p7 or Enum.EasingDirection.InOut)
			local v39: Tween = tweenService:Create(p3, tweenInfo, p5)

			v39:Play()

			return v39
		end
		local function setupBeam(p8)
			p8.FaceCamera = true
			p8.LightInfluence = 0
			p8.Segments = 4
		end
		local function fadeBeam(p9, p10)
			if not p9 or not p9.Parent then
				return
			end

			local numberValue: NumberValue = Instance.new("NumberValue")

			numberValue.Value = 0

			local connection = nil

			connection = numberValue:GetPropertyChangedSignal("Value"):Connect(function()
				if not p9.Parent then
					if connection then
						connection:Disconnect()
					end

					return
				end

				p9.Transparency = NumberSequence.new(numberValue.Value)
			end)

			local tweenInfo = TweenInfo.new(p10, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v46: Tween = tweenService:Create(numberValue, tweenInfo, { Value = 1 })

			v46:Play()
			v46.Completed:Once(function()
				if connection then
					connection:Disconnect()
				end

				if p9.Parent then
					p9.Transparency = NumberSequence.new(1)
				end

				numberValue:Destroy()
			end)
		end
		local function playWebSound(p11)
			local humanoidRootPart = p11:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local webShoot = humanoidRootPart:FindFirstChild("WebShoot")
			local webShoot2 = humanoidRootPart:FindFirstChild("WebShoot2")
			local v51 = if webShoot and webShoot2 then math.random(1, 2) == 1 and webShoot or webShoot2 else webShoot or webShoot2

			if not v51 or not v51:IsA("Sound") then
				return
			end

			local clone = v51:Clone()

			clone.PlaybackSpeed = math.random(100, 120) / 100
			clone.Volume = v51.Volume * 0.2
			clone.Parent = humanoidRootPart
			clone:Play()
			debris:AddItem(clone, 3)
		end
		local function createAnchor(cFrame, p13)
			local part: Part = Instance.new("Part")

			part.Name = p13 or "LocalWebAnchor"
			part.Size = Vector3.new(0.1, 0.1, 0.1)
			part.Transparency = 1
			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.CanQuery = false
			part.CFrame = cFrame
			part.Parent = workspace:FindFirstChild("Effects") or workspace

			local attachment: Attachment = Instance.new("Attachment")

			attachment.Parent = part

			return part, attachment
		end
		local function getHandAttachment(p14, p15)
			local foundChild = p14:FindFirstChild(p15 or "RightHand")

			if not foundChild or not foundChild:IsA("BasePart") then
				return nil, nil
			end

			local moveEWebAttachment = foundChild:FindFirstChild("MoveEWebAttachment")

			if not moveEWebAttachment or not moveEWebAttachment:IsA("Attachment") then
				if moveEWebAttachment then
					moveEWebAttachment:Destroy()
				end

				moveEWebAttachment = Instance.new("Attachment")
				moveEWebAttachment.Name = "MoveEWebAttachment"
				moveEWebAttachment.Parent = foundChild
			end

			return foundChild, moveEWebAttachment
		end
		local function elasticImpact(p16)
			if not p16 or not p16.Parent then
				return
			end

			local n1: number = if math.random(0, 1) == 0 then -1 else 1
			local randomNumber = math.random(20, 32)
			local randomNumber2 = math.random(15, 25)
			local v65 = tweenBeam(p16, 0.22, {
				CurveSize0 = randomNumber / 10 * n1,
				CurveSize1 = -(randomNumber2 / 10) * n1
			}, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out)

			if v65 then
				v65.Completed:Wait()
			end

			if not p16.Parent then
				return
			end

			v65 = tweenBeam(p16, 0.12, { CurveSize0 = -1.1 * n1, CurveSize1 = 0.7 * n1 }, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

			if v65 then
				v65.Completed:Wait()
			end

			if not p16.Parent then
				return
			end

			local randomNumber3 = math.random(-4, 4)
			local randomNumber4 = math.random(-4, 4)

			tweenBeam(p16, 0.18, { CurveSize0 = randomNumber3 / 10, CurveSize1 = randomNumber4 / 10 }, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
		end
		local function createRoomWeb(p17, p18, p19, p20)
			if not not p19.Ended or not p17 or not p17.Parent then
				return
			end

			local v72, attachment0 = getHandAttachment(p17, p18.HandName)

			if v72 and attachment0 then
				local startPosition = p18.StartPosition
				local endPosition = p18.EndPosition
				local shootDuration = p18.ShootDuration
				local clone = evfx:Clone()

				clone.Parent = workspace:FindFirstChild("Effects") or workspace
				debris:AddItem(clone, 12)

				if not clone:IsA("BasePart") then
					clone:Destroy()

					return
				end

				local at1 = clone:FindFirstChild("At1")
				local at2 = clone:FindFirstChild("At2")
				local beam = clone:FindFirstChild("Beam")

				if not at1 or not at2 or not beam or not at1:IsA("Attachment") or not at2:IsA("Attachment") or not beam:IsA("Beam") then
					clone:Destroy()

					return
				end

				beam.FaceCamera = true
				beam.LightInfluence = 0
				beam.Segments = 4
				clone.CFrame = CFrame.new(startPosition)
				at2.Position = clone.CFrame:PointToObjectSpace(v72.Position)

				local v81 = clone.CFrame:PointToObjectSpace(endPosition)

				beam.Attachment0 = attachment0
				beam.Attachment1 = at2
				beam.Enabled = false
				beam.Width0 = 4
				beam.Width1 = 15
				beam.CurveSize0 = math.random(-10, 10)
				beam.CurveSize1 = math.random(-10, 10)
				beam.Transparency = NumberSequence.new(0)
				beam.Enabled = true

				if (p20 - 1) % 4 == 0 then
					playWebSound(p17)
				end

				tweenBeam(beam, 0.12, { Width0 = 15, Width1 = 4 }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				table.insert(p19.Webs, {
					Ended = false,
					Web = clone,
					Beam = beam,
					At2 = at2,
					HandAttachment = attachment0
				})

				local n1 = math.random(-40, 40) / 10
				local n2 = math.random(-40, 40) / 10

				tweenBeam(beam, 0.1, { CurveSize0 = n1, CurveSize1 = n2 }, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

				local tweenInfo = TweenInfo.new(shootDuration, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local v85: Tween = tweenService:Create(at2, tweenInfo, { Position = v81 })

				v85:Play()
				tweenBeam(beam, shootDuration, { CurveSize0 = n1 * 0.2, CurveSize1 = n2 * 0.2 }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				v85.Completed:Wait()

				if clone.Parent and not p19.Ended then
					elasticImpact(beam)

					return
				end

				return
			end
		end
		local function createBurst(p21, p22, p23)
			local v89 = t1[p21]

			if v89 then
				v89.Ended = true

				for _, v in ipairs(v89.Webs) do
					if v.Web and v.Web.Parent then
						v.Web:Destroy()
					end
				end
			end

			local t2: {[any]: any} = {
				Ended = false,
				Webs = {}
			}

			t1[p21] = t2

			local v93 = getVisibleWebBudget(p21, #p22)

			if v93 <= 0 then
				return
			end

			for i = 1, v93 do
				local v95 = p22[i]

				task.delay((i - 1) * p23, function()
					if not not t2.Ended or not p21.Parent then
						return
					end

					createRoomWeb(p21, v95, t2, i)
				end)
			end
		end
		local function endBurst(p24)
			local v97 = t1[p24]

			if not v97 then
				return
			end

			v97.Ended = true

			local map: Instance = workspace:FindFirstChild("Map")

			for _, v in ipairs(v97.Webs) do
				local taskDelay = task.delay
				local randomNumber = math.random(0, 20)

				taskDelay(randomNumber / 100, function()
					if v.Ended then
						return
					end

					v.Ended = true

					local vWeb = v.Web
					local vBeam = v.Beam
					local vAt2 = v.At2
					local vHandAttachment = v.HandAttachment

					if not vWeb or not vWeb.Parent or not vBeam or not vBeam.Parent or not vAt2 or not vAt2.Parent or not vHandAttachment or not vHandAttachment.Parent then
						return
					end

					local vHandAttachmentWorldCFrame = vHandAttachment.WorldCFrame
					local v127, v128 = createAnchor(vHandAttachmentWorldCFrame, "LocalGroundWeb")

					if vHandAttachment == vBeam.Attachment0 then
						vBeam.Attachment0 = v128
					elseif vHandAttachment == vBeam.Attachment1 then
						vBeam.Attachment1 = v128
					end

					local raycastParams = RaycastParams.new()

					if map then
						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { map }
					else
						raycastParams.FilterType = Enum.RaycastFilterType.Exclude
						raycastParams.FilterDescendantsInstances = { p24 }
					end

					local v130 = workspace:Raycast(vHandAttachmentWorldCFrame.Position, Vector3.new(0, -100, 0), raycastParams)
					local n1 = if v130 then v130.Position + Vector3.new(0, 0.05, 0) else vHandAttachmentWorldCFrame.Position - Vector3.new(0, 12, 0)
					local n2 = math.random(45, 75) / 100
					local tweenInfo = TweenInfo.new(n2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					v130 = tweenService:Create(v127, tweenInfo, { Position = n1 })
					v130:Play()
					n1 = if math.random(0, 1) == 0 then -1 else 1
					tweenBeam(vBeam, n2, { CurveSize0 = 3.2 * n1, CurveSize1 = -2 * n1 }, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
					v130.Completed:Wait()

					if not vBeam.Parent or not vWeb.Parent then
						return
					end

					local taskWait = task.wait
					local randomNumber5 = math.random(0, 70)

					taskWait(5 + randomNumber5 / 100)

					if not vBeam.Parent or not vWeb.Parent then
						return
					end

					local n3 = math.random(140, 220) / 100
					local tweenInfo2 = TweenInfo.new(n3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					local v138 = v127.Position
					local randomNumber6 = math.random(-20, 20)
					local randomNumber7 = math.random(5, 10)
					local randomNumber8 = math.random(-20, 20)
					local vector3 = Vector3.new(randomNumber6 / 10, -randomNumber7, randomNumber8 / 10)

					tweenService:Create(v127, tweenInfo2, { Position = v138 + vector3 }):Play()

					local tweenInfo3 = TweenInfo.new(n3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

					v138 = vWeb.Position

					local randomNumber9 = math.random(-25, 25)
					local randomNumber10 = math.random(7, 13)
					local randomNumber11 = math.random(-25, 25)
					local vector32 = Vector3.new(randomNumber9 / 10, -randomNumber10, randomNumber11 / 10)

					tweenService:Create(vWeb, tweenInfo3, { Position = v138 + vector32 }):Play()
					tweenBeam(vBeam, n3, { CurveSize0 = 6 * n1, CurveSize1 = -4 * n1 }, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
					task.delay(0.15, function()
						if vBeam.Parent then
							fadeBeam(vBeam, n3 * 0.85)
						end
					end)
					debris:AddItem(vWeb, n3 + 0.3)
					debris:AddItem(v127, n3 + 0.3)
				end)
			end

			task.delay(8, function()
				if t1[p24] == v97 then
					t1[p24] = nil
				end
			end)
		end
		local function createVictimWeb(_, p26, p27)
			if not p26 or not p26.Parent then
				return
			end

			local parent = p26:FindFirstChild("UpperTorso") or p26:FindFirstChild("Torso")

			if not parent then
				return
			end

			local parentPosition = parent.Position
			local n1 = parentPosition + Vector3.new(0, 120, 0)
			local map: Instance = workspace:FindFirstChild("Map")

			if map then
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { map }

				local v111 = workspace:Raycast(parentPosition, Vector3.new(0, 120, 0), raycastParams)

				if v111 then
					n1 = v111.Position
				end
			end

			local moveEClientWeb: Attachment = Instance.new("Attachment")

			moveEClientWeb.Name = "MoveEClientWeb"
			moveEClientWeb.Parent = parent

			local cFrame = CFrame.new(n1)
			local v114, attachment1 = createAnchor(cFrame, "MoveERoofWeb")
			local clone = beam:Clone()

			clone.FaceCamera = true
			clone.LightInfluence = 0
			clone.Segments = 4
			clone.Attachment0 = moveEClientWeb
			clone.Attachment1 = attachment1
			clone.Width0 = 0.05
			clone.Width1 = 0.05
			clone.CurveSize0 = 0
			clone.CurveSize1 = 0
			clone.Transparency = NumberSequence.new(0)
			clone.Parent = v114
			tweenBeam(clone, 0.15, { Width0 = 4, Width1 = 15 }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			local u117: boolean = true

			task.spawn(function()
				local n1: number = 1

				while true do
					local v149 = u117 and clone.Parent and p26.Parent and tweenBeam(clone, 0.65, { CurveSize0 = n1 * 1.4, CurveSize1 = n1 * -0.8 }, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

					if not v149 then
						break
					end

					v149.Completed:Wait()
					n1 *= -1
				end
			end)
			task.delay(p27, function()
				u117 = false

				if not clone.Parent or not moveEClientWeb.Parent then
					return
				end

				local v150, v151 = createAnchor(moveEClientWeb.WorldCFrame, "MoveELooseVictimWeb")

				if clone.Attachment0 == moveEClientWeb then
					clone.Attachment0 = v151
				elseif clone.Attachment1 == moveEClientWeb then
					clone.Attachment1 = v151
				end

				moveEClientWeb:Destroy()

				local tweenInfo = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

				tweenService:Create(v150, tweenInfo, { Position = v150.Position + Vector3.new(1, -9, 0) }):Play()

				local tweenInfo4 = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

				tweenService:Create(v114, tweenInfo4, { Position = v114.Position + Vector3.new(-1, -11, 0) }):Play()
				tweenBeam(clone, 1.2, { CurveSize0 = 5, CurveSize1 = -3 }, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
				task.delay(0.1, function()
					if clone.Parent then
						fadeBeam(clone, 1)
					end
				end)
				debris:AddItem(v150, 1.4)
				debris:AddItem(v114, 1.4)
			end)
		end

		moveEVFX.OnClientEvent:Connect(function(p28, p29, p30, p31)
			if p28 == "WebBurst" then
				createBurst(p29, p30, p31)
			elseif p28 == "EndBurst" then
				endBurst(p29)
			elseif p28 == "VictimWeb" then
				createVictimWeb(p29, p30, p31)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TomSpider.EffectsE", result)
	end
end)

return true
