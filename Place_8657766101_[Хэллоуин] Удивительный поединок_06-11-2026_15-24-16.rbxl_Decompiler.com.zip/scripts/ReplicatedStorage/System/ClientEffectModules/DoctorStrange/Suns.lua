-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local bolts = game.ReplicatedStorage.Characters.DoctorStrange.Remotes.Bolts
		local bpart1 = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Bpart1
		local v7 = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Bpart1
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local effects: Instance = workspace:WaitForChild("Effects")

		local function randf(p1, p2)
			local randomNumber = math.random()

			return p1 + randomNumber * (p2 - p1)
		end
		local function v3rand(p3, p4)
			local x = p3.X
			local v25 = p4.X
			local randomNumber = math.random()
			local y = p3.Y
			local v28 = p4.Y
			local randomNumber2 = math.random()
			local z = p3.Z
			local v31 = p4.Z
			local randomNumber3 = math.random()
			local vector3 = Vector3.new(x + randomNumber * (v25 - x), y + randomNumber2 * (v28 - y), z + randomNumber3 * (v31 - z))

			return vector3
		end
		local function copySurfaceChildren(p5, parent)
			for _, v in ipairs(p5:GetChildren()) do
				if not v:IsA("SurfaceAppearance") then
					local ok2, result2 = pcall(function()
						return v:Clone()
					end)

					if ok2 and result2 then
						result2.Parent = parent
					end
				end
			end
		end
		local function fadeSink(p7)
			task.delay(1.6, function()
				if not p7 or not p7.Parent then
					return
				end

				for _, v in ipairs(p7:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Linear)

						tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local tweenInfo = TweenInfo.new(0.9, Enum.EasingStyle.Linear)
				local v131 = p7.Position
				local vector3 = Vector3.new(0, p7.Size.Y * 0.6, 0)

				tweenService:Create(p7, tweenInfo, { Size = Vector3.new(0, 0, 0), Position = v131 - vector3 }):Play()
			end)
		end
		local function beamHitRocks(p8, p9, p10, p11, p12)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			local randomNumber = math.random(10, 20)
			local randomNumber4 = math.random()
			local n1 = 12 + math.random() * 16
			local randomNumber5 = math.random()
			local randomNumber6 = math.random()

			for i = 1, randomNumber do
				local n2 = -n1
				local randomNumber7 = math.random()
				local n3 = 0 + randomNumber4 * 360 + i * (360 / randomNumber) + (n2 + randomNumber7 * (n1 - n2))
				local randomNumber8 = math.random()
				local n4 = p9 * (0.35 + randomNumber8 * 0.65)
				local v58 = math.rad(n3)
				local cosine = math.cos(v58)
				local randomNumber9 = math.random()
				local v61 = math.rad(n3)
				local sine = math.sin(v61)
				local randomNumber10 = math.random()
				local v64 = p8.CFrame
				local cFrame = CFrame.new(cosine * n4 * (0.55 + randomNumber5 * 0.5999999999999999) + (-0.7 + randomNumber9 * 1.4), 0, sine * n4 * (0.55 + randomNumber6 * 0.5999999999999999) + (-0.7 + randomNumber10 * 1.4))

				n2 = workspace:Raycast((v64 * cFrame).Position + Vector3.new(0, 14, 0), Vector3.new(0, -80, 0), raycastParams)

				if n2 then
					local instance = n2.Instance
					local v67 = n2.Position
					local normal = n2.Normal
					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.CanQuery = false
					part.Material = instance.Material
					part.Color = instance.Color
					copySurfaceChildren(instance, part)

					local v70 = math.clamp(n4 / p9, 0, 1)
					local x = p10.X
					local v72 = p11.X
					local randomNumber11 = math.random()
					local y = p10.Y
					local v75 = p11.Y
					local randomNumber12 = math.random()
					local z = p10.Z
					local v78 = p11.Z
					local randomNumber13 = math.random()

					part.Size = Vector3.new(x + randomNumber11 * (v72 - x), y + randomNumber12 * (v75 - y), z + randomNumber13 * (v78 - z)) * ((1 - v70) * 0.6 + 0.7)

					local cFrameFromAxisAngle = CFrame.fromAxisAngle
					local randomNumber14 = math.random(-180, 180)
					local v82 = math.rad(randomNumber14)

					v70 = cFrameFromAxisAngle(normal, v82)
					part.CFrame = CFrame.new(v67, v67 + p8.CFrame.LookVector) * v70

					local partOrientation: Vector3 = part.Orientation
					local randomNumber15 = math.random(-25, 25)
					local vector3 = Vector3.new(randomNumber15, 0, math.random(-25, 25))

					part.Orientation = partOrientation + vector3

					local randomNumber16 = math.random()

					part.Position = v67 + normal * (2 + randomNumber16 * 4)
					part.Parent = effects

					local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, tweenInfo, { Position = v67 + normal * (part.Size.Y * 0.2) }):Play()
					debris:AddItem(part, 3)
					task.delay(1.6, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local tweenInfo2 = TweenInfo.new(0.5, Enum.EasingStyle.Linear)

								tweenService:Create(v, tweenInfo2, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local tweenInfo3 = TweenInfo.new(0.9, Enum.EasingStyle.Linear)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.Y * 0.6, 0)

						tweenService:Create(part, tweenInfo3, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
					end)
				end
			end

			local v88 = p12 and workspace:Raycast(p8.Position + Vector3.new(0, 14, 0), Vector3.new(0, -80, 0), raycastParams)

			if v88 then
				local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

				clone.Material = v88.Instance.Material
				clone.Color = v88.Instance.Color

				if clone:FindFirstChild("Trail") then
					clone.Trail.Color = ColorSequence.new(v88.Instance.Color)
				end

				local v90 = p8.CFrame
				local cFrameAngles = CFrame.Angles
				local randomNumber17 = math.random(0, 360)
				local v93 = math.rad(randomNumber17)
				local randomNumber18 = math.random(0, 360)
				local v95 = math.rad(randomNumber18)
				local randomNumber19 = math.random(0, 360)
				local v97 = math.rad(randomNumber19)
				local v98 = cFrameAngles(v93, v95, v97)

				clone.CFrame = v90 * v98
				clone.Parent = effects

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

				local lookVector = p8.CFrame.LookVector
				local randomNumber20 = math.random()
				local randomNumber21 = math.random()
				local randomNumber22 = math.random()
				local randomNumber23 = math.random()
				local vector3 = Vector3.new(-35 + randomNumber21 * 70, 35 + randomNumber22 * 35, -35 + randomNumber23 * 70)

				bodyVelocity.Velocity = lookVector * (20 + randomNumber20 * 50) + vector3
				bodyVelocity.Parent = clone
				debris:AddItem(clone, 3)
				debris:AddItem(bodyVelocity, 0.25)
			end
		end
		local function TestRock1(p13)
			beamHitRocks(p13, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)
		end
		local function TestRock2(p14)
			beamHitRocks(p14, 15, Vector3.new(2.6, 1.1, 2.6), Vector3.new(6.4, 2.5, 6.4), false)
		end

		local bowDown = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.BowDown

		bolts.OnClientEvent:Connect(function(_, cFrame, p17, p18)
			if p18 then
				local clone = bpart1:Clone()

				clone.Parent = workspace.Effects
				clone.CFrame = cFrame
				game.Debris:AddItem(clone, 3)
				game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.15), { Width0 = 3 }):Play()
				game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.15), { Width0 = 30 }):Play()
				game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.15), { Width0 = 3 }):Play()

				local clone2 = v7:Clone()

				clone2.Parent = workspace.Effects
				clone2.CFrame = cFrame
				game.Debris:AddItem(clone2, 3)
				clone2.Beam:Play()
				clone.Attachment.Beam1.Attachment1 = clone2.Attachment
				clone.Attachment.Beam2.Attachment1 = clone2.Attachment
				clone.Attachment.Beam3.Attachment1 = clone2.Attachment
				task.spawn(function()
					beamHitRocks(clone, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v140 = workspace:Raycast(clone.Position, clone.CFrame.UpVector * -3, raycastParams)

					if v140 ~= nil then
						clone.Rocks.Color = ColorSequence.new(v140.Instance.Color)
						clone.Rocks.Enabled = true
					end

					clone.Explode.PlaybackSpeed = math.random(1, 1.3)
					clone.Explode:Play()
				end)
				task.wait(0.2)
				game.TweenService:Create(clone2, TweenInfo.new(0.15), { CFrame = p17 }):Play()
				game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.15), { Width1 = 3 }):Play()
				game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.15), { Width1 = 30 }):Play()
				game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.15), { Width1 = 3 }):Play()
				task.spawn(function()
					task.wait(0.15)
					beamHitRocks(clone2, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v142 = workspace:Raycast(clone2.Position, clone2.CFrame.UpVector * -3, raycastParams)

					if v142 ~= nil then
						clone2.Rocks.Color = ColorSequence.new(v142.Instance.Color)
						clone2.Rocks.Enabled = true
					end

					clone2.Explode.PlaybackSpeed = math.random(1, 1.3)
					clone2.Explode:Play()
				end)

				local clone3 = bpart1:Clone()

				clone3.Parent = workspace.Effects
				clone3.CFrame = p17
				game.Debris:AddItem(clone3, 3)
				game.TweenService:Create(clone3.Attachment.Beam1, TweenInfo.new(0.15), { Width0 = 3 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam2, TweenInfo.new(0.15), { Width0 = 30 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam3, TweenInfo.new(0.15), { Width0 = 3 }):Play()
				clone3.Beam:Play()
				task.wait(0.2)
				clone3.Attachment.Beam1.Attachment1 = clone2.Attachment
				clone3.Attachment.Beam2.Attachment1 = clone2.Attachment
				clone3.Attachment.Beam3.Attachment1 = clone2.Attachment
				game.TweenService:Create(clone3, TweenInfo.new(0.15), { CFrame = p18 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam1, TweenInfo.new(0.15), { Width1 = 3 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam2, TweenInfo.new(0.15), { Width1 = 30 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam3, TweenInfo.new(0.15), { Width1 = 3 }):Play()
				task.spawn(function()
					task.wait(0.15)
					clone3.Explode.PlaybackSpeed = math.random(1, 1.3)
					clone3.Explode:Play()

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v144 = workspace:Raycast(clone3.Position, clone3.CFrame.UpVector * -3, raycastParams)

					if v144 ~= nil then
						clone3.Rocks.Color = ColorSequence.new(v144.Instance.Color)
						clone3.Rocks.Enabled = true
					end

					beamHitRocks(clone3, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)
				end)
				task.wait(1)

				if clone:FindFirstChild("Attachment") then
					game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.3), { Width0 = 0 }):Play()
					game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.3), { Width0 = 0 }):Play()
					game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.3), { Width0 = 0 }):Play()
					game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.3), { Width1 = 0 }):Play()
					game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.3), { Width1 = 0 }):Play()
					game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.3), { Width1 = 0 }):Play()
					game.TweenService:Create(clone.PointLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
				end

				for _, v in pairs(clone:GetDescendants()) do
					if v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				task.wait(0.1)

				for _, v in pairs(clone2:GetDescendants()) do
					if v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				task.wait(0.2)

				for _, v in pairs(clone3:GetDescendants()) do
					if v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				game.TweenService:Create(clone3.Attachment.Beam1, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam2, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam3, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam1, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam2, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone3.Attachment.Beam3, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone3.PointLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
				game.TweenService:Create(clone.Beam, TweenInfo.new(0.15), { Volume = 0 }):Play()
				game.TweenService:Create(clone2.Beam, TweenInfo.new(0.15), { Volume = 0 }):Play()
				game.TweenService:Create(clone3.Beam, TweenInfo.new(0.15), { Volume = 0 }):Play()

				return
			end

			local clone = bpart1:Clone()

			clone.Parent = workspace.Effects
			clone.CFrame = cFrame
			game.Debris:AddItem(clone, 3)
			game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.15), { Width0 = 3 }):Play()
			game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.15), { Width0 = 30 }):Play()
			game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.15), { Width0 = 3 }):Play()

			local clone4 = v7:Clone()

			clone4.Parent = workspace.Effects
			clone4.CFrame = cFrame
			game.Debris:AddItem(clone4, 3)
			clone4.Beam:Play()
			clone.Attachment.Beam1.Attachment1 = clone4.Attachment
			clone.Attachment.Beam2.Attachment1 = clone4.Attachment
			clone.Attachment.Beam3.Attachment1 = clone4.Attachment
			task.spawn(function()
				beamHitRocks(clone, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v146 = workspace:Raycast(clone.Position, clone.CFrame.UpVector * -3, raycastParams)

				if v146 ~= nil then
					clone.Rocks.Color = ColorSequence.new(v146.Instance.Color)
					clone.Rocks.Enabled = true
				end

				clone.Explode.PlaybackSpeed = math.random(1, 1.3)
				clone.Explode:Play()
			end)
			task.wait(0.2)
			game.TweenService:Create(clone4, TweenInfo.new(0.15), { CFrame = p17 }):Play()
			game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.15), { Width1 = 3 }):Play()
			game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.15), { Width1 = 30 }):Play()
			game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.15), { Width1 = 3 }):Play()
			task.spawn(function()
				task.wait(0.15)
				beamHitRocks(clone4, 12, Vector3.new(2.2, 1, 2.2), Vector3.new(5.2, 2.2, 5.2), true)

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v148 = workspace:Raycast(clone4.Position, clone4.CFrame.UpVector * -3, raycastParams)

				if v148 ~= nil then
					clone4.Rocks.Color = ColorSequence.new(v148.Instance.Color)
					clone4.Rocks.Enabled = true
				end

				clone4.Explode.PlaybackSpeed = math.random(1, 1.3)
				clone4.Explode:Play()
			end)
			task.wait(1)

			if clone:FindFirstChild("Attachment") then
				game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.3), { Width0 = 0 }):Play()
				game.TweenService:Create(clone.Attachment.Beam1, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone.Attachment.Beam2, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone.Attachment.Beam3, TweenInfo.new(0.3), { Width1 = 0 }):Play()
				game.TweenService:Create(clone.PointLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
			end

			for _, v in pairs(clone:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					v.Enabled = false
				end
			end

			task.wait(0.1)

			for _, v in pairs(clone4:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					v.Enabled = false
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.Suns", result)
	end
end)

return true
