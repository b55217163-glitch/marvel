-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local tendrillSlam = game.ReplicatedStorage.Characters.DoctorStrange.Remotes.TendrillSlam
		local tweenService: TweenService = game:GetService("TweenService")
		local tendrillGrab = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.TendrillGrab
		local tendrillStrange = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.TendrillStrange
		local lowTendrillGrab = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.LowTendrillGrab
		local lowTendrillStrange = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.LowTendrillStrange
		local tweenService2: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock2(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v25 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v27 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v27, 0)
				local n2 = v25 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v30 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v30 then
					local instance = v30.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v36 = mathRandom(-180, 180)
					local v37 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v36, v37, mathRandom(-180, 180))
					part.Position = p1.Position

					local v38 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v38, { Position = v30.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v123 = tweenInfoNew(4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v123, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v124 = tweenInfoNew(4, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v124, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v43 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v45 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v45, 0)
				local n2 = v43 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v48 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v48 then
					local instance = v48.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v54 = mathRandom(-180, 180)
					local v55 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v54, v55, mathRandom(-180, 180))
					part.Position = p2.Position

					local v56 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v56, { Position = v48.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v129 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v129, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v130 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v130, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local wrap = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Wrap

		local function safeEmit(p3, p4)
			if p3 and p3:IsA("ParticleEmitter") then
				p3:Emit(p4)
			end
		end
		local function UseMove(player, parent)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			if workspace:Raycast(parent.HumanoidRootPart.Position, parent.HumanoidRootPart.CFrame.UpVector * 10, raycastParams) == nil then
				local v62 = animationService.GetTrack(player.Character.Humanoid, tendrillStrange)

				if not v62.IsPlaying then
					v62:Play(0.2)
				end
			else
				local v63 = animationService.GetTrack(player.Character.Humanoid, lowTendrillStrange)

				if not v63.IsPlaying then
					v63:Play(0.2)
				end
			end

			local raycastParams2 = RaycastParams.new()

			raycastParams2.FilterType = Enum.RaycastFilterType.Include
			raycastParams2.FilterDescendantsInstances = { workspace.Map }

			if workspace:Raycast(parent.HumanoidRootPart.Position, parent.HumanoidRootPart.CFrame.UpVector * 20, raycastParams2) == nil then
				animationService.GetTrack(parent.Humanoid, tendrillGrab):Play()

				if parent:FindFirstChild("Tendrill") then
					parent:FindFirstChild("Tendrill"):Destroy()
				end

				if parent.Head:FindFirstChild("LongScream") then
					parent.Head.LongScream:Play()
				end

				local clone = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Tendrill:Clone()

				clone.Parent = parent
				game.Debris:AddItem(clone, 6)

				local foundChild = clone:FindFirstChild("GroundPart", true)
				local foundChild2 = clone:FindFirstChild("MovingPart", true)

				if foundChild and foundChild2 then
					local v68 = clone:GetDescendants()
					local tweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Linear)

					for _, v in pairs(v68) do
						if v:IsA("Beam") then
							tweenService:Create(v, tweenInfo, { Width0 = 5, Width1 = 1 }):Play()
						end
					end

					tweenService:Create(foundChild.GroundBeam, tweenInfo, { Width0 = 30, Width1 = 1 }):Play()

					local motor6D: Motor6D = Instance.new("Motor6D", parent)

					motor6D.Part0 = parent.HumanoidRootPart
					motor6D.Part1 = foundChild

					local v73 = CFrame.Angles(0, 0, 0)

					motor6D.C0 = CFrame.new(0, -2, 0) * v73
					game.Debris:AddItem(motor6D, 3)

					local motor6D2: Motor6D = Instance.new("Motor6D", foundChild2)

					motor6D2.Part0 = foundChild
					motor6D2.Part1 = foundChild2
					v73 = CFrame.Angles(0, 0, 0)
					motor6D2.C0 = CFrame.new(0, -2, 0) * v73
					game.Debris:AddItem(motor6D2, 3)

					local light = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Light

					TestRock2(parent.HumanoidRootPart)

					local raycastParams3 = RaycastParams.new()

					raycastParams3.FilterType = Enum.RaycastFilterType.Include
					raycastParams3.FilterDescendantsInstances = { workspace.Map }
					v68 = workspace:Raycast(parent.HumanoidRootPart.Position, parent.HumanoidRootPart.CFrame.UpVector * -10, raycastParams3)

					if v68 == nil then
						foundChild.Open.PlaybackSpeed = math.random(1, 1.2)
						foundChild.Open:Play()
						foundChild.PortalOpen.PlaybackSpeed = math.random(1, 1.2)
						foundChild.PortalOpen:Play()
						task.wait(1)

						local tentacles = foundChild:FindFirstChild("Tentacles")

						if tentacles then
							tentacles.PlaybackSpeed = math.random(1, 1.2)
							tentacles:Play()
						else
							warn("Tentacles sound missing inside:", foundChild:GetFullName())
						end

						task.wait(0.3)

						local clone2 = wrap:Clone()

						clone2.Parent = parent.UpperTorso
						clone2:Emit(20)
						game.Debris:AddItem(clone2, 3)
						foundChild2.Wrap1:Play()
						foundChild2.Wrap2:Play()
						foundChild2.Wrap3:Play()
						task.wait(0.6)
						foundChild.Smash.PlaybackSpeed = math.random(1, 1.2)
						foundChild.Smash:Play()

						local explosion = foundChild:FindFirstChild("Explosion")

						if explosion then
							local flying = explosion:FindFirstChild("Flying")

							if flying and flying:IsA("ParticleEmitter") then
								flying:Emit(50)
							end

							local ring2 = explosion:FindFirstChild("Ring2")

							if ring2 then
								ring2.Size = NumberSequence.new(0, 60)
								ring2:Emit(1)
							end
						end

						if parent.Head:FindFirstChild("LongScream") then
							parent.Head.LongScream:Stop()
						end

						TestRock3(parent.HumanoidRootPart)

						local tweenInfo2 = TweenInfo.new(1, Enum.EasingStyle.Linear)
						local descendants = clone:GetDescendants()

						for _, v in pairs(descendants) do
							if v:IsA("Beam") then
								game.TweenService:Create(v, tweenInfo2, { Width0 = 0, Width1 = 0 }):Play()
							end
						end

						task.wait(1)

						return
					end

					if parent.Head:FindFirstChild("LongScream") then
						parent.Head.LongScream:Play()
					end

					local clone3 = light:Clone()

					clone3.Parent = workspace
					clone3.Position = v68.Position
					foundChild.Open.PlaybackSpeed = math.random(1, 1.2)
					foundChild.Open:Play()
					foundChild.PortalOpen.PlaybackSpeed = math.random(1, 1.2)
					foundChild.PortalOpen:Play()
					task.wait(1)

					local tentacles = foundChild:FindFirstChild("Tentacles")

					if tentacles then
						tentacles.PlaybackSpeed = math.random(1, 1.2)
						tentacles:Play()
					else
						warn("Tentacles sound missing inside:", foundChild:GetFullName())
					end

					task.wait(0.3)

					local clone4 = wrap:Clone()

					clone4.Parent = parent.UpperTorso
					clone4:Emit(20)
					game.Debris:AddItem(clone4, 3)
					foundChild2.Wrap1:Play()
					foundChild2.Wrap2:Play()
					foundChild2.Wrap3:Play()
					task.wait(0.6)
					foundChild.Smash.PlaybackSpeed = math.random(1, 1.2)
					foundChild.Smash:Play()

					if parent.Head:FindFirstChild("LongScream") then
						parent.Head.LongScream:Stop()
					end

					TestRock3(parent.HumanoidRootPart)
					clone3.Attachment.Aura.Enabled = false

					local tweenInfo3 = TweenInfo.new(1, Enum.EasingStyle.Linear)

					v73 = clone:GetDescendants()

					for _, v in pairs(v73) do
						if v:IsA("Beam") then
							game.TweenService:Create(v, tweenInfo3, { Width0 = 0, Width1 = 0 }):Play()
						end
					end

					game.TweenService:Create(clone3.PointLight, tweenInfo3, { Range = 0 }):Play()

					return
				end

				warn("Tendrill missing GroundPart or MovingPart:", clone:GetFullName())

				return
			end

			animationService.GetTrack(parent.Humanoid, lowTendrillGrab):Play()

			if parent:FindFirstChild("Tendrill") then
				parent:FindFirstChild("Tendrill"):Destroy()
			end

			local clone = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Tendrill:Clone()

			clone.Parent = parent
			game.Debris:AddItem(clone, 6)

			local foundChild = clone:FindFirstChild("GroundPart", true)
			local foundChild3 = clone:FindFirstChild("MovingPart", true)

			if foundChild and foundChild3 then
				local v95 = clone:GetDescendants()
				local tweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Linear)

				for _, v in pairs(v95) do
					if v:IsA("Beam") then
						tweenService:Create(v, tweenInfo, { Width0 = 5, Width1 = 1 }):Play()
					end
				end

				tweenService:Create(foundChild.GroundBeam, tweenInfo, { Width0 = 30, Width1 = 1 }):Play()

				local motor6D: Motor6D = Instance.new("Motor6D", parent)

				motor6D.Part0 = parent.HumanoidRootPart
				motor6D.Part1 = foundChild

				local v100 = CFrame.Angles(0, 0, 0)

				motor6D.C0 = CFrame.new(0, -2, 0) * v100
				game.Debris:AddItem(motor6D, 3)

				local motor6D3: Motor6D = Instance.new("Motor6D", foundChild3)

				motor6D3.Part0 = foundChild
				motor6D3.Part1 = foundChild3
				v100 = CFrame.Angles(0, 0, 0)
				motor6D3.C0 = CFrame.new(0, -2, 0) * v100
				game.Debris:AddItem(motor6D3, 3)

				local v102 = game.ReplicatedStorage.Characters.DoctorStrange.Fx.Light

				TestRock2(parent.HumanoidRootPart)

				local raycastParams4 = RaycastParams.new()

				raycastParams4.FilterType = Enum.RaycastFilterType.Include
				raycastParams4.FilterDescendantsInstances = { workspace.Map }
				v95 = workspace:Raycast(parent.HumanoidRootPart.Position, parent.HumanoidRootPart.CFrame.UpVector * -10, raycastParams4)

				if v95 == nil then
					foundChild.Open.PlaybackSpeed = math.random(1, 1.2)
					foundChild.Open:Play()
					foundChild.PortalOpen.PlaybackSpeed = math.random(1, 1.2)
					foundChild.PortalOpen:Play()
					task.wait(1)

					local tentacles = foundChild:FindFirstChild("Tentacles")

					if tentacles then
						tentacles.PlaybackSpeed = math.random(1, 1.2)
						tentacles:Play()
					else
						warn("Tentacles sound missing inside:", foundChild:GetFullName())
					end

					task.wait(0.3)

					local clone5 = wrap:Clone()

					clone5.Parent = parent.UpperTorso
					clone5:Emit(20)
					game.Debris:AddItem(clone5, 3)
					foundChild3.Wrap1:Play()
					foundChild3.Wrap2:Play()
					foundChild3.Wrap3:Play()
					task.wait(0.6)
					foundChild.Smash.PlaybackSpeed = math.random(1, 1.2)
					foundChild.Smash:Play()

					local explosion = foundChild:FindFirstChild("Explosion")

					if explosion then
						local flying = explosion:FindFirstChild("Flying")

						if flying and flying:IsA("ParticleEmitter") then
							flying:Emit(50)
						end

						local ring2 = explosion:FindFirstChild("Ring2")

						if ring2 then
							ring2.Size = NumberSequence.new(0, 60)
							ring2:Emit(1)
						end
					end

					TestRock3(parent.HumanoidRootPart)

					local tweenInfo4 = TweenInfo.new(1, Enum.EasingStyle.Linear)
					local v110 = clone:GetDescendants()

					for _, v in pairs(v110) do
						if v:IsA("Beam") then
							game.TweenService:Create(v, tweenInfo4, { Width0 = 0, Width1 = 0 }):Play()
						end
					end

					task.wait(1)

					return
				end

				local clone6 = v102:Clone()

				clone6.Parent = workspace
				clone6.Position = v95.Position
				foundChild.Open.PlaybackSpeed = math.random(1, 1.2)
				foundChild.Open:Play()
				foundChild.PortalOpen.PlaybackSpeed = math.random(1, 1.2)
				foundChild.PortalOpen:Play()
				task.wait(1)

				local tentacles = foundChild:FindFirstChild("Tentacles")

				if tentacles then
					tentacles.PlaybackSpeed = math.random(1, 1.2)
					tentacles:Play()
				else
					warn("Tentacles sound missing inside:", foundChild:GetFullName())
				end

				task.wait(0.3)

				local clone7 = wrap:Clone()

				clone7.Parent = parent.UpperTorso
				clone7:Emit(20)
				game.Debris:AddItem(clone7, 3)
				foundChild3.Wrap1:Play()
				foundChild3.Wrap2:Play()
				foundChild3.Wrap3:Play()
				task.wait(0.6)
				foundChild.Smash.PlaybackSpeed = math.random(1, 1.2)
				foundChild.Smash:Play()
				TestRock3(parent.HumanoidRootPart)
				clone6.Attachment.Aura.Enabled = false

				local tweenInfo5 = TweenInfo.new(1, Enum.EasingStyle.Linear)

				v100 = clone:GetDescendants()

				for _, v in pairs(v100) do
					if v:IsA("Beam") then
						game.TweenService:Create(v, tweenInfo5, { Width0 = 0, Width1 = 0 }):Play()
					end
				end

				game.TweenService:Create(clone6.PointLight, tweenInfo5, { Range = 0 }):Play()

				return
			end

			warn("Tendrill missing GroundPart or MovingPart:", clone:GetFullName())
		end

		tendrillSlam.OnClientEvent:Connect(function(p7, p8)
			UseMove(p7, p8)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.TendrillHitEffect", result)
	end
end)

return true
