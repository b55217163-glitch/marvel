-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)

		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local push = replicatedStorage.Characters.DoctorStrange.AnimationsExtra.Push
		local pushHit = replicatedStorage.Characters.DoctorStrange.AnimationsExtra.PushHit
		local soulAnimation = replicatedStorage.Characters.DoctorStrange.AnimationsExtra.SoulAnimation
		local soulAnimation2 = replicatedStorage.Characters.DoctorStrange.AnimationsExtra.SoulAnimation2
		local blackLines = replicatedStorage.Characters.MoonKnight.Other.BlackLines
		local soulPushScreen = replicatedStorage.Characters.DoctorStrange.Fx.SoulPushScreen

		local function applyGhostTransparency(p1, p2)
			for _, v in ipairs(p1:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					v.Transparency = math.clamp(v.Transparency + p2, 0, 1)
				end
			end
		end
		local function disableNoisyStuff(p3)
			if not p3:IsA("ParticleEmitter") and not p3:IsA("Trail") and not p3:IsA("Beam") then
				if not p3:IsA("PointLight") and not p3:IsA("SpotLight") and not p3:IsA("SurfaceLight") then
					if not p3:IsA("BillboardGui") and not p3:IsA("SurfaceGui") then
						if p3:IsA("Sound") then
							p3:Stop()
							p3.Playing = false
							p3.Volume = 0

							return
						end

						if p3:IsA("Constraint") then
							p3.Enabled = false

							return
						end

						if p3:IsA("BodyMover") then
							p3:Destroy()

							return
						end

						if not p3:IsA("AlignPosition") and not p3:IsA("AlignOrientation") then
							if not p3:IsA("Script") and not p3:IsA("LocalScript") then
								return
							end

							p3.Disabled = true

							return
						end

						p3.Enabled = false

						return
					end

					p3.Enabled = false

					return
				end

				p3.Enabled = false

				return
			end

			p3.Enabled = false
		end
		local function hideNameplates(character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if humanoid then
				humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			end
		end
		local function prepGhostClone(character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if humanoid then
				humanoid.EvaluateStateMachine = false
				humanoid.PlatformStand = true
				humanoid.AutoRotate = false
				humanoid.WalkSpeed = 0
				humanoid.JumpPower = 0
				humanoid:ChangeState(Enum.HumanoidStateType.Physics)
			end

			for _, v in ipairs(character:GetDescendants()) do
				disableNoisyStuff(v)

				if v:IsA("BasePart") then
					v.CanCollide = false
					v.CanQuery = false
					v.CanTouch = false
					v.Massless = true
					v.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
				end
			end
		end
		local function tweenTransparencyToOne(p6, p7)
			local tweenInfo = TweenInfo.new(p7, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

			for _, v in ipairs(p6:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
				end
			end
		end
		local function setTransparency(p8, transparency)
			for _, v in ipairs(p8:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					v.Transparency = transparency
				end
			end
		end

		setTransparency = function(p10)
			return p10:FindFirstChild("HumanoidRootPart") or p10.PrimaryPart
		end

		local function GhostClone(p11, p12)
			if not p11 or not p11:IsA("Model") then
				return nil
			end

			local t1 = p12 or {}
			local parent = t1.parent or workspace
			local v51 = t1.fadeOut or 0.5
			local v52 = t1.life or 2.1
			local v53 = t1.ghostAmount or 0.7
			local clone = p11:Clone()

			clone.Name = p11.Name .. "_SoulGhost"
			clone.Parent = parent
			pcall(function()
				clone:PivotTo(p11:GetPivot())
			end)

			local humanoid = clone:FindFirstChildOfClass("Humanoid")

			if humanoid then
				humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			end

			prepGhostClone(clone)
			applyGhostTransparency(clone, v53)

			local taskDelay = task.delay
			local v57 = math.max(0, v52 - v51)

			taskDelay(v57, function()
				tweenTransparencyToOne(clone, v51)
			end)
			debris:AddItem(clone, v52 + 0.05)

			return clone
		end
		local function weldTo(part0, part1, p15, parent, p17)
			if part0 and part1 then
				local weld: Weld = Instance.new("Weld")

				weld.Part0 = part0
				weld.Part1 = part1
				weld.C0 = p15 or CFrame.new()
				weld.Parent = parent

				if p17 then
					debris:AddItem(weld, p17)
				end

				return weld
			end

			return nil
		end
		local function tryPlayAnim(character, p19)
			if not p19 then
				return
			end

			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local v67 = humanoid:FindFirstChildOfClass("Animator") or humanoid:WaitForChild("Animator", 0.1)

			if not v67 then
				return
			end

			local ok2, result2 = pcall(function()
				return animationService.GetTrack(v67, p19)
			end)

			if ok2 and result2 then
				result2:Play()
			end
		end
		local function Soul2sys(p20, p21)
			task.spawn(function()
				local v96 = GhostClone(p20, {
					life = 2.1,
					fadeIn = 0.08,
					fadeOut = 0.5,
					startTransparent = 1,
					endTransparent = 1
				})

				if not v96 then
					return
				end

				local part1 = v96:FindFirstChild("HumanoidRootPart") or v96.PrimaryPart

				if not part1 then
					return
				end

				tryPlayAnim(v96, soulAnimation2)

				local fakeUpperTorso = p21:FindFirstChild("FakeUpperTorso")

				if fakeUpperTorso and fakeUpperTorso:IsA("BasePart") then
					local parent = p21

					if fakeUpperTorso and part1 then
						local weld: Weld = Instance.new("Weld")

						weld.Part0 = fakeUpperTorso
						weld.Part1 = part1
						weld.C0 = CFrame.new(0, 0, 0) or CFrame.new()
						weld.Parent = parent
						debris:AddItem(weld, 2.6)
					end
				end

				task.wait(1.3)
				tweenTransparencyToOne(v96, 0.5, 1)
			end)
		end
		local function Soul1Sys(p22, parent)
			local v74 = GhostClone(p22, {
				life = 2.1,
				fadeIn = 0.08,
				fadeOut = 0.5,
				startTransparent = 1,
				endTransparent = 1
			})

			if not v74 then
				return
			end

			local part1 = v74:FindFirstChild("HumanoidRootPart") or v74.PrimaryPart

			if not part1 then
				return
			end

			tryPlayAnim(v74, soulAnimation)

			local glowFake = parent:FindFirstChild("GlowFake")

			if glowFake and glowFake:IsA("BasePart") then
				if not glowFake then
					return
				end

				if not part1 then
					return
				end

				local weld: Weld = Instance.new("Weld")

				weld.Part0 = glowFake
				weld.Part1 = part1
				weld.C0 = CFrame.new(0, 0, 0) or CFrame.new()
				weld.Parent = parent
				debris:AddItem(weld, 2.6)

				return
			end
		end
		local function Soul1SysMoon(p24, p25)
			for i = 1, 3 do
				task.spawn(function()
					local v101 = GhostClone(p24, {
						life = 2.1,
						fadeIn = 0.06,
						fadeOut = 0.2,
						startTransparent = 1,
						endTransparent = 1
					})

					if not v101 then
						return
					end

					local part1 = v101:FindFirstChild("HumanoidRootPart") or v101.PrimaryPart

					if not part1 then
						return
					end

					tryPlayAnim(v101, soulAnimation)

					local glowFake = p25:FindFirstChild("GlowFake")

					if glowFake and glowFake:IsA("BasePart") then
						local cFrame = CFrame.new(0, 0, (i - 1) * 4)
						local parent = p25

						if glowFake and part1 then
							local weld: Weld = Instance.new("Weld")

							weld.Part0 = glowFake
							weld.Part1 = part1
							weld.C0 = cFrame or CFrame.new()
							weld.Parent = parent
							debris:AddItem(weld, 2.6)
						end
					end

					task.wait(1.8)
					tweenTransparencyToOne(v101, 0.2, 1)
				end)
			end
		end
		local function playScream(p26)
			local head = p26:FindFirstChild("Head")
			local longScream = head and head:FindFirstChild("LongScream")

			if not longScream or not longScream:IsA("Sound") then
				return
			end

			local clone = longScream:Clone()

			clone.Parent = head
			clone.Volume = 1
			clone.TimePosition = 0

			local echoSoundEffect: EchoSoundEffect = Instance.new("EchoSoundEffect")

			echoSoundEffect.Delay = 0.12
			echoSoundEffect.Feedback = 0.45
			echoSoundEffect.DryLevel = 0.5
			echoSoundEffect.WetLevel = 1
			echoSoundEffect.Parent = clone

			local reverbSoundEffect: ReverbSoundEffect = Instance.new("ReverbSoundEffect")

			reverbSoundEffect.DecayTime = 2.5
			reverbSoundEffect.Density = 0.9
			reverbSoundEffect.Diffusion = 0.7
			reverbSoundEffect.DryLevel = 0.6
			reverbSoundEffect.WetLevel = 0.9
			reverbSoundEffect.Parent = clone
			clone:Play()
			task.delay(1, function()
				local v107: Tween = tweenService:Create(clone, TweenInfo.new(0.4), { Volume = 0 })

				v107:Play()
				v107.Completed:Connect(function()
					clone:Stop()
					clone:Destroy()
				end)
			end)
		end

		replicatedStorage.Characters.DoctorStrange.Remotes.CounterPush.OnClientEvent:Connect(function(character, player)
			if typeof(character) ~= "Instance" or not character:IsA("Model") then
			elseif typeof(player) == "Instance" then
				local Character = player.Character

				if not Character or not Character:IsA("Model") then
					return
				end

				local humanoid = Character:FindFirstChildOfClass("Humanoid")

				if not humanoid then
					return
				end

				local v91 = animationService.GetTrack(humanoid, push)

				if not character:FindFirstChild("MoonKnight") then
					task.spawn(function()
						local v108 = GhostClone(character, {
							life = 2.1,
							fadeIn = 0.08,
							fadeOut = 0.5,
							startTransparent = 1,
							endTransparent = 1
						})

						if not v108 then
							return
						end

						local part1 = v108:FindFirstChild("HumanoidRootPart") or v108.PrimaryPart

						if not part1 then
							return
						end

						tryPlayAnim(v108, soulAnimation2)

						local fakeUpperTorso = Character:FindFirstChild("FakeUpperTorso")

						if fakeUpperTorso and fakeUpperTorso:IsA("BasePart") then
							local parent = Character

							if fakeUpperTorso and part1 then
								local weld: Weld = Instance.new("Weld")

								weld.Part0 = fakeUpperTorso
								weld.Part1 = part1
								weld.C0 = CFrame.new(0, 0, 0) or CFrame.new()
								weld.Parent = parent
								debris:AddItem(weld, 2.6)
							end
						end

						task.wait(1.3)
						tweenTransparencyToOne(v108, 0.5, 1)
					end)
				end

				if character:FindFirstChild("MoonKnight") then
					Soul1SysMoon(character, Character)
				else
					Soul1Sys(character, Character)
				end

				playScream(character)

				local humanoid2 = character:FindFirstChildOfClass("Humanoid")

				if humanoid2 and humanoid2:FindFirstChildOfClass("Animator") then
					animationService.GetTrack(humanoid2, pushHit):Play()
				end

				v91:Play()

				local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

				if humanoidRootPart and humanoidRootPart:FindFirstChild("SoulPushOut") then
					humanoidRootPart.SoulPushOut:Play()
				end

				task.wait(0.2)

				local fakeUpperTorso = Character:FindFirstChild("FakeUpperTorso")
				local v95 = fakeUpperTorso

				if v95 then
					v95 = fakeUpperTorso:FindFirstChild("FinalAt")
				end

				if v95 then
					if v95:FindFirstChild("sh1") then
						v95.sh1:Emit(1)
					end

					if v95:FindFirstChild("sh3") then
						v95.sh3:Emit(1)
					end

					if v95:FindFirstChild("Flare") then
						v95.Flare:Emit(1)
					end

					if v95:FindFirstChild("SparksCircle") then
						v95.SparksCircle:Emit(30)
					end
				end

				task.wait(1.8)

				if v95 then
					if v95:FindFirstChild("shIn1") then
						v95.shIn1:Emit(1)
					end

					if v95:FindFirstChild("ShIn2") then
						v95.ShIn2:Emit(1)
					end

					if v95:FindFirstChild("Flare") then
						v95.Flare:Emit(1)
					end
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.SoulPushHit", result)
	end
end)

return true
