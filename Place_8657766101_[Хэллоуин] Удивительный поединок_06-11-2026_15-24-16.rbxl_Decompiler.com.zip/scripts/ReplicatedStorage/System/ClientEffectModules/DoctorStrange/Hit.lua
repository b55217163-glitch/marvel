-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local knifeHitSound = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.KnifeHitSound
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.DoctorStrange.Remotes.PortalBullets.OnClientEvent:Connect(function(p1, parent, _)
			animationService.GetTrack(p1.Humanoid, hit1)
			animationService.GetTrack(p1.Humanoid, hit2)

			local clone = knifeHitSound:Clone()

			clone.Parent = p1.HumanoidRootPart
			clone.PlaybackSpeed = math.random(1, 1.5)
			clone:Play()
			game.Debris:AddItem(clone, 2)

			local clone2 = neckExplode:Clone()

			clone2.Parent = p1.UpperTorso
			clone2.Bl1:Emit(2)
			clone2.Bl2:Emit(3)

			for _ = 1, 2 do
				local randomNumber = math.random(4, 8)
				local clone3 = bloodDrip:Clone()

				clone3.Parent = workspace

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

				clone3.Parent = parent
				clone3.CFrame = p1.UpperTorso.CFrame
				clone3.LocalScript.Disabled = false
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber2 = math.random(-2, 2)
				local randomNumber3 = math.random(-2, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
				game.Debris:AddItem(clone3, 3)
				game.Debris:AddItem(bodyVelocity, 0.15)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.Hit", result)
	end
end)

return true
