-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.FinisherHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt

		game.ReplicatedStorage.Characters.DoctorStrange.Remotes.HeavyHitRemote.OnClientEvent:Connect(function(p1)
			local clone = hitAt:Clone()

			clone.Parent = p1.HumanoidRootPart
			clone.Sparks:Emit(8)
			clone.SparksCircle:Emit(15)
			clone.Shock:Emit(2)
			clone.ShockwaveMiddle:Emit(1)
			game.Debris:AddItem(clone, 1)

			if script:FindFirstChild("Stab") then
				local clone2 = script.Stab:Clone()

				clone2.Parent = p1.HumanoidRootPart
				clone2:Play()
				game.Debris:AddItem(clone2, 3)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.HeavyHit", result)
	end
end)

return true
