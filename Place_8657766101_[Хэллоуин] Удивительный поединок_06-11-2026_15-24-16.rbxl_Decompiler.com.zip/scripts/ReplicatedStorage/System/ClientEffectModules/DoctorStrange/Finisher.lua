-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.DoctorStrange.AnimationsExtra.Finisher
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.DoctorStrange.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			p2:WaitForChild("Humanoid", 5)

			local clone = Character:Clone()

			clone.HumanoidRootPart.Anchored = false

			local clone2 = Character:Clone()

			clone2.HumanoidRootPart.Anchored = false

			local clone3 = Character:Clone()

			clone3.HumanoidRootPart.Anchored = false

			local clone4 = Character:Clone()

			clone4.HumanoidRootPart.Anchored = false

			local clone5 = Character:Clone()

			clone5.HumanoidRootPart.Anchored = false

			local clone6 = Character:Clone()

			clone6.HumanoidRootPart.Anchored = false

			local clone7 = Character:Clone()

			clone7.HumanoidRootPart.Anchored = false

			local clone8 = Character:Clone()

			clone8.HumanoidRootPart.Anchored = false

			local clone9 = Character:Clone()

			clone9.HumanoidRootPart.Anchored = false
			clone.Parent = workspace
			clone2.Parent = workspace
			clone3.Parent = workspace
			clone4.Parent = workspace
			clone5.Parent = workspace
			clone6.Parent = workspace
			clone7.Parent = workspace
			clone8.Parent = workspace
			clone9.Parent = workspace

			local v22 = animationService.LoadFresh(humanoid, finisher)

			v22.KeyframeReached:Connect(function(p3)
				if p3 == "ClonePosition" then
					local weld: Weld = Instance.new("Weld", Character)

					weld.Part0 = Character.ExtraHR1
					weld.Part1 = clone.HumanoidRootPart

					local v25 = CFrame.Angles(0, 0, 0)

					weld.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld, 4)

					local weld2: Weld = Instance.new("Weld", Character)

					weld2.Part0 = Character.ExtraHR2
					weld2.Part1 = clone2.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld2.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld2, 4)

					local weld3: Weld = Instance.new("Weld", Character)

					weld3.Part0 = Character.ExtraHR3
					weld3.Part1 = clone3.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld3.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld3, 4)

					local weld4: Weld = Instance.new("Weld", Character)

					weld4.Part0 = Character.ExtraHR4
					weld4.Part1 = clone4.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld4.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld4, 4)

					local weld5: Weld = Instance.new("Weld", Character)

					weld5.Part0 = Character.ExtraHR5
					weld5.Part1 = clone5.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld5.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld5, 4)

					local weld6: Weld = Instance.new("Weld", Character)

					weld6.Part0 = Character.ExtraHR6
					weld6.Part1 = clone6.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld6.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld6, 4)

					local weld7: Weld = Instance.new("Weld", Character)

					weld7.Part0 = Character.ExtraHR7
					weld7.Part1 = clone7.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld7.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld7, 4)

					local weld8: Weld = Instance.new("Weld", Character)

					weld8.Part0 = Character.ExtraHR8
					weld8.Part1 = clone8.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld8.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld8, 4)

					local weld9: Weld = Instance.new("Weld", Character)

					weld9.Part0 = Character.ExtraHR9
					weld9.Part1 = clone9.HumanoidRootPart
					v25 = CFrame.Angles(0, 0, 0)
					weld9.C0 = CFrame.new(0, 0, 0) * v25
					game.Debris:AddItem(weld9, 4)
				end
			end)
			v22:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DoctorStrange.Finisher", result)
	end
end)

return true
