-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local players: Players = game:GetService("Players")
		local runService: RunService = game:GetService("RunService")
		local collectionService: CollectionService = game:GetService("CollectionService")
		local workspace: Workspace = game:GetService("Workspace")
		local LocalPlayer: Player = players.LocalPlayer
		local rustleSound: Instance = script:WaitForChild("RustleSound")
		local t1: {[any]: any} = {}
		local t2: {[any]: any} = {}
		local t3: {[any]: any} = {}
		local t4: {[any]: any} = {}

		local function isHumanoidHit(p1)
			local character = p1:FindFirstAncestorOfClass("Model")

			if not character then
				return false
			end

			return character:FindFirstChildOfClass("Humanoid") ~= nil
		end
		local function getLeavesEmitterRuntime(p2)
			local foundChild = p2:FindFirstChild("Leaves", true)

			if foundChild and foundChild:IsA("ParticleEmitter") then
				return foundChild
			end

			if foundChild then
				for _, v in ipairs(foundChild:GetDescendants()) do
					if v:IsA("ParticleEmitter") then
						return v
					end
				end
			end

			for _, v in ipairs(p2:GetDescendants()) do
				if v:IsA("ParticleEmitter") then
					return v
				end
			end

			return nil
		end
		local function emitBush(p3)
			local v38 = os.clock()

			if v38 - p3.lastEmit < 0.35 then
				return
			end

			p3.lastEmit = v38

			local part = p3.part

			if not part or not part.Parent then
				return
			end

			local v40 = getLeavesEmitterRuntime(part)

			if v40 then
				v40:Emit(math.random(8, 15))
			end

			v40 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
			rustleSound.Volume = math.clamp((v40 and v40.AssemblyLinearVelocity.Magnitude or 0) / 22, 0, 1) * 0.7 + 0.5
			rustleSound.PlaybackSpeed = math.random(90, 110) / 100
			rustleSound.TimePosition = 0

			if not rustleSound.IsPlaying then
				rustleSound:Play()
			end
		end
		local function isSafeBushPart(p4)
			if not p4.Parent then
				return false
			end

			if not p4.Anchored then
				return false
			end

			if p4.Size.X > 40 or p4.Size.Y > 40 or p4.Size.Z > 40 then
				return false
			end

			if string.lower(p4.Name) == "baseplate" or string.lower(p4.Name) == "wall" or string.lower(p4.Name) == "floor" or string.lower(p4.Name) == "roof" or string.lower(p4.Name) == "terrain" or string.lower(p4.Name) == "ground" or string.lower(p4.Name) == "road" then
				return false
			end

			return true
		end
		local function addBush(p5)
			if t2[p5] then
				return
			end

			if not p5:IsA("BasePart") then
				return
			end

			if not isSafeBushPart(p5) then
				return
			end

			p5.CanTouch = true
			p5.CanQuery = true

			local v43 = p5.Position
			local cFrame = p5.CFrame
			local n1 = v43.X * 0.13
			local randomNumber = math.random()
			local n2 = v43.Z * 0.13
			local randomNumber2 = math.random()
			local t5: {[any]: any} = {
				lastEmit = -1000000000,
				conn = nil,
				part = p5,
				baseCF = cFrame,
				seedX = n1 + randomNumber * 1000,
				seedZ = n2 + randomNumber2 * 1000
			}

			t5.conn = p5.Touched:Connect(function(p6)
				local character = p6:FindFirstAncestorOfClass("Model")

				if not (if not character then false else character:FindFirstChildOfClass("Humanoid") ~= nil) then
					return
				end

				emitBush(t5)
			end)
			table.insert(t1, t5)
			t2[p5] = #t1
		end
		local function removeBush(p7)
			local v51 = t2[p7]

			if not v51 then
				return
			end

			local v52 = t1[v51]

			if v52 and v52.conn then
				v52.conn:Disconnect()
			end

			v52 = t1[#t1]
			t1[v51] = v52
			t1[#t1] = nil
			t2[p7] = nil

			if v52 and p7 ~= v52.part then
				t2[v52.part] = v51
			end
		end
		local function looksLikeProjectile(p8)
			if not p8.Parent then
				return false
			end

			local lowerText = string.lower(p8.Name)
			local u55: boolean = true

			if lowerText:find("hitbox") == nil then
				u55 = true

				if lowerText:find("hb") == nil then
					u55 = true

					if lowerText:find("bullet") == nil then
						u55 = true

						if lowerText:find("proj") == nil then
							u55 = true

							if lowerText:find("project") == nil then
								u55 = lowerText:find("effect") ~= nil
							end
						end
					end
				end
			end

			local u56 = false

			if p8:FindFirstChild("Sfx", true) then
				u56 = true
			else
				for _, v in ipairs(p8:GetDescendants()) do
					if v:IsA("Sound") then
						u56 = true

						break
					end
				end
			end

			if not u55 and not u56 then
				return false
			end

			local Character: Model = LocalPlayer.Character

			u56 = Character

			if u56 then
				u56 = p8:IsDescendantOf(Character)
			end

			if not u56 then
				if not p8.Anchored then
					return false
				end
			elseif p8.Name == "HumanoidRootPart" or p8.Name == "Head" then
				return false
			end

			return true
		end
		local function addTrigger(p9)
			if t4[p9] then
				return
			end

			if #t3 >= 200 then
				return
			end

			if not looksLikeProjectile(p9) then
				return
			end

			p9.CanQuery = true

			local cFrame = p9.CFrame
			local v62 = os.clock()

			table.insert(t3, { part = p9, lastCF = cFrame, lastSeen = v62 })
			t4[p9] = #t3
		end
		local function removeTrigger(p10)
			local v64 = t4[p10]

			if not v64 then
				return
			end

			local v65 = t3[#t3]

			t3[v64] = v65
			t3[#t3] = nil
			t4[p10] = nil

			if v65 and p10 ~= v65.part then
				t4[v65.part] = v64
			end
		end

		workspace.DescendantAdded:Connect(function(descendant: Instance)
			if descendant:IsA("BasePart") then
				task.defer(function()
					if descendant.Parent then
						addTrigger(descendant)
					end
				end)
			end
		end)

		for _, v in ipairs(workspace:GetDescendants()) do
			if v:IsA("BasePart") then
				addTrigger(v)
			end
		end

		for _, v in ipairs(collectionService:GetTagged("Bush")) do
			if v:IsA("BasePart") then
				addBush(v)
			end
		end

		collectionService:GetInstanceAddedSignal("Bush"):Connect(function(p12)
			if p12:IsA("BasePart") then
				addBush(p12)
			end
		end)
		collectionService:GetInstanceRemovedSignal("Bush"):Connect(function(p13)
			if p13:IsA("BasePart") then
				local v69 = t2[p13]

				if not v69 then
					return
				end

				local v70 = t1[v69]

				if v70 and v70.conn then
					v70.conn:Disconnect()
				end

				v70 = t1[#t1]
				t1[v69] = v70
				t1[#t1] = nil
				t2[p13] = nil

				if v70 and p13 ~= v70.part then
					t2[v70.part] = v69
				end

				return
			end
		end)

		local v26 = OverlapParams.new()

		v26.FilterType = Enum.RaycastFilterType.Exclude
		v26.MaxParts = 20

		local n1: number = 0
		local v28 = os.clock()

		runService.RenderStepped:Connect(function(deltaTime: number)
			local v72 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
			local v73 = v72 and v72.Position or nil

			v72 = (os.clock() - v28) * 0.7

			for i = 1, #t1 do
				local v75 = t1[i]
				local part = v75.part

				if part.Parent and (not v73 or not ((part.Position - v73).Magnitude > 150)) and isSafeBushPart(part) then
					local v77 = math.noise(v75.seedX, v72, 0)
					local v78 = math.noise(v75.seedZ, 0, v72)
					local baseCF = v75.baseCF
					local cFrame = CFrame.new(v77 * 0.08, 0, v78 * 0.08)
					local v81 = CFrame.Angles(v77 * 0.12217304763960307, 0, v78 * 0.12217304763960307)

					part.CFrame = baseCF * cFrame * v81
				end
			end

			n1 += deltaTime

			if n1 < 0.08 then
				return
			end

			n1 = 0
			v73 = os.clock()

			for i = #t3, 1, -1 do
				local v83 = t3[i]
				local v84 = v83.part

				if v84.Parent and not (v73 - v83.lastSeen > 6) then
					local magnitude = (v84.Position - v83.lastCF.Position).Magnitude

					v83.lastCF = v84.CFrame

					if magnitude >= 0.35 then
						v83.lastSeen = v73

						if #t1 ~= 0 then
							v26.FilterDescendantsInstances = { v84 }

							local v86 = workspace:GetPartBoundsInBox(v84.CFrame, v84.Size, v26)

							for _, v in ipairs(v86) do
								local v89 = t2[v]

								if v89 then
									local v90 = t1[v89]

									if v90 then
										emitBush(v90)
									end
								end
							end
						end
					end
				else
					local v91 = t4[v84]

					if v91 then
						local v92 = t3[#t3]

						t3[v91] = v92
						t3[#t3] = nil
						t4[v84] = nil

						if v92 and v84 ~= v92.part then
							t4[v92.part] = v91
						end
					end
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffects2Module] failed:", "Map.BushController", result)
	end
end)

return true
