-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.5)

		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local bloodDrip = game.ReplicatedFirst.Effects.Blood.Fx.BloodDrip
		local bloodSplash = game.ReplicatedFirst.Effects.Blood.Fx.BloodSplash
		local bloodSmoke = game.ReplicatedFirst.Effects.Blood.Fx.BloodSmoke
		local gorePart = game.ReplicatedFirst.Effects.Blood.Fx.GorePart
		local bodyExp = game.ReplicatedFirst.Effects.Blood.Fx.BodyExp
		local finalHit = game.ReplicatedFirst.Effects.Blood.Fx.FinalHit
		local bodyPartSfx = game.ReplicatedFirst.Effects.Blood.Fx.BodyPartSfx

		local function watchBodyPartGroundHits(p1, p2)
			for _, v in ipairs(p1) do
				if v and v.Parent then
					local u19: boolean = false
					local connection = nil

					connection = v.Touched:Connect(function(p3)
						if not not u19 or not v or not v.Parent then
							return
						end

						local v69 = p2()

						if not v69 or not p3 or not p3:IsDescendantOf(v69) then
							return
						end

						if not p3.Anchored or not p3.CanCollide then
							return
						end

						u19 = true

						local v70 = v

						v70.AssemblyLinearVelocity = v70.AssemblyLinearVelocity * 0.15
						v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)

						for _, iterValue in ipairs(v:GetChildren()) do
							if iterValue:IsA("BodyMover") or iterValue:IsA("LinearVelocity") then
								iterValue:Destroy()
							end
						end

						local clone = bodyPartSfx:Clone()

						clone.Parent = v
						clone.PlaybackSpeed = math.random(95, 110) / 100
						clone:Play()
						game.Debris:AddItem(clone, 4)

						if connection then
							connection:Disconnect()
							connection = nil
						end
					end)
					v.Destroying:Connect(function()
						if connection then
							connection:Disconnect()
							connection = nil
						end
					end)
				end
			end
		end
		local function Damage(parent, p5)
			local humanoidRootPart = parent:FindFirstChild("HumanoidRootPart")

			if humanoidRootPart then
				humanoidRootPart:Destroy()
			end

			local head = parent:WaitForChild("Head")
			local rightUpperArm = parent:WaitForChild("RightUpperArm")
			local rightUpperLeg = parent:WaitForChild("RightUpperLeg")
			local leftUpperLeg = parent:WaitForChild("LeftUpperLeg")
			local leftUpperArm = parent:WaitForChild("LeftUpperArm")

			watchBodyPartGroundHits({
				head,
				rightUpperArm,
				rightUpperLeg,
				leftUpperLeg,
				leftUpperArm,
				parent:WaitForChild("UpperTorso")
			}, function()
				return workspace:FindFirstChild("Map")
			end)

			local animator = p5:FindFirstChildOfClass("Animator")

			if animator then
				local animationTracks = animator:GetPlayingAnimationTracks()

				for _, v in pairs(animationTracks) do
					v:Stop()
				end
			end

			local v33 = parent:GetDescendants()

			for _, v in pairs(v33) do
				if (v.Name == "RightHand" or v.Name == "RightUpperArm" or v.Name == "RightLowerArm" or v.Name == "LeftHand" or v.Name == "LeftUpperArm" or v.Name == "LeftLowerArm" or v.Name == "RightUpperLeg" or v.Name == "RightLowerLeg" or v.Name == "RightFoot" or v.Name == "LeftUpperLeg" or v.Name == "LeftLowerLeg" or v.Name == "LeftFoot" or v.Name == "UpperTorso" or v.Name == "LowerTorso" or v.Name == "Head") and (not not v:IsA("BasePart") or not not v:IsA("Part") or not not v:IsA("MeshPart")) then
					v.CanCollide = false
					v.Massless = true
					v.CanTouch = false
				end
			end

			v33 = parent:GetDescendants()

			for _, v in pairs(v33) do
				if v:IsA("LocalScript") then
					v.Disabled = true
				end
			end

			v33 = parent:GetDescendants()

			for _, v in pairs(v33) do
				if (v.Name == "RightHand" or v.Name == "RightUpperArm" or v.Name == "RightLowerArm" or v.Name == "LeftHand" or v.Name == "LeftUpperArm" or v.Name == "LeftLowerArm" or v.Name == "RightUpperLeg" or v.Name == "RightLowerLeg" or v.Name == "RightFoot" or v.Name == "LeftUpperLeg" or v.Name == "LeftLowerLeg" or v.Name == "LeftFoot" or v.Name == "UpperTorso" or v.Name == "LowerTorso" or v.Name == "Head") and (not not v:IsA("BasePart") or not not v:IsA("Part") or not not v:IsA("MeshPart")) then
					v.CanCollide = false
					v.Massless = true

					local part: Part = Instance.new("Part")

					part.Parent = parent
					part.Transparency = 1
					part.CanCollide = true
					part.Size = v.Size
					part.CFrame = v.CFrame

					local weld: Weld = Instance.new("Weld", parent)

					weld.Part0 = v
					weld.Part1 = part

					local v42 = CFrame.Angles(0, 0, 0)

					weld.C0 = CFrame.new(0, 0, 0) * v42

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", part)

					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(3, 20)
					local randomNumber2 = math.random(-2, 2)
					local randomNumber3 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
					game.Debris:AddItem(bodyVelocity, 0.15)
				end
			end

			if parent.RightUpperLeg:FindFirstChild("RightHip") then
				parent.RightUpperLeg.RightHip:Destroy()
				parent.LeftUpperLeg.LeftHip:Destroy()
				parent.RightUpperArm.RightShoulder:Destroy()
				parent.LeftUpperArm.LeftShoulder:Destroy()
				parent.Head.Neck:Destroy()
			else
				parent.UpperTorso.RightUpperArm:Destroy()
				parent.UpperTorso.LeftUpperArm:Destroy()
				parent.LowerTorso.RightUpperLeg:Destroy()
				parent.LowerTorso.LeftUpperLeg:Destroy()
				parent.UpperTorso.Head:Destroy()
			end

			local parentHead = parent:WaitForChild("Head")
			local parentRightUpperArm = parent:WaitForChild("RightUpperArm")
			local parentRightUpperLeg = parent:WaitForChild("RightUpperLeg")
			local parentLeftUpperLeg = parent:WaitForChild("LeftUpperLeg")
			local parentLeftUpperArm = parent:WaitForChild("LeftUpperArm")

			local function disableFx(p6)
				for _, v in ipairs(p6:GetDescendants()) do
					if v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end
			end

			local clone = bodyExp:Clone()

			clone.Parent = parent.Head
			clone:Play()
			task.spawn(function()
				if parent.Head:FindFirstChild("LongScream") then
					parent.Head.LongScream:Play()
					wait(1)
					parent.Head.LongScream:Stop()
				end
			end)

			for _, v in ipairs({
				parentHead,
				parentRightUpperArm,
				parentRightUpperLeg,
				parentLeftUpperLeg,
				parentLeftUpperArm,
				parent:WaitForChild("UpperTorso")
			}) do
				local t1: {[any]: any} = {}

				for _, iterValue in ipairs(gorePart:GetChildren()) do
					if not iterValue:IsA("SurfaceAppearance") and iterValue:IsA("Attachment") then
						local clone2 = iterValue:Clone()

						clone2.Parent = v
						t1[clone2.Name] = clone2
						task.delay(1.5, function()
							disableFx(clone2)
						end)
					end
				end

				for _, iterValue2 in ipairs(gorePart:GetChildren()) do
					if not iterValue2:IsA("SurfaceAppearance") and not iterValue2:IsA("Attachment") then
						local clone3 = iterValue2:Clone()

						clone3.Parent = v

						if clone3:IsA("Trail") then
							clone3.Attachment0 = t1.At0 or v:FindFirstChild("At0")
							clone3.Attachment1 = t1.At1 or v:FindFirstChild("At1")
						end
					end
				end
			end
		end
		local function CloneBoom(p7)
			local clone = finalHit:Clone()

			if p7:FindFirstChild("UpperTorso") then
				clone.Parent = p7.UpperTorso
			elseif p7:FindFirstChild("LowerTorso") then
				clone.Parent = p7.LowerTorso
			elseif p7:FindFirstChild("HumanoidRootPart") then
				clone.Parent = p7.HumanoidRootPart
			elseif p7:FindFirstChild("Head") then
				clone.Parent = p7.Head
			end

			for _ = 1, 3 do
				clone.Blood1:Emit(20)
			end
		end

		game.ReplicatedStorage.Characters.Combat.Remotes.BodyExplode.OnClientEvent:Connect(function(character)
			if not character or not character.Parent then
				return
			end

			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			CloneBoom(character)
			Damage(character, humanoid)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "BodyBoom", result)
	end
end)

return true
