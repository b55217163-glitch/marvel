-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")

		local function makeRock(p1, p2, p3, p4, p5)
			local randomNumber = math.random(1, 4)
			local randomNumber2 = math.random(1, 3)
			local vector3 = Vector3.new(randomNumber, randomNumber2, math.random(1, 4))
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.Material = p3 or Enum.Material.Slate
			part.Color = p4 or Color3.fromRGB(80, 75, 70)
			part.Size = vector3

			local cFrameNew = CFrame.new
			local vector32 = Vector3.new(0, vector3.Y * 0.25, 0)
			local v18 = cFrameNew(p1 - vector32)
			local cFrameAngles = CFrame.Angles
			local randomNumber3 = math.random(-35, 35)
			local v21 = math.rad(randomNumber3)
			local randomNumber4 = math.random(0, 360)
			local v23 = math.rad(randomNumber4)
			local randomNumber5 = math.random(-35, 35)
			local v25 = math.rad(randomNumber5)
			local v26 = cFrameAngles(v21, v23, v25)

			part.CFrame = v18 * v26
			part.Parent = workspace

			local randomNumber6 = math.random(3, 6)
			local randomNumber7 = math.random(3, 7)
			local randomNumber8 = math.random(5, 10)
			local vector33 = Vector3.new(0, vector3.Y * 0.35, 0)
			local cFrame = CFrame.new(p1 + p5 * randomNumber8 - vector33)
			local angles = CFrame.Angles
			local randomNumber9 = math.random(-45, 45)

			v23 = math.rad(randomNumber9)

			local randomNumber10 = math.random(0, 360)

			v25 = math.rad(randomNumber10)

			local randomNumber11 = math.random(-45, 45)
			local v36 = math.rad(randomNumber11)

			v21 = angles(v23, v25, v36)

			local tweenInfo = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			v18 = tweenService:Create(part, tweenInfo, { Position = p1 + p2 * randomNumber6 + p5 * randomNumber7 })

			local tweenInfo2 = TweenInfo.new(0.38, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)
			local v39: Tween = tweenService:Create(part, tweenInfo2, { CFrame = cFrame * v21 })

			v18:Play()
			v18.Completed:Connect(function()
				v39:Play()
			end)
			v39.Completed:Connect(function()
				task.delay(2, function()
					if not part or not part.Parent then
						return
					end

					local tweenInfo3 = TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					local partPosition: Vector3 = part.Position
					local randomNumber12 = math.random(3, 7)
					local vector34 = Vector3.new(0, randomNumber12, 0)
					local v71: Tween = tweenService:Create(part, tweenInfo3, {
						Size = Vector3.new(0, 0, 0),
						Transparency = 1,
						Position = partPosition - vector34
					})

					v71:Play()
					v71.Completed:Connect(function()
						if part then
							part:Destroy()
						end
					end)
				end)
			end)
		end
		local function doSlamEffect(p6)
			local humanoidRootPart = p6:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local map: Instance = workspace:FindFirstChild("Map")

			if not map then
				return
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			local v44 = workspace:Raycast(humanoidRootPart.Position + Vector3.new(0, 8, 0), Vector3.new(0, -40, 0), raycastParams)

			if v44 then
				local instance = v44.Instance
				local color3 = Color3.fromRGB(80, 75, 70)

				if instance and instance:IsA("BasePart") then
					color3 = instance.Color
				end

				local oneCrack = replicatedStorage.Characters.Mohawk.Fx:FindFirstChild("OneCrack")

				if oneCrack then
					local clone = oneCrack:Clone()

					clone.CFrame = CFrame.new(v44.Position)
					clone.Parent = workspace
					game:GetService("TweenService"):Create(clone.CrackDecal, TweenInfo.new(7), { Transparency = 1 }):Play()

					local foundChild = clone:FindFirstChild("Rocks", true)
					local foundChild2 = clone:FindFirstChild("Smoke", true)

					if foundChild and foundChild:IsA("ParticleEmitter") then
						foundChild.Color = ColorSequence.new(color3)
						foundChild:Emit(20)
					end

					if foundChild2 and foundChild2:IsA("ParticleEmitter") then
						foundChild2.Color = ColorSequence.new(color3)
						foundChild2:Emit(30)
					end

					task.delay(7, function()
						if clone then
							clone:Destroy()
						end
					end)
				end
			end

			for i = 1, 18 do
				local randomNumber = math.random(-10, 10)
				local v53 = math.rad(randomNumber)
				local n1 = 0.3490658503988659 * i + v53
				local randomNumber13 = math.random(3, 14)
				local cosine = math.cos(n1)
				local sine = math.sin(n1)
				local unit = Vector3.new(cosine, 0, sine).Unit
				local randomNumber14 = math.random(-3, 3)
				local vector3 = Vector3.new(randomNumber14, 0, math.random(-3, 3))
				local v61 = workspace:Raycast(humanoidRootPart.Position + unit * randomNumber13 + vector3 + Vector3.new(0, 10, 0), Vector3.new(0, -45, 0), raycastParams)

				if v61 then
					local v62 = v61.Instance
					local v63 = Enum.Material.Slate
					local color3 = Color3.fromRGB(80, 75, 70)

					if v62 and v62:IsA("BasePart") then
						v63 = v62.Material
						color3 = v62.Color
					end

					makeRock(v61.Position + Vector3.new(0, 0.35, 0), v61.Normal, v63, color3, unit)
				end
			end
		end

		replicatedStorage.Characters.Mohawk.Remotes.MoveOne.OnClientEvent:Connect(function(player)
			if not player then
				return
			end

			local Character = nil

			if typeof(player) == "Instance" and player:IsA("Player") then
				Character = player.Character
			elseif typeof(player) == "Instance" and player:IsA("Model") then
				Character = player
			end

			if not Character then
				return
			end

			doSlamEffect(Character)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Mohawk.MoveOne", result)
	end
end)

return true
