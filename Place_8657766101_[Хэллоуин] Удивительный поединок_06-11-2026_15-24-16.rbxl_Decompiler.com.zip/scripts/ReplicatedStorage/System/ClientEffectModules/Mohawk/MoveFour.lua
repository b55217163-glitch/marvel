-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local moveFour = game.ReplicatedStorage.Characters.Mohawk.Remotes.MoveFour
		local fourCrack = game.ReplicatedStorage.Characters.Mohawk.Fx.FourCrack
		local gameDebris = game.Debris
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function getSurfaceCF(p1)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			local v18 = p1.Position
			local v19 = nil
			local n1 = math.huge

			for _, v in ipairs({
				Vector3.new(0, 0, -1),
				Vector3.new(0, 0, 1),
				Vector3.new(1, 0, 0),
				Vector3.new(-1, 0, 0)
			}) do
				local v23 = workspace:Raycast(v18 - v * 3, v * 10, raycastParams)

				if v23 and math.abs(v23.Normal.Y) < 0.45 then
					local magnitude = (v23.Position - v18).Magnitude

					if n1 > magnitude then
						n1 = magnitude
						v19 = v23
					end
				end
			end

			if v19 and n1 <= 6 then
				local n2 = v19.Position + v19.Normal * 0.04
				local v26 = CFrame.lookAt(n2, n2 - v19.Normal, Vector3.new(0, 1, 0))
				local v27 = CFrame.Angles(-1.5707963267948966, 0, 0)

				return v26 * v27, v19, "Wall"
			end

			n1 = workspace:Raycast(v18 + Vector3.new(0, 20, 0), Vector3.new(0, -90, 0), raycastParams)

			if n1 then
				local cFrame = CFrame.new(n1.Position + Vector3.new(0, 0.04, 0))

				return cFrame, n1, "Ground"
			end

			return p1, nil, "Ground"
		end
		local function TestRock(p2)
			local v30, v31, v32 = getSurfaceCF(p2.CFrame)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 22 do
				local u36

				if v32 == "Ground" then
					local cFrameAngles = CFrame.Angles
					local v38 = math.rad(n1)
					local cFrame = cFrameAngles(0, v38, 0)

					u36 = workspace:Raycast((v30 * cFrame * CFrame.new(0, 20, -4.7)).Position, Vector3.new(0, -90, 0), raycastParams)
				else
					local angles = CFrame.Angles
					local v41 = math.rad(n1)
					local v42 = angles(0, 0, v41)

					u36 = workspace:Raycast((v30 * v42 * CFrame.new(4.7, 0, 0)).Position - v30.LookVector * 12, v30.LookVector * 30, raycastParams)
				end

				n1 += 16.363636363636363

				if u36 then
					local instance = u36.Instance

					if instance and instance:IsA("BasePart") and instance.Parent then
						local part: Part = Instance.new("Part")

						part.Anchored = true
						part.CanCollide = false
						part.CanTouch = false
						part.CanQuery = false
						part.Material = instance.Material
						part.Color = instance.Color

						local n2 = math.random(7, 13) / 10
						local randomNumber = math.random(85, 110)
						local randomNumber2 = math.random(70, 115)
						local randomNumber3 = math.random(85, 110)
						local vector3 = Vector3.new(n2 * randomNumber / 100, n2 * randomNumber2 / 100, n2 * randomNumber3 / 100)

						part.Size = Vector3.new(0.1, 0.1, 0.1)

						if v32 == "Ground" then
							local cFrameNew = CFrame.new
							local v51 = u36.Position
							local vector32 = Vector3.new(0, vector3.Y * 0.15, 0)
							local v53 = cFrameNew(v51 + vector32)
							local v54 = CFrame.Angles
							local v55 = mathRandom(-25, 25)

							v51 = math.rad(v55)

							local v56 = mathRandom(-180, 180)

							v55 = math.rad(v56)

							local v57 = mathRandom(-25, 25)

							v56 = math.rad(v57)

							local v58 = v54(v51, v55, v56)

							part.CFrame = v53 * v58
						else
							local n3 = u36.Position + u36.Normal * (vector3.Y * 0.18)
							local v60 = CFrame.lookAt(n3, n3 - u36.Normal)
							local v61 = CFrame.Angles
							local v62 = mathRandom(-18, 18)
							local v63 = math.rad(v62)
							local v64 = mathRandom(-180, 180)

							v62 = math.rad(v64)

							local v65 = mathRandom(-18, 18)

							v64 = math.rad(v65)

							local v66 = v61(v63, v62, v64)

							part.CFrame = v60 * v66
						end

						part.Parent = workspaceEffects

						local v67 = tweenInfoNew(0.16, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

						tweenService:Create(part, v67, { Size = vector3 }):Play()
						gameDebris:AddItem(part, 6)
						task.delay(5, function()
							if not part or not part.Parent then
								return
							end

							local v83 = v32 == "Ground" and Vector3.new(0, part.Size.Y, 0) or u36.Normal * part.Size.Y
							local v84 = tweenInfoNew(0.6, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

							tweenService:Create(part, v84, { Size = Vector3.new(0, 0, 0), Position = part.Position - v83 }):Play()
						end)
					end
				end
			end
		end
		local function SpawnCrack(p3)
			local cFrame, v70 = getSurfaceCF(p3.CFrame)
			local clone = fourCrack:Clone()

			clone.Parent = workspaceEffects
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.CFrame = cFrame

			local color3 = Color3.fromRGB(100, 100, 100)

			if v70 and v70.Instance and v70.Instance:IsA("BasePart") then
				color3 = v70.Instance.Color
			end

			local smoke = clone:FindFirstChild("Smoke")

			if smoke and smoke:IsA("ParticleEmitter") then
				smoke.Color = ColorSequence.new(color3)
				smoke:Emit(10)
			end

			local rocks = clone:FindFirstChild("Rocks")

			if rocks and rocks:IsA("ParticleEmitter") then
				rocks.Color = ColorSequence.new(color3)
				rocks:Emit(20)
			end

			local decal = clone:FindFirstChild("Decal")

			if decal then
				decal.Transparency = 0
				task.delay(6, function()
					if not decal or not decal.Parent then
						return
					end

					local v85 = tweenInfoNew(1, Enum.EasingStyle.Linear)

					tweenService:Create(decal, v85, { Transparency = 1 }):Play()
				end)
			end

			gameDebris:AddItem(clone, 7.2)
		end

		local block = game.ReplicatedStorage.Characters["A-Train"].Fx.block

		moveFour.OnClientEvent:Connect(function(player, p5)
			local v78

			if p5 and p5.Parent then
				v78 = p5.CFrame

				local randomNumber = math.random(1, 3)

				if randomNumber == 1 then
					p5.Slam1:Play()
				elseif randomNumber == 2 then
					p5.Slam2:Play()
				elseif randomNumber == 3 then
					p5.Slam3:Play()
				end
			else
				local Character = nil

				if typeof(player) == "Instance" and player:IsA("Player") then
					Character = player.Character
				elseif typeof(player) == "Instance" and player:IsA("Model") then
					Character = player
				end

				if not Character then
					return
				end

				local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

				if not humanoidRootPart then
					return
				end

				v78 = humanoidRootPart.CFrame * CFrame.new(0, 0, -5.5)
			end

			local clone = block:Clone()

			clone.Parent = workspace
			clone.CFrame = v78
			gameDebris:AddItem(clone, 4)
			TestRock(clone)
			SpawnCrack(clone)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Mohawk.MoveFour", result)
	end
end)

return true
