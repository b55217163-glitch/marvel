-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local landing = replicatedStorage.Characters.DareDevil.Remotes:WaitForChild("Landing")
		local landingPart = replicatedStorage.Characters:WaitForChild("LandingPart")
		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new
		local raycastParams = RaycastParams.new()

		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.IgnoreWater = true

		local u12 = nil

		local function refreshMap()
			local map: Instance = workspace:FindFirstChild("Map")

			if map == u12 then
				return
			end

			u12 = map
			raycastParams.FilterDescendantsInstances = if u12 then { u12 } else {}
		end

		refreshMap()
		workspace.ChildAdded:Connect(function(child: Instance)
			if child.Name == "Map" then
				refreshMap()
			end
		end)
		workspace.ChildRemoved:Connect(function(child: Instance)
			if child == u12 or child.Name == "Map" then
				refreshMap()
			end
		end)

		local function makeCloneFromSurface(p3, p4, p5)
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.Material = p3.Material
			part.Color = p3.Color
			part.Size = p4

			local v25 = mathRandom(-180, 180)
			local v26 = mathRandom(-180, 180)

			part.Orientation = Vector3.new(v25, v26, mathRandom(-180, 180))
			part.Position = p5

			for _, v in ipairs(p3:GetChildren()) do
				if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
					local clone = v:Clone()

					clone.Parent = part
				end
			end

			part.Parent = effects
			debris:AddItem(part, 2)
			task.delay(1, function()
				if not part or not part.Parent then
					return
				end

				for _, v in ipairs(part:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v97 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

						tweenService:Create(v, v97, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local v98 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local partPosition: Vector3 = part.Position
				local vector3 = Vector3.new(0, part.Size.Y / 2, 0)

				tweenService:Create(part, v98, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
			end)

			return part
		end
		local function spawnRockRing(p6, p7, p8, p9)
			if not u12 then
				return
			end

			local n1: number = 0

			for _ = 1, 20 do
				local v36 = p6.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v38 = math.rad(n1)
				local v39 = cFrameFromEulerAnglesXYZ(0, v38, 0)
				local cFrame = CFrame.new(0, 0, -p7)
				local n2 = (v36 * v39 * cFrame).Position + Vector3.new(0, 10, 0)
				local v42 = workspace:Raycast(n2, n2 - Vector3.new(0, 60, 0) - n2, raycastParams)

				n1 += 18

				if v42 and v42.Instance and v42.Instance:IsA("BasePart") then
					local instance = v42.Instance
					local v44 = makeCloneFromSurface(instance, p8, p6.Position)
					local v45 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(v44, v45, { Position = v42.Position }):Play()

					if not p9 then
						continue
					end

					local clone = replicatedStorage.Characters.Physics.Rock:Clone()

					clone.Material = instance.Material
					clone.Color = instance.Color

					if clone:FindFirstChild("Trail") then
						clone.Trail.Color = ColorSequence.new(instance.Color)
					end

					local v47 = p6.CFrame
					local cFrameAngles = CFrame.Angles
					local v49 = mathRandom(0, 360)

					v45 = math.rad(v49)

					local v50 = mathRandom(0, 360)

					v49 = math.rad(v50)

					local v51 = mathRandom(0, 360)

					v50 = math.rad(v51)

					local v52 = cFrameAngles(v45, v49, v50)

					clone.CFrame = v47 * v52
					clone.Parent = effects

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)
					v45 = mathRandom(-2, 2)
					v49 = mathRandom(-2, 2)
					bodyVelocity.Velocity = Vector3.new(v45, v49, mathRandom(-2, 2)) * 60
					bodyVelocity.Parent = clone
					debris:AddItem(clone, 3)
					debris:AddItem(bodyVelocity, 0.3)
				end
			end
		end
		local function doAllRocks(p10)
			spawnRockRing(p10, 20, Vector3.new(10, 10, 10), true)
			spawnRockRing(p10, 5, Vector3.new(3, 2, 3), false)
			spawnRockRing(p10, 10, Vector3.new(5, 2, 5), false)
		end
		local function OliviaLandingRopes(p11, p12)
			local t1: {[any]: any} = {}

			for _, v in ipairs(p11:GetDescendants()) do
				if v:IsA("Attachment") and v.Name == "RopeAt1" then
					table.insert(t1, v)
				end
			end

			if #t1 == 0 then
				return
			end

			for _, v in ipairs(t1) do
				local oliviaLandingRopeTarget: Part = Instance.new("Part")

				oliviaLandingRopeTarget.Name = "OliviaLandingRopeTarget"
				oliviaLandingRopeTarget.Anchored = true
				oliviaLandingRopeTarget.CanCollide = false
				oliviaLandingRopeTarget.CanTouch = false
				oliviaLandingRopeTarget.CanQuery = false
				oliviaLandingRopeTarget.Transparency = 1
				oliviaLandingRopeTarget.Size = Vector3.new(0.1, 0.1, 0.1)

				local v63 = mathRandom(-12, 12)
				local v64 = mathRandom(0, 4)
				local vector3 = Vector3.new(v63, v64, mathRandom(-12, 12))

				oliviaLandingRopeTarget.Position = p12 + vector3
				oliviaLandingRopeTarget.Parent = effects

				local attachment: Attachment = Instance.new("Attachment")

				attachment.Parent = oliviaLandingRopeTarget

				local oliviaLandingRope: Beam = Instance.new("Beam")

				oliviaLandingRope.Name = "OliviaLandingRope"
				oliviaLandingRope.Attachment0 = v
				oliviaLandingRope.Attachment1 = attachment
				oliviaLandingRope.Width0 = 0.28
				oliviaLandingRope.Width1 = 0.18
				oliviaLandingRope.FaceCamera = true
				oliviaLandingRope.Segments = 12
				oliviaLandingRope.CurveSize0 = mathRandom(-4, 4)
				oliviaLandingRope.CurveSize1 = mathRandom(-4, 4)
				oliviaLandingRope.Color = ColorSequence.new(Color3.fromRGB(170, 20, 30))
				oliviaLandingRope.Transparency = NumberSequence.new(0)
				oliviaLandingRope.Parent = oliviaLandingRopeTarget

				local vector3Unit = vector3.Unit
				local v69 = mathRandom(15, 22)
				local v70 = mathRandom(1, 6)
				local vector32 = Vector3.new(0, v70, 0)
				local tweenInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)

				tweenService:Create(oliviaLandingRopeTarget, tweenInfo, { Position = p12 + vector3Unit * v69 + vector32 }):Play()
				task.delay(0.35, function()
					if oliviaLandingRope.Parent then
						tweenService:Create(oliviaLandingRope, TweenInfo.new(0.25), { Width0 = 0, Width1 = 0 }):Play()
					end
				end)
				debris:AddItem(oliviaLandingRopeTarget, 0.65)
			end
		end

		landing.OnClientEvent:Connect(function(p13)
			if not p13 or not p13.Parent then
				return
			end

			local humanoidRootPart = p13:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			refreshMap()

			if not u12 then
				return
			end

			local u75: boolean = p13:FindFirstChild("WandaMax") ~= nil
			local olivia = p13:FindFirstChild("Olivia")
			local v77 = p13:FindFirstChild("CantAttack") or p13:FindFirstChild("Cantattack")
			local u78: boolean = p13:FindFirstChild("JustLanded") ~= nil

			if u75 and not u78 and not v77 then
				local v79 = workspace:Raycast(humanoidRootPart.Position, humanoidRootPart.CFrame.UpVector * -35, raycastParams)

				if v79 then
					local InstanceColor = v79.Instance.Color
					local clone = landingPart:Clone()

					clone.Parent = effects
					clone.Position = v79.Position

					if olivia ~= nil then
						OliviaLandingRopes(p13, v79.Position)
					end

					local v82 = mathRandom(-180, 180)

					clone.Orientation = Vector3.new(0, v82, 0)
					debris:AddItem(clone, 4)

					if clone:FindFirstChild("Smoke") then
						clone.Smoke.Color = ColorSequence.new(InstanceColor)

						local v83 = mathRandom(0, 360)

						clone.Orientation = Vector3.new(0, v83, 0)
						clone.Smoke:Emit(40)
					end

					local landAt = humanoidRootPart:FindFirstChild("LandAt")

					if landAt then
						local clone2 = landAt:Clone()

						clone2.Parent = clone

						if clone2:FindFirstChild("ChaosBlack") then
							clone2.ChaosBlack:Emit(5)
						end

						if clone2:FindFirstChild("ChaosRed") then
							clone2.ChaosRed:Emit(5)
						end

						if clone2:FindFirstChild("Flare") then
							clone2.Flare:Emit(10)
						end

						if clone2:FindFirstChild("Shock") then
							clone2.Shock:Emit(30)
						end

						if clone2:FindFirstChild("Smoke") then
							clone2.Smoke:Emit(30)
						end

						if clone2:FindFirstChild("Smoke2") then
							clone2.Smoke2:Emit(30)
						end
					end

					spawnRockRing(humanoidRootPart, 20, Vector3.new(10, 10, 10), true)
					spawnRockRing(humanoidRootPart, 5, Vector3.new(3, 2, 3), false)
					spawnRockRing(humanoidRootPart, 10, Vector3.new(5, 2, 5), false)

					local head = p13:FindFirstChild("Head")
					local landingSound = head and head:FindFirstChild("LandingSound")

					if landingSound and landingSound:IsA("Sound") then
						landingSound:Play()
					end

					task.delay(3, function()
						local v101 = clone and clone.Parent and clone:FindFirstChild("Decal")

						if v101 and v101:IsA("Decal") then
							tweenService:Create(v101, TweenInfo.new(1), { Transparency = 1 }):Play()
						end
					end)

					return
				end

				spawnRockRing(humanoidRootPart, 20, Vector3.new(10, 10, 10), true)
				spawnRockRing(humanoidRootPart, 5, Vector3.new(3, 2, 3), false)
				spawnRockRing(humanoidRootPart, 10, Vector3.new(5, 2, 5), false)

				local head = p13:FindFirstChild("Head")
				local headLandingSound = head and head:FindFirstChild("LandingSound")

				if headLandingSound and headLandingSound:IsA("Sound") then
					headLandingSound:Play()
				end

				return
			end

			if u75 and not u78 then
				return
			end

			v77 = workspace:Raycast(humanoidRootPart.Position, humanoidRootPart.CFrame.UpVector * -35, raycastParams)

			if not v77 then
				return
			end

			local v90 = v77.Instance.Color
			local clone = landingPart:Clone()

			clone.Parent = effects
			clone.Position = v77.Position

			local v92 = mathRandom(-180, 180)

			clone.Orientation = Vector3.new(0, v92, 0)
			debris:AddItem(clone, 4)

			if clone:FindFirstChild("Smoke") then
				clone.Smoke.Color = ColorSequence.new(v90)

				local v93 = mathRandom(0, 360)

				clone.Orientation = Vector3.new(0, v93, 0)
				clone.Smoke:Emit(40)
			end

			local head = p13:FindFirstChild("Head")

			v90 = head

			if v90 then
				v90 = head:FindFirstChild("LandingSound")
			end

			if v90 and v90:IsA("Sound") then
				v90:Play()
			end

			if p13:FindFirstChild("Homelander") then
				if clone:FindFirstChild("HomelanderBoom") then
					clone.HomelanderBoom:Play()
				end
			elseif p13:FindFirstChild("Viltrumite") then
				if clone:FindFirstChild("ViltrumiteBoom") then
					clone.ViltrumiteBoom:Play()
				end
			elseif clone:FindFirstChild("Boom") then
				clone.Boom:Play()
			end

			task.delay(3, function()
				if clone and clone.Parent and clone:FindFirstChild("Decal") then
					tweenService:Create(clone.Decal, TweenInfo.new(1), { Transparency = 1 }):Play()
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Landing", result)
	end
end)

return true
