-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local shake = ReplicatedStorage.Characters.Speed.Remotes.Shake
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function createClone(p1, p2, p3, p4, p5)
			if not p1 or not p1:IsA("BasePart") then
				return
			end

			local clone = p1:Clone()

			for _, v in ipairs(clone:GetChildren()) do
				if not v:IsA("Texture") and not v:IsA("Decal") and not v:IsA("SurfaceAppearance") then
					v:Destroy()
				end
			end

			clone.Name = "ShakeRock"
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Size = p2

			local v26 = mathRandom(-5, 5)
			local v27 = mathRandom(-5, 5)
			local vector3 = Vector3.new(v26, v27, mathRandom(-5, 5))

			clone.Position = p3 + vector3

			local v29 = mathRandom(-180, 180)

			v26 = mathRandom(-180, 180)
			clone.Orientation = Vector3.new(v29, v26, mathRandom(-180, 180))
			clone.Parent = workspaceEffects
			v27 = tweenInfoNew(p5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			tweenService:Create(clone, v27, { Position = p4 }):Play()
			game.Debris:AddItem(clone, 2)
			task.delay(1, function()
				if not clone.Parent then
					return
				end

				for _, v in ipairs(clone:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v76 = tweenInfoNew(0.5, Enum.EasingStyle.Linear)

						tweenService:Create(v, v76, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local v77 = tweenInfoNew(1, Enum.EasingStyle.Linear)
				local clonePosition = clone.Position
				local vector32 = Vector3.new(0, clone.Size.X / 2, 0)

				tweenService:Create(clone, v77, { Size = Vector3.new(0, 0, 0), Position = clonePosition - vector32 }):Play()
			end)
		end
		local function createExplosion(p6, p7)
			local clone = ReplicatedStorage.Characters.Physics.Rock:Clone()

			clone.Parent = workspace
			clone.Material = p6.Material
			clone.Color = p6.Color
			clone.Trail.Color = ColorSequence.new(p6.Color)

			local v33 = mathRandom(-180, 180)
			local v34 = mathRandom(-180, 180)

			clone.Orientation = Vector3.new(v33, v34, mathRandom(-180, 180))

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

			local randomNumber = math.random(-2, 2)
			local randomNumber2 = math.random(-2, 2)

			bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 60
			game.Debris:AddItem(clone, 3)
			game.Debris:AddItem(bodyVelocity, 0.3)
			v33 = mathRandom(-5, 5)
			v34 = mathRandom(0, 5)

			local vector3 = Vector3.new(v33, v34, mathRandom(-5, 5))

			clone.CFrame = p7.CFrame + vector3
		end
		local function TestRockGeneric(p8, p9, p10, _, p12, p13)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			local n1: number = 0

			for _ = 1, 20 do
				local v48 = p8.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v50 = math.rad(n1)
				local v51 = cFrameFromEulerAnglesXYZ(0, v50, 0)
				local cFrame = CFrame.new(0, 0, p10)
				local n2 = v48 * v51 * cFrame.Position + Vector3.new(0, 10, 0)
				local v54 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v54 then
					local instance = v54.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local v56 = v54.Position
					local vector3

					if (p8.Position - p13.HumanoidRootPart.Position).Magnitude < 15 then
						vector3 = p9
					else
						local v58 = mathRandom(8, 20)
						local v59 = mathRandom(8, 20)

						vector3 = Vector3.new(v58, v59, mathRandom(8, 20))
					end

					createClone(instance, vector3, p8.Position, v56, p12)
					createExplosion(instance, p8)
				end
			end
		end
		local function TestRock(p14, p15)
			TestRockGeneric(p14, Vector3.new(10, 10, 10), -20, 20, 0.5, p15)
		end
		local function TestRock2(p16, p17)
			TestRockGeneric(p16, Vector3.new(3, 2, 3), -5, 5, 0.5, p17)
		end
		local function TestRock3(p18, p19)
			TestRockGeneric(p18, Vector3.new(5, 2, 5), -10, 10, 0.5, p19)
		end

		local smoke = ReplicatedStorage.Characters.Vecna.Fx.Smoke

		local function cloneAndRandomizeSound(p20)
			local clone = p20:Clone()

			clone.PlaybackSpeed = math.random(100, 130) / 100
			clone.Parent = p20.Parent
			clone:Play()
			game.Debris:AddItem(clone, clone.TimeLength)
		end

		shake.OnClientEvent:Connect(function(player)
			if typeof(player) ~= "Instance" or not player:IsA("Player") then
				return
			end

			local Character = player.Character

			if not Character then
				return
			end

			local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
			local head = Character:FindFirstChild("Head")

			if humanoidRootPart and head then
				local moveFourShock = head:FindFirstChild("MoveFourShock")

				if moveFourShock and moveFourShock:IsA("Sound") then
					moveFourShock:Play()

					local clone = moveFourShock:Clone()

					clone.PlaybackSpeed = math.random(100, 130) / 100
					clone.Parent = moveFourShock.Parent
					clone:Play()
					game.Debris:AddItem(clone, clone.TimeLength)
				end

				TestRockGeneric(humanoidRootPart, Vector3.new(10, 10, 10), -20, 20, 0.5, Character)
				TestRockGeneric(humanoidRootPart, Vector3.new(3, 2, 3), -5, 5, 0.5, Character)
				TestRockGeneric(humanoidRootPart, Vector3.new(5, 2, 5), -10, 10, 0.5, Character)

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Speed.Shake", result)
	end
end)

return true
