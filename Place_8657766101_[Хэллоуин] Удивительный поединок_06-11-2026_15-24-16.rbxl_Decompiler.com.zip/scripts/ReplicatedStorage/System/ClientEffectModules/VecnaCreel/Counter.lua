-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local counter = game.ReplicatedStorage.Characters.Creel.Remotes.Counter
		local v7 = game.ReplicatedStorage.Characters.Creel.AnimationsExtra.Counter
		local counterHit = game.ReplicatedStorage.Characters.Creel.AnimationsExtra.CounterHit
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock2(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v20 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v22 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v22, 0)
				local n2 = v20 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v25 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v25 then
					local instance = v25.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v31 = mathRandom(-180, 180)
					local v32 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v31, v32, mathRandom(-180, 180))
					part.Position = p1.Position

					local v33 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v33, { Position = v25.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v61 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v61, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v62 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v62, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v38 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v40 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v40, 0)
				local n2 = v38 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v43 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v43 then
					local instance = v43.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v49 = mathRandom(-180, 180)
					local v50 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v49, v50, mathRandom(-180, 180))
					part.Position = p2.Position

					local v51 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v51, { Position = v43.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v67 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v67, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v68 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v68, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local groundhit = game.ReplicatedStorage.Characters.Wanda.Fx.Groundhit

		counter.OnClientEvent:Connect(function(p3, player)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)
			local v56 = p3:WaitForChild("Humanoid", 5)
			local v57 = animationService.LoadFresh(humanoid, v7)
			local v58 = animationService.GetTrack(v56, counterHit)

			animationService.ConnectMarker(v57, "SlamDown", function(_)
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v73 = workspace:Raycast(Character.HumanoidRootPart.SmashAttachment.WorldPosition, Character.HumanoidRootPart.SmashAttachment.CFrame.UpVector * -10, raycastParams)

				if v73 == nil then
					return
				end

				local InstanceColor = v73.Instance.Color
				local clone = groundhit:Clone()

				clone.Parent = workspace
				clone.Rocks.Color = ColorSequence.new(InstanceColor)
				clone.Smoke.Color = ColorSequence.new(InstanceColor)
				clone.Rocks:Emit(30)
				clone.Smoke:Emit(30)
				clone.Position = v73.Position
				game.Debris:AddItem(clone, 5)
				TestRock2(clone)
				TestRock3(clone)
			end)
			animationService.ConnectMarker(v57, "VinesOn", function(_)
				Character.Head.VinesCounter:Play()
			end)
			v57:Play()
			v58:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "VecnaCreel.Counter", result)
	end
end)

return true
