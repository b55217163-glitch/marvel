-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local vinePull = ReplicatedStorage.Characters.Creel.Remotes.VinePull
		local v7 = ReplicatedStorage.Characters.Creel.AnimationsExtra.VinePull
		local tweenService: TweenService = game:GetService("TweenService")
		local windChoke001 = ReplicatedStorage.Characters.Vecna.Fx.Windpart.WindChoke001

		local function createAttachment(p1)
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.Transparency = 1
			part.Parent = workspace
			part.CFrame = p1.UpperTorso.CFrame
			game.Debris:AddItem(part, 2)

			local attachment: Attachment = Instance.new("Attachment")

			attachment.Parent = part
			game.Debris:AddItem(attachment, 3)

			return part, attachment
		end

		local t1: {[any]: any} = {
			ReplicatedStorage.Characters.Creel.Fx.VineBeam1,
			ReplicatedStorage.Characters.Creel.Fx.VineBeam2,
			ReplicatedStorage.Characters.Creel.Fx.VineBeam3
		}

		local function createVineBeam(parent, attachment1)
			local t2: {[any]: any} = {}

			for _, v in ipairs(t1) do
				local clone = v:Clone()

				clone.Parent = parent

				if parent:FindFirstChild("SlenderMan") then
					clone.Color = ColorSequence.new(Color3.new(0, 0, 0))
				end

				clone.Attachment0 = parent.UpperTorso.VineAt
				clone.Attachment1 = attachment1
				game.Debris:AddItem(clone, 3)
				table.insert(t2, clone)
			end

			return t2
		end
		local function playVineAnimations(p4, p5, p6, p7)
			task.spawn(function()
				local TweenService = game.TweenService

				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
				task.wait(p5)
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize1 = p6 }):Play()
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize0 = p6 }):Play()
				task.wait(0.1)
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize1 = p7 }):Play()
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize0 = p7 }):Play()
				task.wait(0.1)
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
				TweenService:Create(p4, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
			end)
		end
		local function Scream(_, p9, p10)
			task.spawn(function()
				if p9.Head:FindFirstChild("LongScream") then
					p9.Head.LongScream:Play()
				end

				p10:Play()
				task.wait(0.7)

				if p9.Head:FindFirstChild("LongScream") then
					p9.Head.LongScream:Stop()
				end
			end)
		end

		vinePull.OnClientEvent:Connect(function(p11, player)
			if p11 and player then
				local Character = player.Character

				if not Character then
					return
				end

				local humanoid = Character:WaitForChild("Humanoid", 5)
				local v35 = p11:WaitForChild("Humanoid", 5)

				if humanoid and v35 then
					local animator = v35:FindFirstChildOfClass("Animator")
					local v37 = animationService.GetTrack(animator, v7)

					if not Character:WaitForChild("Humanoid", 5) then
						return
					end

					local head = p11:FindFirstChild("Head")

					if Character.UpperTorso:FindFirstChild("TwoHitAt") then
						local clone = Character.UpperTorso.TwoHitAt:Clone()

						clone.Parent = p11.UpperTorso
						clone.Shock:Emit(1)
						clone.ShockwaveMiddle:Emit(1)
						game.Debris:AddItem(clone, 2)

						if Character:FindFirstChild("001") then
							local clone2 = Character.UpperTorso.TwoHitAt:Clone()

							clone2.Parent = Character.LeftHand
							clone2.Shock:Emit(1)
							clone2.ShockwaveMiddle:Emit(1)
							game.Debris:AddItem(clone2, 2)
						end
					end

					if Character:FindFirstChild("TheVecna") then
						Character.Head.VinePullSfx:Play()

						local parent, v42 = createAttachment(Character)
						local v43 = createVineBeam(Character, v42)

						if parent and head then
							tweenService:Create(parent, TweenInfo.new(0.3), { Position = head.Position }):Play()
						end

						local v44 = v43[1]
						local n1: number = 0.2
						local n2: number = -5
						local n3: number = -30

						task.spawn(function()
							local TweenService = game.TweenService

							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
							task.wait(n1)
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize1 = n2 }):Play()
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize0 = n2 }):Play()
							task.wait(0.1)
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize1 = n3 }):Play()
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize0 = n3 }):Play()
							task.wait(0.1)
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v44, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
						end)

						local v48 = v43[2]
						local n4: number = 0.2
						local n5: number = 10
						local n6: number = -30

						task.spawn(function()
							local TweenService = game.TweenService

							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
							task.wait(n4)
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize1 = n5 }):Play()
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize0 = n5 }):Play()
							task.wait(0.1)
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize1 = n6 }):Play()
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize0 = n6 }):Play()
							task.wait(0.1)
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v48, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
						end)

						local v52 = v43[3]
						local n7: number = 0.2
						local n8: number = -10
						local n9: number = -30

						task.spawn(function()
							local TweenService = game.TweenService

							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
							task.wait(n7)
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize1 = n8 }):Play()
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize0 = n8 }):Play()
							task.wait(0.1)
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize1 = n9 }):Play()
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize0 = n9 }):Play()
							task.wait(0.1)
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize1 = 0 }):Play()
							TweenService:Create(v52, TweenInfo.new(0.8), { CurveSize0 = 0 }):Play()
						end)

						for _, v in ipairs(v43) do
							tweenService:Create(v, TweenInfo.new(0.1), { Width0 = 2 }):Play()
							tweenService:Create(v, TweenInfo.new(0.2), { Width1 = 1 }):Play()
						end

						task.wait(0.3)
						task.spawn(function()
							if p11.Head:FindFirstChild("LongScream") then
								p11.Head.LongScream:Play()
							end

							v37:Play()
							task.wait(0.7)

							if p11.Head:FindFirstChild("LongScream") then
								p11.Head.LongScream:Stop()
							end
						end)

						if parent and head then
							parent.Anchored = false
							parent.CFrame = head.CFrame

							local weldConstraint: WeldConstraint = Instance.new("WeldConstraint")

							weldConstraint.Part0 = parent
							weldConstraint.Part1 = head
							weldConstraint.Parent = parent
						end

						task.delay(0.7, function()
							for _, v in ipairs(v43) do
								tweenService:Create(v, TweenInfo.new(0.1), { Width0 = 0 }):Play()
								tweenService:Create(v, TweenInfo.new(0.2), { Width1 = 0 }):Play()
							end
						end)

						return
					end

					Character.Head.TwoNotice:Play()
					Character.Head.VinePullSfx:Play()

					local clone = windChoke001:Clone()

					clone.Parent = p11.UpperTorso
					clone.SparksSlow.Enabled = false
					clone.Wv.Enabled = false
					clone.Wv2.Enabled = false
					clone.Wv3.Enabled = false
					game.Debris:AddItem(clone, 3)
					task.wait(0.3)

					if clone:FindFirstChild("Wv") then
						clone.Wv.Enabled = true
						clone.Wv2.Enabled = true
						clone.Wv3.Enabled = true
						clone.SparksSlow.Enabled = true
						task.spawn(function()
							wait(0.3)
							clone.Wv.Enabled = false
							clone.Wv2.Enabled = false
							clone.Wv3.Enabled = false
							clone.SparksSlow.Enabled = false
						end)
					end

					task.spawn(function()
						if p11.Head:FindFirstChild("LongScream") then
							p11.Head.LongScream:Play()
						end

						v37:Play()
						task.wait(0.7)

						if p11.Head:FindFirstChild("LongScream") then
							p11.Head.LongScream:Stop()
						end
					end)

					return
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "VecnaCreel.VinePull", result)
	end
end)

return true
