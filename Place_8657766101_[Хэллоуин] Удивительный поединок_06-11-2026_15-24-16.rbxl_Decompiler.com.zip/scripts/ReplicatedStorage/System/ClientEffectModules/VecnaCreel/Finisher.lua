-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Creel.Remotes.Finisher
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "VecnaCreel.Finisher", result)
	end
end)

return true
