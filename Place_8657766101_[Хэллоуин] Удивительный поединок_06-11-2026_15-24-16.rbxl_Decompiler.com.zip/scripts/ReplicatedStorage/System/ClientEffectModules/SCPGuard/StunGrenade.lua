-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local explosionEffect = replicatedStorage.Characters.SCPGuard.Fx.ExplosionEffect

		local function createShockwave(p1)
			local effects = workspace:FindFirstChild("Effects")

			if not effects then
				effects = Instance.new("Folder")
				effects.Name = "Effects"
				effects.Parent = workspace
			end

			local shockwavePart: Part = Instance.new("Part")

			shockwavePart.Name = "ShockwavePart"
			shockwavePart.Anchored = true
			shockwavePart.CanCollide = false
			shockwavePart.CanTouch = true
			shockwavePart.CanQuery = false
			shockwavePart.Massless = true
			shockwavePart.Position = p1
			shockwavePart.Size = Vector3.new(4, 4, 4)
			shockwavePart.Material = Enum.Material.Glass
			shockwavePart.MaterialVariant = ""
			shockwavePart.Color = Color3.fromRGB(163, 162, 165)
			shockwavePart.Transparency = 2
			shockwavePart.Reflectance = 0.5
			shockwavePart.Shape = Enum.PartType.Ball
			shockwavePart.Parent = effects

			local shockwaveHighlight: Highlight = Instance.new("Highlight")

			shockwaveHighlight.Name = "ShockwaveHighlight"
			shockwaveHighlight.FillTransparency = 1
			shockwaveHighlight.OutlineTransparency = 1
			shockwaveHighlight.Parent = shockwavePart

			local tweenInfo = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local v15: Tween = tweenService:Create(shockwavePart, tweenInfo, { Size = Vector3.new(25, 25, 25), Transparency = 5 })

			v15:Play()
			v15.Completed:Once(function()
				if not shockwavePart.Parent then
					return
				end

				local tweenInfo2 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				local v30: Tween = tweenService:Create(shockwavePart, tweenInfo2, { Size = Vector3.new(0, 0, 0) })

				v30:Play()
				v30.Completed:Once(function()
					if shockwavePart.Parent then
						shockwavePart:Destroy()
					end
				end)
			end)
		end
		local function getMapGround(p2)
			local map: Instance = workspace:FindFirstChild("Map")

			if not map then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			return workspace:Raycast(p2 + Vector3.new(0, 5, 0), Vector3.new(0, -30, 0), raycastParams)
		end
		local function setEmitterColour(p3, p4)
			if p3 and p3:IsA("ParticleEmitter") then
				p3.Color = ColorSequence.new(p4)
			end
		end

		replicatedStorage.Characters.SCPGuard.Remotes.Grenade.OnClientEvent:Connect(function(p5)
			if typeof(p5) == "Vector3" then
				local clone = explosionEffect:Clone()

				clone.Position = p5
				clone.Parent = workspace

				if clone:FindFirstChild("Sound") then
					clone.Sound:Play()
				end

				local oneHitAt = clone:FindFirstChild("OneHitAt")

				if oneHitAt then
					oneHitAt.Impact:Emit(1)
					oneHitAt.Shock:Emit(1)
					oneHitAt.Sparks:Emit(8)
					oneHitAt.SparksCircle:Emit(8)
				end

				createShockwave(p5)

				local v24 = getMapGround(p5)
				local debriAt = clone:FindFirstChild("DebriAt")

				if v24 and debriAt then
					local InstanceColor = v24.Instance.Color
					local smoke = debriAt:FindFirstChild("Smoke")
					local rocks = debriAt:FindFirstChild("Rocks")

					if smoke and smoke:IsA("ParticleEmitter") then
						smoke.Color = ColorSequence.new(InstanceColor)
					end

					if rocks and rocks:IsA("ParticleEmitter") then
						rocks.Color = ColorSequence.new(InstanceColor)
					end

					if smoke and smoke:IsA("ParticleEmitter") then
						smoke:Emit(20)
					end

					if rocks and rocks:IsA("ParticleEmitter") then
						rocks:Emit(10)
					end
				end

				debris:AddItem(clone, 4)

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SCPGuard.Grenade", result)
	end
end)

return true
