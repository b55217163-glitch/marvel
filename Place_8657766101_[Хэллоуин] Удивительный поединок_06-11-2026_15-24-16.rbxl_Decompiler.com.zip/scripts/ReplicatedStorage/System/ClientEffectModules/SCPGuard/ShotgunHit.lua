-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local shotgunHitAnim = game.ReplicatedStorage.Characters.SCPGuard.AnimationsExtra.ShotgunHitAnim
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.SCPGuard.Remotes.HitShotGun.OnClientEvent:Connect(function(p1, _)
			animationService.GetTrack(p1.Humanoid, shotgunHitAnim):Play()

			local clone = script.HitSfx:Clone()

			clone.Parent = p1.HumanoidRootPart
			clone.PlaybackSpeed = math.random(1, 1.5)
			clone:Play()
			game.Debris:AddItem(clone, 2)

			local clone2 = neckExplode:Clone()

			clone2.Parent = p1.UpperTorso
			clone2.Bl1:Emit(4)
			clone2.Bl2:Emit(15)

			for _ = 1, 4 do
				local randomNumber = math.random(15, 30)
				local clone3 = bloodDrip:Clone()

				clone3.Parent = workspace

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

				clone3.Parent = workspace
				clone3.CFrame = p1.UpperTorso.CFrame
				clone3.LocalScript.Disabled = false
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber2 = math.random(-2, 2)
				local randomNumber3 = math.random(-2, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
				game.Debris:AddItem(clone3, 3)
				game.Debris:AddItem(bodyVelocity, 0.15)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SCPGuard.ShotgunHit", result)
	end
end)

return true
