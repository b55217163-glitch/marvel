-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local scpGuard = replicatedStorage.Characters.SCPGuard
		local containmentCage = scpGuard.Fx.ContainmentCage
		local containmentCageAsync = scpGuard.Fx.ContainmentCageAsync
		local guardFinisher = scpGuard.AnimationsExtra.GuardFinisher
		local t1: {[any]: any} = {}

		local function prepareGuardClone(p1, p2)
			local archivable = p1.Archivable

			p1.Archivable = true

			local clone = p1:Clone()

			p1.Archivable = archivable
			clone.Name = "FinisherGuard"
			clone.Parent = workspace:FindFirstChild("Effects") or workspace
			debris:AddItem(clone, 15)

			for _, v in ipairs(clone:GetDescendants()) do
				if not v:IsA("Script") and not v:IsA("LocalScript") and not v:IsA("Sound") then
					if v:IsA("ParticleEmitter") then
						local u26: boolean = not p2

						if u26 then
							u26 = v:FindFirstAncestor("P90") ~= nil
						end

						local v27 = p2

						if v27 then
							v27 = v:FindFirstAncestor("SteamTank1") ~= nil
						end

						if not u26 and not v27 then
							v:Destroy()
						end
					elseif v:IsA("JointInstance") then
						local v28 = v.Part0 and v.Part0:IsDescendantOf(clone)
						local v29 = v.Part1 and v.Part1:IsDescendantOf(clone)

						if not v28 or not v29 then
							v:Destroy()
						end
					elseif v:IsA("BasePart") then
						v.Anchored = false
						v.CanCollide = false
						v.CanTouch = false
						v.CanQuery = false
						v.Massless = true
					end
				else
					v:Destroy()
				end
			end

			for _, v in ipairs({ "GuiCop", "CamForce", "CustomShiftlock", "MouseLock" }) do
				local v = clone:FindFirstChild(v)

				if v then
					v:Destroy()
				end
			end

			return clone
		end
		local function createFinisherGuards(p3, p4, p5)
			if p3:FindFirstChild("035") then
				return
			end

			local fakeUpperTorso = p3:FindFirstChild("FakeUpperTorso")

			if not fakeUpperTorso then
				return
			end

			for _, v in ipairs({ -1, 1 }) do
				local character = prepareGuardClone(p3, p5.IsAsync)
				local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
				local humanoid = character:FindFirstChildOfClass("Humanoid")

				if humanoidRootPart and humanoid then
					local cFrame = CFrame.new(v * 7, 0, 9)
					local n1 = p4 * cFrame
					local cFrame2 = CFrame.new(v * 5, 0, 0)
					local n2 = p4 * cFrame2

					character:PivotTo(n1)
					humanoidRootPart.CFrame = n1
					humanoidRootPart.Anchored = true
					humanoid.AutoRotate = false

					local animator = humanoid:FindFirstChildOfClass("Animator")

					if not animator then
						animator = Instance.new("Animator")
						animator.Parent = humanoid
					end

					local animationTrack = animator:LoadAnimation(guardFinisher)

					table.insert(p5.Guards, {
						Firing = false,
						Model = character,
						Root = humanoidRootPart,
						Animation = animationTrack
					})
					animationTrack:Play()

					local tweenInfo = TweenInfo.new(2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

					n1 = tweenService:Create(humanoidRootPart, tweenInfo, { CFrame = n2 })
					n1:Play()
					n1.Completed:Once(function()
						if not humanoidRootPart.Parent or not fakeUpperTorso.Parent then
							return
						end

						local v98 = n2.Position
						local vector3 = Vector3.new(fakeUpperTorso.Position.X, v98.Y, fakeUpperTorso.Position.Z)
						local v100 = CFrame.lookAt(v98, vector3, Vector3.new(0, 1, 0))
						local tweenInfo2 = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

						tweenService:Create(humanoidRootPart, tweenInfo2, { CFrame = v100 }):Play()
					end)
				else
					character:Destroy()
				end
			end
		end
		local function shootGun(p6)
			local p90 = p6 and p6:FindFirstChild("P90")

			if not p90 then
				return
			end

			local gunAt = p90:FindFirstChild("GunAt")
			local shootShock = p90:FindFirstChild("ShootShock")

			if gunAt then
				local flash = gunAt:FindFirstChild("Flash")
				local longSpark = gunAt:FindFirstChild("LongSpark")
				local smoke = gunAt:FindFirstChild("Smoke")

				if flash then
					flash:Emit(1)
				end

				if longSpark then
					longSpark:Emit(3)
				end

				if smoke then
					smoke:Emit(10)
				end
			end

			if shootShock then
				local blueSparks = shootShock:FindFirstChild("BlueSparks")
				local light = shootShock:FindFirstChild("Light")
				local spotLight = shootShock:FindFirstChild("SpotLight")

				if blueSparks then
					blueSparks:Emit(5)
				end

				if light then
					light.Enabled = true
				end

				if spotLight then
					spotLight.Enabled = true
				end

				task.delay(0.08, function()
					if light and light.Parent then
						light.Enabled = false
					end

					if spotLight and spotLight.Parent then
						spotLight.Enabled = false
					end
				end)
			end
		end
		local function shootSteam(p7)
			local steamTank1 = p7 and p7:FindFirstChild("SteamTank1")
			local steamAt = steamTank1 and steamTank1:FindFirstChild("SteamAt")

			if not steamAt then
				return
			end

			local dots = steamAt:FindFirstChild("Dots")
			local lines = steamAt:FindFirstChild("Lines")
			local smoke_Steam = steamAt:FindFirstChild("Smoke_Steam")

			if dots then
				dots:Emit(5)
			end

			if lines then
				lines:Emit(5)
			end

			if smoke_Steam then
				smoke_Steam:Emit(5)
			end
		end
		local function stopGuardShooting(p8)
			for _, v in ipairs(p8.Guards) do
				v.Firing = false

				local v68 = v.Model and v.Model:FindFirstChild("P90")
				local shootShock = v68 and v68:FindFirstChild("ShootShock")

				if shootShock then
					local light = shootShock:FindFirstChild("Light")
					local spotLight = shootShock:FindFirstChild("SpotLight")

					if light then
						light.Enabled = false
					end

					if spotLight then
						spotLight.Enabled = false
					end
				end
			end
		end
		local function startGuardShooting(p9)
			for _, v in ipairs(p9.Guards) do
				if not v.Firing then
					v.Firing = true
					task.spawn(function()
						while v.Firing and v.Model and v.Model.Parent do
							if p9.IsAsync then
								shootSteam(v.Model)
							else
								shootGun(v.Model)
							end

							task.wait(0.15)
						end
					end)
				end
			end
		end
		local function fadeFinisherGuards(p10)
			if p10.Faded then
				return
			end

			p10.Faded = true
			stopGuardShooting(p10)

			for _, v in ipairs(p10.Guards) do
				local vModel = v.Model

				if vModel and vModel.Parent then
					for _, iterValue in ipairs(vModel:GetDescendants()) do
						if iterValue:IsA("ParticleEmitter") or iterValue:IsA("Beam") or iterValue:IsA("Trail") then
							iterValue.Enabled = false
						elseif iterValue:IsA("BasePart") or iterValue:IsA("Decal") or iterValue:IsA("Texture") then
							local tweenInfo = TweenInfo.new(0.7, Enum.EasingStyle.Linear)

							tweenService:Create(iterValue, tweenInfo, { Transparency = 1 }):Play()
						end
					end

					debris:AddItem(vModel, 0.7999999999999999)
				end
			end
		end
		local function addRPGHighlight(parent)
			local highlight: Highlight = Instance.new("Highlight")

			highlight.FillColor = Color3.new(1, 1, 1)
			highlight.FillTransparency = 0
			highlight.OutlineTransparency = 1
			highlight.Adornee = parent
			highlight.Parent = parent

			local tweenInfo = TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
			local v85: Tween = tweenService:Create(highlight, tweenInfo, { FillTransparency = 1 })

			v85:Play()
			v85.Completed:Once(function()
				highlight:Destroy()
			end)
		end
		local function spawnContainer(p12, p13)
			local async = p13:FindFirstChild("Async")
			local clone

			if async then
				clone = containmentCageAsync:Clone()
			else
				clone = containmentCage:Clone()
			end

			clone.Parent = workspace
			clone:PivotTo(p12)
			clone.FHumanoidRootPart.CloseDoorSfx:Play()
			addRPGHighlight(clone)
			task.delay(1, function()
				if not clone.Parent then
					return
				end

				tweenService:Create(clone.Door.Door1, TweenInfo.new(1), { CFrame = clone.Door.Door1Move.CFrame }):Play()
				tweenService:Create(clone.Door.Door2, TweenInfo.new(1), { CFrame = clone.Door.Door2Move.CFrame }):Play()
			end)
			debris:AddItem(clone, 5)
		end

		scpGuard.Remotes.Finisher.OnClientEvent:Connect(function(player, _, p16, p17, p18)
			if p16 == "Start" then
				local Character = player.Character

				if Character and typeof(p18) == "CFrame" then
					local t2: {[any]: any} = {
						Faded = false,
						Guards = {},
						IsAsync = Character:FindFirstChild("Async") ~= nil
					}

					t1[p17] = t2
					createFinisherGuards(Character, p18, t2)
					task.delay(14, function()
						if t1[p17] == t2 then
							fadeFinisherGuards(t2)
							t1[p17] = nil
						end
					end)

					return
				end
			elseif p16 == "Container" then
				if typeof(p18) == "CFrame" then
					spawnContainer(p18, player.Character)

					return
				end
			else
				local v97 = t1[p17]

				if not v97 then
					return
				end

				if p16 == "Fire" then
					startGuardShooting(v97)

					return
				end

				if p16 == "FireStop" then
					stopGuardShooting(v97)

					return
				end

				if p16 == "Fade" then
					fadeFinisherGuards(v97)
					t1[p17] = nil
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SCPGuard.SCP096", result)
	end
end)

return true
