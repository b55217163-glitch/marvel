-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local sculpture = game.ReplicatedStorage.Characters.SCPGuard.Fx.Sculpture

		game.ReplicatedStorage.Characters.SCPGuard.Remotes.SculptureBash.OnClientEvent:Connect(function(_, p2)
			local map: Instance = workspace:FindFirstChild("Map")

			if not map then
				return
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			local function getGroundPosition(p3)
				local v30 = workspace:Raycast(p3 + Vector3.new(0, 20, 0), Vector3.new(0, -100, 0), raycastParams)

				if not v30 then
					return nil, nil
				end

				return v30.Position, v30.Instance.Color
			end
			local function emitGroundEffects(p4, p5)
				if not p5 then
					return
				end

				local attachment = p4:FindFirstChild("Attachment")

				if not attachment then
					return
				end

				local colorSequence = ColorSequence.new(p5)
				local smoke = attachment:FindFirstChild("Smoke")

				if smoke and smoke:IsA("ParticleEmitter") then
					smoke.Color = colorSequence
					smoke:Emit(10)
				end

				local rocks = attachment:FindFirstChild("Rocks")

				if rocks and rocks:IsA("ParticleEmitter") then
					rocks.Color = colorSequence
					rocks:Emit(10)
				end
			end

			local humanoidRootPart = p2:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local n1 = humanoidRootPart.CFrame * CFrame.new(0, 0, -15)
			local v14 = workspace:Raycast(n1.Position + Vector3.new(0, 20, 0), Vector3.new(0, -100, 0), raycastParams)
			local v15
			local v16

			if not v14 then
				v15 = nil
				v16 = nil
			else
				v15 = v14.Position
				v16 = v14.Instance.Color
			end

			if not v15 then
				return
			end

			local clone = sculpture:Clone()

			clone.Parent = workspace
			game.Debris:AddItem(clone, 8)
			clone.CFrame = CFrame.new(v15 + Vector3.new(0, 3.9695, 0)) * n1.Rotation
			clone.Spawn:Play()
			emitGroundEffects(clone, v16)
			task.wait(0.95)

			if not clone.Parent or not humanoidRootPart.Parent then
				return
			end

			clone.Scare:Play()
			clone.Rock:Play()
			v14 = workspace:Raycast(humanoidRootPart.Position + Vector3.new(0, 20, 0), Vector3.new(0, -100, 0), raycastParams)

			local v18

			if not v14 then
				v18 = nil
			else
				v18 = v14.Position

				local InstanceColor = v14.Instance.Color
			end

			if v18 then
				local v20 = workspace:Raycast(humanoidRootPart.Position - humanoidRootPart.CFrame.LookVector * 1.5 + Vector3.new(0, 20, 0), Vector3.new(0, -100, 0), raycastParams)
				local v21
				local v22

				if not v20 then
					v21 = nil
					v22 = nil
				else
					v21 = v20.Position
					v22 = v20.Instance.Color
				end

				if v21 then
					local n2 = v21 + Vector3.new(0, 3.9695, 0)
					local vector3 = Vector3.new(humanoidRootPart.Position.X, n2.Y, humanoidRootPart.Position.Z)

					vector3 = CFrame.lookAt(n2, vector3)

					local v25 = CFrame.Angles(0, 3.141592653589793, 0)

					game.TweenService:Create(clone, TweenInfo.new(0.05), { CFrame = vector3 * v25 }):Play()
					emitGroundEffects(clone, v22)
				end
			end

			task.wait(2)

			if not clone.Parent then
				return
			end

			clone.CanCollide = false
			clone.Transparency = 1
			clone.Rock:Play()

			local v26 = workspace:Raycast(clone.Position + Vector3.new(0, 20, 0), Vector3.new(0, -100, 0), raycastParams)
			local v27
			local v28

			if not v26 then
				v27 = nil
				v28 = nil
			else
				v27 = v26.Position
				v28 = v26.Instance.Color
			end

			if v27 then
				emitGroundEffects(clone, v28)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SCPGuard.Sculpture", result)
	end
end)

return true
