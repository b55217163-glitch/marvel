-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local ReplicatedStorage = game.ReplicatedStorage
		local shyGuy = ReplicatedStorage.Characters.SCPGuard.Remotes.ShyGuy
		local v6 = ReplicatedStorage.Characters.SCPGuard.Fx["SCP-106"]
		local blackHole = ReplicatedStorage.Characters.SCPGuard.Fx.BlackHole
		local scp106 = ReplicatedStorage.Characters.SCPGuard.AnimationsExtra.Scp106
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")

		local function Launch(parent)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(10000, 10000, 10000)
			bodyPosition.P = 100000
			bodyPosition.D = 3000
			bodyPosition.Position = (parent.CFrame * CFrame.new(0, 16, 0)).Position
			bodyPosition.Parent = parent
			debris:AddItem(bodyPosition, 0.5)
		end

		shyGuy.OnClientEvent:Connect(function(parent, p3)
			local clone2 = nil
			local clone = v6:Clone()

			debris:AddItem(clone, 5)
			clone.Parent = workspace

			for _, v in pairs(clone:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") or v:IsA("MeshPart") then
					task.spawn(function()
						if v.Name ~= "HumanoidRootPart" then
							v.Transparency = 1
						end
					end)
				end
			end

			clone.HumanoidRootPart.CFrame = p3.HumanoidRootPart.CFrame * CFrame.new(0, 0, 0)

			local weld: Weld = Instance.new("Weld")

			weld.Part0 = clone.FakeUpperTorso
			weld.Part1 = p3.UpperTorso

			local v21 = CFrame.Angles(0, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v21
			weld.Parent = parent
			clone.HumanoidRootPart.Anchored = true
			debris:AddItem(clone, 6)

			local v22 = animationService.LoadFresh(clone.Humanoid, scp106)

			v22.KeyframeReached:Connect(function(p4)
				if p4 == "Appear" then
					if p3.Head:FindFirstChild("LongScream") then
						p3.Head.LongScream:Play()
					end

					clone.Head.Appear:Play()

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v27 = workspace:Raycast(clone.HumanoidRootPart.Position, clone.HumanoidRootPart.CFrame.UpVector * -15, raycastParams)

					if v27 then
						clone2 = blackHole:Clone()
						clone2.Parent = workspace
						clone2.Position = v27.Position
						debris:AddItem(clone2, 8)
						tweenService:Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(7.553, 0.085, 8.337) }):Play()

						if clone2:FindFirstChild("Splash") then
							clone2.Splash:Play()
						end
					end
				end

				if p4 == "Grab" then
					clone.Head.Grab1:Play()
					clone.Head.Grab2:Play()

					if clone2 and clone2.Parent then
						if clone2:FindFirstChild("Hit") then
							clone2.Hit:Play()
						end

						if clone2:FindFirstChild("Splash") then
							clone2.Splash:Play()
						end

						if clone2:FindFirstChild("LiquidFog") then
							clone2.LiquidFog:Emit(8)
						end
					end

					if p3.Head:FindFirstChild("Percentage") then
						p3.Head.Percentage.Enabled = false
					end

					task.wait(0.4)

					if p3.Head:FindFirstChild("LongScream") then
						p3.Head.LongScream:Stop()
					end
				end

				if p4 == "Hi" then
					if clone2 and clone2.Parent then
						tweenService:Create(clone2, TweenInfo.new(0.8), { Size = Vector3.new(0, 0, 0) }):Play()

						local atmos = clone2:FindFirstChild("Atmos")

						if atmos then
							atmos.Enabled = false
						end

						local attachment = clone2:FindFirstChild("Attachment")

						if attachment and attachment:FindFirstChild("ParticleEmitter") then
							attachment.ParticleEmitter.Enabled = false
						end

						if clone2:FindFirstChild("SplashOut") then
							clone2.SplashOut:Play()
						end
					end

					for _, v in pairs(clone:GetDescendants()) do
						if v:IsA("BasePart") or v:IsA("MeshPart") then
							v.Anchored = true
						end
					end
				end

				if p4 == "Off" then
					weld:Destroy()
					p3.Humanoid:ChangeState(Enum.HumanoidStateType.Running)
					Launch(p3.HumanoidRootPart)

					if clone2:FindFirstChild("LiquidFog") then
						clone2.LiquidFog:Emit(8)
					end

					p3.Humanoid:ChangeState(Enum.HumanoidStateType.Running)
					task.wait(0.3)
					p3.Humanoid:ChangeState(Enum.HumanoidStateType.Running)

					if p3.Head:FindFirstChild("Percentage") then
						p3.Head.Percentage.Enabled = true
					end

					task.wait(2)

					if clone2 and clone2.Parent then
						clone2:Destroy()
						clone2 = nil
					end

					clone:Destroy()
				end

				if p4 == "Underground" then
					if clone2 and clone2.Parent and clone2:FindFirstChild("Laugh") then
						clone2.Laugh:Play()
					end

					local t1: {[any]: any} = { Transparency = 1 }

					for _, v in ipairs(clone:GetDescendants()) do
						if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") or v:IsA("MeshPart") then
							tweenService:Create(v, TweenInfo.new(0.5), t1):Play()
						end
					end

					if clone:FindFirstChild("Head") and clone.Head:FindFirstChild("Percentage") then
						clone.Head.Percentage.Enabled = false
					end
				end
			end)
			v22:Play()
			task.wait(0.2)

			for _, v in pairs(clone:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") or v:IsA("MeshPart") then
					task.spawn(function()
						if v.Name ~= "HumanoidRootPart" and v.Name ~= "FakeUpperTorso" then
							v.Transparency = 0
						end
					end)
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SCPGuard.OldMan", result)
	end
end)

return true
