-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local runService: RunService = game:GetService("RunService")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local players: Players = game:GetService("Players")
		local workspace: Workspace = game:GetService("Workspace")
		local LocalPlayer: Player = players.LocalPlayer
		local CurrentCamera: Camera = workspace.CurrentCamera
		local bloodBomb2: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat"):WaitForChild("Remotes"):WaitForChild("BloodBomb2")
		local bloodDrip = game.ReplicatedFirst.Effects.Blood.Fx.BloodDrip
		local bloodSplash = game.ReplicatedFirst.Effects.Blood.Fx.BloodSplash
		local bloodSmoke = game.ReplicatedFirst.Effects.Blood.Fx.BloodSmoke
		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		local t1: {[any]: any} = {
			Effects = true,
			Fx = true,
			VFX = true,
			Events = true,
			Event = true,
			Particles = true,
			Projectiles = true,
			Remotes = true
		}

		local function inRange(p1)
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v38 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position

			if not v38 then
				return true
			end

			local n1 = p1 - v38

			return n1:Dot(n1) <= 19600
		end
		local function legacyVelocityBomb2()
			local randomNumber = math.random(-15, 15)
			local randomNumber2 = math.random(2, 35)
			local vector3 = Vector3.new(randomNumber, randomNumber2, math.random(-15, 15))

			return vector3
		end

		local raycastParams = RaycastParams.new()

		raycastParams.IgnoreWater = true
		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.FilterDescendantsInstances = {}

		local u20 = nil

		local function refreshRayFilter()
			local map: Instance = workspace:FindFirstChild("Map")

			if map == u20 then
				return
			end

			u20 = map

			if u20 then
				raycastParams.FilterDescendantsInstances = { u20 }

				return
			end

			raycastParams.FilterDescendantsInstances = {}
		end

		refreshRayFilter()
		workspace.ChildAdded:Connect(function(child: Instance)
			if child.Name == "Map" then
				refreshRayFilter()
			end
		end)
		workspace.ChildRemoved:Connect(function(child: Instance)
			if child == u20 or child.Name == "Map" then
				refreshRayFilter()
			end
		end)

		local t2: {[any]: any} = {}

		local function getActiveDripCount()
			local n1: number = 0

			for iterKey in pairs(t2) do
				if iterKey.Parent then
					n1 += 1
				else
					t2[iterKey] = nil
				end
			end

			return n1
		end
		local function safeParentEffects(p4)
			p4.Parent = effects
		end
		local function emitSmoke(parent, p6)
			if not parent then
				return
			end

			local clone = bloodSmoke:Clone()

			clone.Parent = parent
			clone:Emit(5)
			debris:AddItem(clone, p6)
		end
		local function playSplashSfx(p7)
			local bloodSFX = p7:FindFirstChild("BloodSFX")

			if bloodSFX and bloodSFX:IsA("Sound") then
				bloodSFX.PlaybackSpeed = math.random(100, 130) / 100
				bloodSFX:Play()
			end
		end
		local function tweenSplashSize(p8, p9)
			local randomNumber = math.random(1, 3)

			tweenService:Create(p8, TweenInfo.new(0.3), {
				Size = if p9 == "torso" then if randomNumber == 1 then Vector3.new(0.9, 0.2, 0.9) else if randomNumber == 2 then Vector3.new(4, 0.2, 4) else Vector3.new(2, 0.2, 2) else if randomNumber == 1 then Vector3.new(0.5, 0.2, 0.5) else if randomNumber == 2 then Vector3.new(0.8, 0.2, 0.8) else Vector3.new(2, 0.2, 2)
			}):Play()

			local taskDelay = task.delay
			local randomNumber3 = math.random(8, 12)

			taskDelay(randomNumber3, function()
				if p8 and p8.Parent then
					tweenService:Create(p8, TweenInfo.new(2), { Size = Vector3.new(0, 0, 0) }):Play()
					debris:AddItem(p8, 2.1)
				end
			end)
		end
		local function makeSplash(p10, p11, p12, p13)
			local clone = bloodSplash:Clone()

			clone.Size = Vector3.new(0, 0, 0)
			clone.Parent = effects

			local v64 = CFrame.lookAt(p10, p10 + p11)
			local v65 = CFrame.Angles(-1.5707963267948966, 0, 0)

			clone.CFrame = v64 * v65
			debris:AddItem(clone, p13)
			tweenSplashSize(clone, p12)

			local bloodSFX = clone:FindFirstChild("BloodSFX")

			if bloodSFX and bloodSFX:IsA("Sound") then
				bloodSFX.PlaybackSpeed = math.random(100, 130) / 100
				bloodSFX:Play()
			end
		end
		local function isBlacklistedHit(p14)
			if p14:IsDescendantOf(effects) then
				return true
			end

			local v68 = p14

			while v68 and v68 ~= u20 do
				if t1[v68.Name] then
					return true
				end

				v68 = v68.Parent
			end

			return false
		end
		local function validGroundHit(p15)
			local instance = p15.Instance

			if not instance then
				return false
			end

			if not u20 then
				return false
			end

			if not instance:IsDescendantOf(u20) then
				return false
			end

			local u71

			if instance:IsDescendantOf(effects) then
				u71 = true
			else
				local v72 = instance

				while v72 and v72 ~= u20 do
					if t1[v72.Name] then
						u71 = true

						break
					end

					v72 = v72.Parent
				end

				if not v72 or v72 == u20 then
					u71 = false
				end
			end

			if u71 then
				return false
			end

			if not instance.Anchored then
				return false
			end

			if not instance.CanCollide then
				return false
			end

			return true
		end
		local function spawnDrip(p16, p17, p18)
			local clone = bloodDrip:Clone()

			clone.Parent = effects

			local v77 = p16.Position
			local vector3 = Vector3.new(0, p18 or 0, 0)
			local n1 = v77 + vector3

			clone.CFrame = p16.CFrame
			clone.Position = n1
			clone.Anchored = false
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.CastShadow = false
			clone.Massless = true
			clone.Transparency = 0

			local randomNumber = math.random(-15, 15)
			local randomNumber4 = math.random(2, 35)

			clone.AssemblyLinearVelocity = Vector3.new(randomNumber, randomNumber4, math.random(-15, 15))
			debris:AddItem(clone, 12)

			local v82 = os.clock()

			t2[clone] = {
				lastPos = n1,
				expireAt = v82 + 12 + 0.1,
				preset = p17,
				splashLife = if p17 == "torso" then 20 else 10
			}
		end

		local n1: number = 0

		runService.Heartbeat:Connect(function(deltaTime: number)
			n1 += deltaTime

			if n1 < 0.03333333333333333 then
				return
			end

			n1 -= 0.03333333333333333

			if not u20 then
				return
			end

			local v84 = os.clock()

			for k, v in pairs(t2) do
				if not k or not k.Parent or v84 > v.expireAt then
					t2[k] = nil
				else
					local kPosition = k.Position
					local v88 = v.lastPos
					local n2 = kPosition - v88
					local vectorValue

					if n2:Dot(n2) < 0.0025 then
						v88 = kPosition
						vectorValue = Vector3.new(0, -14, 0)
					else
						vectorValue = n2 + Vector3.new(0, -0.75, 0)
					end

					n2 = workspace:Raycast(v88, vectorValue, raycastParams)
					v.lastPos = kPosition

					if n2 then
						local instance = n2.Instance
						local u92

						if not instance or not u20 or not instance:IsDescendantOf(u20) then
							u92 = false
						else
							local u93

							if instance:IsDescendantOf(effects) then
								u93 = true
							else
								local v94 = instance

								while v94 and v94 ~= u20 do
									if t1[v94.Name] then
										u93 = true

										break
									else
										v94 = v94.Parent
									end
								end

								if not v94 or v94 == u20 then
									u93 = false
								end
							end

							u92 = if u93 then false else if not instance.Anchored then false else not not instance.CanCollide
						end

						if u92 then
							t2[k] = nil
							k.Anchored = true
							k.Transparency = 1
							makeSplash(n2.Position, n2.Normal, v.preset, v.splashLife)
							debris:AddItem(k, 0.25)
						end
					end
				end
			end
		end)

		local function BloodTorso(p20, p21)
			if not p20 then
				return
			end

			local upperTorso = p20:FindFirstChild("UpperTorso")

			if not upperTorso or not upperTorso:IsA("BasePart") then
				return
			end

			local upperTorsoPosition = upperTorso.Position
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v101 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position
			local u103

			if not v101 then
				u103 = true
			else
				local n1 = upperTorsoPosition - v101

				u103 = n1:Dot(n1) <= 19600
			end

			if not u103 then
				return
			end

			if upperTorso then
				local clone = bloodSmoke:Clone()

				clone.Parent = upperTorso
				clone:Emit(5)
				debris:AddItem(clone, 12)
			end

			local numberValue = tonumber(p21) or 0

			if numberValue <= 0 then
				return
			end

			for _ = 1, numberValue do
				spawnDrip(upperTorso, "torso", 2)
			end
		end
		local function BloodPartFx(p22, p23, parent)
			if not p22 or not parent or not parent:IsA("BasePart") then
				return
			end

			local parentPosition = parent.Position
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v113 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position
			local u115

			if not v113 then
				u115 = true
			else
				local n1 = parentPosition - v113

				u115 = n1:Dot(n1) <= 19600
			end

			if not u115 then
				return
			end

			if parent then
				local clone = bloodSmoke:Clone()

				clone.Parent = parent
				clone:Emit(5)
				debris:AddItem(clone, 2)
			end

			local numberValue = tonumber(p23) or 0

			if numberValue <= 0 then
				return
			end

			for _ = 1, numberValue do
				spawnDrip(parent, "other", 0)
			end
		end

		bloodBomb2.OnClientEvent:Connect(function(p25, p26, _, p28)
			if not p25 or not u20 then
				return
			end

			local numberValue: number? = tonumber(p26)
			local floored = math.floor(numberValue or 0)
			local v125 = math.clamp(floored, 0, 25)
			local n1: number = 0

			for iterKey in pairs(t2) do
				if iterKey.Parent then
					n1 += 1
				else
					t2[iterKey] = nil
				end
			end

			local v128 = math.max(0, 60 - n1)
			local v129 = math.min(v125, v128)

			if v129 <= 0 then
				return
			end

			if p28 and p28:IsA("BasePart") then
				BloodPartFx(p25, v129, p28)

				return
			end

			BloodTorso(p25, v129)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "BloodBombLong", result)
	end
end)

return true
