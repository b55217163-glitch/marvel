-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local counter = game.ReplicatedStorage.Characters.Zoom.Remotes.Counter
		local tweenService: TweenService = game:GetService("TweenService")
		local v8 = game.ReplicatedStorage.Characters.Zoom.AnimationsExtra.Counter
		local hitCounter = game.ReplicatedStorage.Characters.Zoom.AnimationsExtra.HitCounter
		local attachment = game.ReplicatedStorage.Characters.LandPart.Attachment
		local rocks = game.ReplicatedStorage.Characters.LandPart.Rocks
		local v12 = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.Attachment
		local bloodUpperTorso = game.ReplicatedStorage.Characters.Peacemaker.Fx.BloodUpperTorso
		local v14 = game.ReplicatedStorage.Characters.HitAnimations.TheBatman.Counter
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local tweenService2: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock2(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v29 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v31 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v31, 0)
				local n2 = v29 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v34 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v34 then
					local instance = v34.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v40 = mathRandom(-180, 180)
					local v41 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v40, v41, mathRandom(-180, 180))
					part.Position = p1.Position

					local v42 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v42, { Position = v34.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v68 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v68, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v69 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v69, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v47 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v49 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v49, 0)
				local n2 = v47 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v52 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v52 then
					local instance = v52.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v58 = mathRandom(-180, 180)
					local v59 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v58, v59, mathRandom(-180, 180))
					part.Position = p2.Position

					local v60 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v60, { Position = v52.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v74 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v74, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v75 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v75, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local groundhit = game.ReplicatedStorage.Characters.Wanda.Fx.Groundhit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		counter.OnClientEvent:Connect(function(p3, player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if player.Character:FindFirstChild("Values") then
				local v64 = animationService.GetTrack(p3.Humanoid, hitCounter)
				local v65 = animationService.LoadFresh(player.Character.Humanoid, v8)

				animationService.ConnectMarker(v65, "Start", function(_)
					Character.Head.CounterVC:Play()

					if Character:FindFirstChild("FakeHead") and Character.FakeHead:FindFirstChild("ScreamingFace") then
						tweenService:Create(Character.FakeHead.ScreamingFace, TweenInfo.new(0.1), { Transparency = 0 }):Play()
						tweenService:Create(Character.FakeHead.NormalFace, TweenInfo.new(0.1), { Transparency = 1 }):Play()
						task.wait(3)
						tweenService:Create(Character.FakeHead.NormalFace, TweenInfo.new(0.1), { Transparency = 0 }):Play()
						tweenService:Create(Character.FakeHead.ScreamingFace, TweenInfo.new(0.1), { Transparency = 1 }):Play()
					end
				end)
				animationService.ConnectMarker(v65, "Slam", function(_)
					TestRock2(Character.HumanoidRootPart)
					TestRock3(Character.HumanoidRootPart)
					Character.HumanoidRootPart.GroundSlam:Play()
					Character.Head.HeavyHit:Play()

					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspace.Map }

					local v81 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -8, raycastParams)

					if v81 == nil then
						return
					end

					local InstanceColor = v81.Instance.Color
					local clone = groundhit:Clone()

					clone.Parent = workspace
					clone.Rocks.Color = ColorSequence.new(InstanceColor)
					clone.Smoke.Color = ColorSequence.new(InstanceColor)
					clone.Rocks:Emit(10)
					clone.Smoke:Emit(10)
					clone.Position = v81.Position
					game.Debris:AddItem(clone, 5)
				end)
				animationService.ConnectMarker(v65, "Vibrate", function(_)
					Character.FakeUpperTorso.VibAt.Vib.Enabled = true

					if Character.FakeUpperTorso.VibAt:FindFirstChild("Bats") then
						Character.FakeUpperTorso.VibAt.Bats.Enabled = true
						Character.FakeUpperTorso.VibAt.BatsLight.Enabled = true
					end

					tweenService:Create(Character.RightHand, TweenInfo.new(0.3), { Transparency = 0.2 }):Play()
					tweenService:Create(Character.RightLowerArm, TweenInfo.new(0.3), { Transparency = 0.2 }):Play()
					tweenService:Create(Character.RightUpperArm, TweenInfo.new(0.3), { Transparency = 0.2 }):Play()

					if Character:FindFirstChild("Claws2") then
						tweenService:Create(Character.Claws2, TweenInfo.new(0.3), { Transparency = 0.2 }):Play()
					end

					local n1: number = 23

					while n1 > 0 do
						task.wait(0.1)
						n1 -= 1

						local clone = neckExplode:Clone()

						clone.Parent = p3.UpperTorso
						clone.Bl1:Emit(2)
						clone.Bl2:Emit(4)
						game.Debris:AddItem(clone, 1.5)

						for _ = 1, 4 do
							local clone2 = bloodDrip:Clone()

							clone2.Parent = Character

							local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

							clone2.Parent = Character
							clone2.CFrame = p3.UpperTorso.CFrame
							clone2.LocalScript.Disabled = false
							bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

							local randomNumber = math.random(-2, 2)
							local randomNumber2 = math.random(-2, 2)

							bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 15
							game.Debris:AddItem(clone2, 3)
							game.Debris:AddItem(bodyVelocity, 0.05)
						end
					end
				end)
				animationService.ConnectMarker(v65, "VibrateEnd", function(_)
					Character.FakeUpperTorso.VibAt.Vib.Enabled = false
					tweenService:Create(Character.RightHand, TweenInfo.new(0.3), { Transparency = 0 }):Play()
					tweenService:Create(Character.RightLowerArm, TweenInfo.new(0.3), { Transparency = 0 }):Play()
					tweenService:Create(Character.RightUpperArm, TweenInfo.new(0.3), { Transparency = 0 }):Play()

					if Character:FindFirstChild("Claws2") then
						tweenService:Create(Character.Claws2, TweenInfo.new(0.3), { Transparency = 0 }):Play()
					end

					if Character.FakeUpperTorso.VibAt:FindFirstChild("Bats") then
						Character.FakeUpperTorso.VibAt.Bats.Enabled = false
						Character.FakeUpperTorso.VibAt.BatsLight.Enabled = false
					end
				end)
				v65:Play()
				v64:Play()
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Zoom.Counter", result)
	end
end)

return true
