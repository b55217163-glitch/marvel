-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local choke = game.ReplicatedStorage.Characters.Zoom.Remotes.Choke
		local tweenService: TweenService = game:GetService("TweenService")
		local v8 = game.ReplicatedStorage.Characters.Zoom.AnimationsExtra.Choke
		local choke2 = game.ReplicatedStorage.Characters.Zoom.AnimationsExtra.Choke2
		local chokeHit = game.ReplicatedStorage.Characters.Zoom.AnimationsExtra.ChokeHit

		choke.OnClientEvent:Connect(function(p1, player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if player.Character:FindFirstChild("Values") then
				local v14 = animationService.GetTrack(p1.Humanoid, chokeHit)
				local v15 = animationService.GetTrack(player.Character.Humanoid, v8)
				local v16 = animationService.GetTrack(player.Character.Humanoid, choke2)

				if not Character:FindFirstChild("Movie") and not Character:FindFirstChild("Bonnie") then
					v15:Play()
				else
					v16:Play()
				end

				v14:Play()
				Character.Head.ChokeVC:Play()

				if Character.Values:FindFirstChild("BlackFlash") then
					if not Character:FindFirstChild("RippedMask") or Character.RippedMask.Transparency == 0 then
						tweenService:Create(Character.FakeHead.ScreamingFace, TweenInfo.new(0.1), { Transparency = 0 }):Play()
						tweenService:Create(Character.FakeHead.NormalFace, TweenInfo.new(0.1), { Transparency = 1 }):Play()
					end

					task.wait(2)

					if not Character:FindFirstChild("RippedMask") or Character.RippedMask.Transparency == 0 then
						tweenService:Create(Character.FakeHead.NormalFace, TweenInfo.new(0.1), { Transparency = 0 }):Play()
						tweenService:Create(Character.FakeHead.ScreamingFace, TweenInfo.new(0.1), { Transparency = 1 }):Play()
					end
				end

				if Character.Head:FindFirstChild("Bats") then
					Character.Head.Bats.Enabled = true
					task.wait(2)
					Character.Head.Bats.Enabled = false
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Zoom.MoveFourChoke", result)
	end
end)

return true
