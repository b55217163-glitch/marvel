-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local lighting: Lighting = game:GetService("Lighting")
		local tweenService: TweenService = game:GetService("TweenService")
		local LocalPlayer: Player = players.LocalPlayer
		local CurrentCamera: Camera = workspace.CurrentCamera
		local impactFrame: Instance = replicatedStorage:WaitForChild("Remotes"):WaitForChild("ImpactFrame")
		local playerGui: Instance = LocalPlayer:WaitForChild("PlayerGui")
		local impactFrameGui = playerGui:FindFirstChild("ImpactFrameGui")

		if not impactFrameGui then
			impactFrameGui = Instance.new("ScreenGui")
			impactFrameGui.Name = "ImpactFrameGui"
			impactFrameGui.IgnoreGuiInset = true
			impactFrameGui.ResetOnSpawn = false
			impactFrameGui.DisplayOrder = 999999
			impactFrameGui.Parent = playerGui
		end

		local whiteBG = impactFrameGui:FindFirstChild("WhiteBG")

		if not whiteBG then
			whiteBG = Instance.new("Frame")
			whiteBG.Name = "WhiteBG"
			whiteBG.Size = UDim2.fromScale(1, 1)
			whiteBG.Position = UDim2.fromScale(0, 0)
			whiteBG.BackgroundColor3 = Color3.new(1, 1, 1)
			whiteBG.BackgroundTransparency = 1
			whiteBG.BorderSizePixel = 0
			whiteBG.ZIndex = 999999
			whiteBG.Parent = impactFrameGui
		end

		local flash = impactFrameGui:FindFirstChild("Flash")

		if not flash then
			flash = Instance.new("Frame")
			flash.Name = "Flash"
			flash.Size = UDim2.fromScale(1, 1)
			flash.Position = UDim2.fromScale(0, 0)
			flash.BackgroundColor3 = Color3.new(1, 1, 1)
			flash.BackgroundTransparency = 1
			flash.BorderSizePixel = 0
			flash.ZIndex = 1000000
			flash.Parent = impactFrameGui
		end

		local function getOrCreateCC()
			local impactFrame_CC = lighting:FindFirstChild("ImpactFrame_CC")

			if not impactFrame_CC then
				impactFrame_CC = Instance.new("ColorCorrectionEffect")
				impactFrame_CC.Name = "ImpactFrame_CC"
				impactFrame_CC.Parent = lighting
			end

			return impactFrame_CC
		end

		local n1: number = 0

		local function makeSilhouette(parent)
			if not parent then
				return nil
			end

			local impactSilhouette = parent:FindFirstChild("ImpactSilhouette")

			if impactSilhouette then
				impactSilhouette:Destroy()
			end

			local impactSilhouette: Highlight = Instance.new("Highlight")

			impactSilhouette.Name = "ImpactSilhouette"
			impactSilhouette.Adornee = parent
			impactSilhouette.Parent = parent
			impactSilhouette.DepthMode = Enum.HighlightDepthMode.Occluded
			impactSilhouette.FillColor = Color3.new(0, 0, 0)
			impactSilhouette.OutlineColor = Color3.new(0, 0, 0)
			impactSilhouette.FillTransparency = 1
			impactSilhouette.OutlineTransparency = 1

			return impactSilhouette
		end
		local function fadeDestroyHighlight(p2, p3)
			if not p2 or not p2.Parent then
				return
			end

			local tweenInfo = TweenInfo.new(p3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local v26: Tween = tweenService:Create(p2, tweenInfo, { FillTransparency = 1, OutlineTransparency = 1 })

			v26:Play()
			v26.Completed:Once(function()
				if p2 then
					p2:Destroy()
				end
			end)
		end
		local function playImpact(p4, p5)
			n1 += 1

			local v29: number = n1
			local impactFrame_CC = lighting:FindFirstChild("ImpactFrame_CC")

			if not impactFrame_CC then
				impactFrame_CC = Instance.new("ColorCorrectionEffect")
				impactFrame_CC.Name = "ImpactFrame_CC"
				impactFrame_CC.Parent = lighting
			end

			local v31 = makeSilhouette(p4)
			local v32 = makeSilhouette(p5)

			whiteBG.BackgroundTransparency = 1
			flash.BackgroundTransparency = 1
			impactFrame_CC.Saturation = 0
			impactFrame_CC.Contrast = 0
			impactFrame_CC.Brightness = 0
			impactFrame_CC.TintColor = Color3.new(1, 1, 1)

			if v31 then
				v31.FillTransparency = 1
				v31.OutlineTransparency = 1
			end

			if v32 then
				v32.FillTransparency = 1
				v32.OutlineTransparency = 1
			end

			local v33 = whiteBG
			local tweenInfo = TweenInfo.new(0.035, Enum.EasingStyle.Linear)

			tweenService:Create(v33, tweenInfo, { BackgroundTransparency = 0 }):Play()

			if v31 then
				local tweenInfo2 = TweenInfo.new(0.03, Enum.EasingStyle.Linear)

				tweenService:Create(v31, tweenInfo2, { FillTransparency = 0, OutlineTransparency = 0 }):Play()
			end

			if v32 then
				local tweenInfo3 = TweenInfo.new(0.03, Enum.EasingStyle.Linear)

				tweenService:Create(v32, tweenInfo3, { FillTransparency = 0, OutlineTransparency = 0 }):Play()
			end

			local tweenInfo4 = TweenInfo.new(0.04, Enum.EasingStyle.Linear)

			tweenService:Create(impactFrame_CC, tweenInfo4, {
				Saturation = -1,
				Contrast = 3,
				Brightness = 0.2,
				TintColor = Color3.new(1, 1, 1)
			}):Play()

			local currentCameraFieldOfView: number = CurrentCamera.FieldOfView

			CurrentCamera.FieldOfView = currentCameraFieldOfView + 10

			local tweenInfo5 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			tweenService:Create(CurrentCamera, tweenInfo5, { FieldOfView = currentCameraFieldOfView }):Play()
			task.delay(0.08, function()
				if v29 ~= n1 then
					if v31 then
						v31:Destroy()
					end

					if v32 then
						v32:Destroy()
					end

					return
				end

				local v42 = whiteBG
				local tweenInfo6 = TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				tweenService:Create(v42, tweenInfo6, { BackgroundTransparency = 1 }):Play()

				if v31 then
					local tweenInfo7 = TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					tweenService:Create(v31, tweenInfo7, { FillTransparency = 1, OutlineTransparency = 1 }):Play()
				end

				if v32 then
					local tweenInfo8 = TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					tweenService:Create(v32, tweenInfo8, { FillTransparency = 1, OutlineTransparency = 1 }):Play()
				end
			end)
			task.delay(0.14, function()
				if v29 ~= n1 then
					if v31 then
						v31:Destroy()
					end

					if v32 then
						v32:Destroy()
					end

					return
				end

				flash.BackgroundTransparency = 0.15

				local v46 = flash
				local tweenInfo9 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				tweenService:Create(v46, tweenInfo9, { BackgroundTransparency = 1 }):Play()
				fadeDestroyHighlight(v31, 0.06)
				fadeDestroyHighlight(v32, 0.06)
			end)
			task.delay(0.14, function()
				if v29 ~= n1 then
					return
				end

				local tweenInfo10 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				tweenService:Create(impactFrame_CC, tweenInfo10, {
					Saturation = 0,
					Contrast = 0,
					Brightness = 0,
					TintColor = Color3.new(1, 1, 1)
				}):Play()
			end)
		end

		impactFrame.OnClientEvent:Connect(function(p6, p7)
			playImpact(p6, p7)
		end)
	end)

	if not ok then
		warn("[OldClientEffects2Module] failed:", "ScreenEffects.ImpactFrame", result)
	end
end)

return true
