-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.FinisherHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local Workspace: Workspace = game.Workspace

		game.ReplicatedStorage.Characters.Patrick.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			p2:WaitForChild("Humanoid", 5)

			local v15 = animationService.LoadFresh(humanoid, finisher)
			local v16 = animationService.GetTrack(p2.Humanoid, finisherHit)

			if Character:FindFirstChild("AxeHead") then
				Character.AxeHead.Transparency = 0
			end

			Character.Axe.Transparency = 0

			local clone = neckExplode:Clone()

			clone.Parent = p2.Head
			Character.HumanoidRootPart.TheNews:Play()
			v15.KeyframeReached:Connect(function(p3)
				if p3 == "Scream" then
					game.TweenService:Create(Character.Head.ChainsawScream, TweenInfo.new(0.2), { Volume = 0 }):Play()
					game.TweenService:Create(Character.Head.Simply, TweenInfo.new(0.2), { Volume = 0 }):Play()
					Character.HumanoidRootPart.Scream1:Play()
				end

				if p3 == "Swing1" then
					Character.HumanoidRootPart.Swing1:Play()
				end

				if p3 == "Swing2" then
					Character.HumanoidRootPart.Swing2:Play()
				end

				if p3 == "Swing3" then
					Character.HumanoidRootPart.Swing3:Play()
				end

				if p3 == "Hit1" then
					if p2.Head:FindFirstChild("LongScream") then
						p2.Head.LongScream:Play()
					end

					Character.HumanoidRootPart.Hitsfx1:Play()
					v16:Play()
					clone.Bl1:Emit(10)
					clone.Bl2:Emit(30)

					for _ = 1, 40 do
						local clone2 = bloodDrip:Clone()

						clone2.Parent = Character
						clone2.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

						clone2.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber = math.random(-2, 2)
						local randomNumber2 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 10
						game.Debris:AddItem(clone2, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					task.wait(0.1)
					game.TweenService:Create(Character.FakeHead.Blood, TweenInfo.new(0.2), { Transparency = 0 }):Play()
				end

				if p3 == "Hit2" then
					Character.HumanoidRootPart.Hitsfx2:Play()
					clone.Bl1:Emit(5)
					clone.Bl2:Emit(15)

					for _ = 1, 12 do
						local randomNumber = math.random(15, 30)
						local clone3 = bloodDrip:Clone()

						clone3.Parent = Character
						clone3.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

						clone3.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber3 = math.random(-2, 2)
						local randomNumber4 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber3, randomNumber4, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone3, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end

				if p3 == "Hit3" then
					Character.HumanoidRootPart.Hitsfx3:Play()
					clone.Bl1:Emit(5)
					clone.Bl2:Emit(15)

					for _ = 1, 25 do
						local randomNumber = math.random(15, 30)
						local clone4 = bloodDrip:Clone()

						clone4.Parent = Character
						clone4.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone4)

						clone4.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber5 = math.random(-2, 2)
						local randomNumber6 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber5, randomNumber6, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone4, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)

						if p2.Head:FindFirstChild("LongScream") then
							p2.Head.LongScream:Stop()
						end
					end
				end

				if p3 == "PullOut" then
					Character.HumanoidRootPart.PullOut:Play()

					for _ = 1, 10 do
						local randomNumber = math.random(15, 30)
						local clone5 = bloodDrip:Clone()

						clone5.Parent = Character
						clone5.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone5)

						clone5.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber7 = math.random(-2, 2)
						local randomNumber8 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber7, randomNumber8, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone5, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end
			end)
			v15:Play()
			task.wait(0.1)
			Character.Axe.Transparency = 0

			if Character:FindFirstChild("AxeHead") then
				Character.AxeHead.Transparency = 0
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Patrick.Finisher", result)
	end
end)

return true
