-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local players: Players = game:GetService("Players")
		local debris: Debris = game:GetService("Debris")
		local t1: {[any]: any} = {}

		local function setHandFx(p1, enabled)
			for _, v in ipairs({ "RightHand", "LeftHand" }) do
				local v = p1:FindFirstChild(v)

				if v then
					for _, iterValue in ipairs(v:GetDescendants()) do
						if iterValue.Name == "SpeedTrail" then
							if iterValue:IsA("Trail") or iterValue:IsA("ParticleEmitter") then
								iterValue.Enabled = enabled
							end
						elseif (iterValue.Name == "Elect1" or iterValue.Name == "Elect2") and iterValue:IsA("ParticleEmitter") then
							iterValue.Enabled = enabled
						end
					end
				end
			end
		end
		local function stopLocalActionAndMovementAnims(character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local animator = humanoid:FindFirstChildOfClass("Animator")

			if not animator then
				return
			end

			for _, v in ipairs(animator:GetPlayingAnimationTracks()) do
				if v and v.IsPlaying and (v.Priority == Enum.AnimationPriority.Action or v.Priority == Enum.AnimationPriority.Action2 or v.Priority == Enum.AnimationPriority.Action3 or v.Priority == Enum.AnimationPriority.Action4 or v.Priority == Enum.AnimationPriority.Movement) then
					pcall(function()
						v:Stop(0.3)
					end)
				end
			end
		end
		local function playBarrageSfxOnce(p4)
			local humanoidRootPart = p4:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local barrageSfx = humanoidRootPart:FindFirstChild("BarrageSfx")

			if not barrageSfx or not barrageSfx:IsA("Sound") then
				return
			end

			local clone = barrageSfx:Clone()

			if p4:FindFirstChild("TheFlashCW") then
				clone.PlaybackSpeed = math.random(400, 430) / 100
			else
				clone.PlaybackSpeed = math.random(100, 140) / 100
			end

			clone.Parent = humanoidRootPart
			clone:Play()
			debris:AddItem(clone, 2)
		end
		local function stopAllBarrageSfx(p5)
			local humanoidRootPart = p5:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			for _, v in ipairs(humanoidRootPart:GetChildren()) do
				if v:IsA("Sound") and v.Name == "BarrageSfx" then
					v:Stop()
					v:Destroy()
				end
			end
		end

		game:GetService("ReplicatedStorage").Characters.TheFlashCw.Remotes:WaitForChild("Barrage").OnClientEvent:Connect(function(player, p7)
			local Character = player.Character

			if not Character then
				return
			end

			if Character:FindFirstChild("Amazo") then
				return
			end

			t1[player] = (t1[player] or 0) + 1

			local v33 = t1[player]

			if p7 == false then
				setHandFx(Character, false)
				stopAllBarrageSfx(Character)

				if player == players.LocalPlayer then
					stopLocalActionAndMovementAnims(Character)
				end

				return
			end

			setHandFx(Character, true)
			task.spawn(function()
				local n1: number = 9

				while n1 > 0 do
					if t1[player] ~= v33 then
						return
					end

					if player.Character ~= Character then
						return
					end

					if player.Character ~= Character then
						return
					end

					playBarrageSfxOnce(Character)
					task.wait(0.1)

					if t1[player] ~= v33 then
						return
					end

					if player.Character ~= Character then
						return
					end

					playBarrageSfxOnce(Character)
					n1 -= 1
				end

				if t1[player] == v33 then
					setHandFx(Character, false)
					stopAllBarrageSfx(Character)
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.Barrage", result)
	end
end)

return true
