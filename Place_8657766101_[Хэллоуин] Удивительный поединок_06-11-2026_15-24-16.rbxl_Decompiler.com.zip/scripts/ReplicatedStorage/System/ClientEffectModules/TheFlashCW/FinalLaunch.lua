-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local lungeCrack = game.ReplicatedStorage.Characters.Gigachad.Fx.LungeCrack
		local smoke = game.ReplicatedStorage.Characters.Gigachad.Fx.Smoke
		local rock = game.ReplicatedStorage.Characters.Gigachad.Fx.Rock

		game.ReplicatedStorage.Characters.TheFlashCw.Remotes.FinalLaunch.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			local v11 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

			if v11 == nil then
				return
			end

			local InstanceColor = v11.Instance.Color
			local clone = lungeCrack:Clone()

			clone.Parent = workspace
			clone.Position = v11.Position

			local randomNumber = math.random(-180, 180)

			clone.Orientation = Vector3.new(0, randomNumber, 0)
			game.Debris:AddItem(clone, 10)
			clone.Boom:Play()

			local clone2 = smoke:Clone()

			clone2.Parent = clone
			clone2.Color = ColorSequence.new(InstanceColor)
			clone2:Emit(20)
			game.Debris:AddItem(clone2, 7)

			local clone3 = rock:Clone()

			clone3.Parent = clone
			clone3.Color = ColorSequence.new(InstanceColor)
			clone3:Emit(30)
			game.Debris:AddItem(clone3, 7)
			game.TweenService:Create(clone.Decal, TweenInfo.new(5), { Transparency = 1 }):Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.FinalLaunch", result)
	end
end)

return true
