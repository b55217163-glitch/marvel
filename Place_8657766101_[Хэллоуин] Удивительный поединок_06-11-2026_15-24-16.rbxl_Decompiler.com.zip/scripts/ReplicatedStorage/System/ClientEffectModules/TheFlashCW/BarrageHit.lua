-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local LocalPlayer: Player = players.LocalPlayer
		local oneHitAt = replicatedStorage.Characters.TheFlashCw.Fx.OneHitAt
		local barrageHit = replicatedStorage.Characters.TheFlashCw.Fx.BarrageHit
		local barrageHit1 = replicatedStorage.Characters.TheFlashCw.AnimationsExtra.BarrageHit1
		local barrageHit2 = replicatedStorage.Characters.TheFlashCw.AnimationsExtra.BarrageHit2

		local function disableNoisyStuff(p1)
			if not p1:IsA("ParticleEmitter") and not p1:IsA("Trail") and not p1:IsA("Beam") then
				if not p1:IsA("PointLight") and not p1:IsA("SpotLight") and not p1:IsA("SurfaceLight") then
					if not p1:IsA("BillboardGui") and not p1:IsA("SurfaceGui") then
						if p1:IsA("Sound") then
							p1:Stop()
							p1.Playing = false

							return
						end

						if p1:IsA("Constraint") then
							p1.Enabled = false

							return
						end

						if p1:IsA("BodyMover") then
							p1:Destroy()

							return
						end

						if not p1:IsA("AlignPosition") and not p1:IsA("AlignOrientation") then
							if not p1:IsA("Script") and not p1:IsA("LocalScript") then
								return
							end

							p1.Disabled = true

							return
						end

						p1.Enabled = false

						return
					end

					p1.Enabled = false

					return
				end

				p1.Enabled = false

				return
			end

			p1.Enabled = false
		end
		local function anchorClone(p2)
			for _, v in ipairs(p2:GetDescendants()) do
				if v:IsA("BasePart") then
					v.Anchored = true
					v.CanCollide = false
					v.CanTouch = false
					v.CanQuery = false
					v.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)

					if v.Name == "HumanoidRootPart" then
						v.Size = Vector3.new(0, 0, 0)
					end
				end
			end
		end
		local function hideNameplates(character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if humanoid then
				humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			end
		end

		local t1: {[any]: any} = {
			Spawn = function(p4, p5)
				if not p4 or not p4:IsA("Model") then
					return
				end

				if not p4:FindFirstChild("HumanoidRootPart") then
					return
				end

				local t2 = p5 or {}
				local v26 = t2.duration or 0.5
				local parent = t2.parent or workspace
				local clone = p4:Clone()

				clone.Name = p4.Name .. "_AfterImage"
				clone.Parent = parent
				clone:PivotTo(p4:GetPivot())

				local iframe: BoolValue = Instance.new("BoolValue")

				iframe.Name = "Iframe"
				iframe.Parent = clone

				local humanoid = clone:FindFirstChildOfClass("Humanoid")

				if humanoid then
					humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				end

				anchorClone(clone)

				for _, v in ipairs(clone:GetDescendants()) do
					disableNoisyStuff(v)
				end

				local tweenInfo = TweenInfo.new(v26, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

				for _, v in ipairs(clone:GetDescendants()) do
					if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
						tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
					end
				end

				debris:AddItem(clone, v26 + 0.05)

				return clone
			end
		}

		replicatedStorage.Characters.TheFlashCw.Remotes.BarrageHit.OnClientEvent:Connect(function(character, p7)
			if typeof(character) == "Instance" then
				if not character:IsA("Model") then
					return
				end

				local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
				local humanoid = character:FindFirstChildOfClass("Humanoid")

				if humanoid and humanoidRootPart then
					local v40 = typeof(p7) == "Instance" and p7:IsA("Model") and p7 or LocalPlayer.Character

					if v40 then
						t1.Spawn(v40, { duration = 0.5 })
					end

					local clone = oneHitAt:Clone()

					clone.Parent = humanoidRootPart

					if clone:FindFirstChild("Shock") then
						clone.Shock:Emit(1)
					end

					if clone:FindFirstChild("ShockwaveMiddle") then
						clone.ShockwaveMiddle:Emit(1)
					end

					if clone:FindFirstChild("Sparks") then
						clone.Sparks:Emit(8)
					end

					if clone:FindFirstChild("SparksCircle") then
						clone.SparksCircle:Emit(8)
					end

					debris:AddItem(clone, 1)

					local v42

					if math.random(1, 2) == 1 then
						v42 = animationService.GetTrack(humanoid, barrageHit1)
					else
						v42 = animationService.GetTrack(humanoid, barrageHit2)
					end

					v42:Play()

					local clone2 = barrageHit:Clone()

					clone2.PlaybackSpeed = math.random(10, 20) / 10
					clone2.Parent = humanoidRootPart
					clone2:Play()
					debris:AddItem(clone2, 2)

					return
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.BarrageHit", result)
	end
end)

return true
