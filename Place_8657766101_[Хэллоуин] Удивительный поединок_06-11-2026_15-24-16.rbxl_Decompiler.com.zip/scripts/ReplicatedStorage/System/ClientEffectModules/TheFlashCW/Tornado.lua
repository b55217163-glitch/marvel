-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local tweenService: TweenService = game:GetService("TweenService")
		local runService: RunService = game:GetService("RunService")
		local debris: Debris = game:GetService("Debris")
		local mirrage = game:GetService("ReplicatedStorage").Characters.TheFlashCw.Remotes.Mirrage
		local effects: Instance = workspace:WaitForChild("Effects")
		local mathRandom = math.random

		local function makeRayParams()
			local map: Instance = workspace:FindFirstChild("Map")

			if not map then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function copySurfaceDetails(p1, parent)
			for _, v in ipairs(p1:GetChildren()) do
				if v:IsA("Decal") or v:IsA("Texture") then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function fadeSurfaceDetails(p3, p4)
			for _, v in ipairs(p3:GetChildren()) do
				if v:IsA("Decal") or v:IsA("Texture") then
					local tweenInfo = TweenInfo.new(p4)

					tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
				end
			end
		end
		local function createGroundBreakCircle(p5)
			local v27 = makeRayParams()

			if not v27 or not p5.Parent then
				return
			end

			local v28 = mathRandom(8, 11)
			local v29 = mathRandom(15, 20)

			for i, v in ipairs({
				{ Count = 7, Radius = v28 },
				{ Count = 10, Radius = v29 }
			}) do
				for i2 = 1, v.Count do
					local n1 = (i2 - 1) / v.Count * 3.141592653589793 * 2
					local v34 = mathRandom(-7, 7)
					local v35 = math.rad(v34)
					local n2 = n1 + v35
					local vRadius = v.Radius
					local v38 = mathRandom(-12, 12)

					v35 = vRadius + v38 / 10

					local cosine = math.cos(n2)
					local sine = math.sin(n2)
					local vector3 = Vector3.new(cosine * v35, 0, sine * v35)
					local v42 = workspace:Raycast(p5.Position + vector3 + Vector3.new(0, 16, 0), Vector3.new(0, -42, 0), v27)

					if v42 and v42.Instance:IsA("BasePart") then
						local instance = v42.Instance
						local n3 = mathRandom(9, 21) / 10
						local tornadoGroundBreakRock: Part = Instance.new("Part")

						tornadoGroundBreakRock.Name = "TornadoGroundBreakRock"
						tornadoGroundBreakRock.Anchored = true
						tornadoGroundBreakRock.CanCollide = false
						tornadoGroundBreakRock.CanTouch = false
						tornadoGroundBreakRock.CanQuery = false
						tornadoGroundBreakRock.CastShadow = true
						tornadoGroundBreakRock.Material = instance.Material
						tornadoGroundBreakRock.Color = instance.Color

						local v46 = mathRandom(8, 13)
						local v47 = mathRandom(4, 8)
						local v48 = mathRandom(8, 13)

						tornadoGroundBreakRock.Size = Vector3.new(n3 * v46 / 10, n3 * v47 / 10, n3 * v48 / 10)

						local cFrameNew = CFrame.new

						v46 = v42.Position

						local vector32 = Vector3.new(0, tornadoGroundBreakRock.Size.Y, 0)
						local cFrame = cFrameNew(v46 - vector32)
						local cFrameAngles = CFrame.Angles

						v47 = mathRandom(-25, 25)
						v46 = math.rad(v47)

						local v53 = mathRandom(-25, 25)

						v48 = math.rad(v53)

						local v54 = cFrameAngles(v46, n2, v48)

						tornadoGroundBreakRock.CFrame = cFrame * v54
						copySurfaceDetails(instance, tornadoGroundBreakRock)
						tornadoGroundBreakRock.Parent = effects
						debris:AddItem(tornadoGroundBreakRock, 1.5)
						task.delay((i - 1) * 0.045 + i2 * 0.003, function()
							if not tornadoGroundBreakRock.Parent then
								return
							end

							local v74 = v42.Position
							local vector33 = Vector3.new(0, tornadoGroundBreakRock.Size.Y * 0.42, 0)
							local n1 = v74 + vector33
							local tweenInfo = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
							local tornadoGroundBreakRockOrientation: Vector3 = tornadoGroundBreakRock.Orientation
							local v79 = mathRandom(-25, 25)
							local v80 = mathRandom(-55, 55)
							local vector34 = Vector3.new(v79, v80, mathRandom(-25, 25))

							tweenService:Create(tornadoGroundBreakRock, tweenInfo, {
								Position = n1,
								Orientation = tornadoGroundBreakRockOrientation + vector34
							}):Play()
							task.delay(0.32, function()
								if not tornadoGroundBreakRock.Parent then
									return
								end

								fadeSurfaceDetails(tornadoGroundBreakRock, 0.25)

								local tweenInfo2 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
								local vector35 = Vector3.new(0, tornadoGroundBreakRock.Size.Y + 0.15, 0)

								tweenService:Create(tornadoGroundBreakRock, tweenInfo2, {
									Transparency = 1,
									Position = n1 - vector35,
									Size = tornadoGroundBreakRock.Size * 0.15
								}):Play()
							end)
						end)
					end
				end
			end
		end
		local function createTornadoRocks(p6)
			local v56 = makeRayParams()

			if not v56 or not p6.Parent then
				return
			end

			local t1: {[any]: any} = {}
			local v58 = os.clock()
			local t2: {[any]: any} = {
				{ Radius = 6, Count = 12, Delay = 0 },
				{ Radius = 12, Count = 18, Delay = 0.04 },
				{ Radius = 19, Count = 24, Delay = 0.08 }
			}

			local function createRock(p7, p8, p9, p10)
				local cosine = math.cos(p7)
				local sine = math.sin(p7)
				local vector3 = Vector3.new(cosine * p8, 0, sine * p8)
				local v89 = workspace:Raycast(p6.Position + vector3 + Vector3.new(0, 18, 0), Vector3.new(0, -45, 0), v56)

				if not v89 or not v89.Instance:IsA("BasePart") then
					return
				end

				local instance = v89.Instance
				local n1

				if p10 == 1 then
					n1 = mathRandom(9, 18) / 10
				elseif p10 == 2 then
					n1 = mathRandom(13, 24) / 10
				else
					n1 = mathRandom(17, 32) / 10
				end

				local tornadoOrbitRock: Part = Instance.new("Part")

				tornadoOrbitRock.Name = "TornadoOrbitRock"
				tornadoOrbitRock.Anchored = true
				tornadoOrbitRock.CanCollide = false
				tornadoOrbitRock.CanTouch = false
				tornadoOrbitRock.CanQuery = false
				tornadoOrbitRock.CastShadow = true
				tornadoOrbitRock.Material = instance.Material
				tornadoOrbitRock.Color = instance.Color

				local v93 = mathRandom(8, 13)
				local v94 = mathRandom(5, 10)
				local v95 = mathRandom(8, 13)

				tornadoOrbitRock.Size = Vector3.new(n1 * v93 / 10, n1 * v94 / 10, n1 * v95 / 10)

				local cFrameNew = CFrame.new

				v93 = v89.Position

				local vector36 = Vector3.new(0, tornadoOrbitRock.Size.Y * 0.35, 0)
				local cFrame = cFrameNew(v93 - vector36)
				local cFrameAngles = CFrame.Angles

				v94 = mathRandom(-25, 25)
				v93 = math.rad(v94)

				local v100 = mathRandom(-20, 20)

				v95 = math.rad(v100)
				v100 = mathRandom(-25, 25)

				local v101 = math.rad(v100)
				local v102 = cFrameAngles(v93, p7 + v95, v101)

				tornadoOrbitRock.CFrame = cFrame * v102
				copySurfaceDetails(instance, tornadoOrbitRock)
				tornadoOrbitRock.Parent = effects
				debris:AddItem(tornadoOrbitRock, 6)
				v101 = mathRandom(0, 14)
				v100 = mathRandom(-35, 35)

				local v103 = mathRandom(-45, 65)

				v93 = mathRandom(8, 15)
				v94 = mathRandom(-10, 10)
				v95 = mathRandom(-15, 15)

				local vector37 = Vector3.new(v94, v95, mathRandom(-10, 10))
				local rotation = tornadoOrbitRock.CFrame.Rotation

				v94 = mathRandom(65, 190)
				table.insert(t1, {
					Released = false,
					Part = tornadoOrbitRock,
					StartAngle = p7,
					StartRadius = p8,
					Delay = p9 + v101 / 100,
					TargetRadius = 12 + v100 / 10,
					TargetHeight = -1 + (p10 - 1) / (#t2 - 1) * 24 + v103 / 10,
					VerticalSpeed = v93,
					Spin = vector37,
					Rotation = rotation,
					ReleaseAt = v94 / 100
				})
			end

			for i, v in ipairs(t2) do
				for i2 = 1, v.Count do
					local n1 = (i2 - 1) / v.Count * 3.141592653589793 * 2
					local v65 = mathRandom(-7, 7)
					local v66 = math.rad(v65)
					local vRadius = v.Radius
					local v68 = mathRandom(-15, 15)

					createRock(n1 + v66, vRadius + v68 / 10, v.Delay, i)
				end
			end

			local function releaseRock(p11, p12)
				if p11.Released then
					return
				end

				p11.Released = true

				local part = p11.Part

				if not part or not part.Parent or not p6.Parent then
					return
				end

				local v109 = math.max(#t1, 1)
				local v110 = mathRandom(-40, 40)
				local v111 = math.rad(v110)
				local n1 = p12 / v109 * 3.141592653589793 * 2 + v111
				local cosine = math.cos(n1)
				local sine = math.sin(n1)
				local vector3 = Vector3.new(cosine, 0, sine)

				n1 = mathRandom(20, 45)
				v109 = workspace:Raycast(p6.Position + vector3 * n1 + Vector3.new(0, 55, 0), Vector3.new(0, -110, 0), v56)

				if not v109 then
					local tweenInfo = TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					tweenService:Create(part, tweenInfo, {
						Transparency = 1,
						Size = Vector3.new(0.05, 0.05, 0.05),
						Position = part.Position + vector3 * n1 + Vector3.new(0, 12, 0)
					}):Play()

					return
				end

				local partPosition = part.Position
				local v118 = v109.Position
				local vector38 = Vector3.new(0, part.Size.Y * 0.5, 0)
				local n2 = v118 + vector38
				local magnitude = (partPosition - n2).Magnitude
				local v122 = math.clamp(magnitude / 45, 0.55, 0.95)
				local v123 = math.clamp(magnitude * 0.42, 9, 22)
				local partOrientation = part.Orientation
				local v125 = mathRandom(-360, 360)
				local v126 = mathRandom(-600, 600)
				local vector39 = Vector3.new(v125, v126, mathRandom(-360, 360))
				local v128 = os.clock()
				local connection = nil

				connection = runService.RenderStepped:Connect(function()
					if not part.Parent then
						connection:Disconnect()

						return
					end

					local v154 = os.clock()
					local v155 = math.clamp((v154 - v128) / v122, 0, 1)
					local v156 = partPosition:Lerp(n2, v155 * v155 * (3 - v155 * 2))
					local vector310 = Vector3.new(0, v123 * 4 * v155 * (1 - v155), 0)
					local cFrame = CFrame.new(v156 + vector310)
					local cFrameAngles = CFrame.Angles
					local v160 = math.rad(partOrientation.X + vector39.X * v155)
					local v161 = math.rad(partOrientation.Y + vector39.Y * v155)
					local v162 = math.rad(partOrientation.Z + vector39.Z * v155)
					local v163 = cFrameAngles(v160, v161, v162)

					part.CFrame = cFrame * v163

					if v155 < 1 then
						return
					end

					connection:Disconnect()
					part.Position = n2

					local tweenInfo = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					tweenService:Create(part, tweenInfo, { Position = n2 + Vector3.new(0, 0.12, 0) }):Play()
					task.delay(0.1, function()
						if part.Parent then
							local tweenInfo3 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

							tweenService:Create(part, tweenInfo3, { Position = n2 }):Play()
						end
					end)

					local taskDelay = task.delay
					local v166 = mathRandom(70, 120)

					taskDelay(v166 / 100, function()
						if not part.Parent then
							return
						end

						fadeSurfaceDetails(part, 0.3)

						local tweenInfo4 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						local partPosition = part.Position
						local vector311 = Vector3.new(0, part.Size.Y + 0.25, 0)

						tweenService:Create(part, tweenInfo4, {
							Transparency = 1,
							Position = partPosition - vector311,
							Size = part.Size * 0.25
						}):Play()
					end)
				end)
			end

			local connection = nil

			connection = runService.RenderStepped:Connect(function(deltaTime: number)
				if not p6.Parent then
					connection:Disconnect()

					for _, v in ipairs(t1) do
						if v.Part.Parent then
							v.Part:Destroy()
						end
					end

					return
				end

				local n1 = os.clock() - v58
				local u134: boolean = true

				for i, v in ipairs(t1) do
					local vPart = v.Part

					if not v.Released and vPart.Parent then
						u134 = false

						if n1 >= v.ReleaseAt or n1 >= 2 then
							releaseRock(v, i)
						else
							local n2 = n1 - v.Delay

							if not (n2 < 0) then
								local n3 = 1 - (1 - math.clamp(n2 / 0.16, 0, 1)) ^ 3
								local n4 = v.StartRadius + (v.TargetRadius - v.StartRadius) * n3
								local n5 = v.StartAngle + n2 * 8
								local n6 = (v.TargetHeight + n2 * v.VerticalSpeed + 4) % 34 - 4
								local n7 = math.sin(n2 * 10 + i * 0.8) * 1.1
								local sine = math.sin(n2 * 9 + i)
								local v145 = p6.Position
								local cosine = math.cos(n5)
								local sine2 = math.sin(n5)
								local vector3 = Vector3.new(cosine * (n4 + n7), (n6 + sine * 0.7) * n3, sine2 * (n4 + n7))
								local vRotation = v.Rotation
								local v150 = CFrame.Angles(v.Spin.X * deltaTime, v.Spin.Y * deltaTime, v.Spin.Z * deltaTime)

								v.Rotation = vRotation * v150
								vPart.CFrame = CFrame.new(v145 + vector3) * v.Rotation
							end
						end
					end
				end

				if n1 >= 2 and u134 then
					connection:Disconnect()
				end
			end)
		end

		mirrage.OnClientEvent:Connect(function(player)
			local character = player and player.Character
			local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			createTornadoRocks(humanoidRootPart)
			task.spawn(function()
				local v151 = os.clock()

				while humanoidRootPart.Parent and os.clock() - v151 < 2 do
					createGroundBreakCircle(humanoidRootPart)
					task.wait(0.38)
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.Tornado", result)
	end
end)

return true
