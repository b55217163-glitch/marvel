-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local fastPart = game.ReplicatedStorage.Characters.TheFlashCw.Fx.FastPart
		local superRun = game.ReplicatedStorage.Characters.Gigachad.Fx.SuperRun
		local lightning = game.ReplicatedStorage.Characters.TheFlashCw.Fx.Lightning
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		local function RocksGround(p1, p2)
			for _, v in ipairs(p1:GetChildren()) do
				if v.Name == "DolAt" then
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { p2 }

					local v15 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

					if v15 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v15.Position

						local randomNumber = math.random(-0.1, 0.1)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber2 = math.random(0.5, 1)
						local randomNumber3 = math.random(360)
						local v22 = math.rad(randomNumber3)
						local randomNumber4 = math.random(360)
						local v24 = math.rad(randomNumber4)
						local randomNumber5 = math.random(360)
						local v26 = math.rad(randomNumber5)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v29 = CFrame.Angles(v22, v24, v26)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v29 }):Play()

						local TweenService2 = game.TweenService
						local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

						TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
						part.Material = v15.Material
						part.Color = v15.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						for _ = 1, 1 do
							local explosionPart: Part = Instance.new("Part")

							explosionPart.Anchored = false
							explosionPart.Name = "ExplosionPart"
							explosionPart.Size = Vector3.new(0, 0, 0)
							explosionPart.Material = part.Material
							explosionPart.CanCollide = true
							explosionPart.CFrame = part.CFrame
							explosionPart.Color = v15.Instance.Color
							game.TweenService:Create(explosionPart, TweenInfo.new(0.15), { Size = Vector3.new(0.1, 0.1, 0.1) }):Play()

							local randomNumber6 = math.random(-40, 40)
							local randomNumber7 = math.random(0, 40)

							explosionPart.Velocity = Vector3.new(randomNumber6, randomNumber7, math.random(-40, 40))

							local cFrame2 = CFrame.new(part.Position)
							local v40 = CFrame.Angles(v22, v24, v26)

							explosionPart.CFrame = cFrame2 * v40
							explosionPart.Parent = workspace
							game.Debris:AddItem(explosionPart, 3)
							task.delay(2, function()
								game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end)
						end

						local randomNumber8 = math.random(2, 2.3)

						task.delay(randomNumber8, function()
							local randomNumber9 = math.random(360)
							local v56 = math.rad(randomNumber9)
							local randomNumber10 = math.random(360)
							local v58 = math.rad(randomNumber10)
							local randomNumber11 = math.random(360)
							local v60 = math.rad(randomNumber11)
							local TweenService3 = game.TweenService
							local cFrame3 = CFrame.new(part.Position)
							local v63 = CFrame.Angles(v56, v58, v60)

							TweenService3:Create(part, TweenInfo.new(0.5), { CFrame = cFrame3 * v63 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end
			end
		end

		game.ReplicatedStorage.Characters.TheFlashCw.Remotes.FastestMan.OnClientEvent:Connect(function(p3, _)
			local Humanoid = p3.Humanoid
			local HumanoidRootPart = p3.HumanoidRootPart
			local n1: number = 14

			while n1 > 0 do
				RocksGround(HumanoidRootPart, workspace.Map)

				if p3:FindFirstChild("CantAttack") then
					n1 = 1
				end

				local clone = superRun:Clone()

				clone.Parent = workspace
				clone.CFrame = p3.HumanoidRootPart.CFrame * CFrame.new(0, -6, 0)
				game.Debris:AddItem(clone, 8)

				local weld: Weld = Instance.new("Weld", p3)

				weld.Part0 = p3.FakeUpperTorso
				weld.Part1 = clone

				local v49 = CFrame.Angles(0, 0, 0)

				weld.C0 = CFrame.new(0, -3, 0) * v49
				game.Debris:AddItem(weld, 3)

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v51 = workspace:Raycast(clone.Position, clone.CFrame.UpVector * -6, raycastParams)

				if v51 ~= nil then
					local InstanceColor = v51.Instance.Color
					local clone2 = fastPart:Clone()

					clone2.Parent = workspace
					clone2.Position = v51.Position

					local randomNumber = math.random(-180, 180)

					clone2.Orientation = Vector3.new(0, randomNumber, 0)
					game.Debris:AddItem(clone2, 10)
					clone.Smoke.Color = ColorSequence.new(InstanceColor)
					clone.Rock.Color = ColorSequence.new(InstanceColor)
					clone.Smoke.Enabled = true
					clone.Rock.Enabled = true
					task.spawn(function()
						task.wait(0.4)

						local smoke = clone:FindFirstChild("Smoke")
						local rock = clone:FindFirstChild("Rock")

						if smoke then
							smoke.Enabled = false
						end

						if rock then
							rock.Enabled = false
						end

						task.wait(1.6)
					end)
				end

				task.wait(0.1)
				RocksGround(HumanoidRootPart, workspace.Map)
				task.wait(0.1)
				n1 -= 1
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.FastestMan", result)
	end
end)

return true
