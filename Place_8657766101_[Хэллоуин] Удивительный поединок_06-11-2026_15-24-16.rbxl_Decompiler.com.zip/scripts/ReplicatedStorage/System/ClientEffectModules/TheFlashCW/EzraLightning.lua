-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local workspace: Workspace = game:GetService("Workspace")
		local tweenService: TweenService = game:GetService("TweenService")
		local ezraLightning: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("TheFlashCw"):WaitForChild("Remotes"):WaitForChild("EzraLightning")
		local runEzra: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("TheFlashCw"):WaitForChild("Fx"):WaitForChild("RunEzra")
		local runDarkFlash: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("TheFlashCw"):WaitForChild("Fx"):WaitForChild("RunDarkFlash")
		local runEzraB: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("TheFlashCw"):WaitForChild("Fx"):WaitForChild("RunEzraB")
		local n1: number = 0

		local function tryAcquireBoltSlot()
			if n1 >= 40 then
				return false
			end

			n1 += 1

			return true
		end
		local function releaseBoltSlot()
			n1 -= 1

			if n1 < 0 then
				n1 = 0
			end
		end

		local t1: {[any]: any} = { 0.15, 0.3 }
		local t2: {[any]: any} = {}

		local function getState(player)
			local userId = player.UserId

			t2[userId] = t2[userId] or { active = false, token = 0 }

			return t2[userId]
		end
		local function canSpawn(player, p3)
			local v33 = t2[player.UserId]

			return v33 and v33.active and p3 == v33.token
		end
		local function getLimbPart(p4)
			if not p4 then
				return nil
			end

			local upperTorso = p4:FindFirstChild("UpperTorso")
			local rightHand = p4:FindFirstChild("RightHand")
			local leftHand = p4:FindFirstChild("LeftHand")
			local rightFoot = p4:FindFirstChild("RightFoot")
			local leftFoot = p4:FindFirstChild("LeftFoot")
			local torso = p4:FindFirstChild("Torso")
			local t3: {[any]: any} = {}

			for _, v in ipairs({
				upperTorso,
				rightHand,
				leftHand,
				rightFoot,
				leftFoot,
				torso,
				p4:FindFirstChild("HumanoidRootPart")
			}) do
				if v and v:IsA("BasePart") then
					table.insert(t3, v)
				end
			end

			if #t3 == 0 then
				return nil
			end

			local randomNumber = math.random(1, #t3)

			return t3[randomNumber]
		end
		local function safeEmit(p5, p6, p7)
			if not p5 then
				return
			end

			local foundChild = p5:FindFirstChild(p6)

			if foundChild and foundChild:IsA("ParticleEmitter") then
				foundChild:Emit(p7)
			end
		end
		local function setEmitterTimeScale(p8, p9, p10)
			if not p8 then
				return
			end

			local foundChild = p8:FindFirstChild(p9)

			if foundChild and foundChild:IsA("ParticleEmitter") then
				pcall(function()
					foundChild.TimeScale = p10
				end)
			end
		end

		local raycastParams = RaycastParams.new()

		raycastParams.FilterType = Enum.RaycastFilterType.Exclude
		raycastParams.IgnoreWater = false

		local function raycastToGround(p11, p12)
			raycastParams.FilterDescendantsInstances = { p12 }

			local v55 = workspace:Raycast(p11, Vector3.new(0, -900, 0), raycastParams)

			if v55 then
				return v55.Position, v55.Normal
			end

			return p11 + Vector3.new(0, -40, 0), Vector3.new(0, 1, 0)
		end
		local function makeAnchorPart(name)
			local part: Part = Instance.new("Part")

			part.Name = name
			part.Size = Vector3.new(1.5, 1.5, 1.5)
			part.Transparency = 1
			part.CanCollide = false
			part.Anchored = true
			part.CanQuery = false
			part.CanTouch = false
			part.Parent = workspace

			return part
		end
		local function getSoundDurationAdjusted(p14)
			if not p14 or not p14:IsA("Sound") then
				return 0.35
			end

			if p14.TimeLength <= 0 then
				pcall(function()
					p14.Loaded:Wait()
				end)
			end

			local v59 = p14.TimeLength

			if v59 <= 0 then
				v59 = 0.35
			end

			local v60 = p14.PlaybackSpeed

			if v60 <= 0 then
				v60 = 1
			end

			return v59 / v60
		end
		local function tweenLightDown(p15)
			if not p15 or not p15:IsA("PointLight") then
				return
			end

			local tweenInfo = TweenInfo.new(0.18, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v63: Tween = tweenService:Create(p15, tweenInfo, { Brightness = 0, Range = 0 })

			v63:Play()
			v63.Completed:Connect(function()
				if p15 then
					p15.Enabled = false
				end
			end)
		end
		local function unitOr(p16, p17)
			if p16.Magnitude > 0.001 then
				return p16.Unit
			end

			return p17
		end
		local function randomDirMostlySide()
			local randomNumber = math.random(-100, 100)
			local randomNumber2 = math.random(-25, 25)
			local randomNumber3 = math.random(-100, 100)
			local vector3 = Vector3.new(randomNumber / 100, randomNumber2 / 100, randomNumber3 / 100)

			if vector3.Magnitude > 0.001 then
				return vector3.Unit
			end

			return Vector3.new(1, 0, 0)
		end
		local function spawnBolt(p18, p19)
			local u72

			if n1 >= 40 then
				u72 = false
			else
				n1 += 1
				u72 = true
			end

			if not u72 then
				return
			end

			local parent = getLimbPart(p18)

			if not parent then
				n1 -= 1

				if n1 < 0 then
					n1 = 0
				end

				return
			end

			local darkFlash = p18:FindFirstChild("DarkFlash")
			local clone

			if darkFlash then
				clone = runDarkFlash:Clone()
			elseif p18:FindFirstChild("EzraB") then
				clone = runEzraB:Clone()
			else
				clone = runEzra:Clone()
			end

			clone.Anchored = true
			clone.CanCollide = false
			clone.Parent = workspace

			local beam = clone:FindFirstChild("Beam")

			if not beam or not beam:IsA("Beam") then
				clone:Destroy()
				n1 -= 1

				if n1 < 0 then
					n1 = 0
				end

				return
			end

			local curveSize0 = math.random(-900, 900) / 100
			local curveSize1 = math.random(-900, 900) / 100

			beam.CurveSize0 = curveSize0
			beam.CurveSize1 = curveSize1

			local tweenInfo = TweenInfo.new(0.06, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

			tweenService:Create(beam, tweenInfo, { CurveSize0 = -curveSize0, CurveSize1 = -curveSize1 }):Play()

			local hitSound = clone:FindFirstChild("HitSound")
			local at = clone:FindFirstChild("At")
			local v82 = at and at:FindFirstChildOfClass("PointLight") or nil
			local v83 = nil
			local v84 = nil

			if v82 then
				v83 = v82.Brightness
				v84 = v82.Range
				v82.Enabled = false
			end

			local beamAt = clone:FindFirstChild("BeamAt")
			local beamAt2 = clone:FindFirstChild("BeamAt2")

			if not beamAt or not beamAt:IsA("Attachment") or not beamAt2 or not beamAt2:IsA("Attachment") then
				clone:Destroy()
				n1 -= 1

				if n1 < 0 then
					n1 = 0
				end

				return
			end

			local n3: number = if p19 then 3 else 1
			local part = Instance.new("Part")

			part.Name = "EzraStartAnchor"
			part.Size = Vector3.new(1.5, 1.5, 1.5)
			part.Transparency = 1
			part.CanCollide = false
			part.Anchored = true
			part.CanQuery = false
			part.CanTouch = false
			part.Parent = workspace

			local part2 = Instance.new("Part")

			part2.Name = "EzraEndAnchor"
			part2.Size = Vector3.new(1.5, 1.5, 1.5)
			part2.Transparency = 1
			part2.CanCollide = false
			part2.Anchored = true
			part2.CanQuery = false
			part2.CanTouch = false
			part2.Parent = workspace

			local u90: boolean = false

			local function cleanupNow()
				if u90 then
					return
				end

				u90 = true

				if beamAt and beamAt.Parent then
					beamAt:Destroy()
				end

				if beamAt2 and beamAt2.Parent then
					beamAt2:Destroy()
				end

				if part then
					part:Destroy()
					part = nil
				end

				if part2 then
					part2:Destroy()
					part2 = nil
				end

				if clone then
					clone:Destroy()
					clone = nil
				end

				n1 -= 1

				if n1 < 0 then
					n1 = 0
				end
			end

			beamAt.Parent = parent
			beamAt2.Parent = part2
			beam.Attachment0 = beamAt
			beam.Attachment1 = beamAt2

			local cFrameNew = CFrame.new
			local randomNumber = math.random(-6, 6)
			local randomNumber4 = math.random(0, 10)
			local randomNumber5 = math.random(-6, 6)
			local v96 = cFrameNew(randomNumber / 10, randomNumber4 / 10, randomNumber5 / 10)

			local function getStartWorld()
				return (parent.CFrame * v96).Position
			end

			local v98 = (parent.CFrame * v96).Position

			clone.CFrame = CFrame.new(v98)
			part2.CFrame = CFrame.new(v98)

			local randomNumber6 = math.random(1, #t1)
			local n4 = math.max(0.01, t1[randomNumber6] / 4) * n3

			for _ = 1, 4 do
				if not part or not part2 or not beamAt or not beamAt2 then
					cleanupNow()

					return
				end

				local worldPosition = (parent.CFrame * v96).Position

				beamAt.WorldPosition = worldPosition

				local v103 = randomDirMostlySide()
				local randomNumber7 = math.random(200, 600)

				randomNumber7 = worldPosition + v103 * (randomNumber7 / 100)

				local n5 = randomNumber7.Y - worldPosition.Y

				if n5 > 2.5 then
					randomNumber7 = Vector3.new(randomNumber7.X, worldPosition.Y + 2.5, randomNumber7.Z)
				elseif n5 < -1.2 then
					randomNumber7 = Vector3.new(randomNumber7.X, worldPosition.Y - 1.2, randomNumber7.Z)
				end

				n5 = randomNumber7 - worldPosition

				if n5.Magnitude > 7.5 then
					randomNumber7 = worldPosition + n5.Unit * 7.5
				end

				local v106 = part2
				local tweenInfoNew = TweenInfo.new
				local v108 = math.min(0.06 * n3, n4)
				local v109 = tweenInfoNew(v108, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
				local cFrame = CFrame.new(randomNumber7)

				tweenService:Create(v106, v109, { CFrame = cFrame }):Play()
				task.wait(n4)
			end

			part.CFrame = CFrame.new(beamAt.WorldPosition)
			beamAt.Parent = part
			beamAt.Position = Vector3.new(0, 0, 0)

			local v111 = os.clock()

			while true do
				local v112 = os.clock()

				if not (v111 + 0.1 * n3 > v112) then
					break
				end

				if not part or not part2 then
					cleanupNow()

					return
				end

				v112 = randomDirMostlySide()

				local randomNumber8 = math.random(0, 500)

				randomNumber8 = part.Position + v112 * (randomNumber8 / 100)

				local y = part.Position.Y
				local n6 = randomNumber8.Y - y

				if n6 > 1.5 then
					randomNumber8 = Vector3.new(randomNumber8.X, y + 1.5, randomNumber8.Z)
				elseif n6 < -0.8 then
					randomNumber8 = Vector3.new(randomNumber8.X, y - 0.8, randomNumber8.Z)
				end

				local v116 = part
				local tweenInfo2 = TweenInfo.new(0.05 * n3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
				local cFrame2 = CFrame.new(randomNumber8)

				v112 = tweenService:Create(v116, tweenInfo2, { CFrame = cFrame2 })
				v112:Play()
				v112.Completed:Wait()
				part2.CFrame = part.CFrame
			end

			n4 = parent.Position

			local randomNumber9 = math.random(-14, 14)
			local vector3 = Vector3.new(randomNumber9, 0, math.random(-14, 14))
			local n7 = n4 + vector3 + Vector3.new(0, 12, 0)

			raycastParams.FilterDescendantsInstances = { p18 }

			local v122 = workspace:Raycast(n7, Vector3.new(0, -900, 0), raycastParams)
			local v123
			local vectorValue

			if v122 then
				v123 = v122.Position
				vectorValue = v122.Normal
			else
				v123 = n7 + Vector3.new(0, -40, 0)
				vectorValue = Vector3.new(0, 1, 0)
			end

			clone.CFrame = CFrame.new(v123, v123 + vectorValue)

			local partPosition = part.Position

			v111 = v123 - partPosition
			n4 = if v111.Magnitude > 0.001 then v111.Unit else Vector3.new(0, -1, 0)
			n7 = n4:Cross(Vector3.new(0, 1, 0))
			v111 = if n7.Magnitude > 0.001 then n7.Unit else Vector3.new(1, 0, 0)
			n7 = v111:Cross(n4)

			for i = 1, 8 do
				if not part2 then
					cleanupNow()

					return
				end

				local n8: number = i / 8
				local v128 = partPosition:Lerp(v123, n8)
				local v129 = math.clamp((1 - n8) ^ 0.55, 0, 1)
				local randomNumber10 = math.random(-100, 100)
				local randomNumber11 = math.random(-100, 100)
				local n9 = v128 + v111 * (randomNumber10 / 100 * 9 * v129) + n7 * (randomNumber11 / 100 * 4.95 * v129)

				if i == 8 then
					n9 = v123
				end

				local v133 = part2
				local tweenInfo3 = TweenInfo.new(0.025 * n3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local cFrame3 = CFrame.new(n9)
				local v136: Tween = tweenService:Create(v133, tweenInfo3, { CFrame = cFrame3 })

				v136:Play()
				v136.Completed:Wait()
			end

			if hitSound and hitSound:IsA("Sound") then
				if p19 then
					hitSound.PlaybackSpeed = math.random(50, 60) / 100
				else
					hitSound.PlaybackSpeed = math.random(100, 130) / 100
				end

				hitSound:Play()
			end

			if at then
				setEmitterTimeScale(at, "Impact", 0.5)
				setEmitterTimeScale(at, "Sparks", 0.5)

				if at then
					local impact = at:FindFirstChild("Impact")

					if impact and impact:IsA("ParticleEmitter") then
						impact:Emit(2)
					end
				end

				if at then
					local sparks = at:FindFirstChild("Sparks")

					if sparks and sparks:IsA("ParticleEmitter") then
						sparks:Emit(15)
					end
				end
			end

			if v82 then
				v82.Enabled = true
				v82.Brightness = v83 or v82.Brightness
				v82.Range = v84 or v82.Range
			end

			tweenLightDown(v82)

			local v139 = part
			local tweenInfo4 = TweenInfo.new(0.12 * n3, Enum.EasingStyle.Sine, Enum.EasingDirection.In)
			local cFrame4 = CFrame.new(v123)

			tweenService:Create(v139, tweenInfo4, { CFrame = cFrame4 }):Play()
			v122 = getSoundDurationAdjusted(hitSound)
			task.delay(v122, cleanupNow)
		end
		local function spawnBurst(player, p21, p22, p23)
			for _ = 1, 3 do
				local v147 = t2[player.UserId]

				if not v147 or not v147.active or p23 ~= v147.token then
					return
				end

				spawnBolt(p21, p22)
				task.wait(0.05 * (if p22 then 3 else 1))
			end
		end

		ezraLightning.OnClientEvent:Connect(function(player, p25, p26, p27)
			if not player then
				return
			end

			local userId = player.UserId

			t2[userId] = t2[userId] or { active = false, token = 0 }

			local v153 = t2[userId]

			v153.token = p27 or v153.token + 1

			if not p25 then
				v153.active = false

				return
			end

			v153.active = true

			local Character = player.Character

			if not Character then
				return
			end

			local token = v153.token

			task.spawn(function()
				local v156 = t2[player.UserId]

				if not v156 or not v156.active or token ~= v156.token then
					return
				end

				spawnBurst(player, Character, if p26 then true else false, token)
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.EzraLightning", result)
	end
end)

return true
