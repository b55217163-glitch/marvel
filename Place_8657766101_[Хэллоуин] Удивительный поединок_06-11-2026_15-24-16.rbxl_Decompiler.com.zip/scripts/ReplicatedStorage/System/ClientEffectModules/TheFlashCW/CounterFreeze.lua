-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local freezeCharacterAnim = game:GetService("ReplicatedStorage").Characters.TheFlashCw.Remotes.FreezeCharacterAnim
		local object = setmetatable({}, { __mode = "k" })
		local object2 = setmetatable({}, { __mode = "k" })
		local object3 = setmetatable({}, { __mode = "k" })

		local function disconnectHooks(p1)
			local v11 = object2[p1]

			if v11 then
				for _, v in ipairs(v11) do
					if v and v.Disconnect then
						v:Disconnect()
					end
				end
			end

			object2[p1] = nil
		end
		local function setTrackSpeed(p2, p3)
			if p2 and p2.IsPlaying then
				pcall(function()
					p2:AdjustSpeed(p3)
				end)
			end
		end
		local function freezeCharacterAnims(character, p5)
			if not character or not character.Parent then
				return
			end

			local humanoid = character:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local animator = humanoid:FindFirstChildOfClass("Animator")

			if not animator then
				return
			end

			if not p5 then
				if not object[character] then
					return
				end

				object[character] = nil
				object3[character] = (object3[character] or 0) + 1
				disconnectHooks(character)

				for _, v in ipairs(humanoid:GetPlayingAnimationTracks()) do
					if v and v.IsPlaying then
						local n1: number = 1

						pcall(function()
							v:AdjustSpeed(n1)
						end)
					end
				end

				local animate = character:FindFirstChild("Animate")

				if animate and animate:IsA("Script") then
					animate.Disabled = false
				end

				return
			end

			if object[character] then
				return
			end

			object[character] = true

			local animate = character:FindFirstChild("Animate")

			if animate and animate:IsA("Script") then
				animate.Disabled = true
			end

			for _, v in ipairs(humanoid:GetPlayingAnimationTracks()) do
				if v and v.IsPlaying then
					local n2: number = 0

					pcall(function()
						v:AdjustSpeed(n2)
					end)
				end
			end

			local t1: {[any]: any} = {}

			t1[#t1 + 1] = animator.AnimationPlayed:Connect(function(p6)
				if object[character] and p6 and p6.IsPlaying then
					local n1: number = 0

					pcall(function()
						p6:AdjustSpeed(n1)
					end)
				end
			end)
			object2[character] = t1
		end

		freezeCharacterAnim.OnClientEvent:Connect(function(p7, p8, p9)
			freezeCharacterAnims(p7, p8)

			if p8 and p9 and p9 > 0 then
				object3[p7] = (object3[p7] or 0) + 1

				local v32 = object3[p7]

				task.delay(p9, function()
					if object3[p7] == v32 and object[p7] then
						freezeCharacterAnims(p7, false)
					end
				end)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "TheFlashCW.CounterFreeze", result)
	end
end)

return true
