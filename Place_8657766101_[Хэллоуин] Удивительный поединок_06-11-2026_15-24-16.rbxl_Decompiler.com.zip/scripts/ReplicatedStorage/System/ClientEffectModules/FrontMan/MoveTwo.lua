-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local spinner = game.ReplicatedStorage.Characters.FrontMan.Remotes.Spinner

		game:GetService("TweenService")

		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		spinner.OnClientEvent:Connect(function(_, p2)
			for _ = 1, 20 do
				if p2 and p2:FindFirstChild("Blocked") and p2.Blocked.Value == false then
					for _, v in ipairs(p2:GetChildren()) do
						if v.Name == "Attachment1" or v.Name == "Attachment2" then
							local raycastParams = RaycastParams.new()

							raycastParams.FilterType = Enum.RaycastFilterType.Include
							raycastParams.FilterDescendantsInstances = { workspace.Map }

							local v11 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

							if v11 ~= nil then
								local part: Part = Instance.new("Part")

								part.Position = v11.Position

								local randomNumber = math.random(-0.1, 0.1)
								local partCFrame: CFrame = part.CFrame
								local vector3 = Vector3.new(randomNumber, 0, 0)

								part.CFrame = partCFrame + vector3
								part.Parent = workspace
								part.Anchored = true
								part.Size = Vector3.new(0, 0, 0)
								part.CanCollide = false
								part.CanTouch = false
								game.Debris:AddItem(part, 3)

								if p2.Hitting.Value == true then
									part.Transparency = 1
								end

								local randomNumber2 = math.random(2, 2.5)
								local randomNumber3 = math.random(360)
								local v18 = math.rad(randomNumber3)
								local randomNumber4 = math.random(360)
								local v20 = math.rad(randomNumber4)
								local randomNumber5 = math.random(360)
								local v22 = math.rad(randomNumber5)
								local TweenService = game.TweenService
								local cFrame = CFrame.new(part.Position)
								local v25 = CFrame.Angles(v18, v20, v22)

								TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v25 }):Play()

								local TweenService2 = game.TweenService
								local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

								TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
								part.Material = v11.Material
								part.Color = v11.Instance.Color

								local clone = smoke:Clone()

								clone.Parent = part

								local colorSequenceNew = ColorSequence.new
								local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

								clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
								clone:Emit(2)

								if math.random(1, 3) == 1 then
									for _ = 1, 1 do
										local explosionPart: Part = Instance.new("Part")

										explosionPart.Anchored = false
										explosionPart.Name = "ExplosionPart"
										explosionPart.Size = Vector3.new(0, 0, 0)
										explosionPart.Material = part.Material
										explosionPart.CanCollide = true
										explosionPart.CFrame = part.CFrame
										explosionPart.Color = v11.Instance.Color

										local TweenService3 = game.TweenService
										local randomNumber6 = math.random(1.5, 2.5)
										local randomNumber7 = math.random(1.5, 2.5)
										local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))

										TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

										local randomNumber8 = math.random(-80, 80)
										local randomNumber9 = math.random(0, 80)

										explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

										local cFrame2 = CFrame.new(part.Position)
										local v40 = CFrame.Angles(v18, v20, v22)

										explosionPart.CFrame = cFrame2 * v40
										explosionPart.Parent = workspace
										game.Debris:AddItem(explosionPart, 3)

										local part2: Part = Instance.new("Part")

										part2.Anchored = false
										part2.Name = "ExplosionPart"
										part2.Size = Vector3.new(0, 0, 0)
										part2.Material = part.Material
										part2.CanCollide = true
										part2.CFrame = part.CFrame
										part2.Color = v11.Instance.Color
										game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

										local randomNumber10 = math.random(-40, 40)
										local randomNumber11 = math.random(0, 40)

										part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

										local cFrame3 = CFrame.new(part.Position)
										local v45 = CFrame.Angles(v18, v20, v22)

										part2.CFrame = cFrame3 * v45
										part2.Parent = workspace
										game.Debris:AddItem(part2, 3)
										task.delay(2, function()
											game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
											game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										end)
									end
								end

								local randomNumber12 = math.random(2, 2.3)

								task.delay(randomNumber12, function()
									local randomNumber13 = math.random(360)
									local v48 = math.rad(randomNumber13)
									local randomNumber14 = math.random(360)
									local v50 = math.rad(randomNumber14)
									local randomNumber15 = math.random(360)
									local v52 = math.rad(randomNumber15)
									local TweenService4 = game.TweenService
									local cFrame4 = CFrame.new(part.Position)
									local v55 = CFrame.Angles(v48, v50, v52)

									TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v55 }):Play()
									game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
								end)
							end
						end
					end

					task.wait(0.1)
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "FrontMan.MoveTwo", result)
	end
end)

return true
