-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local downSlam = game.ReplicatedStorage.Characters.SpiderMan.Remotes.DownSlam
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v37 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v39 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v39, 0)
				local n2 = v37 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v42 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v42 then
					local instance = v42.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v48 = mathRandom(-180, 180)
					local v49 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v48, v49, mathRandom(-180, 180))
					part.Position = p1.Position

					local v50 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v50, { Position = v42.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v168 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v168, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v169 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v169, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v55 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v57 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v59 = math.rad(randomNumber3)
						local v60 = cFrameAngles(v55, v57, v59)

						clone.CFrame = p1.CFrame * v60

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v68 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v70 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v70, 0)
				local n2 = v68 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v73 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v73 then
					local instance = v73.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v79 = mathRandom(-180, 180)
					local v80 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v79, v80, mathRandom(-180, 180))
					part.Position = p2.Position

					local v81 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v81, { Position = v73.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v174 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v174, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v175 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v175, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v86 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v88 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v88, 0)
				local n2 = v86 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v91 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v91 then
					local instance = v91.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v97 = mathRandom(-180, 180)
					local v98 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v97, v98, mathRandom(-180, 180))
					part.Position = p3.Position

					local v99 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v99, { Position = v91.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v180 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v180, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v181 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v181, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local heavy = game.ReplicatedStorage.Characters.SpiderMan.Fx.Heavy
		local counterSlam = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.CounterSlam
		local counterslamhit = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.counterslamhit
		local weaverCounterSlam = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.WeaverCounterSlam
		local specCounterSlam = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.SpecCounterSlam
		local v19 = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.counterslamhit
		local counterMiles = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.CounterMiles
		local hitCounterMiles = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.HitCounterMiles
		local miguelSlam = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.MiguelSlam
		local grabSlamHitAnim = game.ReplicatedStorage.Characters["2099"].AnimationsExtra.GrabSlamHitAnim
		local webbed = game.ReplicatedStorage.Characters.SpiderMan.Fx.Webbed

		game:GetService("TweenService")

		local smoke = game.ReplicatedStorage.Characters.Vecna.Fx.Smoke
		local tweenService2: TweenService = game:GetService("TweenService")
		local v27 = TweenInfo.new
		local v28 = math.random

		local function Math(p4, p5, p6)
			return p4 + (p5 - p4) * p6
		end
		local function RockSpawn(p7, p8: number, p9, parent, p11, p12, p13)
			if p8 > 180 or p8 < 0 then
				warn("Too high or low of a number!")
				p8 = 15
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p8 do
				local v113 = p7.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v115 = math.rad(n1)
				local v116 = cFrameFromEulerAnglesXYZ(0, v115, 0)
				local cFrame = CFrame.new(0, 0, p11)
				local n2 = v113 * v116 * cFrame.Position
				local v119 = p7.CFrame
				local v120 = CFrame.fromEulerAnglesXYZ
				local v121 = math.rad(n1)
				local v122 = v120(0, v121, 0)
				local cFrame2 = CFrame.new(0, 0, -p11 / 1.25)
				local n3 = v119 * v122 * cFrame2.Position
				local vector3 = Vector3.new(0, -p11, 0)
				local v126 = workspace:Raycast(n2, n3 + vector3 - n2, raycastParams)

				n1 += p8

				if v126 then
					local instance = v126.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local cFrame3 = CFrame.new(v126.Position, p7.Position)
					local cFrameAngles = CFrame.Angles
					local v131 = v28(-3.141592653589793, 3.141592653589793)
					local v132 = cFrameAngles(v131, 0, 0)
					local v133 = p7.Position
					local n4 = v133 + (v126.Position - v133) * 0.2
					local magnitude = (p7.Position - v126.Position).Magnitude

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.CFrame = CFrame.new(n4, p7.Position)
					game.Debris:AddItem(part, 5)

					for _, v in pairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					if p13 == true then
						local v139 = v28(p9.Min, p9.Max)
						local v140 = v28(p9.Min, p9.Max)

						part.Size = Vector3.new(v139, v140, v28(p9.Min, p9.Max))
					else
						part.Size = p9
					end

					if p12 == true then
						local v141 = v28(-180, 180)
						local v142 = v28(-180, 180)

						part.Orientation = Vector3.new(v141, v142, v28(-180, 180))

						local v143 = v27(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService2:Create(part, v143, { Position = v126.Position }):Play()
					elseif p12 == false then
						local v144 = v27(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local cFrame4 = CFrame.new(v126.Position, p7.Position)

						tweenService2:Create(part, v144, { CFrame = cFrame4 }):Play()
					elseif p12 == "Middle" then
						local v146 = v27(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService2:Create(part, v146, { CFrame = cFrame3 * v132 }):Play()
					end

					part.Parent = parent
					task.delay(4, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v186 = v27(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v186, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v187 = v27(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v187, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
						task.wait(1)
					end)
				end
			end
		end

		local highlight = game.ReplicatedStorage.Characters.Miles.Fx.Highlight
		local localZapText = game.ReplicatedStorage.Characters.Miles.Fx.LocalZapText

		downSlam.OnClientEvent:Connect(function(player, p15)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			if Character:FindFirstChild("Spectacular") then
				local v151 = animationService.LoadFresh(humanoid, specCounterSlam)
				local v152 = animationService.LoadFresh(p15.Humanoid, v19)

				animationService.ConnectMarker(v151, "WebOn", function(_)
					local clone = webbed:Clone()

					webbed:Clone()
					Character.WebArm2.Enabled = true
					Character.HumanoidRootPart.WebShoot2:Play()
					Character.RightHand.Attachment.Blast:Emit(10)
					Character.RightHand.Attachment.Smoke:Emit(10)
					clone.Parent = p15.HumanoidRootPart
					clone:Emit(15)
					game.Debris:AddItem(clone, 3)
				end)
				animationService.ConnectMarker(v151, "WebOff", function(_)
					Character.WebArm2.Enabled = false
				end)
				animationService.ConnectMarker(v151, "Slam", function(_)
					local clone = heavy:Clone()

					clone.Transparency = 1
					clone.Anchored = true
					clone.CanCollide = false
					clone.Parent = workspace
					clone.Position = Character.HumanoidRootPart.SlamAttachment.WorldPosition
					game.Debris:AddItem(clone, 3)
					TestRock2(clone)
					TestRock3(clone)
					clone.Attachment.Sparks:Emit(30)
					clone.Attachment.sh:Emit(1)
					clone.Attachment.sh2:Emit(1)
				end)
				v151:Play()
				v152:Play()
				Character.Head.CounterVc:Play()

				return
			end

			if Character:FindFirstChild("2099") then
				local v153 = animationService.LoadFresh(humanoid, miguelSlam)
				local v154 = animationService.LoadFresh(p15.Humanoid, grabSlamHitAnim)

				animationService.ConnectMarker(v153, "Start", function(_)
					Character.Head.MistakeVc:Play()
				end)
				animationService.ConnectMarker(v153, "WebOn", function(_)
					webbed:Clone()
					webbed:Clone()
					Character.WebArm1Crazy.Width0 = 2
					Character.WebArm1Crazy.Width1 = 2
					Character.WebArm1Crazy.Enabled = true
					Character.HumanoidRootPart.WebShoot2:Play()
				end)
				animationService.ConnectMarker(v153, "CrazyWebOff", function(_)
					webbed:Clone()
					webbed:Clone()
					Character.WebArm1.Width0 = 2
					Character.WebArm1.Width1 = 2
					Character.WebArm1.Enabled = true
					Character.WebArm1Crazy.Enabled = false
				end)
				animationService.ConnectMarker(v153, "Slam", function(_)
					local clone = heavy:Clone()

					clone.Transparency = 1
					clone.Anchored = true
					clone.CanCollide = false
					clone.Parent = workspace
					clone.Position = Character.HumanoidRootPart.SlamAttachment.WorldPosition
					game.Debris:AddItem(clone, 3)
					TestRock2(clone)
					TestRock3(clone)
					clone.Attachment.Sparks:Emit(30)
					clone.Attachment.sh:Emit(1)
					clone.Attachment.sh2:Emit(1)
					Character.WebArm1.Enabled = false
				end)
				v153:Play()
				v154:Play()

				return
			end

			if Character:FindFirstChild("Miles") then
				local v155 = animationService.LoadFresh(humanoid, counterMiles)
				local v156 = animationService.LoadFresh(p15.Humanoid, hitCounterMiles)

				animationService.ConnectMarker(v155, "ChargeUp", function(_)
					Character.Head.ThingVc:Play()
					Character.Head.ElectricCounter:Play()
					game.TweenService:Create(Character.HumanoidRootPart.GlowStart1, TweenInfo.new(2), { Brightness = 3 }):Play()
					game.TweenService:Create(Character.HumanoidRootPart.GlowStart2, TweenInfo.new(2), { Brightness = 5 }):Play()
					task.wait(1)
					Character.RightHand.Electric.Enabled = true
					Character.RightHand.Electric2.Enabled = true
					Character.RightLowerArm.Electric.Enabled = true
					Character.RightLowerArm.Electric2.Enabled = true
					Character.LeftHand.Electric.Enabled = true
					Character.LeftHand.Electric2.Enabled = true
					Character.LeftLowerArm.Electric.Enabled = true
					Character.LeftLowerArm.Electric2.Enabled = true
				end)
				animationService.ConnectMarker(v155, "Release", function(_)
					local clone = highlight:Clone()

					clone.Parent = Character
					game.Debris:AddItem(clone, 1)

					local clone2 = localZapText:Clone()

					clone2.Parent = Character
					clone2.Enabled = true
					game.Debris:AddItem(clone2, 1.5)

					local clone3 = localZapText:Clone()

					clone3.Parent = p15
					clone3.Enabled = true
					game.Debris:AddItem(clone3, 1.5)
					Character.HumanoidRootPart.ElectricAt.El1:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El2:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El3:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El4:Emit(5)
					TestRock(Character.HumanoidRootPart)
					TestRock2(Character.HumanoidRootPart)
					TestRock3(Character.HumanoidRootPart)
					RockSpawn(Character.HumanoidRootPart, 60, NumberRange.new(0.5, 2), workspace.Effects, 15, false, true)
					Character.HumanoidRootPart.Glow.Enabled = true
					Character.HumanoidRootPart.GlowStart1.Brightness = 0
					Character.HumanoidRootPart.GlowStart2.Brightness = 0
					Character.RightHand.Electric.Enabled = false
					Character.RightHand.Electric2.Enabled = false
					Character.RightLowerArm.Electric.Enabled = false
					Character.RightLowerArm.Electric2.Enabled = false
					Character.LeftHand.Electric.Enabled = false
					Character.LeftHand.Electric2.Enabled = false
					Character.LeftLowerArm.Electric.Enabled = false
					Character.LeftLowerArm.Electric2.Enabled = false
					game.TweenService:Create(clone, TweenInfo.new(0.1), { FillTransparency = 0 }):Play()
					task.wait(0.1)
					game.TweenService:Create(clone, TweenInfo.new(0.1), { FillTransparency = 1 }):Play()
					Character.HumanoidRootPart.Glow.Enabled = false
					Character.HumanoidRootPart.ElectricAt.El1:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El2:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El3:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El4:Emit(5)
					task.wait(0.1)
					game.TweenService:Create(clone, TweenInfo.new(0.1), { FillTransparency = 0 }):Play()
					Character.HumanoidRootPart.Glow.Enabled = true
					Character.HumanoidRootPart.ElectricAt.El1:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El2:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El3:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El4:Emit(5)
					task.wait(0.1)
					game.TweenService:Create(clone, TweenInfo.new(0.1), { FillTransparency = 1 }):Play()
					Character.HumanoidRootPart.ElectricAt.El1:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El2:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El3:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El4:Emit(5)
					task.wait(0.1)
					game.TweenService:Create(clone, TweenInfo.new(0.1), { FillTransparency = 0 }):Play()
					Character.HumanoidRootPart.Glow.Enabled = false
					game.TweenService:Create(Character.HumanoidRootPart.GlowStart1, TweenInfo.new(0.5), { Brightness = 0 }):Play()
					game.TweenService:Create(Character.HumanoidRootPart.GlowStart2, TweenInfo.new(0.5), { Brightness = 0 }):Play()
					Character.HumanoidRootPart.ElectricAt.El1:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El2:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El3:Emit(5)
					Character.HumanoidRootPart.ElectricAt.El4:Emit(5)
					clone:Destroy()
				end)
				v155:Play()
				v156:Play()

				return
			end

			local v157: boolean = false

			if Character:FindFirstChild("WebWeaver") then
				Character.WebArm1.Enabled = true
				Character.WebArm2.Enabled = true

				local v158 = animationService.LoadFresh(humanoid, weaverCounterSlam)
				local v159 = animationService.LoadFresh(p15.Humanoid, v19)

				v158.KeyframeReached:Connect(function(p25)
					if p25 == "GroundHit" then
						Character.HumanoidRootPart.Explode:Play()

						local clone = heavy:Clone()

						clone.Transparency = 1
						clone.Anchored = true
						clone.CanCollide = false
						clone.Parent = workspace
						clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, -1.5, -16.958)
						game.Debris:AddItem(clone, 3)
						TestRock2(clone)
						TestRock3(clone)
						clone.Attachment.Sparks:Emit(30)
						clone.Attachment.sh:Emit(1)
						clone.Attachment.sh2:Emit(1)
					end
				end)

				if Character.Head:FindFirstChild("CounterSlamLine") then
					Character.Head.CounterSlamLine:Play()
				end

				v158:Play()
				v159:Play()
				v157 = true
			end

			local v161
			local v163

			if not v157 then
				Character.WebArm1.Enabled = true
				Character.WebArm2.Enabled = true
				v161 = animationService.LoadFresh(humanoid, counterSlam)
				v163 = animationService.LoadFresh(p15.Humanoid, v19)
				v161.KeyframeReached:Connect(function(p26)
					if p26 == "GroundHit" then
						Character.HumanoidRootPart.Explode:Play()

						local clone = heavy:Clone()

						clone.Transparency = 1
						clone.Anchored = true
						clone.CanCollide = false
						clone.Parent = workspace
						clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, -1.5, -16.958)
						game.Debris:AddItem(clone, 3)
						TestRock2(clone)
						TestRock3(clone)
						clone.Attachment.Sparks:Emit(30)
						clone.Attachment.sh:Emit(1)
						clone.Attachment.sh2:Emit(1)
					end
				end)

				if Character.Head:FindFirstChild("CounterSlamLine") then
					Character.Head.CounterSlamLine:Play()
				end

				v161:Play()
				v163:Play()
			end

			local clone = webbed:Clone()
			local clone4 = webbed:Clone()

			task.wait(0.1)
			Character.HumanoidRootPart.WebShoot2:Play()
			Character.RightHand.Attachment.Blast:Emit(10)
			Character.RightHand.Attachment.Smoke:Emit(10)
			clone.Parent = p15.HumanoidRootPart
			clone:Emit(15)
			game.Debris:AddItem(clone, 3)
			task.wait(0.3)
			Character.HumanoidRootPart.Jump:Play()

			if not Character.Head:FindFirstChild("CounterSlamLine") then
				Character.Head.Grunt2:Play()
			end

			task.wait(0.1)
			Character.HumanoidRootPart.WebShoot:Play()
			Character.LeftHand.Attachment.Blast:Emit(10)
			Character.LeftHand.Attachment.Smoke:Emit(10)
			clone4.Parent = p15.HumanoidRootPart
			clone4:Emit(15)
			game.Debris:AddItem(clone4, 3)
			task.wait(1.3)
			Character.HumanoidRootPart.Jump:Play()
			Character.HumanoidRootPart.Stretch:Play()
			task.wait(1.1)
			Character.WebArm1.Enabled = false
			Character.WebArm2.Enabled = false
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.DownSlam", result)
	end
end)

return true
