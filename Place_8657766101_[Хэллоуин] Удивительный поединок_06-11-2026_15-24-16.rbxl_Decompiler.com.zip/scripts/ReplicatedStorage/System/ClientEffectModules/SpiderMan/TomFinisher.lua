-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local tomFinisher = game.ReplicatedStorage.Characters.SpiderMan.Remotes.TomFinisher
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock2(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v28 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v30 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v30, 0)
				local n2 = v28 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v33 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v33 then
					local instance = v33.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v39 = mathRandom(-180, 180)
					local v40 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v39, v40, mathRandom(-180, 180))
					part.Position = p1.Position

					local v41 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v41, { Position = v33.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v149 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v149, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v150 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v150, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local tweenService2: TweenService = game:GetService("TweenService")
		local effects = workspace.Effects
		local v13 = math.random
		local v14 = TweenInfo.new

		local function TestRock(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v46 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v48 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v48, 0)
				local n2 = v46 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v51 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v51 then
					local instance = v51.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local children = instance:GetChildren()

					for _, v in ipairs(children) do
						local v57 = v and v:Clone()

						v57.Parent = workspace.Effects
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v58 = v13(-180, 180)
					local v59 = v13(-180, 180)

					part.Orientation = Vector3.new(v58, v59, v13(-180, 180))
					part.Position = p2.Position

					local v60 = v14(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v60, { Position = v51.Position }):Play()
					part.Parent = effects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v155 = v14(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v155, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v156 = v14(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v156, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v65 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v67 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v69 = math.rad(randomNumber3)
						local v70 = cFrameAngles(v65, v67, v69)

						clone.CFrame = p2.CFrame * v70

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p2.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v78 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v80 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v80, 0)
				local n2 = v78 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v83 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v83 then
					local instance = v83.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v89 = v13(-180, 180)
					local v90 = v13(-180, 180)

					part.Orientation = Vector3.new(v89, v90, v13(-180, 180))
					part.Position = p3.Position

					local v91 = v14(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService2:Create(part, v91, { Position = v83.Position }):Play()
					part.Parent = effects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v161 = v14(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v161, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v162 = v14(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v162, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local smoke = game.ReplicatedStorage.Characters.Vecna.Fx.Smoke
		local tweenService3: TweenService = game:GetService("TweenService")
		local v19 = TweenInfo.new
		local v20 = math.random

		local function Math(p4, p5, p6)
			return p4 + (p5 - p4) * p6
		end
		local function RockSpawn(p7, p8: number, p9, parent, p11, p12, p13)
			if p8 > 180 or p8 < 0 then
				warn("Too high or low of a number!")
				p8 = 15
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p8 do
				local v105 = p7.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v107 = math.rad(n1)
				local v108 = cFrameFromEulerAnglesXYZ(0, v107, 0)
				local cFrame = CFrame.new(0, 0, p11)
				local n2 = v105 * v108 * cFrame.Position
				local v111 = p7.CFrame
				local v112 = CFrame.fromEulerAnglesXYZ
				local v113 = math.rad(n1)
				local v114 = v112(0, v113, 0)
				local cFrame2 = CFrame.new(0, 0, -p11 / 1.25)
				local n3 = v111 * v114 * cFrame2.Position
				local vector3 = Vector3.new(0, -p11, 0)
				local v118 = workspace:Raycast(n2, n3 + vector3 - n2, raycastParams)

				n1 += p8

				if v118 then
					local instance = v118.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local cFrame3 = CFrame.new(v118.Position, p7.Position)
					local cFrameAngles = CFrame.Angles
					local v123 = v20(-3.141592653589793, 3.141592653589793)
					local v124 = cFrameAngles(v123, 0, 0)
					local v125 = p7.Position
					local n4 = v125 + (v118.Position - v125) * 0.2
					local magnitude = (p7.Position - v118.Position).Magnitude

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.CFrame = CFrame.new(n4, p7.Position)
					game.Debris:AddItem(part, 5)

					for _, v in pairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					if p13 == true then
						local v131 = v20(p9.Min, p9.Max)
						local v132 = v20(p9.Min, p9.Max)

						part.Size = Vector3.new(v131, v132, v20(p9.Min, p9.Max))
					else
						part.Size = p9
					end

					if p12 == true then
						local v133 = v20(-180, 180)
						local v134 = v20(-180, 180)

						part.Orientation = Vector3.new(v133, v134, v20(-180, 180))

						local v135 = v19(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService3:Create(part, v135, { Position = v118.Position }):Play()
					elseif p12 == false then
						local v136 = v19(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local cFrame4 = CFrame.new(v118.Position, p7.Position)

						tweenService3:Create(part, v136, { CFrame = cFrame4 }):Play()
					elseif p12 == "Middle" then
						local v138 = v19(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService3:Create(part, v138, { CFrame = cFrame3 * v124 }):Play()
					end

					part.Parent = parent
					task.delay(4, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v167 = v19(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService3:Create(v, v167, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v168 = v19(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService3:Create(part, v168, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
						task.wait(1)
					end)
				end
			end
		end

		local groundhit = game.ReplicatedStorage.Characters.Wanda.Fx.Groundhit

		tomFinisher.OnClientEvent:Connect(function(player, p15)
			local Character = player.Character

			TestRock(p15.HumanoidRootPart)
			TestRock2(p15.HumanoidRootPart)
			TestRock3(p15.HumanoidRootPart)
			RockSpawn(p15.HumanoidRootPart, 60, NumberRange.new(0.5, 2), workspace.Effects, 15, false, true)

			local characterFakeUpperTorso = Character.FakeUpperTorso
			local HumanoidRootPart = Character.HumanoidRootPart
			local characterFakeUpperTorsoPosition = characterFakeUpperTorso.Position
			local cFrame = CFrame.new(characterFakeUpperTorso.Position)
			local t1: {[any]: any} = {
				Position = characterFakeUpperTorsoPosition,
				CFrame = cFrame * HumanoidRootPart.CFrame.Rotation
			}

			TestRock(t1)
			TestRock2(t1)
			TestRock3(t1)
			RockSpawn(t1, 60, NumberRange.new(0.5, 2), workspace.Effects, 15, false, true)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.TomFinisher", result)
	end
end)

return true
