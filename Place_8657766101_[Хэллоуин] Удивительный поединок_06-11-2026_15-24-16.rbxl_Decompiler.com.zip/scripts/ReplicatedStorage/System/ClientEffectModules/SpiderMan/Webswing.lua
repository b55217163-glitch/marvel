-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")

		local function getHand(p1, p2)
			local v14 = (p2 == "RightHand" or p2 == "LeftHand") and p1:FindFirstChild(p2)

			if v14 then
				return v14
			end

			if not p1:FindFirstChild("TomSpider") and not p1:FindFirstChild("WebWeaver") then
				return p1:FindFirstChild("LeftHand")
			end

			return p1:FindFirstChild("RightHand")
		end
		local function getWebSettings(p3)
			local symVal = p3:FindFirstChild("SymVal")

			if symVal and symVal.Value == true then
				local symWebswingWebStart = p3:FindFirstChild("SymWebswingWebStart")
				local symWebswingWeb = p3:FindFirstChild("SymWebswingWeb")

				return {
					StartBeam = symWebswingWebStart,
					MainBeam = symWebswingWeb,
					Sound = p3:FindFirstChild("Head") and p3.Head:FindFirstChild("SwingSym")
				}
			end

			local webswingWebStart = p3:FindFirstChild("WebswingWebStart")
			local webswingWeb = p3:FindFirstChild("WebswingWeb")

			return {
				StartBeam = webswingWebStart,
				MainBeam = webswingWeb,
				Sound = p3:FindFirstChild("Head") and p3.Head:FindFirstChild("SwingMove")
			}
		end
		local function createInvisiblePart(p4, anchored, p6)
			local webswingAnchor: Part = Instance.new("Part")

			webswingAnchor.Name = "WebswingAnchor"
			webswingAnchor.Size = Vector3.new(0.2, 0.2, 0.2)
			webswingAnchor.Transparency = 1
			webswingAnchor.Anchored = anchored
			webswingAnchor.CanCollide = false
			webswingAnchor.CanTouch = false
			webswingAnchor.CanQuery = false
			webswingAnchor.CFrame = CFrame.new(p4)
			webswingAnchor.Parent = workspace
			debris:AddItem(webswingAnchor, p6)

			return webswingAnchor
		end
		local function createAttachment(parent)
			local attachment: Attachment = Instance.new("Attachment")

			attachment.Parent = parent

			return attachment
		end
		local function fadeBeam(p8)
			if not p8 or not p8.Parent then
				return
			end

			local tweenInfo = TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v29: Tween = tweenService:Create(p8, tweenInfo, { Width0 = 0, Width1 = 0 })

			v29:Play()
			v29.Completed:Wait()

			if p8.Parent then
				p8:Destroy()
			end
		end
		local function playWebswingEffect(player, p10)
			local character = player and player.Character

			if not character then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
			local v34 = getHand(character, p10)

			if humanoidRootPart and v34 then
				local attachment = v34:FindFirstChild("Attachment")

				if not attachment then
					return
				end

				local v36 = getWebSettings(character)

				if not v36.StartBeam or not v36.MainBeam then
					warn("Missing webswing beam for:", character.Name)

					return
				end

				if v36.Sound then
					v36.Sound:Play()
				end

				local n1 = humanoidRootPart.Position + Vector3.new(0, 80, 0) + humanoidRootPart.CFrame.LookVector * 15
				local map: Instance = workspace:FindFirstChild("Map")
				local v39 = nil

				if map then
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { map }
					v39 = workspace:Raycast(humanoidRootPart.Position, Vector3.new(0, 80, 0), raycastParams)

					if v39 then
						n1 = v39.Position
					end
				end

				local parent = createInvisiblePart(n1, true, 5)

				if v39 and v39.Instance and v39.Instance:IsA("BasePart") then
					parent.Anchored = false
					parent.CFrame = CFrame.new(v39.Position)

					local weldConstraint: WeldConstraint = Instance.new("WeldConstraint")

					weldConstraint.Part0 = parent
					weldConstraint.Part1 = v39.Instance
					weldConstraint.Parent = parent
				end

				local attachment2: Attachment = Instance.new("Attachment")

				attachment2.Parent = parent

				local clone = v36.StartBeam:Clone()

				clone.Name = "WebswingStartBeam"
				clone.Attachment0 = attachment
				clone.Attachment1 = attachment2
				clone.Enabled = true
				clone.Parent = character
				debris:AddItem(clone, 0.4)

				local v45 = not v36.Sound and character:FindFirstChild("Head") and character.Head:FindFirstChild("SwingMove")

				if v45 then
					v45.PlaybackSpeed = math.random(100, 120) / 100
					v45:Play()
				end

				local head = character:FindFirstChild("Head")

				if head then
					local t1: {[any]: any} = {}
					local webShoot = head:FindFirstChild("WebShoot")
					local webShoot2 = head:FindFirstChild("WebShoot2")

					if webShoot then
						table.insert(t1, webShoot)
					end

					if webShoot2 then
						table.insert(t1, webShoot2)
					end

					if #t1 > 0 then
						local randomNumber = math.random(1, #t1)
						local v51 = t1[randomNumber]

						v51.PlaybackSpeed = math.random(100, 120) / 100
						v51:Play()
					end
				end

				v45 = (not character:FindFirstChild("SymVal") or not character.SymVal.Value) and character:FindFirstChild("Andrew") and attachment:FindFirstChild("RedLight")

				if v45 and v45:IsA("ParticleEmitter") then
					v45:Emit(15)
				end

				task.wait(0.2)

				if not character.Parent or not v34.Parent then
					return
				end

				local clone2 = v36.MainBeam:Clone()

				clone2.Name = "WebswingMainBeam"
				clone2.Attachment0 = attachment
				clone2.Attachment1 = attachment2
				clone2.Enabled = true
				clone2.Parent = character

				if clone.Parent then
					clone:Destroy()
				end

				task.wait(0.6)

				if not clone2.Parent then
					return
				end

				local looseWebEnd = createInvisiblePart(v34.Position, false, 5)

				looseWebEnd.Name = "LooseWebEnd"
				looseWebEnd.Size = Vector3.new(0.3, 0.3, 0.3)
				looseWebEnd.Massless = false
				looseWebEnd.CustomPhysicalProperties = PhysicalProperties.new(0.15, 0, 0, 0, 0)

				local attachment3: Attachment = Instance.new("Attachment")

				attachment3.Parent = looseWebEnd
				clone2.Attachment0 = attachment3
				clone2.Attachment1 = attachment2

				local looseWebRope: RopeConstraint = Instance.new("RopeConstraint")

				looseWebRope.Name = "LooseWebRope"
				looseWebRope.Attachment0 = attachment3
				looseWebRope.Attachment1 = attachment2
				looseWebRope.Visible = false
				looseWebRope.Restitution = 0
				looseWebRope.Length = math.max(1, (looseWebEnd.Position - parent.Position).Magnitude)
				looseWebRope.Parent = looseWebEnd

				local n2 = humanoidRootPart.AssemblyLinearVelocity * 0.65
				local rightVector = humanoidRootPart.CFrame.RightVector
				local randomNumber = math.random(-5, 5)

				looseWebEnd.AssemblyLinearVelocity = n2 + rightVector * randomNumber

				local randomNumber2 = math.random(-3, 3)
				local randomNumber3 = math.random(-3, 3)

				looseWebEnd.AssemblyAngularVelocity = Vector3.new(randomNumber2, randomNumber3, math.random(-3, 3))
				task.wait(4)
				fadeBeam(clone2)

				return
			end
		end

		replicatedStorage.Characters.SpiderMan.Remotes.Webswing.OnClientEvent:Connect(function(p11, p12)
			task.spawn(function()
				local ok2, result2 = pcall(playWebswingEffect, p11, p12)

				if not ok2 then
					warn("Webswing effect failed:", result2)
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.Webswing", result)
	end
end)

return true
