-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local groundBreakDecal = game.ReplicatedStorage.Movement.Rocks.Fx.GroundBreakDecal
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local medBoom = game.ReplicatedStorage.Movement.Rocks.Sfx.MedBoom

		local function Rockfun(_, p2)
			task.spawn(function()
				local raycastParams = RaycastParams.new()
				local workspaceMap = workspace.Map

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspaceMap }

				local v25 = workspace:Raycast(p2.WorldPosition, p2.CFrame.UpVector * -6, raycastParams)

				if v25 ~= nil then
					local part: Part = Instance.new("Part")

					part.Position = v25.Position

					local randomNumber = math.random(-2, 2)
					local partCFrame: CFrame = part.CFrame
					local vector3 = Vector3.new(randomNumber, 0, 0)

					part.CFrame = partCFrame + vector3
					part.Parent = workspace
					part.Anchored = true
					part.Size = Vector3.new(0, 0, 0)
					part.CanCollide = false
					part.CanTouch = false
					game.Debris:AddItem(part, 3)

					local randomNumber2 = math.random(2, 2.5)
					local randomNumber3 = math.random(360)
					local v32 = math.rad(randomNumber3)
					local randomNumber4 = math.random(360)
					local v34 = math.rad(randomNumber4)
					local randomNumber5 = math.random(360)
					local v36 = math.rad(randomNumber5)
					local TweenService = game.TweenService
					local cFrame = CFrame.new(part.Position)
					local v39 = CFrame.Angles(v32, v34, v36)

					TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v39 }):Play()

					local TweenService2 = game.TweenService
					local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

					TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
					part.Material = v25.Material
					part.Color = v25.Instance.Color

					local clone = smoke:Clone()

					clone.Parent = part

					local colorSequenceNew = ColorSequence.new
					local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

					clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
					clone:Emit(2)

					if math.random(1, 3) == 1 then
						for _ = 1, 1 do
							local explosionPart: Part = Instance.new("Part")

							explosionPart.Anchored = false
							explosionPart.Name = "ExplosionPart"

							local randomNumber6 = math.random(1.5, 2.5)
							local randomNumber7 = math.random(1.5, 2.5)

							explosionPart.Size = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))
							explosionPart.Material = part.Material
							explosionPart.CanCollide = true
							explosionPart.CFrame = part.CFrame
							explosionPart.Color = v25.Instance.Color

							local randomNumber8 = math.random(-80, 80)
							local randomNumber9 = math.random(0, 80)

							explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

							local cFrame2 = CFrame.new(part.Position)
							local v52 = CFrame.Angles(v32, v34, v36)

							explosionPart.CFrame = cFrame2 * v52
							explosionPart.Parent = workspace
							game.Debris:AddItem(explosionPart, 3)

							local part2: Part = Instance.new("Part")

							part2.Anchored = false
							part2.Name = "ExplosionPart"
							part2.Size = Vector3.new(0, 0, 0)
							part2.Material = part.Material
							part2.CanCollide = true
							part2.CFrame = part.CFrame
							part2.Color = v25.Instance.Color
							game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

							local randomNumber10 = math.random(-40, 40)
							local randomNumber11 = math.random(0, 40)

							part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

							local cFrame3 = CFrame.new(part.Position)
							local v57 = CFrame.Angles(v32, v34, v36)

							part2.CFrame = cFrame3 * v57
							part2.Parent = workspace
							game.Debris:AddItem(part2, 3)
							task.delay(2, function()
								game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							end)
						end
					end

					local randomNumber12 = math.random(2, 2.3)

					task.delay(randomNumber12, function()
						local randomNumber13 = math.random(360)
						local v208 = math.rad(randomNumber13)
						local randomNumber14 = math.random(360)
						local v210 = math.rad(randomNumber14)
						local randomNumber15 = math.random(360)
						local v212 = math.rad(randomNumber15)
						local TweenService3 = game.TweenService
						local cFrame4 = CFrame.new(part.Position)
						local v215 = CFrame.Angles(v208, v210, v212)

						TweenService3:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v215 }):Play()
						game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
						game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
					end)
				end
			end)
		end

		local inkDrip = game.ReplicatedFirst.Effects.Blood.Fx.InkDrip
		local inkSplash = game.ReplicatedFirst.Effects.Blood.Fx.InkSplash

		local function InkDrops(p3, p4, _)
			for _ = 1, p4 do
				task.spawn(function()
					local boolValue: BoolValue = Instance.new("BoolValue")

					boolValue.Parent = p3
					game.Debris:AddItem(boolValue, 5)

					local clone = inkDrip:Clone()

					clone.Parent = workspace.Effects
					clone.Position = p3.UpperTorso.Position + Vector3.new(0, 0, 0)

					local randomNumber = math.random(-15, 15)
					local randomNumber16 = math.random(2, 35)

					clone.Velocity = Vector3.new(randomNumber, randomNumber16, math.random(-15, 15))
					game.Debris:AddItem(clone, 5)
					clone.CFrame = p3.UpperTorso.CFrame
					game.Debris:AddItem(clone, 6)
					task.spawn(function()
						local connection = game:GetService("RunService").Heartbeat:Connect(function()
							local raycastParams = RaycastParams.new()

							raycastParams.FilterType = Enum.RaycastFilterType.Include
							raycastParams.FilterDescendantsInstances = { workspace.Map }

							local v254 = workspace:Raycast(clone.Position, Vector3.new(-0.5, -0.5, -0.5), raycastParams)

							if v254 and v254.Instance.Anchored == true and v254.Instance.CanCollide == true then
								local v255 = CFrame.lookAt(v254.Position, v254.Position + v254.Normal)
								local v256 = CFrame.Angles(-1.5707963267948966, 0, 0)

								boolValue:Destroy()

								local clone2 = inkSplash:Clone()

								game.Debris:AddItem(clone2, 10)
								clone2.Parent = game.Workspace.Effects

								local clone2Size = clone2.Size

								clone2.Size = Vector3.new(0, 0, 0)
								math.random(0.5, 1)
								clone2.CFrame = v255 * v256
								clone.Anchored = true
								clone.Transparency = 1
								task.spawn(function()
									local randomNumber17 = math.random(1, 3)

									if randomNumber17 == 1 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(0.5, 0.2, 0.5) }):Play()
									elseif randomNumber17 == 2 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(0.8, 0.2, 0.8) }):Play()
									elseif randomNumber17 == 3 then
										game:GetService("TweenService"):Create(clone2, TweenInfo.new(0.3), { Size = Vector3.new(2, 0.2, 2) }):Play()
									end

									if clone2:FindFirstChild("BloodSFX") then
										clone2.BloodSFX.PlaybackSpeed = math.random(0.9, 1.2)
										clone2.BloodSFX:Play()
									end

									task.wait(math.random(3, 5))
									game:GetService("TweenService"):Create(clone2, TweenInfo.new(2), { Size = Vector3.new(0, 0, 0) }):Play()
									game.Debris:AddItem(clone2, 2)
									task.wait(0.2)
									clone:Destroy()
									task.wait(2)
									clone2:Destroy()
								end)
							end
						end)

						task.spawn(function()
							boolValue.Destroying:Connect(function()
								connection:Disconnect()
							end)
						end)
					end)
				end)
			end
		end

		game.ReplicatedStorage.Characters.SpiderMan.Remotes.SymbiotePunch.OnClientEvent:Connect(function(player)
			local Character = player.Character
			local n1: number = 0

			repeat
				local at1 = Character.HumanoidRootPart.At1

				task.spawn(function()
					local raycastParams = RaycastParams.new()
					local workspaceMap = workspace.Map

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspaceMap }

					local v65 = workspace:Raycast(at1.WorldPosition, at1.CFrame.UpVector * -6, raycastParams)

					if v65 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v65.Position

						local randomNumber = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber18 = math.random(2, 2.5)
						local randomNumber19 = math.random(360)
						local v72 = math.rad(randomNumber19)
						local randomNumber20 = math.random(360)
						local v74 = math.rad(randomNumber20)
						local randomNumber21 = math.random(360)
						local v76 = math.rad(randomNumber21)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v79 = CFrame.Angles(v72, v74, v76)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v79 }):Play()

						local TweenService4 = game.TweenService
						local vector33 = Vector3.new(randomNumber18, randomNumber18, randomNumber18)

						TweenService4:Create(part, TweenInfo.new(0.25), { Size = vector33 }):Play()
						part.Material = v65.Material
						part.Color = v65.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"

								local randomNumber22 = math.random(1.5, 2.5)
								local randomNumber23 = math.random(1.5, 2.5)

								explosionPart.Size = Vector3.new(randomNumber22, randomNumber23, math.random(1.5, 2.5))
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v65.Instance.Color

								local randomNumber24 = math.random(-80, 80)
								local randomNumber25 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber24, randomNumber25, math.random(-80, 80))

								local cFrame5 = CFrame.new(part.Position)
								local v92 = CFrame.Angles(v72, v74, v76)

								explosionPart.CFrame = cFrame5 * v92
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part3: Part = Instance.new("Part")

								part3.Anchored = false
								part3.Name = "ExplosionPart"
								part3.Size = Vector3.new(0, 0, 0)
								part3.Material = part.Material
								part3.CanCollide = true
								part3.CFrame = part.CFrame
								part3.Color = v65.Instance.Color
								game.TweenService:Create(part3, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber26 = math.random(-40, 40)
								local randomNumber27 = math.random(0, 40)

								part3.Velocity = Vector3.new(randomNumber26, randomNumber27, math.random(-40, 40))

								local cFrame6 = CFrame.new(part.Position)
								local v97 = CFrame.Angles(v72, v74, v76)

								part3.CFrame = cFrame6 * v97
								part3.Parent = workspace
								game.Debris:AddItem(part3, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part3, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber28 = math.random(2, 2.3)

						task.delay(randomNumber28, function()
							local randomNumber29 = math.random(360)
							local v218 = math.rad(randomNumber29)
							local randomNumber30 = math.random(360)
							local v220 = math.rad(randomNumber30)
							local randomNumber31 = math.random(360)
							local v222 = math.rad(randomNumber31)
							local TweenService5 = game.TweenService
							local cFrame7 = CFrame.new(part.Position)
							local v225 = CFrame.Angles(v218, v220, v222)

							TweenService5:Create(part, TweenInfo.new(0.5), { CFrame = cFrame7 * v225 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end)

				local at2 = Character.HumanoidRootPart.At2

				task.spawn(function()
					local raycastParams = RaycastParams.new()
					local workspaceMap = workspace.Map

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspaceMap }

					local v101 = workspace:Raycast(at2.WorldPosition, at2.CFrame.UpVector * -6, raycastParams)

					if v101 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v101.Position

						local randomNumber = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber32 = math.random(2, 2.5)
						local randomNumber33 = math.random(360)
						local v108 = math.rad(randomNumber33)
						local randomNumber34 = math.random(360)
						local v110 = math.rad(randomNumber34)
						local randomNumber35 = math.random(360)
						local v112 = math.rad(randomNumber35)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v115 = CFrame.Angles(v108, v110, v112)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v115 }):Play()

						local TweenService6 = game.TweenService
						local vector34 = Vector3.new(randomNumber32, randomNumber32, randomNumber32)

						TweenService6:Create(part, TweenInfo.new(0.25), { Size = vector34 }):Play()
						part.Material = v101.Material
						part.Color = v101.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"

								local randomNumber36 = math.random(1.5, 2.5)
								local randomNumber37 = math.random(1.5, 2.5)

								explosionPart.Size = Vector3.new(randomNumber36, randomNumber37, math.random(1.5, 2.5))
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v101.Instance.Color

								local randomNumber38 = math.random(-80, 80)
								local randomNumber39 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber38, randomNumber39, math.random(-80, 80))

								local cFrame8 = CFrame.new(part.Position)
								local v128 = CFrame.Angles(v108, v110, v112)

								explosionPart.CFrame = cFrame8 * v128
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part4: Part = Instance.new("Part")

								part4.Anchored = false
								part4.Name = "ExplosionPart"
								part4.Size = Vector3.new(0, 0, 0)
								part4.Material = part.Material
								part4.CanCollide = true
								part4.CFrame = part.CFrame
								part4.Color = v101.Instance.Color
								game.TweenService:Create(part4, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber40 = math.random(-40, 40)
								local randomNumber41 = math.random(0, 40)

								part4.Velocity = Vector3.new(randomNumber40, randomNumber41, math.random(-40, 40))

								local cFrame9 = CFrame.new(part.Position)
								local v133 = CFrame.Angles(v108, v110, v112)

								part4.CFrame = cFrame9 * v133
								part4.Parent = workspace
								game.Debris:AddItem(part4, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part4, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber42 = math.random(2, 2.3)

						task.delay(randomNumber42, function()
							local randomNumber43 = math.random(360)
							local v227 = math.rad(randomNumber43)
							local randomNumber44 = math.random(360)
							local v229 = math.rad(randomNumber44)
							local randomNumber45 = math.random(360)
							local v231 = math.rad(randomNumber45)
							local TweenService7 = game.TweenService
							local cFrame10 = CFrame.new(part.Position)
							local v234 = CFrame.Angles(v227, v229, v231)

							TweenService7:Create(part, TweenInfo.new(0.5), { CFrame = cFrame10 * v234 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end)
				InkDrops(Character, 10, Character)
				task.wait(0.1)

				local v21 = Character.HumanoidRootPart.At1

				task.spawn(function()
					local raycastParams = RaycastParams.new()
					local workspaceMap = workspace.Map

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspaceMap }

					local v137 = workspace:Raycast(v21.WorldPosition, v21.CFrame.UpVector * -6, raycastParams)

					if v137 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v137.Position

						local randomNumber = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber46 = math.random(2, 2.5)
						local randomNumber47 = math.random(360)
						local v144 = math.rad(randomNumber47)
						local randomNumber48 = math.random(360)
						local v146 = math.rad(randomNumber48)
						local randomNumber49 = math.random(360)
						local v148 = math.rad(randomNumber49)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v151 = CFrame.Angles(v144, v146, v148)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v151 }):Play()

						local TweenService8 = game.TweenService
						local vector35 = Vector3.new(randomNumber46, randomNumber46, randomNumber46)

						TweenService8:Create(part, TweenInfo.new(0.25), { Size = vector35 }):Play()
						part.Material = v137.Material
						part.Color = v137.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"

								local randomNumber50 = math.random(1.5, 2.5)
								local randomNumber51 = math.random(1.5, 2.5)

								explosionPart.Size = Vector3.new(randomNumber50, randomNumber51, math.random(1.5, 2.5))
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v137.Instance.Color

								local randomNumber52 = math.random(-80, 80)
								local randomNumber53 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber52, randomNumber53, math.random(-80, 80))

								local cFrame11 = CFrame.new(part.Position)
								local v164 = CFrame.Angles(v144, v146, v148)

								explosionPart.CFrame = cFrame11 * v164
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part5: Part = Instance.new("Part")

								part5.Anchored = false
								part5.Name = "ExplosionPart"
								part5.Size = Vector3.new(0, 0, 0)
								part5.Material = part.Material
								part5.CanCollide = true
								part5.CFrame = part.CFrame
								part5.Color = v137.Instance.Color
								game.TweenService:Create(part5, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber54 = math.random(-40, 40)
								local randomNumber55 = math.random(0, 40)

								part5.Velocity = Vector3.new(randomNumber54, randomNumber55, math.random(-40, 40))

								local cFrame12 = CFrame.new(part.Position)
								local v169 = CFrame.Angles(v144, v146, v148)

								part5.CFrame = cFrame12 * v169
								part5.Parent = workspace
								game.Debris:AddItem(part5, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part5, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber56 = math.random(2, 2.3)

						task.delay(randomNumber56, function()
							local randomNumber57 = math.random(360)
							local v236 = math.rad(randomNumber57)
							local randomNumber58 = math.random(360)
							local v238 = math.rad(randomNumber58)
							local randomNumber59 = math.random(360)
							local v240 = math.rad(randomNumber59)
							local TweenService9 = game.TweenService
							local cFrame13 = CFrame.new(part.Position)
							local v243 = CFrame.Angles(v236, v238, v240)

							TweenService9:Create(part, TweenInfo.new(0.5), { CFrame = cFrame13 * v243 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end)

				local v22 = Character.HumanoidRootPart.At2

				task.spawn(function()
					local raycastParams = RaycastParams.new()
					local workspaceMap = workspace.Map

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { workspaceMap }

					local v173 = workspace:Raycast(v22.WorldPosition, v22.CFrame.UpVector * -6, raycastParams)

					if v173 ~= nil then
						local part: Part = Instance.new("Part")

						part.Position = v173.Position

						local randomNumber = math.random(-2, 2)
						local partCFrame: CFrame = part.CFrame
						local vector3 = Vector3.new(randomNumber, 0, 0)

						part.CFrame = partCFrame + vector3
						part.Parent = workspace
						part.Anchored = true
						part.Size = Vector3.new(0, 0, 0)
						part.CanCollide = false
						part.CanTouch = false
						game.Debris:AddItem(part, 3)

						local randomNumber60 = math.random(2, 2.5)
						local randomNumber61 = math.random(360)
						local v180 = math.rad(randomNumber61)
						local randomNumber62 = math.random(360)
						local v182 = math.rad(randomNumber62)
						local randomNumber63 = math.random(360)
						local v184 = math.rad(randomNumber63)
						local TweenService = game.TweenService
						local cFrame = CFrame.new(part.Position)
						local v187 = CFrame.Angles(v180, v182, v184)

						TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v187 }):Play()

						local TweenService10 = game.TweenService
						local vector36 = Vector3.new(randomNumber60, randomNumber60, randomNumber60)

						TweenService10:Create(part, TweenInfo.new(0.25), { Size = vector36 }):Play()
						part.Material = v173.Material
						part.Color = v173.Instance.Color

						local clone = smoke:Clone()

						clone.Parent = part

						local colorSequenceNew = ColorSequence.new
						local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

						clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
						clone:Emit(2)

						if math.random(1, 3) == 1 then
							for _ = 1, 1 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"

								local randomNumber64 = math.random(1.5, 2.5)
								local randomNumber65 = math.random(1.5, 2.5)

								explosionPart.Size = Vector3.new(randomNumber64, randomNumber65, math.random(1.5, 2.5))
								explosionPart.Material = part.Material
								explosionPart.CanCollide = true
								explosionPart.CFrame = part.CFrame
								explosionPart.Color = v173.Instance.Color

								local randomNumber66 = math.random(-80, 80)
								local randomNumber67 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber66, randomNumber67, math.random(-80, 80))

								local cFrame14 = CFrame.new(part.Position)
								local v200 = CFrame.Angles(v180, v182, v184)

								explosionPart.CFrame = cFrame14 * v200
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 3)

								local part6: Part = Instance.new("Part")

								part6.Anchored = false
								part6.Name = "ExplosionPart"
								part6.Size = Vector3.new(0, 0, 0)
								part6.Material = part.Material
								part6.CanCollide = true
								part6.CFrame = part.CFrame
								part6.Color = v173.Instance.Color
								game.TweenService:Create(part6, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber68 = math.random(-40, 40)
								local randomNumber69 = math.random(0, 40)

								part6.Velocity = Vector3.new(randomNumber68, randomNumber69, math.random(-40, 40))

								local cFrame15 = CFrame.new(part.Position)
								local v205 = CFrame.Angles(v180, v182, v184)

								part6.CFrame = cFrame15 * v205
								part6.Parent = workspace
								game.Debris:AddItem(part6, 3)
								task.delay(2, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part6, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end

						local randomNumber70 = math.random(2, 2.3)

						task.delay(randomNumber70, function()
							local randomNumber71 = math.random(360)
							local v245 = math.rad(randomNumber71)
							local randomNumber72 = math.random(360)
							local v247 = math.rad(randomNumber72)
							local randomNumber73 = math.random(360)
							local v249 = math.rad(randomNumber73)
							local TweenService11 = game.TweenService
							local cFrame16 = CFrame.new(part.Position)
							local v252 = CFrame.Angles(v245, v247, v249)

							TweenService11:Create(part, TweenInfo.new(0.5), { CFrame = cFrame16 * v252 }):Play()
							game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
							game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
						end)
					end
				end)
				n1 += 1
			until n1 == 20
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.SymbioteStrike", result)
	end
end)

return true
