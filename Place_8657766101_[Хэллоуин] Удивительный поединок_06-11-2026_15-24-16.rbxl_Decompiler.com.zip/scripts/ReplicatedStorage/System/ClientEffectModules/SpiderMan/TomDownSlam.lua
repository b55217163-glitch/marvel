-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local tomDownSlam = game.ReplicatedStorage.Characters.SpiderMan.Remotes.TomDownSlam
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v21 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v23 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v23, 0)
				local n2 = v21 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v26 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v26 then
					local instance = v26.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v32 = mathRandom(-180, 180)
					local v33 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v32, v33, mathRandom(-180, 180))
					part.Position = p1.Position

					local v34 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v34, { Position = v26.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v91 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v91, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v92 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v92, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v39 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v41 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v43 = math.rad(randomNumber3)
						local v44 = cFrameAngles(v39, v41, v43)

						clone.CFrame = p1.CFrame * v44

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end

		TestRock = function(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v52 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v54 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v54, 0)
				local n2 = v52 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v57 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v57 then
					local instance = v57.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v63 = mathRandom(-180, 180)
					local v64 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v63, v64, mathRandom(-180, 180))
					part.Position = p2.Position

					local v65 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v65, { Position = v57.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v97 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v97, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v98 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v98, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		TestRock = function(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v70 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v72 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v72, 0)
				local n2 = v70 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v75 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v75 then
					local instance = v75.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v81 = mathRandom(-180, 180)
					local v82 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v81, v82, mathRandom(-180, 180))
					part.Position = p3.Position

					local v83 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v83, { Position = v75.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v103 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v103, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v104 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v104, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local heavy = game.ReplicatedStorage.Characters.SpiderMan.Fx.Heavy
		local finisherTom = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.FinisherTom
		local finisherAndrewHit = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.FinisherAndrewHit
		local taserHitSfx = game.ReplicatedStorage.Characters.TheBatman.Fx.TaserHitSfx
		local TweenService = game.TweenService

		tomDownSlam.OnClientEvent:Connect(function(player, p5)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			animationService.GetTrack(humanoid, finisherTom):Play()
			Character.WebArm1.Enabled = true
			Character.WebArm2.Enabled = true
			Character.Head.TaserWeb:Play()
			task.wait(0.1)
			Character.HumanoidRootPart.Stretch:Play()
			Character.HumanoidRootPart.WebShoot:Play()
			Character.RightHand.Attachment.Blast:Emit(10)
			Character.RightHand.Attachment.Smoke:Emit(10)
			Character.HumanoidRootPart.WebShoot2:Play()
			Character.LeftHand.Attachment.Blast:Emit(10)
			Character.LeftHand.Attachment.Smoke:Emit(10)
			task.wait(0.4)
			Character.HumanoidRootPart.Dash:Play()
			Character.HumanoidRootPart.Kick:Play()
			task.wait(0.1)
			Character.TaserWeb1.Width0 = 0
			Character.TaserWeb1.Width1 = 0
			Character.TaserWeb2.Width0 = 0
			Character.TaserWeb2.Width1 = 0
			task.wait(0.3)
			Character.HumanoidRootPart.Jump:Play()
			Character.HumanoidRootPart.Taser:Play()
			Character.TaserWeb1.Enabled = true
			Character.TaserWeb2.Enabled = true
			TweenService:Create(Character.TaserWeb1, TweenInfo.new(0.2), { Width0 = 1.5 }):Play()
			TweenService:Create(Character.TaserWeb1, TweenInfo.new(0.2), { Width1 = 1.5 }):Play()
			TweenService:Create(Character.TaserWeb2, TweenInfo.new(0.2), { Width0 = 1.5 }):Play()
			TweenService:Create(Character.TaserWeb2, TweenInfo.new(0.2), { Width1 = 1.5 }):Play()

			local clone = taserHitSfx:Clone()

			clone.Parent = p5.HumanoidRootPart
			clone:Play()
			game.Debris:AddItem(clone, 3)
			task.wait(1)
			TweenService:Create(Character.TaserWeb1, TweenInfo.new(0.2), { Width0 = 0 }):Play()
			TweenService:Create(Character.TaserWeb1, TweenInfo.new(0.2), { Width1 = 0 }):Play()
			TweenService:Create(Character.TaserWeb2, TweenInfo.new(0.2), { Width0 = 0 }):Play()
			TweenService:Create(Character.TaserWeb2, TweenInfo.new(0.2), { Width1 = 0 }):Play()
			task.wait(0.2)
			Character.TaserWeb1.Enabled = false
			Character.TaserWeb2.Enabled = false
			Character.WebArm1.Enabled = false
			Character.WebArm2.Enabled = false
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.TomDownSlam", result)
	end
end)

return true
