-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local heavy = game.ReplicatedStorage.Characters.SpiderMan.Fx.Heavy

		game.ReplicatedStorage.Characters.SpiderMan.Remotes.WebBlossem.OnClientEvent:Connect(function(player, _)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local n1: number = 12

			while n1 > 0 do
				local clone = Character.HumanoidRootPart.WebShoot:Clone()

				clone.PlaybackSpeed = math.random(1, 1.4)
				clone.Parent = Character.HumanoidRootPart
				clone:Play()
				game.Debris:AddItem(clone, 2)
				Character.LeftHand.Attachment.Blast:Emit(5)
				Character.LeftHand.Attachment.Smoke:Emit(5)
				Character.LeftHand.Attachment.Light:Emit(10)
				task.wait(0.1)
				Character.RightHand.Attachment.Blast:Emit(5)
				Character.RightHand.Attachment.Smoke:Emit(5)
				Character.RightHand.Attachment.Light:Emit(10)

				local clone2 = Character.HumanoidRootPart.WebShoot2:Clone()

				clone2.PlaybackSpeed = math.random(1, 1.2)
				clone2.Parent = Character.HumanoidRootPart
				clone2:Play()
				game.Debris:AddItem(clone2, 2)
				n1 -= 1
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.SpamWeb", result)
	end
end)

return true
