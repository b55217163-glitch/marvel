-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local webTornado = game.ReplicatedStorage.Characters.SpiderMan.Fx.WebTornado
		local webCoc = game.ReplicatedStorage.Characters.SpiderMan.Fx.WebCoc

		game.ReplicatedStorage.Characters.SpiderMan.Remotes.WebBallRem.OnClientEvent:Connect(function(_, p2)
			local clone = webTornado:Clone()

			clone.Parent = workspace
			clone.Sound:Play()
			game.Debris:AddItem(clone, 4.3)

			local weld: Weld = Instance.new("Weld", clone)

			weld.Part0 = clone
			weld.Part1 = p2.UpperTorso

			local v11 = CFrame.Angles(0, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v11
			game.TweenService:Create(clone, TweenInfo.new(0.4), { Size = Vector3.new(0, 0, 0) }):Play()
			task.wait(0.1)

			local clone2 = webCoc:Clone()

			clone2.Parent = workspace
			game.Debris:AddItem(clone2, 3.5)

			local weld2: Weld = Instance.new("Weld", clone2)

			weld2.Part0 = clone2
			weld2.Part1 = p2.UpperTorso

			local v14 = CFrame.Angles(0, 0, 0)

			weld2.C0 = CFrame.new(0, 0, 0) * v14
			task.wait(1.9)
			game.TweenService:Create(clone, TweenInfo.new(0.4), { Size = Vector3.new(7.786, 10.343, 7.219) }):Play()
			game.TweenService:Create(clone, TweenInfo.new(0.4), { Transparency = 1 }):Play()

			for _, v in pairs(clone2:GetChildren()) do
				if v:IsA("Decal") then
					task.spawn(function()
						game.TweenService:Create(v, TweenInfo.new(0.3), { Transparency = 1 }):Play()
					end)
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.WebBall", result)
	end
end)

return true
