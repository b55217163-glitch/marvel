-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local beam = game.ReplicatedStorage.Characters.SpiderMan.Fx.Beam
		local webPullAnim = game.ReplicatedStorage.Characters.SpiderMan.AnimationsExtra.WebPullAnim

		local function DashForward(parent, p2)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 100000
			bodyPosition.D = 3000
			bodyPosition.Position = p2.Position
			bodyPosition.Parent = parent
			game.Debris:AddItem(bodyPosition, 0.5)
		end

		game.ReplicatedStorage.Characters.SpiderMan.Remotes.WebGrapple.OnClientEvent:Connect(function(parent, p4)
			animationService.GetTrack(parent.Humanoid, webPullAnim):Play()
			parent.Humanoid.WalkSpeed = 0
			parent.Humanoid.JumpPower = 0
			parent.HumanoidRootPart.WebShoot.PlaybackSpeed = math.random(1, 1.2)
			parent.HumanoidRootPart.WebShoot2.PlaybackSpeed = math.random(1, 1.2)
			parent.HumanoidRootPart.WebShoot:Play()
			parent.HumanoidRootPart.WebShoot2:Play()

			local clone = beam:Clone()

			clone.Parent = parent
			game.Debris:AddItem(clone, 2)

			local clone2 = beam:Clone()

			clone2.Parent = parent
			game.Debris:AddItem(clone2, 2)

			local attachment: Attachment = Instance.new("Attachment")

			attachment.Parent = parent.LeftHand
			game.Debris:AddItem(attachment, 2)

			local attachment2: Attachment = Instance.new("Attachment")

			attachment2.Parent = parent.RightHand
			game.Debris:AddItem(attachment2, 2)

			local attachment3: Attachment = Instance.new("Attachment")

			attachment3.Parent = p4.UpperTorso
			game.Debris:AddItem(attachment3, 2)

			local attachment4: Attachment = Instance.new("Attachment")

			attachment4.Parent = p4.UpperTorso
			game.Debris:AddItem(attachment4, 2)
			clone.Attachment0 = attachment
			clone.Attachment1 = attachment3
			clone2.Attachment0 = attachment2
			clone2.Attachment1 = attachment4
			clone2.CurveSize0 = -10
			clone2.CurveSize1 = 10
			game.TweenService:Create(clone, TweenInfo.new(0.2), { Width0 = 4 }):Play()
			game.TweenService:Create(clone, TweenInfo.new(0.2), { Width1 = 4 }):Play()
			game.TweenService:Create(clone2, TweenInfo.new(0.2), { Width0 = 4 }):Play()
			game.TweenService:Create(clone2, TweenInfo.new(0.2), { Width1 = 4 }):Play()
			task.spawn(function()
				game.TweenService:Create(clone, TweenInfo.new(0.2), { CurveSize0 = 0 }):Play()
				game.TweenService:Create(clone, TweenInfo.new(0.2), { CurveSize1 = 0 }):Play()
				game.TweenService:Create(clone2, TweenInfo.new(0.2), { CurveSize0 = 0 }):Play()
				game.TweenService:Create(clone2, TweenInfo.new(0.2), { CurveSize1 = 0 }):Play()
				task.wait(0.8)
				game.TweenService:Create(clone, TweenInfo.new(0.2), { Width0 = 0 }):Play()
				game.TweenService:Create(clone, TweenInfo.new(0.2), { Width1 = 0 }):Play()
				game.TweenService:Create(clone2, TweenInfo.new(0.2), { Width0 = 0 }):Play()
				game.TweenService:Create(clone2, TweenInfo.new(0.2), { Width1 = 0 }):Play()
			end)
			parent.Head.Stretch:Play()
			task.wait(0.4)
			parent.Head.Grunt1:Play()
			task.wait(0.1)

			local upperTorso = p4.UpperTorso
			local fakeUpperTorso = parent.FakeUpperTorso
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 100000
			bodyPosition.D = 3000
			bodyPosition.Position = fakeUpperTorso.Position
			bodyPosition.Parent = upperTorso
			game.Debris:AddItem(bodyPosition, 0.5)
			parent.Head.PullIn:Play()
			parent.Head.Stretch:Stop()
			task.wait(0.3)
			parent.Humanoid.WalkSpeed = 10
			parent.Humanoid.JumpPower = 30
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.WebPull", result)
	end
end)

return true
