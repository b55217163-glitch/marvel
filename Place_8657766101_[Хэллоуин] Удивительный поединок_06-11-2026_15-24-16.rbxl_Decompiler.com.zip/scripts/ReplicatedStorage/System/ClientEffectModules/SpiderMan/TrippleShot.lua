-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local LocalPlayer = game.Players.LocalPlayer
		local ReplicatedStorage = game.ReplicatedStorage

		local function DashForward(parent)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 10000
			bodyPosition.D = 3000
			bodyPosition.Position = (parent.CFrame * CFrame.new(0, 0, -300)).Position
			bodyPosition.Parent = parent
			game.Debris:AddItem(bodyPosition, 3)
		end

		local webshot = game.ReplicatedStorage.Characters.SpiderMan.Fx.Webshot
		local hitboxPunch = game.ReplicatedStorage.Characters.Combat.Peacemaker.HitboxPunch
		local webHit = game.ReplicatedStorage.Characters.SpiderMan.Remotes.WebHit
		local webbed = game.ReplicatedStorage.Characters.SpiderMan.Fx.Webbed

		game.ReplicatedStorage.Characters.SpiderMan.Remotes.TrippleShot.OnClientEvent:Connect(function(p2, p3)
			local clone = webshot:Clone()

			clone.Parent = workspace.Effects
			game.Debris:AddItem(clone, 3)
			p2.HumanoidRootPart.WebShoot.PlaybackSpeed = math.random(1, 1.2)
			p2.HumanoidRootPart.WebShoot:Play()

			local clone2 = hitboxPunch:Clone()

			clone2.Parent = clone

			local weld: Weld = Instance.new("Weld", clone2)

			weld.Part0 = clone
			weld.Part1 = clone2

			local v17 = CFrame.Angles(0, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v17
			clone.CFrame = p2.HumanoidRootPart.CFrame * CFrame.new(0, 0, 1)
			DashForward(clone)

			if p2:FindFirstChild("SpiderVerse") then
				local randomNumber = math.random(1, 2)

				if randomNumber == 1 then
					p2.HumanoidRootPart.TAt.Twhip:Emit(1)
				elseif randomNumber == 2 then
					p2.HumanoidRootPart.TAt2.Twhip:Emit(1)
				end
			end

			task.spawn(function()
				task.wait(2.7)

				if clone:FindFirstChild("Hitbox") then
					clone.WebAt.Smoke.Enabled = false
					clone.WebAt.Blast.Enabled = false
					clone.WebAt.Blast.Enabled = false
					clone.Anchored = true
					clone2:Destroy()
				end
			end)
			clone2.Touched:Connect(function(_)
				for _, v in ipairs(workspace:GetChildren()) do
					local v22 = v:IsA("Model") and v

					if v22 and v22:FindFirstChild("Humanoid") and v22:FindFirstChild("HumanoidRootPart") and v22 ~= p2 and not v22:FindFirstChild("Iframe") and (clone.Position - v22.HumanoidRootPart.Position).magnitude <= 3 then
						local values = p2:FindFirstChild("Values")
						local values2 = v22:FindFirstChild("Values")
						local v25 = values

						if v25 then
							v25 = values:FindFirstChild("TeamColor")
						end

						local teamColor = values2 and values2:FindFirstChild("TeamColor")

						if not v25 or not teamColor then
							return
						end

						local v27 = v25.Value
						local teamColorValue = teamColor.Value
						local FFAColorValue = game.ReplicatedStorage.FFAColor.Value

						if teamColorValue ~= v27 or teamColorValue == FFAColorValue and v27 == FFAColorValue then
							clone2:Destroy()
							clone.Anchored = true

							if LocalPlayer == p3 then
								webHit:FireServer(v22, p3, p2)
							end

							local clone3 = webbed:Clone()

							clone3.Parent = v22.UpperTorso
							clone3:Emit(30)
							game.Debris:AddItem(clone3, 3)
							clone.WebAt.Smoke.Enabled = false
							clone.WebAt.Blast.Enabled = false
							clone.WebAt.Shockwave.Enabled = false
						end
					end
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "SpiderMan.TrippleShot", result)
	end
end)

return true
