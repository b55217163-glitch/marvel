-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local orbs = game.ReplicatedStorage.Characters.Springbonnie.Fx.Orbs

		game.ReplicatedStorage.Characters.Springbonnie.Remotes.Assist.OnClientEvent:Connect(function(parent, p2)
			p2:WaitForChild("Humanoid", 5)

			local v9 = animationService.LoadFresh(parent.Humanoid, orbs.Animation)
			local clone = orbs:Clone()

			clone.Parent = parent
			game.Debris:AddItem(clone, 4)

			local cloneWGhost1 = clone.WGhost1

			cloneWGhost1.Part0 = parent.HumanoidRootPart
			cloneWGhost1.Part1 = clone.Ghost1
			cloneWGhost1.Parent = clone

			local cloneWGhost2 = clone.WGhost2

			cloneWGhost2.Part0 = parent.HumanoidRootPart
			cloneWGhost2.Part1 = clone.Ghost2
			cloneWGhost2.Parent = clone

			local cloneWGhost3 = clone.WGhost3

			cloneWGhost3.Part0 = parent.HumanoidRootPart
			cloneWGhost3.Part1 = clone.Ghost3
			cloneWGhost3.Parent = clone

			local cloneWGhost4 = clone.WGhost4

			cloneWGhost4.Part0 = parent.HumanoidRootPart
			cloneWGhost4.Part1 = clone.Ghost4
			cloneWGhost4.Parent = clone
			animationService.ConnectMarker(v9, "Start", function(_)
				clone.Ghost1.Sound:Play()
			end)
			animationService.ConnectMarker(v9, "Tra", function(_)
				clone.Ghost1.Transparency = 0
				clone.Ghost2.Transparency = 0
				clone.Ghost3.Transparency = 0
				clone.Ghost4.Transparency = 0
				clone.Ghost1.SmokeTrail.Enabled = true
				clone.Ghost2.SmokeTrail.Enabled = true
				clone.Ghost3.SmokeTrail.Enabled = true
				clone.Ghost4.SmokeTrail.Enabled = true
				clone.Ghost1.PointLight.Enabled = true
				clone.Ghost2.PointLight.Enabled = true
				clone.Ghost3.PointLight.Enabled = true
				clone.Ghost4.PointLight.Enabled = true
			end)
			animationService.ConnectMarker(v9, "End", function(_)
				if clone:FindFirstChild("Ghost1") then
					clone.Ghost1.SmokeTrail.Enabled = false
					clone.Ghost2.SmokeTrail.Enabled = false
					clone.Ghost3.SmokeTrail.Enabled = false
					clone.Ghost4.SmokeTrail.Enabled = false
					game.TweenService:Create(clone.Ghost1, TweenInfo.new(0.5), { Transparency = 1 }):Play()
					game.TweenService:Create(clone.Ghost2, TweenInfo.new(0.5), { Transparency = 1 }):Play()
					game.TweenService:Create(clone.Ghost3, TweenInfo.new(0.5), { Transparency = 1 }):Play()
					game.TweenService:Create(clone.Ghost4, TweenInfo.new(0.5), { Transparency = 1 }):Play()
					clone.Ghost1.PointLight.Enabled = false
					clone.Ghost2.PointLight.Enabled = false
					clone.Ghost3.PointLight.Enabled = false
					clone.Ghost4.PointLight.Enabled = false
				end
			end)
			v9:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Springbonnie.Orbs", result)
	end
end)

return true
