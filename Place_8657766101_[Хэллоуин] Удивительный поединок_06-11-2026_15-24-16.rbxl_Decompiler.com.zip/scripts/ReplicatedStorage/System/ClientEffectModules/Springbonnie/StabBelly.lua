-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local stabBelly = game.ReplicatedStorage.Characters.Springbonnie.Remotes.StabBelly

		game:GetService("TweenService")
		game:GetService("TweenService")
		stabBelly.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character.Head.Thrust:Play()
			task.wait(0.25)

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			local v9 = workspace:Raycast(Character.FakeUpperTorso.Position, Character.FakeUpperTorso.CFrame.UpVector * -6, raycastParams)
			local v10: boolean = false

			if v9 == nil then
				Character.FakeUpperTorso.Chop.Flare:Emit(5)
				Character.FakeUpperTorso.Chop.Flare2:Emit(5)
				v10 = true
			end

			local v12

			if not v10 then
				v12 = v9.Instance.Color
				Character.FakeUpperTorso.Chop2.Rock.Color = ColorSequence.new(v12)
				Character.FakeUpperTorso.Chop2.Smoke.Color = ColorSequence.new(v12)
				Character.FakeUpperTorso.Chop.Flare:Emit(5)
				Character.FakeUpperTorso.Chop.Flare2:Emit(5)
				Character.FakeUpperTorso.Chop2.Rock:Emit(3)
				Character.FakeUpperTorso.Chop2.Smoke:Emit(10)
			end

			Character.FakeUpperTorso.Blast.Ring:Emit(2)
			Character.FakeUpperTorso.Blast.Ring2:Emit(2)
			Character.FakeUpperTorso.Blast2.Ring:Emit(2)
			Character.FakeUpperTorso.Blast2.Ring2:Emit(2)
			Character.FakeUpperTorso.Blast3.Ring:Emit(2)
			Character.FakeUpperTorso.Blast3.Ring2:Emit(2)
			Character.FakeUpperTorso.Blast4.Ring:Emit(2)
			Character.FakeUpperTorso.Blast4.Ring2:Emit(2)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Springbonnie.StabBelly", result)
	end
end)

return true
