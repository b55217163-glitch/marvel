-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local customDeath = game.ReplicatedStorage.Characters.Springbonnie.Remotes.CustomDeath
		local v7 = game.ReplicatedStorage.Characters.Springbonnie.AnimationsExtra.CustomDeath

		game:GetService("TweenService")
		game:GetService("TweenService")
		customDeath.OnClientEvent:Connect(function(player)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)
			local v11 = animationService.LoadFresh(humanoid, v7)

			animationService.ConnectMarker(v11, "Start", function(_)
				Character.Head.DeathLine:Play()
				Character["Suit.001"].Transparency = 0
				Character["Suit.002"].Transparency = 0

				if Character:FindFirstChild("Eye") then
					Character.Eye.Transparency = 0
					Character.Eye2.Transparency = 0
				end
			end)
			v11:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Springbonnie.Death", result)
	end
end)

return true
