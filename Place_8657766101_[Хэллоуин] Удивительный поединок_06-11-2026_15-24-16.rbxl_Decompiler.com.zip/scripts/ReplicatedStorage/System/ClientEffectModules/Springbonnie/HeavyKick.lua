-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local heavyKickRem = game.ReplicatedStorage.Characters.Springbonnie.Remotes.HeavyKickRem

		game:GetService("TweenService")
		game:GetService("TweenService")

		local tweenService: TweenService = game:GetService("TweenService")
		local tweenInfoNew = TweenInfo.new
		local mathRandom = math.random

		local function Math(p1, p2, p3)
			return p1 + (p2 - p1) * p3
		end
		local function RockSpawn(p4, p5: number, p6, parent, p8, p9, p10)
			if p5 > 180 or p5 < 0 then
				warn("Too high or low of a number!")
				p5 = 15
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p5 do
				local v28 = p4.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v30 = math.rad(n1)
				local v31 = cFrameFromEulerAnglesXYZ(0, v30, 0)
				local cFrame = CFrame.new(0, 0, p8)
				local n2 = v28 * v31 * cFrame.Position
				local v34 = p4.CFrame
				local v35 = CFrame.fromEulerAnglesXYZ
				local v36 = math.rad(n1)
				local v37 = v35(0, v36, 0)
				local cFrame2 = CFrame.new(0, 0, -p8 / 1.25)
				local n3 = v34 * v37 * cFrame2.Position
				local vector3 = Vector3.new(0, -p8, 0)
				local v41 = workspace:Raycast(n2, n3 + vector3 - n2, raycastParams)

				n1 += p5

				if v41 then
					local instance = v41.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local cFrame3 = CFrame.new(v41.Position, p4.Position)
					local cFrameAngles = CFrame.Angles
					local v46 = mathRandom(-3.141592653589793, 3.141592653589793)
					local v47 = cFrameAngles(v46, 0, 0)
					local v48 = p4.Position
					local n4 = v48 + (v41.Position - v48) * 0.2
					local magnitude = (p4.Position - v41.Position).Magnitude

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.CFrame = CFrame.new(n4, p4.Position)
					game.Debris:AddItem(part, 5)

					for _, v in pairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					if p10 == true then
						local v54 = mathRandom(p6.Min, p6.Max)
						local v55 = mathRandom(p6.Min, p6.Max)

						part.Size = Vector3.new(v54, v55, mathRandom(p6.Min, p6.Max))
					else
						part.Size = p6
					end

					if p9 == true then
						local v56 = mathRandom(-180, 180)
						local v57 = mathRandom(-180, 180)

						part.Orientation = Vector3.new(v56, v57, mathRandom(-180, 180))

						local v58 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService:Create(part, v58, { Position = v41.Position }):Play()
					elseif p9 == false then
						local v59 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local cFrame4 = CFrame.new(v41.Position, p4.Position)

						tweenService:Create(part, v59, { CFrame = cFrame4 }):Play()
					elseif p9 == "Middle" then
						local v61 = tweenInfoNew(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService:Create(part, v61, { CFrame = cFrame3 * v47 }):Play()
					end

					part.Parent = parent
					task.delay(4, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v75 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v75, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v76 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v76, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
						task.wait(1)
					end)
				end
			end
		end

		local lungeCrack = game.ReplicatedStorage.Characters.Gigachad.Fx.LungeCrack
		local smoke = game.ReplicatedStorage.Characters.Gigachad.Fx.Smoke
		local rock = game.ReplicatedStorage.Characters.Gigachad.Fx.Rock
		local clap = game.ReplicatedStorage.Characters.OmniMan.Fx.ClapShock.Clap

		heavyKickRem.OnClientEvent:Connect(function(player)
			local Character = player.Character
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			local v65 = workspace:Raycast(Character.FakeUpperTorso.Position, Character.FakeUpperTorso.CFrame.UpVector * -6, raycastParams)

			if v65 == nil then
				return
			end

			local InstanceColor = v65.Instance.Color
			local material = v65.Instance.Material
			local clone = lungeCrack:Clone()

			clone.Parent = workspace
			clone.Position = v65.Position

			local randomNumber = math.random(-180, 180)

			clone.Orientation = Vector3.new(0, randomNumber, 0)
			game.Debris:AddItem(clone, 10)

			local clone2 = smoke:Clone()

			clone2.Parent = clone
			clone2.Color = ColorSequence.new(InstanceColor)
			clone2:Emit(10)
			game.Debris:AddItem(clone2, 7)

			local clone3 = rock:Clone()

			clone3.Parent = clone
			clone3.Color = ColorSequence.new(InstanceColor)
			clone3:Emit(30)
			game.Debris:AddItem(clone3, 7)
			game.TweenService:Create(clone.Decal, TweenInfo.new(5), { Transparency = 1 }):Play()
			RockSpawn(Character.HumanoidRootPart, 30, NumberRange.new(0.5, 2), workspace.Effects, 7, false, true)

			local clone4 = clap:Clone()

			clone4.Parent = Character.HumanoidRootPart

			if clone4:FindFirstChild("Sparks") then
				clone4.Sparks:Emit(3)
			end

			game.Debris:AddItem(clone4, 4)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Springbonnie.HeavyKick", result)
	end
end)

return true
