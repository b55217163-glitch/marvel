-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.StarLight.Remotes.Finisher
		local part = game.ReplicatedStorage.Characters.SoldierBoy.Fx.Part
		local scriptParent: Instance = script.Parent
		local finish = game.ReplicatedStorage.Characters.StarLight.AnimationsExtra.Finish
		local landingPart = game.ReplicatedStorage.Characters.LandingPart
		local gameDebris = game.Debris
		local counterStop = game.ReplicatedStorage.Characters.Conquest.Fx.CounterStop
		local rock = game.ReplicatedStorage:WaitForChild("Characters"):WaitForChild("Physics"):WaitForChild("Rock")
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke
		local TweenService = game.TweenService

		local function tween(p1, p2, p3, p4, p5)
			local tweenInfo = TweenInfo.new(p2, p4 or Enum.EasingStyle.Quad, p5 or Enum.EasingDirection.Out)
			local v35 = TweenService:Create(p1, tweenInfo, p3)

			v35:Play()

			return v35
		end
		local function copySurfaceLook(p6, parent)
			if not p6 or not parent or not p6:IsA("BasePart") or not parent:IsA("BasePart") then
				return
			end

			for _, v in ipairs(p6:GetChildren()) do
				if v:IsA("Decal") or v:IsA("Texture") or v:IsA("DataModelMesh") or v:IsA("Attachment") or v:IsA("ParticleEmitter") then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function getGroundHit(p8)
			local map: Instance = workspace:FindFirstChild("Map")
			local fakeUpperTorso = p8 and p8:FindFirstChild("FakeUpperTorso")

			if not fakeUpperTorso then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.IgnoreWater = true

			if map then
				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { map }
			else
				raycastParams.FilterType = Enum.RaycastFilterType.Exclude
				raycastParams.FilterDescendantsInstances = { p8 }
			end

			return workspace:Raycast(fakeUpperTorso.Position + Vector3.new(0, 6, 0), Vector3.new(0, -30, 0), raycastParams)
		end
		local function getEffectsFolder()
			local effects = workspace:FindFirstChild("Effects")

			if not effects then
				effects = Instance.new("Folder")
				effects.Name = "Effects"
				effects.Parent = workspace
			end

			return effects
		end
		local function emitIfExists(p9, p10, p11)
			local v49 = p9 and p9:FindFirstChild(p10, true)

			if v49 and v49:IsA("ParticleEmitter") then
				v49:Emit(p11)
			end
		end
		local function setParticleColor(p12, p13)
			if not p12 or not p12:IsA("ParticleEmitter") then
				return
			end

			p12.Color = ColorSequence.new(p13)
		end
		local function recolorNamedEmitters(p14, p15, p16)
			if not p14 then
				return
			end

			local t1: {[any]: any} = {}

			for _, v in ipairs(p15) do
				t1[v] = true
			end

			for _, v in ipairs(p14:GetDescendants()) do
				if v:IsA("ParticleEmitter") and t1[v.Name] and v and v:IsA("ParticleEmitter") then
					v.Color = ColorSequence.new(p16)
				end
			end
		end
		local function setModelToGround(p17, p18, p19)
			if not p17 or not p17:IsA("Model") then
				return
			end

			local v63 = p19 or Vector3.new(0, 1, 0)
			local vectorValue = Vector3.new(0, 0, -1)
			local v65 = v63:Dot(vectorValue)

			if math.abs(v65) > 0.98 then
				vectorValue = Vector3.new(1, 0, 0)
			end

			local unit = vectorValue:Cross(v63).Unit

			v65 = v63:Cross(unit)
			v65 = CFrame.fromMatrix(p18, unit, v63, -v65.Unit)
			p17:PivotTo(v65)
		end
		local function fadeChildrenAndRemove(p20, p21, p22, p23, p24)
			local taskDelay = task.delay
			local v73 = math.max(0, p21 - p22)

			taskDelay(v73, function()
				if not p20 or not p20.Parent then
					return
				end

				for _, v in ipairs(p20:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v142 = math.min(0.45, p22)
						local tweenInfo = TweenInfo.new(v142, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						TweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local t2: {[any]: any} = { Transparency = 1 }

				if p23 and p23 ~= 0 then
					local cFrame = p20.CFrame
					local vector3 = Vector3.new(0, p23, 0)

					t2.CFrame = cFrame - vector3
				end

				if p24 then
					local v147 = math.max(0.01, p20.Size.X * p24)
					local v148 = math.max(0.01, p20.Size.Y * p24)
					local v149 = math.max(0.01, p20.Size.Z * p24)

					t2.Size = Vector3.new(v147, v148, v149)
				end

				local tweenInfo = TweenInfo.new(p22, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

				TweenService:Create(p20, tweenInfo, t2):Play()
			end)
			gameDebris:AddItem(p20, p21)
		end
		local function createGroundChunk(p25, material, p27, p28, _, cFrame, parent)
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Material = material
			part.Color = p27
			part.Size = p28
			part.CFrame = cFrame
			part.Parent = parent

			if p25 then
				copySurfaceLook(p25, part)
			end

			return part
		end
		local function createCraterRing(p32, p33, p34, p35, p36, p37, p38, p39)
			local u90 = p38 or 1
			local u91 = p39 or 1
			local v92 = math.max(1, u90 * 0.9)
			local floored = math.floor(v92 * 44)
			local n1 = 8 * u90
			local n2 = 20 * u90

			for i = 1, floored do
				local taskDelay = task.delay
				local randomNumber = math.random()

				taskDelay((i - 1) * 0.003 + randomNumber * 0.012, function()
					local randomNumber2 = math.random(-10, 10)
					local v152 = math.rad(360 / floored * i + randomNumber2)
					local cosine = math.cos(v152)
					local sine = math.sin(v152)
					local vector3 = Vector3.new(cosine, 0, sine)
					local randomNumber3 = math.random()
					local n9 = if u90 <= 1.05 then n1 + (n2 - n1) * randomNumber3 ^ 2.4 else n1 + (n2 - n1) * randomNumber3 ^ 1.2
					local randomNumber4 = math.random(-20, 20)
					local n10 = p32 + vector3 * (n9 + randomNumber4 / 10 * u90) + p33 * 0.12
					local n3 = math.random(28, 54) / 10 * u91
					local n4 = math.random(12, 24) / 10 * u91
					local randomNumber5 = math.random(22, 44)
					local vector32 = Vector3.new(n3, n4, randomNumber5 / 10 * u91)
					local cFrame = CFrame.new(n10, n10 + vector3)
					local cFrameAngles = CFrame.Angles
					local randomNumber6 = math.random(-16, 16)

					n3 = math.rad(randomNumber6)

					local randomNumber7 = math.random(-35, 35)

					n4 = math.rad(randomNumber7)

					local randomNumber8 = math.random(-35, 35)
					local v169 = math.rad(randomNumber8)
					local v170 = cFrameAngles(n3, n4, v169)
					local n5 = cFrame * v170

					v170 = p34

					local vector33 = Vector3.new(0, vector32.Y * 0.45, 0)
					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanQuery = false
					part.CanTouch = false
					part.Material = p35
					part.Color = p36
					part.Size = Vector3.new(0.08, 0.08, 0.08)
					part.CFrame = n5 - vector33
					part.Parent = p37

					if v170 then
						copySurfaceLook(v170, part)
					end

					local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Back or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

					TweenService:Create(part, tweenInfo, { Size = vector32, CFrame = n5 }):Play()

					local n6 = 1.1 * u91
					local n7: number = 0.75
					local n8: number = 0.08

					task.delay(5.25, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v259 = math.min(0.45, n7)
								local tweenInfo2 = TweenInfo.new(v259, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

								TweenService:Create(v, tweenInfo2, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local t3: {[any]: any} = { Transparency = 1 }

						if n6 and n6 ~= 0 then
							local partCFrame: CFrame = part.CFrame
							local vector34 = Vector3.new(0, n6, 0)

							t3.CFrame = partCFrame - vector34
						end

						if n8 then
							local v264 = math.max(0.01, part.Size.X * n8)
							local v265 = math.max(0.01, part.Size.Y * n8)
							local v266 = math.max(0.01, part.Size.Z * n8)

							t3.Size = Vector3.new(v264, v265, v266)
						end

						local tweenInfo3 = TweenInfo.new(n7, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						TweenService:Create(part, tweenInfo3, t3):Play()
					end)
					gameDebris:AddItem(part, 6)
				end)
			end
		end
		local function createFlyingRockProjectile(p40, material, p42, parent, p44, p45)
			local clone = rock:Clone()

			clone.Parent = parent

			if clone:IsA("BasePart") then
				clone.Material = material
				clone.Color = p42
				clone.CanCollide = false
				clone.CanTouch = false
				clone.CanQuery = false

				if clone:FindFirstChild("Trail") and clone.Trail:IsA("Trail") then
					clone.Trail.Color = ColorSequence.new(p42)
				end

				local randomNumber = math.random(85, 130)

				clone.Size = clone.Size * (randomNumber / 100) * (p44 or 1)

				local cFrameAngles = CFrame.Angles
				local randomNumber9 = math.random(0, 360)
				local v109 = math.rad(randomNumber9)
				local randomNumber10 = math.random(0, 360)
				local v111 = math.rad(randomNumber10)
				local randomNumber11 = math.random(0, 360)
				local v113 = math.rad(randomNumber11)
				local cFrame = cFrameAngles(v109, v111, v113)

				clone.CFrame = p40 * cFrame
			end

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

			local randomNumber = math.random(-2, 2)
			local randomNumber12 = math.random(1, 3)
			local vector3 = Vector3.new(randomNumber, randomNumber12, math.random(-2, 2))

			if vector3.Magnitude < 0.1 then
				vector3 = Vector3.new(1, 2, 0)
			end

			local vector3Unit = vector3.Unit
			local randomNumber13 = math.random(85, 125)

			bodyVelocity.Velocity = vector3Unit * randomNumber13 * (p45 or 1)
			bodyVelocity.Parent = clone
			gameDebris:AddItem(bodyVelocity, 0.22)
			gameDebris:AddItem(clone, 3)
		end
		local function createMeteorDebris(p46, p47, p48, p49, p50, p51, p52, p53)
			local u129 = p52 or 1
			local u130 = p53 or 1
			local v131 = math.max(1, u129 * 0.9)

			for i = 1, math.floor(v131 * 30) do
				local taskDelay = task.delay
				local randomNumber = math.random()

				taskDelay((i - 1) * 0.002 + randomNumber * 0.012, function()
					local randomNumber14 = math.random(0, 359)
					local v179 = math.rad(randomNumber14)
					local cosine = math.cos(v179)
					local sine = math.sin(v179)
					local unit = Vector3.new(cosine, 0, sine).Unit
					local n1 = math.random(14, 28) / 10 * u130
					local n2 = math.random(12, 22) / 10 * u130
					local randomNumber15 = math.random(14, 28)
					local vector3 = Vector3.new(n1, n2, randomNumber15 / 10 * u130)
					local vector35 = Vector3.new(0, vector3.Y * 0.8, 0)

					n1 = math.random(120, 430) / 10 * u129

					local randomNumber16 = math.random(28, 42)
					local n3 = math.random(7, 12) * u130
					local randomNumber17 = math.random(-25, 25)
					local randomNumber18 = math.random(-25, 25)
					local vector36 = Vector3.new(randomNumber17 / 10, 0, randomNumber18 / 10)
					local vector37 = Vector3.new(0, n3, 0)
					local randomNumber19 = math.random(-50, 50)
					local randomNumber20 = math.random(0, 8)
					local randomNumber21 = math.random(-50, 50)
					local vector38 = Vector3.new(randomNumber19 / 10, randomNumber20 / 100, randomNumber21 / 10)
					local vector39 = Vector3.new(0, vector3.Y * 0.35, 0)
					local n4 = p46 + unit * n1 + vector38 - vector39
					local randomNumber22 = math.random(-180, 180)
					local randomNumber23 = math.random(-180, 180)
					local vector310 = Vector3.new(randomNumber22, randomNumber23, math.random(-180, 180))
					local randomNumber24 = math.random(55, 110)
					local randomNumber25 = math.random(55, 110)
					local vector311 = Vector3.new(randomNumber24, randomNumber25, math.random(55, 110))

					n2 = vector310 + vector311

					local randomNumber26 = math.random(90, 170)
					local randomNumber27 = math.random(90, 170)
					local vector312 = Vector3.new(randomNumber26, randomNumber27, math.random(90, 170))
					local n5 = n2 + vector312
					local v210 = p48
					local cFrame = CFrame.new(p46 + p47 * 0.08 - vector35)
					local cFrameAngles = CFrame.Angles
					local v213 = math.rad(vector310.X)
					local v214 = math.rad(vector310.Y)
					local v215 = math.rad(vector310.Z)
					local v216 = cFrameAngles(v213, v214, v215)
					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanQuery = false
					part.CanTouch = false
					part.Material = p49
					part.Color = p50
					part.Size = vector3
					part.CFrame = cFrame * v216
					part.Parent = p51

					if v210 then
						copySurfaceLook(v210, part)
					end

					local randomNumber28 = math.random(8, 11)
					local n6 = math.random(30, 40) / 100

					createFlyingRockProjectile(part.CFrame, p49, p50, p51, u130, if u129 <= 1.05 then 0.9 else 1.15)

					local cFrame2 = CFrame.new(p46 + unit * (n1 * (randomNumber16 / 100)) + vector36 + vector37)
					local angles = CFrame.Angles
					local v222 = math.rad(n2.X)

					v216 = math.rad(n2.Y)
					v213 = math.rad(n2.Z)

					local v223 = angles(v222, v216, v213)
					local tweenInfo = TweenInfo.new(randomNumber28 / 100, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

					v179 = TweenService:Create(part, tweenInfo, { CFrame = cFrame2 * v223 })
					v179:Play()

					if v179 then
						v179.Completed:Connect(function()
							if not part or not part.Parent then
								return
							end

							local cFrame3 = CFrame.new(n4)
							local cFrameAngles = CFrame.Angles
							local v270 = math.rad(n5.X)
							local v271 = math.rad(n5.Y)
							local v272 = math.rad(n5.Z)
							local cFrame = cFrameAngles(v270, v271, v272)
							local tweenInfo4 = TweenInfo.new(n6, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

							TweenService:Create(part, tweenInfo4, { CFrame = cFrame3 * cFrame }):Play()
						end)
					end

					local n7 = 1.1 * u130
					local n8: number = 0.8
					local n9: number = 0.08

					task.delay(5.2, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v277 = math.min(0.45, n8)
								local tweenInfo5 = TweenInfo.new(v277, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

								TweenService:Create(v, tweenInfo5, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local t4: {[any]: any} = { Transparency = 1 }

						if n7 and n7 ~= 0 then
							local partCFrame: CFrame = part.CFrame
							local vector313 = Vector3.new(0, n7, 0)

							t4.CFrame = partCFrame - vector313
						end

						if n9 then
							local v282 = math.max(0.01, part.Size.X * n9)
							local v283 = math.max(0.01, part.Size.Y * n9)
							local v284 = math.max(0.01, part.Size.Z * n9)

							t4.Size = Vector3.new(v282, v283, v284)
						end

						local tweenInfo6 = TweenInfo.new(n8, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						TweenService:Create(part, tweenInfo6, t4):Play()
					end)
					gameDebris:AddItem(part, 6)
				end)
			end
		end

		finisher.OnClientEvent:Connect(function(player, p55)
			local Character = player.Character
			local v138 = animationService.LoadFresh(Character.Humanoid, finish)

			Character.Head.GlowEye.Flare.Enabled = true
			Character.Head.GlowEye.Flare2.Enabled = true
			Character.Head.GlowEye2.Flare.Enabled = true
			Character.Head.GlowEye2.Flare2.Enabled = true
			Character.RightHand.StarBlast.Flare1.Enabled = true
			Character.RightHand.StarBlast.Flare2.Enabled = true
			Character.LeftHand.StarBlast.Flare1.Enabled = true
			Character.LeftHand.StarBlast.Flare2.Enabled = true
			Character.HumanoidRootPart.Charge:Play()
			animationService.ConnectMarker(v138, "Start", function(_)
				Character.Head.FinisherSfx:Play()
			end)
			animationService.ConnectMarker(v138, "Light", function(_)
			end)
			animationService.ConnectMarker(v138, "Blast", function(_)
				Character.HumanoidRootPart.GiantBlast.ChaosFlames:Emit(40)
				Character.HumanoidRootPart.GiantBlast.Flare:Emit(5)
				Character.HumanoidRootPart.GiantBlast.Shoot1:Emit(5)
				Character.HumanoidRootPart.GiantBlast.Shoot2:Emit(5)

				local effects = workspace:FindFirstChild("Effects")

				if not effects then
					effects = Instance.new("Folder")
					effects.Name = "Effects"
					effects.Parent = workspace
				end

				local clone = counterStop:Clone()

				clone.Parent = effects

				local v233 = getGroundHit(Character)
				local u234 = Enum.Material.Concrete
				local color3 = Color3.fromRGB(90, 90, 90)
				local u236 = nil
				local u237
				local vectorValue

				if v233 then
					u237 = v233.Position
					vectorValue = v233.Normal
					u234 = v233.Material

					if v233.Instance and v233.Instance:IsA("BasePart") then
						color3 = v233.Instance.Color
						u236 = v233.Instance
					end
				else
					u237 = Character.FakeUpperTorso.Position - Vector3.new(0, 3, 0)
					vectorValue = Vector3.new(0, 1, 0)
				end

				recolorNamedEmitters(clone, { "Smoke", "SmokeSlide" }, color3)

				if clone:IsA("BasePart") then
					clone.CFrame = CFrame.new(u237 + vectorValue * 0.05)
				elseif clone:IsA("Model") then
					setModelToGround(clone, u237 + vectorValue * 0.05, vectorValue)
				end

				local hitAt = clone:FindFirstChild("HitAt")

				if hitAt then
					local shock = hitAt and hitAt:FindFirstChild("Shock", true)

					if shock and shock:IsA("ParticleEmitter") then
						shock:Emit(4)
					end

					local shockwaveMiddle = hitAt and hitAt:FindFirstChild("ShockwaveMiddle", true)

					if shockwaveMiddle and shockwaveMiddle:IsA("ParticleEmitter") then
						shockwaveMiddle:Emit(1)
					end

					local sparksCircle = hitAt and hitAt:FindFirstChild("SparksCircle", true)

					if sparksCircle and sparksCircle:IsA("ParticleEmitter") then
						sparksCircle:Emit(3)
					end
				end

				v233 = clone

				if v233 then
					v233 = clone:FindFirstChild("Smoke", true)
				end

				if v233 and v233:IsA("ParticleEmitter") then
					v233:Emit(30)
				end

				createCraterRing(u237, vectorValue, u236, u234, color3, effects, 1, 1)
				task.delay(0.015, function()
					createMeteorDebris(u237, vectorValue, u236, u234, color3, effects, 1, 1)
				end)
				game.Debris:AddItem(clone, 8)
				task.wait(0.3)

				if p55:FindFirstChild("Cape") then
					p55.Cape:Destroy()
				end

				local descendants = p55:GetDescendants()

				for _, v in pairs(descendants) do
					if v:IsA("BasePart") or v:IsA("MeshPart") or v:IsA("UnionOperation") then
						game.TweenService:Create(v, TweenInfo.new(0.3), { Size = Vector3.new(0, 0, 0) }):Play()
					end
				end

				for _, v in pairs(descendants) do
					if v:IsA("SpecialMesh") then
						game.TweenService:Create(v, TweenInfo.new(0.3), { Scale = Vector3.new(0, 0, 0) }):Play()
					end
				end

				for _, v in pairs(descendants) do
					if v:IsA("Beam") or v:IsA("Trail") then
						v.Enabled = false
					end
				end
			end)
			animationService.ConnectMarker(v138, "Land", function(_)
				Character.RightHand.HandSpark.Sparks.Enabled = false
				Character.LeftHand.HandSpark.Sparks.Enabled = false
				Character.Head.GlowEye.Flare2.Enabled = false
				Character.Head.GlowEye2.Flare.Enabled = false
				Character.Head.GlowEye2.Flare2.Enabled = false
				Character.Head.GlowEye.Flare.Enabled = false
				Character.LeftHand.Finisher.Flare.Enabled = false
				Character.LeftHand.Finisher.Flare2.Enabled = false
				Character.RightHand.Finisher.Flare.Enabled = false
				Character.RightHand.Finisher.Flare2.Enabled = false
				Character.RightHand.StarBlast.Flare1.Enabled = false
				Character.RightHand.StarBlast.Flare2.Enabled = false
				Character.LeftHand.StarBlast.Flare1.Enabled = false
				Character.LeftHand.StarBlast.Flare2.Enabled = false

				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v252 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

				if v252 == nil then
					return
				end

				local InstanceColor = v252.Instance.Color
				local clone = landingPart:Clone()

				clone.Parent = workspace.Effects
				clone.Position = v252.Position

				local randomNumber = math.random(-180, 180)

				clone.Orientation = Vector3.new(0, randomNumber, 0)
				game.Debris:AddItem(clone, 4)
				clone.Smoke.Color = ColorSequence.new(InstanceColor)

				local randomNumber29 = math.random(0, 360)

				clone.Orientation = Vector3.new(0, randomNumber29, 0)
				clone.Smoke:Emit(40)
				clone.Boom:Play()
				task.wait(3)
				game.TweenService:Create(clone.Decal, TweenInfo.new(1), { Transparency = 1 }):Play()
			end)
			v138:Play()

			while true do
				task.wait(0.3)
				math.random(1, 2)

				local randomNumber = math.random(1, 8)

				if randomNumber == 1 then
					Character.HumanoidRootPart.Spark1.Sparks:emit(100)
					Character.HumanoidRootPart.Spark8.Sparks:emit(100)
				elseif randomNumber == 2 then
					Character.HumanoidRootPart.Spark2.Sparks:emit(100)
					Character.HumanoidRootPart.Spark7.Sparks:emit(100)
				elseif randomNumber == 3 then
					Character.HumanoidRootPart.Spark3.Sparks:emit(100)
					Character.HumanoidRootPart.Spark6.Sparks:emit(100)
				elseif randomNumber == 4 then
					Character.HumanoidRootPart.Spark4.Sparks:emit(100)
					Character.HumanoidRootPart.Spark5.Sparks:emit(100)
				elseif randomNumber == 5 then
					Character.HumanoidRootPart.Spark5.Sparks:emit(100)
					Character.HumanoidRootPart.Spark4.Sparks:emit(100)
				elseif randomNumber == 6 then
					Character.HumanoidRootPart.Spark6.Sparks:emit(100)
					Character.HumanoidRootPart.Spark3.Sparks:emit(100)
				elseif randomNumber == 7 then
					Character.HumanoidRootPart.Spark7.Sparks:emit(100)
					Character.HumanoidRootPart.Spark2.Sparks:emit(100)
				elseif randomNumber == 8 then
					Character.HumanoidRootPart.Spark8.Sparks:emit(100)
					Character.HumanoidRootPart.Spark1.Sparks:emit(100)
				end

				if Character.RightHand.Finisher.Flare2.Enabled == false then
					break
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "StarLight.Finisher", result)
	end
end)

return true
