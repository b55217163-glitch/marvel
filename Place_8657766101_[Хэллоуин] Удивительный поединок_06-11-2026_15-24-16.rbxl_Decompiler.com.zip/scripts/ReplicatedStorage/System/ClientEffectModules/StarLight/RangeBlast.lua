-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local LocalPlayer = game.Players.LocalPlayer
		local ReplicatedStorage = game.ReplicatedStorage
		local rangeBlasts = game.ReplicatedStorage.Characters.StarLight.Remotes.RangeBlasts
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock3(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v21 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v23 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v23, 0)
				local n2 = v21 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v26 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v26 then
					local instance = v26.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v32 = mathRandom(-180, 180)
					local v33 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v32, v33, mathRandom(-180, 180))
					part.Position = p1.Position

					local v34 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v34, { Position = v26.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v62 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v62, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v63 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v63, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace.Effects
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Size = Vector3.new(3, 3, 3)
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v39 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v41 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v43 = math.rad(randomNumber3)
						local v44 = cFrameAngles(v39, v41, v43)

						clone.CFrame = p1.CFrame * v44

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 30
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end

		local explo = game.ReplicatedStorage.Characters.Wanda.Fx.Explo
		local blast = game.ReplicatedStorage.Characters.StarLight.Fx.Blast
		local fireBlast = game.ReplicatedStorage.Characters.StarLight.Fx.FireBlast
		local hitboxPunch = game.ReplicatedStorage.Characters.Combat.Peacemaker.HitboxPunch
		local projectileHit = game.ReplicatedStorage.Characters.MoonKnight.Remotes.ProjectileHit

		local function DashForward(parent)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 10000
			bodyPosition.D = 3000
			bodyPosition.Position = (parent.CFrame * CFrame.new(0, 0, -400)).Position
			bodyPosition.Parent = parent
			game.Debris:AddItem(bodyPosition, 3)
		end

		rangeBlasts.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			if Character:FindFirstChild("StarFire") then
				local clone = fireBlast:Clone()

				clone.Anchored = false
				clone.Parent = workspace
				clone.CFrame = Character.HumanoidRootPart.CFrame
				game.Debris:AddItem(clone, 3)
				clone.Blast.PlaybackSpeed = math.random(1, 1.3)
				clone.ShootSfx.PlaybackSpeed = math.random(1, 1.3)
				clone.Blast:Play()
				clone.ShootSfx:Play()
				clone.Loop:Play()
				clone.CFrame = Character.HumanoidRootPart.CFrame
				clone.At.Shoot1:Emit(1)
				clone.At.Shoot2:Emit(2)

				local clone2 = hitboxPunch:Clone()

				clone2.Parent = clone

				local weld: Weld = Instance.new("Weld", clone2)

				weld.Part0 = clone
				weld.Part1 = clone2

				local v55 = CFrame.Angles(1.5707963267948966, 0, 0)

				weld.C0 = CFrame.new(0, 0, 0) * v55
				clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0.5, 0, 1)
				DashForward(clone)
				task.spawn(function()
					task.wait(2.7)

					if clone:FindFirstChild("Hitbox") then
						TestRock3(clone)
						clone.Anchored = true
						clone.Anchored = true
						clone.HexTrail.Enabled = false
						clone.At.ChaosFlames.Enabled = false
						clone.At.Flare.Enabled = false
						clone.At.Flare2.Enabled = false
						clone.At.Shoot1.Enabled = false
						clone.At.Shoot2.Enabled = false
						clone.Loop:Stop()
						TestRock3(clone)
					end
				end)
				clone2.Touched:Connect(function(_)
					for _, v in ipairs(workspace:GetChildren()) do
						local v69 = v:IsA("Model") and v

						if v69 and v69:FindFirstChild("Humanoid") and v69:FindFirstChild("HumanoidRootPart") and v69 ~= Character and not v69:FindFirstChild("Iframe") and (clone.Position - v69.HumanoidRootPart.Position).magnitude <= 4 then
							local values = Character:FindFirstChild("Values")
							local values2 = v69:FindFirstChild("Values")
							local v72 = values

							if v72 then
								v72 = values:FindFirstChild("TeamColor")
							end

							local teamColor = values2 and values2:FindFirstChild("TeamColor")

							if not v72 or not teamColor then
								return
							end

							local v74 = v72.Value
							local teamColorValue = teamColor.Value
							local FFAColorValue = game.ReplicatedStorage.FFAColor.Value

							if teamColorValue ~= v74 or teamColorValue == FFAColorValue and v74 == FFAColorValue then
								clone2:Destroy()
								clone.Anchored = true

								if LocalPlayer == player then
									projectileHit:FireServer(v69, player, Character)
								end

								TestRock3(v69.HumanoidRootPart)
								clone.Anchored = true
								clone.HexTrail.Enabled = false
								clone.At.ChaosFlames.Enabled = false
								clone.At.Flare.Enabled = false
								clone.At.Flare2.Enabled = false
								clone.At.Shoot1.Enabled = false
								clone.At.Shoot2.Enabled = false
								clone.Loop:Stop()
							end
						end
					end
				end)

				return
			end

			local clone = blast:Clone()

			clone.Anchored = false
			clone.Parent = workspace
			clone.CFrame = Character.HumanoidRootPart.CFrame
			game.Debris:AddItem(clone, 3)
			clone.Blast.PlaybackSpeed = math.random(1, 1.3)
			clone.ShootSfx.PlaybackSpeed = math.random(1, 1.3)
			clone.At.Shoot1:Emit(1)
			clone.At.Shoot2:Emit(2)
			clone.Blast:Play()
			clone.Loop:Play()
			clone.CFrame = Character.HumanoidRootPart.CFrame

			local clone3 = hitboxPunch:Clone()

			clone3.Parent = clone

			local weld: Weld = Instance.new("Weld", clone3)

			weld.Part0 = clone
			weld.Part1 = clone3

			local v59 = CFrame.Angles(1.5707963267948966, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v59
			clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0.5, 0, 1)
			DashForward(clone)
			task.spawn(function()
				task.wait(2.7)

				if clone:FindFirstChild("Hitbox") then
					TestRock3(clone)
					clone.Anchored = true
					clone.Anchored = true
					clone.HexTrail.Enabled = false
					clone.At.ChaosFlames.Enabled = false
					clone.At.Flare.Enabled = false
					clone.At.Flare2.Enabled = false
					clone.At.Shoot1.Enabled = false
					clone.At.Shoot2.Enabled = false
					clone.Loop:Stop()
					TestRock3(clone)
				end
			end)
			clone3.Touched:Connect(function(_)
				for _, v in ipairs(workspace:GetChildren()) do
					local v80 = v:IsA("Model") and v

					if v80 and v80:FindFirstChild("Humanoid") and v80:FindFirstChild("HumanoidRootPart") and v80 ~= Character and not v80:FindFirstChild("Iframe") and (clone.Position - v80.HumanoidRootPart.Position).magnitude <= 4 then
						local values = Character:FindFirstChild("Values")
						local values3 = v80:FindFirstChild("Values")
						local v83 = values

						if v83 then
							v83 = values:FindFirstChild("TeamColor")
						end

						local teamColor = values3 and values3:FindFirstChild("TeamColor")

						if not v83 or not teamColor then
							return
						end

						local v85 = v83.Value
						local teamColorValue = teamColor.Value
						local v87 = game.ReplicatedStorage.FFAColor.Value

						if teamColorValue ~= v85 or teamColorValue == v87 and v85 == v87 then
							clone3:Destroy()
							clone.Anchored = true

							if LocalPlayer == player then
								projectileHit:FireServer(v80, player, Character)
							end

							TestRock3(v80.HumanoidRootPart)
							clone.Anchored = true
							clone.HexTrail.Enabled = false
							clone.At.ChaosFlames.Enabled = false
							clone.At.Flare.Enabled = false
							clone.At.Flare2.Enabled = false
							clone.At.Shoot1.Enabled = false
							clone.At.Shoot2.Enabled = false
							clone.Loop:Stop()
						end
					end
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "StarLight.RangeBlast", result)
	end
end)

return true
