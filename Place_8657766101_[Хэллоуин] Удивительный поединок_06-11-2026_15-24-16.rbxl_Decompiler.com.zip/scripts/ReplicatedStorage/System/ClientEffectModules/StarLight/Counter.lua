-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local counter = game.ReplicatedStorage.Characters.StarLight.AnimationsExtra.Counter
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.StarLight.Remotes.Counter.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			p2:WaitForChild("Humanoid", 5)

			local v13 = animationService.LoadFresh(humanoid, counter)

			animationService.ConnectMarker(v13, "Start", function(_)
				Character.Head.CounterVc:Play()
			end)
			animationService.ConnectMarker(v13, "Light1", function(_)
				Character.HumanoidRootPart.CAt.Flare:Emit(10)
			end)
			animationService.ConnectMarker(v13, "Flare", function(_)
				Character.RightHand.CAt.Flare1.Enabled = true
				Character.RightHand.CAt.Flare2.Enabled = true
			end)
			animationService.ConnectMarker(v13, "Light2", function(_)
				Character.HumanoidRootPart.CAt2.Flare:Emit(20)
				Character.RightHand.CAt.Flare1.Enabled = false
				Character.RightHand.CAt.Flare2.Enabled = false
			end)
			animationService.ConnectMarker(v13, "Hit", function(_)
				local clone = neckExplode:Clone()

				clone.Parent = p2.UpperTorso
				clone.Bl1:Emit(5)
				clone.Bl2:Emit(15)
				game.Debris:AddItem(clone, 3)

				for _ = 1, 12 do
					local randomNumber = math.random(15, 30)
					local clone2 = bloodDrip:Clone()

					clone2.Parent = Character
					clone2.LocalScript.Disabled = false

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

					clone2.CFrame = p2.UpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber2 = math.random(-2, 2)
					local randomNumber3 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
					game.Debris:AddItem(clone2, 3)
					game.Debris:AddItem(bodyVelocity, 0.15)
				end
			end)
			v13:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "StarLight.Counter", result)
	end
end)

return true
