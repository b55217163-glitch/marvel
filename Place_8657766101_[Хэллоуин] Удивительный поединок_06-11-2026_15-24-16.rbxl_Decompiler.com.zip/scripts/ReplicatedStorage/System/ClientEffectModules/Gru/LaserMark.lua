-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local fartGunFire = game.ReplicatedStorage.Characters.Gru.Remotes.FartGunFire

		game:GetService("TweenService")
		game:GetService("TweenService")
		fartGunFire.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character.Fartgun1.Transparency = 0
			Character.Fartgun2.Transparency = 0
			Character.Fartgun2.d1.Transparency = 0
			Character.Fartgun2.d2.Transparency = 0
			Character.Fartgun2.d3.Transparency = 0
			Character.Fartgun2.d4.Transparency = 0
			Character.Fartgun2.d5.Transparency = 0
			Character.Fartgun1.Equip:Play()
			task.wait(0.35)
			Character.Fartgun2.Attachment.Fart:Emit(50)
			Character.Fartgun2.Attachment.Fart2:Emit(50)
			Character.Fartgun1.Fart:Play()
			task.wait(0.55)
			Character.Fartgun1.Transparency = 1
			Character.Fartgun2.Transparency = 1
			Character.Fartgun2.d1.Transparency = 1
			Character.Fartgun2.d2.Transparency = 1
			Character.Fartgun2.d3.Transparency = 1
			Character.Fartgun2.d4.Transparency = 1
			Character.Fartgun2.d5.Transparency = 1
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Gru.LaserMark", result)
	end
end)

return true
