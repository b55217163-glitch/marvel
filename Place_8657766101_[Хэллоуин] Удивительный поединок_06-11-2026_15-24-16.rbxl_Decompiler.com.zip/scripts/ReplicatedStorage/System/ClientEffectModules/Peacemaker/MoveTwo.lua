-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gunShoot = game.ReplicatedStorage.Characters.Peacemaker.Remotes.GunShoot
		local tweenService: TweenService = game:GetService("TweenService")

		gunShoot.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local clone = Character.Gun.BulletAt.Bullet:Clone()

			clone.Parent = Character.Gun.BulletAt
			clone:emit(1)
			game.Debris:AddItem(clone, 1)

			local clone2 = Character.Gun.FsAt.Flash:Clone()

			clone2.Parent = Character.Gun.FsAt
			clone2:emit(1)
			game.Debris:AddItem(clone2, 1)

			local clone3 = Character.Gun.FsAt.Smoke:Clone()

			clone3.Parent = Character.Gun.FsAt
			clone3:emit(10)
			game.Debris:AddItem(clone3, 2)

			local clone4 = Character.Gun.Light:Clone()

			clone4.Parent = Character.Gun
			clone4.Enabled = true
			game.Debris:AddItem(clone4, 0.35)
			tweenService:Create(clone4, TweenInfo.new(0.3), { Brightness = 0 }):Play()

			local clone5 = script.GunShotSfx:Clone()

			clone5.Parent = Character.HumanoidRootPart
			clone5:Play()
			game.Debris:AddItem(clone5, 2)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Peacemaker.MoveTwo", result)
	end
end)

return true
