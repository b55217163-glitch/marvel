-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local sonicBoom = game.ReplicatedStorage.Characters.Peacemaker.Remotes.SonicBoom
		local shockwave = game.ReplicatedStorage.Characters.Combat.Fx.Shockwave
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v19 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v21 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v21, 0)
				local n2 = v19 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v24 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v24 then
					local instance = v24.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v30 = mathRandom(-180, 180)
					local v31 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v30, v31, mathRandom(-180, 180))
					part.Position = p1.Position

					local v32 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v32, { Position = v24.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v109 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v109, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v110 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v110, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v37 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v39 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v41 = math.rad(randomNumber3)
						local v42 = cFrameAngles(v37, v39, v41)

						clone.CFrame = p1.CFrame * v42

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						bodyVelocity.Parent = clone
						clone.Parent = workspace.Effects
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v50 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v52 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v52, 0)
				local n2 = v50 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v55 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v55 then
					local instance = v55.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v61 = mathRandom(-180, 180)
					local v62 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v61, v62, mathRandom(-180, 180))
					part.Position = p2.Position

					local v63 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v63, { Position = v55.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v115 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v115, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v116 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v116, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v68 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v70 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v70, 0)
				local n2 = v68 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v73 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v73 then
					local instance = v73.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v79 = mathRandom(-180, 180)
					local v80 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v79, v80, mathRandom(-180, 180))
					part.Position = p3.Position

					local v81 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v81, { Position = v73.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v121 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v121, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v122 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v122, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local forceField = game.ReplicatedStorage.Characters.Peacemaker.Fx.ForceField

		sonicBoom.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local clone = forceField:Clone()

			clone.Parent = Character.UpperTorso
			game.Debris:AddItem(clone, 4)

			local clone2 = forceField:Clone()

			clone2.Parent = Character.LowerTorso
			game.Debris:AddItem(clone2, 4)

			local clone3 = forceField:Clone()

			clone3.Parent = Character.RightUpperArm
			game.Debris:AddItem(clone3, 4)

			local clone4 = forceField:Clone()

			clone4.Parent = Character.RightLowerArm
			game.Debris:AddItem(clone4, 4)

			local clone5 = forceField:Clone()

			clone5.Parent = Character.LeftUpperArm
			game.Debris:AddItem(clone5, 4)

			local clone6 = forceField:Clone()

			clone6.Parent = Character.LeftLowerArm
			game.Debris:AddItem(clone6, 4)

			local clone7 = forceField:Clone()

			clone7.Parent = Character.LeftHand
			game.Debris:AddItem(clone7, 4)

			local clone8 = forceField:Clone()

			clone8.Parent = Character.RightHand
			game.Debris:AddItem(clone8, 4)

			local clone9 = forceField:Clone()

			clone9.Parent = Character.RightUpperLeg
			game.Debris:AddItem(clone9, 4)

			local clone10 = forceField:Clone()

			clone10.Parent = Character.RightLowerLeg
			game.Debris:AddItem(clone10, 4)

			local clone11 = forceField:Clone()

			clone11.Parent = Character.LeftUpperLeg
			game.Debris:AddItem(clone11, 4)

			local clone12 = forceField:Clone()

			clone12.Parent = Character.LeftLowerLeg
			game.Debris:AddItem(clone12, 4)

			local clone13 = forceField:Clone()

			clone13.Parent = Character.LeftFoot
			game.Debris:AddItem(clone13, 4)

			local clone14 = forceField:Clone()

			clone14.Parent = Character.RightFoot
			game.Debris:AddItem(clone14, 4)

			local clone15 = forceField:Clone()

			clone15.Parent = Character.Head
			game.TweenService:Create(Character.UpperTorso.SonicLight, TweenInfo.new(0.3), { Brightness = 0.4 }):Play()
			task.wait(0.8)

			local clone16 = Character.Helmet.SonicBoom.Flying:Clone()

			clone16.Parent = Character.Helmet.SonicBoom
			game.Debris:AddItem(clone16, 1)
			clone16:Emit(50)

			local clone17 = Character.Helmet.SonicBoom.Ring:Clone()

			clone17.Size = NumberSequence.new(0, 80)
			clone17.Parent = Character.Helmet.SonicBoom
			game.Debris:AddItem(clone17, 1)
			clone17:Emit(10)

			local clone18 = Character.Helmet.SonicBoom.Ring2:Clone()

			clone18.Size = NumberSequence.new(0, 60)
			clone18.Parent = Character.Helmet.SonicBoom
			game.Debris:AddItem(clone18, 1)
			clone18:Emit(10)

			local clone19 = Character.Helmet.SonicBoom.Smoke:Clone()

			clone19.Parent = Character.Helmet.SonicBoom
			game.Debris:AddItem(clone19, 3)
			clone19:Emit(50)
			TestRock(Character.HumanoidRootPart)
			TestRock2(Character.HumanoidRootPart)
			TestRock3(Character.HumanoidRootPart)
			print("clientready")

			local clone20 = shockwave:Clone()

			clone20.Parent = workspace
			clone20.CFrame = Character.HumanoidRootPart.CFrame
			game.Debris:AddItem(clone20, 1)
			game.TweenService:Create(clone20, TweenInfo.new(0.4), { Size = Vector3.new(50, 50, 50) }):Play()
			task.wait(0.4)
			game.TweenService:Create(clone20, TweenInfo.new(0.3), { Transparency = 0 }):Play()
			game.TweenService:Create(clone20, TweenInfo.new(0.3), { Size = Vector3.new(0, 0, 0) }):Play()
			task.wait(1)

			local descendants = Character:GetDescendants()

			for _, v in pairs(descendants) do
				if v.Name == "ForceField" then
					v.Enabled = false
				end
			end

			game.TweenService:Create(Character.UpperTorso.SonicLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Peacemaker.Counter", result)
	end
end)

return true
