-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local forceFieldAntiGravity = game.ReplicatedStorage.Characters.Peacemaker.Fx.ForceFieldAntiGravity

		game.ReplicatedStorage.Characters.Peacemaker.Remotes.AntiGravity.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local clone = script.Sfx:Clone()

			clone.Parent = Character.HumanoidRootPart
			clone:Play()
			game.Debris:AddItem(clone, 3)

			local clone2 = forceFieldAntiGravity:Clone()

			clone2.Parent = Character.UpperTorso
			game.Debris:AddItem(clone2, 4)

			local clone3 = forceFieldAntiGravity:Clone()

			clone3.Parent = Character.LowerTorso
			game.Debris:AddItem(clone3, 4)

			local clone4 = forceFieldAntiGravity:Clone()

			clone4.Parent = Character.RightUpperArm
			game.Debris:AddItem(clone4, 4)

			local clone5 = forceFieldAntiGravity:Clone()

			clone5.Parent = Character.RightLowerArm
			game.Debris:AddItem(clone5, 4)

			local clone6 = forceFieldAntiGravity:Clone()

			clone6.Parent = Character.LeftUpperArm
			game.Debris:AddItem(clone6, 4)

			local clone7 = forceFieldAntiGravity:Clone()

			clone7.Parent = Character.LeftLowerArm
			game.Debris:AddItem(clone7, 4)

			local clone8 = forceFieldAntiGravity:Clone()

			clone8.Parent = Character.LeftHand
			game.Debris:AddItem(clone8, 4)

			local clone9 = forceFieldAntiGravity:Clone()

			clone9.Parent = Character.RightHand
			game.Debris:AddItem(clone9, 4)

			local clone10 = forceFieldAntiGravity:Clone()

			clone10.Parent = Character.RightUpperLeg
			game.Debris:AddItem(clone10, 4)

			local clone11 = forceFieldAntiGravity:Clone()

			clone11.Parent = Character.RightLowerLeg
			game.Debris:AddItem(clone11, 4)

			local clone12 = forceFieldAntiGravity:Clone()

			clone12.Parent = Character.LeftUpperLeg
			game.Debris:AddItem(clone12, 4)

			local clone13 = forceFieldAntiGravity:Clone()

			clone13.Parent = Character.LeftLowerLeg
			game.Debris:AddItem(clone13, 4)

			local clone14 = forceFieldAntiGravity:Clone()

			clone14.Parent = Character.LeftFoot
			game.Debris:AddItem(clone14, 4)

			local clone15 = forceFieldAntiGravity:Clone()

			clone15.Parent = Character.RightFoot
			game.Debris:AddItem(clone15, 4)

			local clone16 = forceFieldAntiGravity:Clone()

			clone16.Parent = Character.Head
			task.wait(1.7)

			local descendants = Character:GetDescendants()

			for _, v in pairs(descendants) do
				if v.Name == "ForceFieldAntiGravity" then
					v.Enabled = false
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Peacemaker.AntiGravity", result)
	end
end)

return true
