-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Patrick.AnimationsExtra.FinisherHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2

		game.ReplicatedStorage.Characters.Peacemaker.Remotes.ShieldSlash.OnClientEvent:Connect(function(parent)
			local v13 = animationService.GetTrack(parent.Humanoid, hit1)
			local v14 = animationService.GetTrack(parent.Humanoid, hit2)
			local randomNumber = math.random(1, 2)

			if randomNumber == 1 then
				v13:Play()
			elseif randomNumber == 2 then
				v14:Play()
			end

			local clone = neckExplode:Clone()

			clone.Parent = parent.Head
			clone.Bl1:Emit(5)
			clone.Bl2:Emit(15)

			local clone2 = bloodDrip:Clone()

			clone2.Parent = parent
			clone2.LocalScript.Disabled = false

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

			clone2.CFrame = parent.UpperTorso.CFrame
			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

			local randomNumber2 = math.random(-2, 2)
			local randomNumber3 = math.random(-2, 2)

			bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * 40
			game.Debris:AddItem(clone2, 3)
			game.Debris:AddItem(bodyVelocity, 0.15)
			game.Debris:AddItem(clone, 3)

			local clone3 = script.Hit:Clone()

			clone3.Parent = parent.HumanoidRootPart
			clone3.PlaybackSpeed = math.random(1, 1.3)
			clone3:Play()
			game.Debris:AddItem(clone3, 3)

			local clone4 = script.MetalHit:Clone()

			clone4.Parent = parent.HumanoidRootPart
			clone4.PlaybackSpeed = math.random(1, 1.3)
			clone4:Play()
			game.Debris:AddItem(clone4, 3)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Peacemaker.ShieldHit", result)
	end
end)

return true
