-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local LocalPlayer = game.Players.LocalPlayer
		local ReplicatedStorage = game.ReplicatedStorage
		local eagly = game.ReplicatedStorage.Characters.Peacemaker.Remotes.Eagly
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock3(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v20 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v22 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v22, 0)
				local n2 = v20 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v25 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v25 then
					local instance = v25.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v31 = mathRandom(-180, 180)
					local v32 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v31, v32, mathRandom(-180, 180))
					part.Position = p1.Position

					local v33 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v33, { Position = v25.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v57 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v57, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v58 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v58, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Size = Vector3.new(3, 3, 3)
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v38 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v40 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v42 = math.rad(randomNumber3)
						local v43 = cFrameAngles(v38, v40, v42)

						clone.CFrame = p1.CFrame * v43

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						bodyVelocity.Parent = clone
						clone.Parent = workspace.Effects
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end

		local explo = game.ReplicatedStorage.Characters.Wanda.Fx.Explo
		local v12 = game.ReplicatedStorage.Characters.Peacemaker.Fx.Eagly
		local hitboxPunch = game.ReplicatedStorage.Characters.Combat.Peacemaker.HitboxPunch
		local projectileHit = game.ReplicatedStorage.Characters.MoonKnight.Remotes.ProjectileHit

		local function DashForward(parent)
			local tata: BodyPosition = Instance.new("BodyPosition")

			tata.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			tata.P = 10000
			tata.D = 3000
			tata.Position = (parent.CFrame * CFrame.new(0, 0, -400)).Position
			tata.Name = "Tata"
			tata.Parent = parent
			game.Debris:AddItem(tata, 3)
		end

		eagly.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local clone = v12:Clone()

			clone.Anchored = false
			clone.Parent = workspace
			clone.CFrame = Character.HumanoidRootPart.CFrame
			game.Debris:AddItem(clone, 6)
			clone.CFrame = Character.HumanoidRootPart.CFrame

			local clone2 = hitboxPunch:Clone()

			clone2.Parent = clone

			local weld: Weld = Instance.new("Weld", clone2)

			weld.Part0 = clone
			weld.Part1 = clone2

			local v54 = CFrame.Angles(0, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v54
			clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
			DashForward(clone)
			clone.Noise:Play()
			task.spawn(function()
				task.wait(2.7)

				if clone:FindFirstChild("Hitbox") then
					TestRock3(clone)

					local bodyPosition: BodyPosition = Instance.new("BodyPosition")

					bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
					bodyPosition.P = 10000
					bodyPosition.D = 3000
					bodyPosition.Position = (clone.CFrame * CFrame.new(0, 400, -400)).Position
					bodyPosition.Parent = clone
					game.Debris:AddItem(bodyPosition, 3)
				end
			end)
			clone2.Touched:Connect(function(_)
				for _, v in ipairs(workspace:GetChildren()) do
					local v65 = v:IsA("Model") and v

					if v65 and v65:FindFirstChild("Humanoid") and v65:FindFirstChild("HumanoidRootPart") and v65 ~= Character and not v65:FindFirstChild("Iframe") and (clone.Position - v65.HumanoidRootPart.Position).magnitude <= 4 then
						local values = Character:FindFirstChild("Values")
						local values2 = v65:FindFirstChild("Values")
						local v68 = values

						if v68 then
							v68 = values:FindFirstChild("TeamColor")
						end

						local teamColor = values2 and values2:FindFirstChild("TeamColor")

						if not v68 or not teamColor then
							return
						end

						local v70 = v68.Value
						local teamColorValue = teamColor.Value
						local FFAColorValue = game.ReplicatedStorage.FFAColor.Value

						if teamColorValue ~= v70 or teamColorValue == FFAColorValue and v70 == FFAColorValue then
							clone2:Destroy()
							clone.Anchored = true

							if LocalPlayer == player then
								projectileHit:FireServer(v65, player, Character)
							end

							TestRock3(v65.HumanoidRootPart)

							local clone3 = explo:Clone()

							clone3.PointLight.Enabled = false
							game.Debris:AddItem(clone3, 3)
							clone3.Parent = workspace
							clone3.Position = v65.HumanoidRootPart.Position
							clone3.GroundSfx:Play()
							clone.Feathers:Emit(30)

							local cloneCFrame = clone.CFrame
							local v75 = CFrame.Angles(1.5707963267948966, 0, 0)

							clone.CFrame = cloneCFrame * v75
							clone.Anchored = true
							game.TweenService:Create(clone, TweenInfo.new(3), { Position = clone.Position + Vector3.new(0, 160, 0) }):Play()

							local raycastParams = RaycastParams.new()

							raycastParams.FilterType = Enum.RaycastFilterType.Include
							raycastParams.FilterDescendantsInstances = { workspace.Map }

							local v77 = workspace:Raycast(v65.HumanoidRootPart.Position, v65.HumanoidRootPart.CFrame.UpVector * -5, raycastParams)
							local InstanceColor = v77.Instance.Color

							if v77 ~= nil then
								clone3.Smoke.Color = ColorSequence.new(InstanceColor)
								clone3.Rocks.Color = ColorSequence.new(InstanceColor)
								clone3.Smoke:Emit(20)
								clone3.Rocks:Emit(30)
							end
						end
					end
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Peacemaker.Eagly", result)
	end
end)

return true
