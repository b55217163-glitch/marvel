-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.Wednesday.Remotes.Pierce.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local v14 = animationService.GetTrack(p2.Humanoid, hit1)
			local v15 = animationService.GetTrack(p2.Humanoid, hit2)
			local clone = hitAt:Clone()

			clone.Parent = p2.HumanoidRootPart
			clone.Sparks:Emit(8)
			clone.Shock:Emit(1)
			game.Debris:AddItem(clone, 1)

			local randomNumber = math.random(1, 2)

			if randomNumber == 1 then
				v14:Play()
			elseif randomNumber == 2 then
				v15:Play()
			end

			for _ = 1, 20 do
				local clone2 = bloodDrip:Clone()

				clone2.Parent = player.Character

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

				clone2.Parent = workspace.Effects
				clone2.CFrame = p2.UpperTorso.CFrame
				clone2.LocalScript.Enabled = true
				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber2 = math.random(-2, 2)
				local randomNumber3 = math.random(-2, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * 15
				game.Debris:AddItem(clone2, 3)
				game.Debris:AddItem(bodyVelocity, 0.05)
			end

			if player.Character:FindFirstChild("Wednesday") then
				local clone3 = script.StabSound:Clone()

				clone3.Parent = p2.HumanoidRootPart
				clone3:Play()
				game.Debris:AddItem(clone3, 2)
			elseif player.Character:FindFirstChild("Springbonnie") then
				local clone4 = script.StabSound2:Clone()

				clone4.Parent = p2.HumanoidRootPart
				clone4:Play()
				game.Debris:AddItem(clone4, 2)
			end

			local clone5 = neckExplode:Clone()

			clone5.Parent = p2.UpperTorso

			if player.Character:FindFirstChild("Wednesday") then
				player.Character.Head.HeadBoneCrush:Play()
			end

			clone5.Bl1:Emit(5)
			clone5.Bl2:Emit(10)

			for _ = 1, 40 do
				local randomNumber4 = math.random(15, 30)
				local clone6 = bloodDrip:Clone()

				clone6.Parent = Character
				clone6.LocalScript.Disabled = false

				local bodyVelocity2: BodyVelocity = Instance.new("BodyVelocity", clone6)

				clone6.CFrame = p2.UpperTorso.CFrame
				bodyVelocity2.MaxForce = Vector3.new(inf, inf, inf) * math.huge

				local randomNumber5 = math.random(-2, 2)
				local randomNumber6 = math.random(-2, 2)

				bodyVelocity2.Velocity = Vector3.new(randomNumber5, randomNumber6, math.random(-2, 2)) * randomNumber4
				game.Debris:AddItem(clone6, 3)
				game.Debris:AddItem(bodyVelocity2, 0.15)
			end

			if player.Character.HumanoidRootPart:FindFirstChild("Stab") then
				player.Character.HumanoidRootPart.Stab:Play()
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Wednesday.PierceHit", result)
	end
end)

return true
