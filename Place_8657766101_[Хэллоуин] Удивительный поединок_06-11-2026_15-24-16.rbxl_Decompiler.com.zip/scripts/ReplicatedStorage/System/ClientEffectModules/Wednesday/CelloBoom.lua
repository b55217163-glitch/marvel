-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		game:GetService("Players")

		local debris: Debris = game:GetService("Debris")

		local function waitForChildTimeout(p1, p2, p3)
			if not p1 then
				return nil
			end

			local foundChild = p1:FindFirstChild(p2)

			if foundChild then
				return foundChild
			end

			local v10 = os.clock()

			while true do
				local v11 = os.clock()

				if not (p3 > v11 - v10) then
					break
				end

				local foundChild2 = p1:FindFirstChild(p2)

				if foundChild2 then
					return foundChild2
				end

				task.wait()
			end

			return nil
		end
		local function resolveCharacter(p4)
			if typeof(p4) == "Instance" then
				if p4:IsA("Model") and p4:FindFirstChildOfClass("Humanoid") then
					return p4
				end

				if p4:IsA("Player") then
					local Character = p4.Character

					if Character and Character.Parent then
						return Character
					end

					local v15 = os.clock()
					local Character2

					while true do
						Character2 = p4.Character

						if Character2 and Character2.Parent then
							break
						end

						task.wait()

						local v17 = os.clock()

						if v15 + 0.4 < v17 then
							return nil
						end
					end

					return Character2
				end

				return nil
			end

			return nil
		end

		game:GetService("ReplicatedStorage").Characters.Wednesday.Remotes.CelloRemote.OnClientEvent:Connect(function(p5)
			local v19 = resolveCharacter(p5)

			if not v19 then
				return
			end

			local parent = v19:FindFirstChild("HumanoidRootPart") or waitForChildTimeout(v19, "HumanoidRootPart", 0.25)

			if not parent then
				return
			end

			if parent:FindFirstChild("CelloBoom") then
				parent.CelloBoom.Fly1:Emit(12)
				parent.CelloBoom.Fly2:Emit(12)
				parent.CelloBoom.Ring1:Emit(4)
				parent.CelloBoom.Ring2:Emit(1)
				parent.CelloBoom.Ring3:Emit(1)
			end

			local celloShock = parent:FindFirstChild("CelloShock")

			if celloShock and celloShock:IsA("Sound") then
				local clone = celloShock:Clone()

				clone.Parent = parent
				clone.PlaybackSpeed = math.random(1, 1.2)
				clone:Play()
				debris:AddItem(clone, clone.TimeLength)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Wednesday.CelloBoom", result)
	end
end)

return true
