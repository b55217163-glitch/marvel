-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local debris: Debris = game:GetService("Debris")
		local wednesday: Instance = game:GetService("ReplicatedStorage"):WaitForChild("Characters"):WaitForChild("Wednesday")
		local fx: Instance = wednesday:WaitForChild("Fx")
		local remotes: Instance = wednesday:WaitForChild("Remotes")
		local hitHandGrab = wednesday:WaitForChild("AnimationsExtra").HitHandGrab

		remotes:WaitForChild("ThingThrow").OnClientEvent:Connect(function(p1)
			if not p1 then
				return
			end

			local humanoid = p1:FindFirstChildOfClass("Humanoid")

			if not humanoid then
				return
			end

			local animator = humanoid:FindFirstChildOfClass("Animator")

			if not animator then
				return
			end

			local head = p1:FindFirstChild("Head")

			if not head then
				return
			end

			animationService.GetTrack(animator, hitHandGrab):Play()

			local clone = fx.GrabHead:Clone()

			clone.Parent = p1
			debris:AddItem(clone, 6)

			local motor6D: Motor6D = Instance.new("Motor6D")

			motor6D.Parent = workspace.Effects
			motor6D.Part0 = head
			motor6D.Part1 = clone.GrHead

			local v15 = CFrame.Angles(0, 0, 0)

			motor6D.C0 = CFrame.new(0, 0, 0) * v15
			debris:AddItem(motor6D, 1.5)

			local grab = clone.GrHead:FindFirstChild("Grab")

			if grab and grab:IsA("Sound") then
				grab:Play()
			end

			clone:FindFirstChild("Hand").CanCollide = false

			local particleAt = clone.GrHead:FindFirstChild("ParticleAt")

			for iterFirst, iterSecond in particleAt:GetChildren() do
				if iterSecond:IsA("ParticleEmitter") then
					local emitCount = iterSecond:GetAttribute("EmitCount")

					iterSecond:Emit(emitCount or 1)
				end
			end

			task.wait(1.5)

			for iterFirst2, iterSecond2 in particleAt:GetChildren() do
				if iterSecond2:IsA("ParticleEmitter") and iterSecond2.Name ~= "SparksFall" and iterSecond2.Name ~= "SparksSlow" then
					local emitCount = iterSecond2:GetAttribute("EmitCount")

					iterSecond2:Emit(emitCount or 1)
				end
			end

			task.wait(3)

			local foundChild = clone:FindFirstChild("Hand", true)

			if foundChild and foundChild:IsA("BasePart") then
				foundChild.CanCollide = true
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Wednesday.ThingThrow", result)
	end
end)

return true
