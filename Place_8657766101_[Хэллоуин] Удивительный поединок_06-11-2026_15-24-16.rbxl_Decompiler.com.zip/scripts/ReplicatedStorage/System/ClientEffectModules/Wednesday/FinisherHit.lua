-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gameDebris = game.Debris
		local finisherAnim = game.ReplicatedStorage.Characters.Wednesday.AnimationsExtra.FinisherAnim
		local finisherHit = game.ReplicatedStorage.Characters.Wednesday.AnimationsExtra.FinisherHit
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local beePart = game.ReplicatedStorage.Characters.Wednesday.Fx.BeePart
		local v12 = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.Wednesday.Remotes.Finisher.OnClientEvent:Connect(function(player, parent)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)
			Character.FenchSword.Transparency = 0

			local clone = v12:Clone()

			clone.Parent = parent.Head

			local v17 = animationService.LoadFresh(Character.Humanoid, finisherAnim)
			local v18 = animationService.LoadFresh(parent.Humanoid, finisherHit)

			Character.Head.MoveFive:Play()
			v17.KeyframeReached:Connect(function(p3)
				if p3 == "Slam" then
					clone.Bl1:Emit(10)
					clone.Bl2:Emit(30)

					for _ = 1, 40 do
						local randomNumber = math.random(15, 30)
						local clone2 = bloodDrip:Clone()

						clone2.Parent = Character
						clone2.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

						clone2.CFrame = parent.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber2 = math.random(-2, 2)
						local randomNumber3 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone2, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					if Character:FindFirstChild("BlackCat") then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v30 = workspace:Raycast(Character.FakeUpperTorso.Position, Character.FakeUpperTorso.CFrame.UpVector * -6, raycastParams)

						if v30 == nil then
							Character.FakeUpperTorso.Chopa.Flare:Emit(5)
							Character.FakeUpperTorso.Chopa.Flare2:Emit(5)
							Character.FakeUpperTorso.Chopb.Flare:Emit(5)
							Character.FakeUpperTorso.Chopb.Flare2:Emit(5)
							Character.FakeUpperTorso.Chopc.Flare:Emit(5)
							Character.FakeUpperTorso.Chopc.Flare2:Emit(5)
						else
							local InstanceColor = v30.Instance.Color

							Character.FakeUpperTorso.Chop2.Rock.Color = ColorSequence.new(InstanceColor)
							Character.FakeUpperTorso.Chop2.Smoke.Color = ColorSequence.new(InstanceColor)
							Character.FakeUpperTorso.Chopa.Flare:Emit(5)
							Character.FakeUpperTorso.Chopa.Flare2:Emit(5)
							Character.FakeUpperTorso.Chopb.Flare:Emit(5)
							Character.FakeUpperTorso.Chopb.Flare2:Emit(5)
							Character.FakeUpperTorso.Chopc.Flare:Emit(5)
							Character.FakeUpperTorso.Chopc.Flare2:Emit(5)
							Character.FakeUpperTorso.Chop2.Rock:Emit(30)
							Character.FakeUpperTorso.Chop2.Smoke:Emit(10)
						end
					end

					v18:Play()
					task.wait(1)
					Character.FenchSword.Transparency = 1
				end
			end)
			v17.KeyframeReached:Connect(function(_)
			end)
			v18.KeyframeReached:Connect(function(_)
			end)
			v17.KeyframeReached:Connect(function(p6)
				if p6 == "Stomp" then
					clone.Bl1:Emit(10)
					clone.Bl2:Emit(30)

					for _ = 1, 40 do
						local randomNumber = math.random(15, 30)
						local clone3 = bloodDrip:Clone()

						clone3.Parent = Character
						clone3.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

						clone3.CFrame = parent.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone3, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end
			end)
			v17:Play()
			task.wait(2)

			if not Character:FindFirstChild("BlackCat") then
				local clone4 = beePart:Clone()

				clone4.Parent = parent
				clone4.Position = Character.FakeUpperTorso.Position + Vector3.new(0, 30, -30)
				clone4.Beebuzz.PlaybackSpeed = math.random(1, 1.5)
				clone4.Beebuzz:Play()
				clone4.Beebuzz2.PlaybackSpeed = math.random(1, 1.5)
				clone4.Beebuzz2:Play()
				game.Debris:AddItem(clone4, 6)
				game.TweenService:Create(clone4, TweenInfo.new(2.2), { Position = parent.UpperTorso.Position }):Play()

				local clone5 = beePart:Clone()

				clone5.Parent = parent
				clone5.Position = Character.FakeUpperTorso.Position + Vector3.new(0, 40, 30)
				clone5.Beebuzz.PlaybackSpeed = math.random(1, 1.5)
				clone5.Beebuzz:Play()
				clone5.Beebuzz2.PlaybackSpeed = math.random(1, 1.5)
				clone5.Beebuzz2:Play()
				game.Debris:AddItem(clone5, 6)
				game.TweenService:Create(clone5, TweenInfo.new(2), { Position = parent.UpperTorso.Position }):Play()

				local clone6 = beePart:Clone()

				clone6.Parent = parent
				clone6.Position = Character.FakeUpperTorso.Position + Vector3.new(30, 32, 0)
				clone6.Beebuzz.PlaybackSpeed = math.random(1, 1.5)
				clone6.Beebuzz:Play()
				clone6.Beebuzz2.PlaybackSpeed = math.random(1, 1.5)
				clone6.Beebuzz2:Play()
				game.Debris:AddItem(clone6, 6)
				game.TweenService:Create(clone6, TweenInfo.new(2.4), { Position = parent.UpperTorso.Position }):Play()
				task.wait(3)
				game.TweenService:Create(clone4, TweenInfo.new(12.2), { Position = parent.UpperTorso.Position + Vector3.new(90, 92, 0) }):Play()
				game.TweenService:Create(clone5, TweenInfo.new(12), { Position = parent.UpperTorso.Position + Vector3.new(-90, 92, 0) }):Play()
				game.TweenService:Create(clone6, TweenInfo.new(12.4), { Position = parent.UpperTorso.Position + Vector3.new(0, 92, 90) }):Play()
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Wednesday.FinisherHit", result)
	end
end)

return true
