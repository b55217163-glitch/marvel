-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local runService: RunService = game:GetService("RunService")
		local debris: Debris = game:GetService("Debris")
		local workspace: Workspace = game:GetService("Workspace")
		local LocalPlayer: Player = players.LocalPlayer
		local trashbag = replicatedStorage.Characters.Dexter.Remotes.Trashbag
		local trashBag = replicatedStorage.Characters.Dexter.Fx.TrashBag
		local waterLand = replicatedStorage.Characters.Dexter.Fx.WaterLand
		local v13 = workspace:FindFirstChild("Effects") or workspace

		local function getMap()
			local map

			while true do
				map = workspace:FindFirstChild("Map")

				if map then
					break
				end

				task.wait(0.1)
			end

			return map
		end
		local function getCharacterFromPlayer(player)
			if not player then
				return nil
			end

			local Character = player.Character

			if not Character then
			elseif Character:FindFirstChildOfClass("Humanoid") and not (Character:FindFirstChildOfClass("Humanoid").Health <= 0) then
				return Character
			end

			return nil
		end
		local function getHand(p2)
			return p2:FindFirstChild("LeftHand") or p2:FindFirstChild("LeftLowerArm")
		end
		local function getRoot(p3)
			return p3:FindFirstChild("HumanoidRootPart")
		end
		local function makeMapIncludeParams()
			local v30 = getMap()
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v30 }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function raycastToGround(p4)
			local v33 = getMap()
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v33 }
			raycastParams.IgnoreWater = true

			return workspace:Raycast(p4, Vector3.new(0, -200, 0), raycastParams)
		end
		local function raycastMap(p5, p6)
			local n1 = p6 - p5

			if n1.Magnitude <= 0.001 then
				return nil
			end

			local v38 = getMap()
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { v38 }
			raycastParams.IgnoreWater = true

			return workspace:Raycast(p5, n1, raycastParams)
		end
		local function bezier(p7, p8, p9, p10)
			local v44 = p7:Lerp(p8, p10)
			local v45 = p8:Lerp(p9, p10)

			return v44:Lerp(v45, p10)
		end
		local function spawnWaterLand(p11, p12)
			local clone = waterLand:Clone()

			clone.Parent = v13

			if clone:IsA("BasePart") then
				clone.Anchored = true
				clone.CanCollide = false
				clone.CanTouch = false
				clone.CanQuery = false

				local cFrame = CFrame.new(p11 + (p12 or Vector3.new(0, 1, 0)) * 0.05)
				local v50 = CFrame.Angles(0, 0, 1.5707963267948966)

				clone.CFrame = cFrame * v50

				local landSfx = clone:FindFirstChild("LandSfx")

				if landSfx and landSfx:IsA("Sound") then
					landSfx.PlaybackSpeed = Random.new():NextNumber(1, 1.4)
					landSfx:Play()
				end
			end

			local attachment = clone:FindFirstChild("Attachment")

			if attachment then
				local whirl = attachment:FindFirstChild("Whirl")

				if whirl and whirl:IsA("ParticleEmitter") then
					whirl:Emit(5)
				end

				local whirlSlow = attachment:FindFirstChild("WhirlSlow")

				if whirlSlow and whirlSlow:IsA("ParticleEmitter") then
					whirlSlow:Emit(5)
				end
			end

			local sprinkler = clone:FindFirstChild("Sprinkler")

			if sprinkler and sprinkler:IsA("ParticleEmitter") then
				sprinkler:Emit(20)
			end

			if clone:IsA("BasePart") then
				local tweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

				tweenService:Create(clone, tweenInfo, { Transparency = 1, CFrame = clone.CFrame + Vector3.new(0, -2.5, 0) }):Play()
			end

			debris:AddItem(clone, 3)
		end
		local function fadeAndRemoveTrashbag(p13)
			if not p13 or not p13.Parent or not p13:IsA("BasePart") then
				return
			end

			local tweenInfo = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

			tweenService:Create(p13, tweenInfo, { Transparency = 1, CFrame = p13.CFrame + Vector3.new(0, -1.3, 0) }):Play()
			debris:AddItem(p13, 0.3)
		end
		local function throwTrashbag(player)
			local v60

			if not player then
				v60 = nil
			else
				local Character = player.Character

				if not Character then
					v60 = nil
				else
					local humanoid = Character:FindFirstChildOfClass("Humanoid")

					v60 = if humanoid and not (humanoid.Health <= 0) then Character else nil
				end
			end

			if not v60 then
				local v63: Player = LocalPlayer

				if not v63 then
					v60 = nil
				else
					local Character: Model = v63.Character

					if not Character then
						v60 = nil
					else
						local humanoid: Instance = Character:FindFirstChildOfClass("Humanoid")

						v60 = if humanoid and not (humanoid.Health <= 0) then Character else nil
					end
				end
			end

			if not v60 then
				return
			end

			local part0 = v60:FindFirstChild("LeftHand") or v60:FindFirstChild("LeftLowerArm")
			local humanoidRootPart = v60:FindFirstChild("HumanoidRootPart")

			if part0 and humanoidRootPart then
				local clone = trashBag:Clone()

				clone.Parent = v13

				if not clone:IsA("BasePart") then
					clone:Destroy()

					return
				end

				clone.Anchored = false
				clone.CanCollide = false
				clone.CanTouch = false
				clone.CanQuery = false
				clone.Massless = true
				clone.CFrame = part0.CFrame

				local weldConstraint: WeldConstraint = Instance.new("WeldConstraint")

				weldConstraint.Part0 = part0
				weldConstraint.Part1 = clone
				weldConstraint.Parent = clone
				task.wait(0.3)

				if not clone.Parent or not v60.Parent or not humanoidRootPart.Parent then
					clone:Destroy()

					return
				end

				weldConstraint:Destroy()
				clone.Anchored = true

				local clonePosition = clone.Position
				local n1 = humanoidRootPart.Position + humanoidRootPart.CFrame.LookVector * 22
				local v72 = getMap()
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { v72 }
				raycastParams.IgnoreWater = true

				local v74 = workspace:Raycast(n1 + Vector3.new(0, 25, 0), Vector3.new(0, -200, 0), raycastParams)
				local v75 = v74 and v74.Position or n1
				local v76 = v74 and v74.Normal or Vector3.new(0, 1, 0)
				local n2 = (clonePosition + v75) * 0.5 + Vector3.new(0, 14, 0)
				local timestamp = tick()
				local u79: boolean = false
				local u80 = clonePosition
				local connection = nil

				connection = runService.RenderStepped:Connect(function()
					if not clone or not clone.Parent then
						if connection then
							connection:Disconnect()
						end

						return
					end

					local n1 = tick() - timestamp
					local v84 = math.clamp(n1 / 0.45, 0, 1)
					local v85 = n2
					local v86 = clonePosition:Lerp(v85, v84)
					local v87 = v85:Lerp(v75, v84)
					local v88 = v86:Lerp(v87, v84)
					local v89 = math.clamp(v84 + 0.03, 0, 1)

					v86 = n2

					local v90 = clonePosition:Lerp(v86, v89)
					local v91 = v86:Lerp(v75, v89)
					local v92 = v90:Lerp(v91, v89)
					local v93 = u80

					v86 = v88 - v93

					local v95

					if v86.Magnitude <= 0.001 then
						v95 = nil
					else
						local v96 = getMap()
						local raycastParams2 = RaycastParams.new()

						raycastParams2.FilterType = Enum.RaycastFilterType.Include
						raycastParams2.FilterDescendantsInstances = { v96 }
						raycastParams2.IgnoreWater = true
						v95 = workspace:Raycast(v93, v86, raycastParams2)
					end

					if v95 then
						local n3 = v95.Position + v95.Normal * 0.05

						clone.CFrame = CFrame.lookAt(n3, n3 + v95.Normal)

						if not u79 then
							u79 = true
							spawnWaterLand(v95.Position, v95.Normal)
						end

						connection:Disconnect()
						fadeAndRemoveTrashbag(clone)

						return
					end

					clone.CFrame = CFrame.lookAt(v88, v92)
					u80 = v88

					if not u79 and n1 >= 0.25 then
						u79 = true
						spawnWaterLand(v75, v76)
					end

					if v84 >= 1 then
						connection:Disconnect()
						fadeAndRemoveTrashbag(clone)
					end
				end)

				return
			end
		end

		trashbag.OnClientEvent:Connect(function(p15)
			task.spawn(function()
				throwTrashbag(p15)
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Dexter.Trashbags", result)
	end
end)

return true
