-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local runService: RunService = game:GetService("RunService")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local bloodBomb: Instance = replicatedStorage:WaitForChild("Characters"):WaitForChild("Combat"):WaitForChild("Remotes"):WaitForChild("BloodBomb")
		local bloodDrip = game.ReplicatedFirst.Effects.Blood.Fx.BloodDrip
		local bloodSplash = game.ReplicatedFirst.Effects.Blood.Fx.BloodSplash
		local bloodSmoke = game.ReplicatedFirst.Effects.Blood.Fx.BloodSmoke
		local effects = workspace:FindFirstChild("Effects")

		if not effects then
			effects = Instance.new("Folder")
			effects.Name = "Effects"
			effects.Parent = workspace
		end

		local t1: {[any]: any} = {
			Effects = true,
			Fx = true,
			VFX = true,
			Events = true,
			Event = true,
			Particles = true,
			Projectiles = true,
			Remotes = true
		}

		local function legacyVelocity()
			local randomNumber = math.random(-15, 15)
			local randomNumber2 = math.random(12, 35)
			local vector3 = Vector3.new(randomNumber, randomNumber2, math.random(-15, 15))

			return vector3
		end

		local LocalPlayer: Player = game:GetService("Players").LocalPlayer
		local CurrentCamera: Camera = workspace.CurrentCamera

		local function inRange(p1)
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v39 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position

			if not v39 then
				return true
			end

			local n1 = p1 - v39

			return n1:Dot(n1) <= 19600
		end

		local raycastParams = RaycastParams.new()

		raycastParams.IgnoreWater = true
		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.FilterDescendantsInstances = {}

		local u18 = nil

		local function refreshRayFilter()
			local map: Instance = workspace:FindFirstChild("Map")

			if map == u18 then
				return
			end

			u18 = map

			if u18 then
				raycastParams.FilterDescendantsInstances = { u18 }

				return
			end

			raycastParams.FilterDescendantsInstances = {}
		end

		refreshRayFilter()
		workspace.ChildAdded:Connect(function(child: Instance)
			if child.Name == "Map" then
				refreshRayFilter()
			end
		end)
		workspace.ChildRemoved:Connect(function(child: Instance)
			if child == u18 or child.Name == "Map" then
				refreshRayFilter()
			end
		end)

		local t2: {[any]: any} = {}

		local function getActiveDripCount()
			local n1: number = 0

			for iterKey in pairs(t2) do
				if iterKey.Parent then
					n1 += 1
				else
					t2[iterKey] = nil
				end
			end

			return n1
		end
		local function safeParentEffects(p4)
			p4.Parent = effects
		end
		local function emitSmoke(parent)
			if not parent then
				return
			end

			local clone = bloodSmoke:Clone()

			clone.Parent = parent
			clone:Emit(5)
			debris:AddItem(clone, 2)
		end
		local function playSplashSfx(p6)
			local bloodSFX = p6:FindFirstChild("BloodSFX")

			if bloodSFX and bloodSFX:IsA("Sound") then
				bloodSFX.PlaybackSpeed = math.random(100, 130) / 100
				bloodSFX:Play()
			end
		end
		local function tweenSplashSize(p7)
			local randomNumber = math.random(1, 3)

			tweenService:Create(p7, TweenInfo.new(0.3), {
				Size = if randomNumber == 1 then Vector3.new(0.5, 0.2, 0.5) else if randomNumber == 2 then Vector3.new(0.8, 0.2, 0.8) else Vector3.new(2, 0.2, 2)
			}):Play()

			local taskDelay = task.delay
			local randomNumber3 = math.random(3, 5)

			taskDelay(randomNumber3, function()
				if p7 and p7.Parent then
					tweenService:Create(p7, TweenInfo.new(2), { Size = Vector3.new(0, 0, 0) }):Play()
					debris:AddItem(p7, 2.1)
				end
			end)
		end
		local function makeSplash(p8, p9)
			local clone = bloodSplash:Clone()

			clone.Size = Vector3.new(0, 0, 0)
			clone.Parent = effects

			local v58 = CFrame.lookAt(p8, p8 + p9)
			local v59 = CFrame.Angles(-1.5707963267948966, 0, 0)

			clone.CFrame = v58 * v59
			debris:AddItem(clone, 10)
			tweenSplashSize(clone)

			local bloodSFX = clone:FindFirstChild("BloodSFX")

			if bloodSFX and bloodSFX:IsA("Sound") then
				bloodSFX.PlaybackSpeed = math.random(100, 130) / 100
				bloodSFX:Play()
			end
		end
		local function isBlacklistedHit(p10)
			if effects and p10:IsDescendantOf(effects) then
				return true
			end

			local v62 = p10

			while v62 and v62 ~= u18 do
				if t1[v62.Name] then
					return true
				end

				v62 = v62.Parent
			end

			return false
		end
		local function validGroundHit(p11)
			local instance = p11.Instance

			if not instance then
				return false
			end

			if not u18 then
				return false
			end

			if not instance:IsDescendantOf(u18) then
				return false
			end

			local u65

			if effects and instance:IsDescendantOf(effects) then
				u65 = true
			else
				local v66 = instance

				while v66 and v66 ~= u18 do
					if t1[v66.Name] then
						u65 = true

						break
					end

					v66 = v66.Parent
				end

				if not v66 or v66 == u18 then
					u65 = false
				end
			end

			if u65 then
				return false
			end

			if not instance.Anchored then
				return false
			end

			if not instance.CanCollide then
				return false
			end

			return true
		end
		local function spawnDrip(p12)
			local clone = bloodDrip:Clone()

			clone.Parent = effects
			clone.CFrame = p12.CFrame
			clone.Position = p12.Position
			clone.Anchored = false
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.CastShadow = false
			clone.Massless = true
			clone.Transparency = 0

			local randomNumber = math.random(-15, 15)
			local randomNumber4 = math.random(12, 35)

			clone.AssemblyLinearVelocity = Vector3.new(randomNumber, randomNumber4, math.random(-15, 15))
			debris:AddItem(clone, 6)

			local clonePosition = clone.Position
			local v72 = os.clock()

			t2[clone] = { lastPos = clonePosition, expireAt = v72 + 6 + 0.1 }
		end

		local n1: number = 0

		runService.Heartbeat:Connect(function(deltaTime: number)
			n1 += deltaTime

			if n1 < 0.03333333333333333 then
				return
			end

			n1 -= 0.03333333333333333

			if not u18 then
				return
			end

			local v74 = os.clock()

			for k, v in pairs(t2) do
				if not k or not k.Parent or v74 > v.expireAt then
					t2[k] = nil
				else
					local kPosition = k.Position
					local v78 = v.lastPos
					local n2 = kPosition - v78
					local vectorValue

					if n2:Dot(n2) < 0.0025 then
						v78 = kPosition
						vectorValue = Vector3.new(0, -14, 0)
					else
						vectorValue = n2 + Vector3.new(0, -0.75, 0)
					end

					n2 = workspace:Raycast(v78, vectorValue, raycastParams)
					v.lastPos = kPosition

					if n2 then
						local instance = n2.Instance
						local u82

						if not instance or not u18 or not instance:IsDescendantOf(u18) then
							u82 = false
						else
							local u83

							if effects and instance:IsDescendantOf(effects) then
								u83 = true
							else
								local v84 = instance

								while v84 and v84 ~= u18 do
									if t1[v84.Name] then
										u83 = true

										break
									else
										v84 = v84.Parent
									end
								end

								if not v84 or v84 == u18 then
									u83 = false
								end
							end

							u82 = if u83 then false else if not instance.Anchored then false else not not instance.CanCollide
						end

						if u82 then
							t2[k] = nil
							k.Anchored = true
							k.Transparency = 1
							makeSplash(n2.Position, n2.Normal)
							debris:AddItem(k, 0.25)
						end
					end
				end
			end
		end)

		local function Blood(p14, p15)
			if not p14 then
				return
			end

			local upperTorso = p14:FindFirstChild("UpperTorso")

			if not upperTorso or not upperTorso:IsA("BasePart") then
				return
			end

			local upperTorsoPosition = upperTorso.Position
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v91 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position
			local u93

			if not v91 then
				u93 = true
			else
				local n1 = upperTorsoPosition - v91

				u93 = n1:Dot(n1) <= 19600
			end

			if not u93 then
				return
			end

			if upperTorso then
				local clone = bloodSmoke:Clone()

				clone.Parent = upperTorso
				clone:Emit(5)
				debris:AddItem(clone, 2)
			end

			for _ = 1, p15 do
				spawnDrip(upperTorso)
			end
		end
		local function BloodParte(p16, p17, parent)
			if not p16 or not parent or not parent:IsA("BasePart") then
				return
			end

			local parentPosition = parent.Position
			local Character: Model = LocalPlayer.Character
			local humanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local v102 = humanoidRootPart and humanoidRootPart.Position or CurrentCamera and CurrentCamera.CFrame.Position
			local u104

			if not v102 then
				u104 = true
			else
				local n1 = parentPosition - v102

				u104 = n1:Dot(n1) <= 19600
			end

			if not u104 then
				return
			end

			if parent then
				local clone = bloodSmoke:Clone()

				clone.Parent = parent
				clone:Emit(5)
				debris:AddItem(clone, 2)
			end

			for _ = 1, p17 do
				spawnDrip(parent)
			end
		end

		bloodBomb.OnClientEvent:Connect(function(p19, p20, _, p22)
			if not p19 then
				return
			end

			local numberValue: number? = tonumber(p20)
			local floored = math.floor(numberValue or 0)
			local v113 = math.clamp(floored, 0, 25)
			local n1: number = 0

			for iterKey in pairs(t2) do
				if iterKey.Parent then
					n1 += 1
				else
					t2[iterKey] = nil
				end
			end

			local v116 = math.max(0, 60 - n1)
			local v117 = math.min(v113, v116)

			if v117 <= 0 then
				return
			end

			if p22 then
				BloodParte(p19, v117, p22)

				return
			end

			Blood(p19, v117)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "BloodBomb", result)
	end
end)

return true
