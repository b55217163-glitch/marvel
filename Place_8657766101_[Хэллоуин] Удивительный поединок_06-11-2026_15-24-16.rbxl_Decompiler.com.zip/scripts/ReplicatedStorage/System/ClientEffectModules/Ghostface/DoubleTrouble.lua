-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local workspace: Workspace = game:GetService("Workspace")
		local double = replicatedStorage.Characters.Ghostface.AnimationsExtra.Double
		local ghostface = replicatedStorage.Characters.Ghostface.Fx.Ghostface

		local function safePlay(p1)
			if p1 and p1:IsA("Sound") then
				p1:Play()
			end
		end
		local function safeEmit(p2, p3)
			if p2 and p2:IsA("ParticleEmitter") then
				p2:Emit(p3)
			end
		end
		local function safeSetEmitterColor(p4, p5)
			if p4 and p4:IsA("ParticleEmitter") then
				p4.Color = ColorSequence.new(p5)
			end
		end
		local function getAnimatorHumanoid(character)
			local parent = character:FindFirstChild("FHumanoid") or character:FindFirstChildOfClass("Humanoid")

			if not parent then
				return nil
			end

			local animator = parent:FindFirstChildOfClass("Animator")

			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = parent
			end

			return parent, animator
		end
		local function setTransparencyInstant(p7, transparency)
			for k, _ in pairs(p7) do
				if k and k.Parent then
					k.Transparency = transparency
				end
			end
		end
		local function tweenToOriginal(p9, p10)
			for k, v in pairs(p9) do
				if k and k.Parent then
					local tweenInfo = TweenInfo.new(p10)

					tweenService:Create(k, tweenInfo, { Transparency = v }):Play()
				end
			end
		end
		local function tweenAllTo(p11, p12, p13)
			for k, _ in pairs(p11) do
				if k and k.Parent then
					local tweenInfo = TweenInfo.new(p13)

					tweenService:Create(k, tweenInfo, { Transparency = p12 }):Play()
				end
			end
		end
		local function findMapFolder()
			local map: Instance = workspace:FindFirstChild("Map")

			if map and map:IsA("Folder") then
				return map
			end

			for _, v in ipairs(workspace:GetChildren()) do
				if v:IsA("Folder") and v.Name == "Map" then
					return v
				end
			end

			return nil
		end
		local function raycastDownToMap(p14, p15, p16)
			if not p14 then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { p14 }
			raycastParams.IgnoreWater = true

			local vector3 = Vector3.new(0, -p16, 0)

			return workspace:Raycast(p15, vector3, raycastParams)
		end
		local function copyMissingChild(p17, parent, p19)
			if p17 and parent and p19 then
				if parent:FindFirstChild(p19) then
					return
				end

				local foundChild = p17:FindFirstChild(p19)

				if foundChild then
					local clone = foundChild:Clone()

					clone.Parent = parent
				end

				return
			end
		end
		local function ensureDoubleTroubleFx(p20)
			if not p20 or not ghostface then
				return
			end

			local head = ghostface:FindFirstChild("Head")
			local head2 = p20:FindFirstChild("Head")

			if head and head2 and not head2:FindFirstChild("DoubleSfx") then
				local doubleSfx = head:FindFirstChild("DoubleSfx")

				if doubleSfx then
					local clone = doubleSfx:Clone()

					clone.Parent = head2
				end
			end

			local v63 = ghostface:FindFirstChild("UpperTorso") or ghostface:FindFirstChild("Torso")
			local upperTorso = p20:FindFirstChild("UpperTorso")

			if not upperTorso then
				upperTorso = p20:FindFirstChild("Torso")
			end

			if v63 and upperTorso and not upperTorso:FindFirstChild("TwoAt") then
				local twoAt = v63:FindFirstChild("TwoAt")

				if twoAt then
					local clone = twoAt:Clone()

					clone.Parent = upperTorso
				end
			end

			if v63 and upperTorso then
				if upperTorso:FindFirstChild("OneSmokeAt") then
					return
				end

				local oneSmokeAt = v63:FindFirstChild("OneSmokeAt")

				if oneSmokeAt then
					local clone = oneSmokeAt:Clone()

					clone.Parent = upperTorso
				end

				return
			end
		end
		local function spawnCloneAt(p21, p22)
			if not p21 then
				return nil, {}
			end

			local archivable = p21.Archivable

			p21.Archivable = true

			local clone = p21:Clone()

			p21.Archivable = archivable

			if not clone then
				return nil, {}
			end

			clone.Name = p21.Name .. "_DoubleTroubleClone"
			clone.Parent = workspace
			ensureDoubleTroubleFx(clone)

			local t1: {[any]: any} = {}

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("BasePart") or v:IsA("Decal") or v:IsA("Texture") then
					t1[v] = v.Transparency
					v.Transparency = 1

					if v:IsA("BasePart") then
						v.CanCollide = false
					end
				end
			end

			local humanoidRootPart = clone:FindFirstChild("HumanoidRootPart")

			if humanoidRootPart and p22 and p22:FindFirstChild("HumanoidRootPart") then
				humanoidRootPart.CFrame = p22.HumanoidRootPart.CFrame * CFrame.new(0, 0, 3)
				humanoidRootPart.Anchored = true
			end

			debris:AddItem(clone, 7)

			return clone, t1
		end

		replicatedStorage.Characters.Ghostface.Remotes.Double.OnClientEvent:Connect(function(p23, p24)
			if not p23 or not p24 or not p24:FindFirstChild("HumanoidRootPart") then
				return
			end

			local character, v80 = spawnCloneAt(p23, p24)

			if not character then
				return
			end

			local parent = character:FindFirstChild("FHumanoid") or character:FindFirstChildOfClass("Humanoid")
			local v82
			local v83

			if not parent then
				v82 = nil
				v83 = nil
			else
				local animator = parent:FindFirstChildOfClass("Animator")

				if not animator then
					animator = Instance.new("Animator")
					animator.Parent = parent
				end

				v82 = parent
				v83 = animator
			end

			if v82 and v83 then
				local v85 = animationService.LoadFresh(v83, double)

				for k, _ in pairs(v80) do
					if k and k.Parent then
						k.Transparency = 1
					end
				end

				local u88: boolean = false
				local u89: boolean = false

				animationService.ConnectMarker(v85, "Start", function()
					if u88 then
						return
					end

					u88 = true
					tweenToOriginal(v80, 0.1)

					local head = character:FindFirstChild("Head")
					local doubleSfx = head and head:FindFirstChild("DoubleSfx")

					if doubleSfx and doubleSfx:IsA("Sound") then
						doubleSfx:Play()
					end
				end)
				animationService.ConnectMarker(v85, "Swing", function()
					local v92 = character:FindFirstChild("UpperTorso") or character:FindFirstChild("Torso")
					local twoAt = v92 and v92:FindFirstChild("TwoAt")

					if twoAt then
						local slash1 = twoAt:FindFirstChild("Slash1")

						if slash1 and slash1:IsA("ParticleEmitter") then
							slash1:Emit(1)
						end

						local slash2 = twoAt:FindFirstChild("Slash2")

						if slash2 and slash2:IsA("ParticleEmitter") then
							slash2:Emit(1)
						end
					end

					local v96 = findMapFolder()
					local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

					if v96 and humanoidRootPart then
						local v98 = raycastDownToMap(v96, humanoidRootPart.Position, 6)

						if not v98 or not v98.Instance then
							return
						end

						local InstanceColor = v98.Instance.Color
						local oneSmokeAt = v92 and v92:FindFirstChild("OneSmokeAt")

						if oneSmokeAt then
							local rock = oneSmokeAt:FindFirstChild("Rock")
							local smoke = oneSmokeAt:FindFirstChild("Smoke")

							if rock and rock:IsA("ParticleEmitter") then
								rock.Color = ColorSequence.new(InstanceColor)
							end

							if smoke and smoke:IsA("ParticleEmitter") then
								smoke.Color = ColorSequence.new(InstanceColor)
							end

							if rock and rock:IsA("ParticleEmitter") then
								rock:Emit(30)
							end

							if smoke and smoke:IsA("ParticleEmitter") then
								smoke:Emit(10)
							end
						end

						return
					end
				end)
				animationService.ConnectMarker(v85, "End", function()
					if u89 then
						return
					end

					u89 = true
					tweenAllTo(v80, 1, 1)
				end)
				v85:Play()

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Ghostface.DoubleTrouble", result)
	end
end)

return true
