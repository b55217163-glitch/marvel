-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage

		game.ReplicatedStorage.Characters.Rambo.Remotes.WoundHeal.OnClientEvent:Connect(function(player)
			local Character = player.Character

			if not Character then
				return
			end

			if not Character:FindFirstChild("Bottle") then
				return
			end

			Character.Bottle.Transparency = 0
			Character.Bottle.Plop:Play()
			task.wait(0.15)
			Character.Bottle.Water:Play()
			Character.Bottle.Attachment.Water.Enabled = true
			Character.Bottle.Attachment.WaterE.Enabled = true
			task.wait(0.2)
			Character.Head.Ah:Play()
			task.wait(0.8)
			Character.Bottle.Attachment.Water.Enabled = false
			Character.Bottle.Attachment.WaterE.Enabled = false
			task.wait(0.45)
			Character.Bottle.Transparency = 1
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Rambo.WoundHeal", result)
	end
end)

return true
