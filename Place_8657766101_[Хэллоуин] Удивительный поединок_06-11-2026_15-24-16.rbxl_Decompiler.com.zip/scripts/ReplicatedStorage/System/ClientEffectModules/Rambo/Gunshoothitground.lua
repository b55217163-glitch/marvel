-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gunshoothitground = game.ReplicatedStorage.Characters.Rambo.Remotes.Gunshoothitground

		game:GetService("TweenService")

		local bullet = game.ReplicatedStorage.Characters.Rambo.Fx.Bullet
		local hitGround = game.ReplicatedStorage.Characters.Rambo.Fx.HitGround

		gunshoothitground.OnClientEvent:Connect(function(_, p2)
			local part: Part = Instance.new("Part")

			part.Transparency = 1
			part.Size = Vector3.new(0, 0, 0)
			part.Parent = workspace
			part.Position = p2.Position
			game.Debris:AddItem(part, 2)

			local InstanceColor = p2.Instance.Color
			local clone = hitGround:Clone()

			clone.PlaybackSpeed = math.random(1, 1.5)
			clone.Parent = part
			clone:Play()

			local clone2 = game.ReplicatedStorage.Characters.Combat.Smoke.SmokeParticle:Clone()

			clone2.Parent = part
			clone2.Color = ColorSequence.new(InstanceColor)
			clone2:Emit(20)

			local clone3 = game.ReplicatedStorage.Characters.Combat.Smoke.RockParticle:Clone()

			clone3.Parent = part
			clone3.Color = ColorSequence.new(InstanceColor)
			clone3:Emit(20)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Rambo.Gunshoothitground", result)
	end
end)

return true
