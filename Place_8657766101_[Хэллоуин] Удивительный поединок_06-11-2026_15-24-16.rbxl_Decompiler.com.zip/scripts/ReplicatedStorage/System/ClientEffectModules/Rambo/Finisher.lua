-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Rambo.Remotes.Finisher
		local v7 = game.ReplicatedStorage.Characters.Rambo.AnimationsExtra.Finisher
		local hit1 = game.ReplicatedStorage.Characters.Rambo.AnimationsExtra.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Rambo.AnimationsExtra.Hit2
		local hitKick1 = game.ReplicatedStorage.Characters.Rambo.AnimationsExtra.HitKick1
		local burnPart = game.ReplicatedStorage.Characters.Steve_H.Fx.BurnPart
		local spurtHit = game.ReplicatedStorage.Characters.Peacemaker.Fx.BloodUpperTorso.SpurtHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v28 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v30 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v30, 0)
				local n2 = v28 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v33 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v33 then
					local instance = v33.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v39 = mathRandom(-180, 180)
					local v40 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v39, v40, mathRandom(-180, 180))
					part.Position = p1.Position

					local v41 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v41, { Position = v33.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v99 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v99, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v100 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v100, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v46 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v48 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v50 = math.rad(randomNumber3)
						local v51 = cFrameAngles(v46, v48, v50)

						clone.CFrame = p1.CFrame * v51
						clone.Flame.Enabled = true
						clone.Sparks.Enabled = true
						clone.PointLight.Enabled = true
						clone.Glow.Enabled = true

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v59 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v61 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v61, 0)
				local n2 = v59 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v64 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v64 then
					local instance = v64.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v70 = mathRandom(-180, 180)
					local v71 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v70, v71, mathRandom(-180, 180))
					part.Position = p2.Position

					local v72 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v72, { Position = v64.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v105 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v105, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v106 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v106, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v77 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v79 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v79, 0)
				local n2 = v77 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v82 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v82 then
					local instance = v82.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v88 = mathRandom(-180, 180)
					local v89 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v88, v89, mathRandom(-180, 180))
					part.Position = p3.Position

					local v90 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v90, { Position = v82.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v111 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v111, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v112 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v112, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local explosionEffect = game.ReplicatedStorage.Characters.TheBatman.Fx.ExplosionEffect
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		finisher.OnClientEvent:Connect(function(player, p5)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)
			local v95 = p5:WaitForChild("Humanoid", 5)
			local v96 = animationService.LoadFresh(humanoid, v7)

			Character.Handle1.Transparency = 0
			Character.HandleMiddle.Transparency = 0
			Character.Handle1.Beam1.Enabled = true
			Character.Handle1.Beam2.Enabled = true
			v96.KeyframeReached:Connect(function(p6)
				if p6 == "Slash1" then
					Character.HumanoidRootPart.Music:Play()

					for _ = 1, 12 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber6 = math.random(-2, 2)
						local randomNumber7 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber6, randomNumber7, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					local clone2 = neckExplode:Clone()

					clone2.Parent = p5.Head
					clone2.Bl1:Emit(5)
					clone2.Bl2:Emit(15)
					animationService.GetTrack(v95, hit1):Play()
					Character.HumanoidRootPart.Hit1:Play()
				end
			end)
			v96.KeyframeReached:Connect(function(p7)
				if p7 == "Slash2" then
					for _ = 1, 10 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber8 = math.random(-2, 2)
						local randomNumber9 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					local clone3 = neckExplode:Clone()

					clone3.Parent = p5.Head
					clone3.Bl1:Emit(5)
					clone3.Bl2:Emit(15)
					animationService.GetTrack(v95, hit2):Play()
					Character.HumanoidRootPart.Hit2:Play()
				end
			end)
			v96.KeyframeReached:Connect(function(p8)
				if p8 == "Slash3" then
					for _ = 1, 15 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber10 = math.random(-2, 2)
						local randomNumber11 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					local clone4 = neckExplode:Clone()

					clone4.Parent = p5.Head
					clone4.Bl1:Emit(5)
					clone4.Bl2:Emit(15)
					animationService.GetTrack(v95, hit1):Play()
					Character.HumanoidRootPart.Hit1:Play()
				end
			end)
			v96.KeyframeReached:Connect(function(p9)
				if p9 == "Kick" then
					for _ = 1, 3 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber12 = math.random(-2, 2)
						local randomNumber13 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber12, randomNumber13, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					animationService.GetTrack(v95, hitKick1):Play()
					Character.HumanoidRootPart.Kick:Play()

					local clone5 = hitAt:Clone()

					clone5.Parent = p5.HumanoidRootPart
					clone5.Sparks:Emit(8)
					clone5.Shock:Emit(1)
				end
			end)
			v96.KeyframeReached:Connect(function(p10)
				if p10 == "Slash4" then
					for _ = 1, 15 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber14 = math.random(-2, 2)
						local randomNumber15 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber14, randomNumber15, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					animationService.GetTrack(v95, hit2):Play()
					Character.HumanoidRootPart.HitHeavy:Play()
					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber16 = math.random(15, 30)
						local clone6 = bloodDrip:Clone()

						clone6.Parent = workspace

						local bodyVelocity2: BodyVelocity = Instance.new("BodyVelocity", clone6)

						clone6.Parent = workspace.Effects
						clone6.CFrame = p5.UpperTorso.CFrame
						bodyVelocity2.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber17 = math.random(-2, 2)
						local randomNumber18 = math.random(-2, 2)

						bodyVelocity2.Velocity = Vector3.new(randomNumber17, randomNumber18, math.random(-2, 2)) * randomNumber16
						game.Debris:AddItem(clone6, 3)
						game.Debris:AddItem(bodyVelocity2, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber19 = math.random(15, 30)
						local clone7 = bloodDrip:Clone()

						clone7.Parent = workspace

						local bodyVelocity3: BodyVelocity = Instance.new("BodyVelocity", clone7)

						clone7.Parent = workspace.Effects
						clone7.CFrame = p5.UpperTorso.CFrame
						bodyVelocity3.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber20 = math.random(-2, 2)
						local randomNumber21 = math.random(-2, 2)

						bodyVelocity3.Velocity = Vector3.new(randomNumber20, randomNumber21, math.random(-2, 2)) * randomNumber19
						game.Debris:AddItem(clone7, 3)
						game.Debris:AddItem(bodyVelocity3, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber22 = math.random(15, 30)
						local clone8 = bloodDrip:Clone()

						clone8.Parent = workspace

						local bodyVelocity4: BodyVelocity = Instance.new("BodyVelocity", clone8)

						clone8.Parent = workspace.Effects
						clone8.CFrame = p5.UpperTorso.CFrame
						bodyVelocity4.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber23 = math.random(-2, 2)
						local randomNumber24 = math.random(-2, 2)

						bodyVelocity4.Velocity = Vector3.new(randomNumber23, randomNumber24, math.random(-2, 2)) * randomNumber22
						game.Debris:AddItem(clone8, 3)
						game.Debris:AddItem(bodyVelocity4, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber25 = math.random(15, 30)
						local clone9 = bloodDrip:Clone()

						clone9.Parent = workspace

						local bodyVelocity5: BodyVelocity = Instance.new("BodyVelocity", clone9)

						clone9.Parent = workspace.Effects
						clone9.CFrame = p5.UpperTorso.CFrame
						bodyVelocity5.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber26 = math.random(-2, 2)
						local randomNumber27 = math.random(-2, 2)

						bodyVelocity5.Velocity = Vector3.new(randomNumber26, randomNumber27, math.random(-2, 2)) * randomNumber25
						game.Debris:AddItem(clone9, 3)
						game.Debris:AddItem(bodyVelocity5, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber28 = math.random(15, 30)
						local clone10 = bloodDrip:Clone()

						clone10.Parent = workspace

						local bodyVelocity6: BodyVelocity = Instance.new("BodyVelocity", clone10)

						clone10.Parent = workspace.Effects
						clone10.CFrame = p5.UpperTorso.CFrame
						bodyVelocity6.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber29 = math.random(-2, 2)
						local randomNumber30 = math.random(-2, 2)

						bodyVelocity6.Velocity = Vector3.new(randomNumber29, randomNumber30, math.random(-2, 2)) * randomNumber28
						game.Debris:AddItem(clone10, 3)
						game.Debris:AddItem(bodyVelocity6, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber31 = math.random(15, 30)
						local clone11 = bloodDrip:Clone()

						clone11.Parent = workspace

						local bodyVelocity7: BodyVelocity = Instance.new("BodyVelocity", clone11)

						clone11.Parent = workspace.Effects
						clone11.CFrame = p5.UpperTorso.CFrame
						bodyVelocity7.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber32 = math.random(-2, 2)
						local randomNumber33 = math.random(-2, 2)

						bodyVelocity7.Velocity = Vector3.new(randomNumber32, randomNumber33, math.random(-2, 2)) * randomNumber31
						game.Debris:AddItem(clone11, 3)
						game.Debris:AddItem(bodyVelocity7, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber34 = math.random(15, 30)
						local clone12 = bloodDrip:Clone()

						clone12.Parent = workspace

						local bodyVelocity8: BodyVelocity = Instance.new("BodyVelocity", clone12)

						clone12.Parent = workspace.Effects
						clone12.CFrame = p5.UpperTorso.CFrame
						bodyVelocity8.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber35 = math.random(-2, 2)
						local randomNumber36 = math.random(-2, 2)

						bodyVelocity8.Velocity = Vector3.new(randomNumber35, randomNumber36, math.random(-2, 2)) * randomNumber34
						game.Debris:AddItem(clone12, 3)
						game.Debris:AddItem(bodyVelocity8, 0.05)
					end

					task.wait(0.1)

					for _ = 1, 5 do
						local randomNumber37 = math.random(15, 30)
						local clone13 = bloodDrip:Clone()

						clone13.Parent = workspace

						local bodyVelocity9: BodyVelocity = Instance.new("BodyVelocity", clone13)

						clone13.Parent = workspace.Effects
						clone13.CFrame = p5.UpperTorso.CFrame
						bodyVelocity9.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber38 = math.random(-2, 2)
						local randomNumber39 = math.random(-2, 2)

						bodyVelocity9.Velocity = Vector3.new(randomNumber38, randomNumber39, math.random(-2, 2)) * randomNumber37
						game.Debris:AddItem(clone13, 3)
						game.Debris:AddItem(bodyVelocity9, 0.05)
					end
				end
			end)
			v96.KeyframeReached:Connect(function(p11)
				if p11 == "ArrowSpawn" then
					Character.Arrow.Transparency = 0
					Character.HumanoidRootPart.BowPull:Play()
					Character.HumanoidRootPart.Nightmare:Play()
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
					Character.Arrow.Tick:Play()
					task.wait(0.2)
				end
			end)
			v96.KeyframeReached:Connect(function(p12)
				if p12 == "BowShoot" then
					Character.HumanoidRootPart.BowShoot:Play()
				end
			end)
			v96.KeyframeReached:Connect(function(p13)
				if p13 == "BowHit" then
					Character.FakeUpperTorso.BowHit:Play()

					for _ = 1, 20 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p5.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber40 = math.random(-2, 2)
						local randomNumber41 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber40, randomNumber41, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end

					task.wait(0.5)

					local clone14 = explosionEffect:Clone()

					clone14.Parent = workspace
					clone14.Position = Character.FakeUpperTorso.Position
					clone14.Sound:Play()
					clone14.Rocks:Emit(50)
					clone14.Smoke:Emit(50)
					clone14.Sparks:Emit(60)
					clone14.Attachment.Explo:Emit(30)
					game.Debris:AddItem(clone14, 3)
					TestRock(Character.FakeUpperTorso)
					TestRock2(Character.FakeUpperTorso)
					task.wait(0.1)

					for _ = 1, 20 do
						local randomNumber42 = math.random(15, 30)
						local clone15 = bloodDrip:Clone()

						clone15.Parent = workspace

						local bodyVelocity10: BodyVelocity = Instance.new("BodyVelocity", clone15)

						clone15.Parent = workspace.Effects
						clone15.CFrame = p5.UpperTorso.CFrame
						bodyVelocity10.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber43 = math.random(-2, 2)
						local randomNumber44 = math.random(-2, 2)

						bodyVelocity10.Velocity = Vector3.new(randomNumber43, randomNumber44, math.random(-2, 2)) * randomNumber42
						game.Debris:AddItem(clone15, 3)
						game.Debris:AddItem(bodyVelocity10, 0.15)
					end

					local descendants = p5:GetDescendants()

					for _, v in pairs(descendants) do
						if v:IsA("BasePart") or v:IsA("MeshPart") or v:IsA("UnionOperation") then
							game.TweenService:Create(v, TweenInfo.new(0.3), { Size = Vector3.new(0, 0, 0) }):Play()
						end
					end

					for _, v in pairs(descendants) do
						if v:IsA("SpecialMesh") then
							game.TweenService:Create(v, TweenInfo.new(0.3), { Scale = Vector3.new(0, 0, 0) }):Play()
						end
					end

					for _, v in pairs(descendants) do
						if v:IsA("Beam") or v:IsA("Trail") then
							v.Enabled = false
						end
					end
				end
			end)
			v96:Play()
			task.wait(6)
			Character.Arrow.Transparency = 1
			Character.Handle1.Transparency = 1
			Character.HandleMiddle.Transparency = 1
			Character.Handle1.Beam1.Enabled = false
			Character.Handle1.Beam2.Enabled = false
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Rambo.Finisher", result)
	end
end)

return true
