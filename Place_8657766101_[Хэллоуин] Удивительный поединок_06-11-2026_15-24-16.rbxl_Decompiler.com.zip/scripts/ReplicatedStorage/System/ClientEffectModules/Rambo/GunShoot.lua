-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local rapidShoot = game.ReplicatedStorage.Characters.Rambo.Remotes.RapidShoot
		local tweenService: TweenService = game:GetService("TweenService")
		local bullet = game.ReplicatedStorage.Characters.Rambo.Fx.Bullet
		local beamPart = game.ReplicatedStorage.Characters.Rambo.Fx.BeamPart
		local mainBeam = game.ReplicatedStorage.Characters.Rambo.Fx.BeamPart.Attachment.MainBeam
		local gunShotSfx = game.ReplicatedStorage.Characters.Rambo.Fx.GunShotSfx
		local v11 = game.ReplicatedStorage.Characters.OptimusPrime.Fx.BeamPart
		local v12 = game.ReplicatedStorage.Characters.OptimusPrime.Fx.BeamPart.Attachment.MainBeam
		local v13 = game.ReplicatedStorage.Characters.OptimusPrime.Fx.GunShotSfx
		local smoke = game.ReplicatedStorage.Characters.Vecna.Fx.Smoke
		local sparks = game.ReplicatedStorage.Characters.OptimusPrime.Fx.Sparks

		local function TestRock3(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v21 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v23 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v23, 0)
				local n2 = v21 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v26 = workspace:Raycast(n2, n2 - Vector3.new(0, 10, 0) - n2, raycastParams)

				n1 += 18

				if v26 then
					local instance = v26.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local randomNumber = math.random(-180, 180)
					local randomNumber2 = math.random(-180, 180)

					part.Orientation = Vector3.new(randomNumber, randomNumber2, math.random(-180, 180))
					part.Position = p1.Position

					local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, tweenInfo, { Position = v26.Position }):Play()
					part.Parent = workspace.Effects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local tweenInfo2 = TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, tweenInfo2, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local tweenInfo3 = TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, tweenInfo3, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		rapidShoot.OnClientEvent:Connect(function(player, p3)
			local Character = nil

			if typeof(player) == "Instance" and player:IsA("Model") then
				Character = player
			elseif typeof(player) == "Instance" and player:IsA("Player") then
				Character = player.Character
			end

			if not Character then
				return
			end

			if not Character:FindFirstChildOfClass("Humanoid") then
				return
			end

			if Character.Values:FindFirstChild("Optimus") then
				local clone = v13:Clone()

				clone.Parent = Character.HumanoidRootPart
				clone.PlaybackSpeed = math.random(1, 1.2)
				clone:Play()
				game.Debris:AddItem(clone, 1.5)

				local part: Part = Instance.new("Part")

				part.Size = Vector3.new(0, 0, 0)
				part.Parent = workspace
				part.Transparency = 1
				part.CanTouch = false
				part.CanCollide = false
				part.Anchored = true
				part.Position = Character.LeftHand.LeftWristRigAttachment.WorldPosition
				game.Debris:AddItem(part, 2)

				local clone2 = v11:Clone()

				clone2.Parent = Character
				game.Debris:AddItem(clone2, 2)

				local clone3 = v12:Clone()

				clone3.Parent = Character
				game.Debris:AddItem(clone3, 2)

				local part2: Part = Instance.new("Part")

				part2.Size = Vector3.new(0, 0, 0)
				part2.Parent = workspace
				part2.Transparency = 1
				part2.CanTouch = false
				part2.CanCollide = false
				part2.Anchored = true
				part2.Position = p3
				game.Debris:AddItem(part2, 2)
				clone3.Attachment0 = clone2.Attachment0
				clone3.Attachment1 = clone2.Attachment1
				clone2.Attachment0.Parent = part
				clone2.Attachment1.Parent = part2
				game.TweenService:Create(clone3, TweenInfo.new(0.2), { Width0 = 2 }):Play()
				game.TweenService:Create(clone3, TweenInfo.new(0.2), { Width1 = 2 }):Play()
				task.spawn(function()
					game.TweenService:Create(clone3, TweenInfo.new(0.1), { CurveSize0 = 0 }):Play()
					game.TweenService:Create(clone3, TweenInfo.new(0.1), { CurveSize1 = 0 }):Play()
					task.wait(0.2)
					game.TweenService:Create(clone3, TweenInfo.new(0.1), { Width0 = 0 }):Play()
					game.TweenService:Create(clone3, TweenInfo.new(0.1), { Width1 = 0 }):Play()
				end)

				local clone4 = sparks:Clone()

				clone4.Parent = part2
				clone4:Emit(10)

				local clone5 = smoke:Clone()

				clone5.Parent = Character
				clone5.CFrame = part2.CFrame
				clone5.Orientation = clone5.Orientation
				clone5.Position = clone5.Position
				game.Debris:AddItem(clone5, 3)
				TestRock3(part2)
			else
				local clone = gunShotSfx:Clone()

				clone.Parent = Character.HumanoidRootPart
				clone.PlaybackSpeed = math.random(1, 1.2)
				clone:Play()
				game.Debris:AddItem(clone, 1.5)

				local part: Part = Instance.new("Part")

				part.Size = Vector3.new(0, 0, 0)
				part.Parent = workspace
				part.Transparency = 1
				part.CanTouch = false
				part.CanCollide = false
				part.Anchored = true

				if Character:FindFirstChild("M60") and Character.M60:FindFirstChild("Bullet") then
					part.Position = Character.M60.Bullet.WorldPosition
				else
					local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

					part.Position = humanoidRootPart and humanoidRootPart.Position + humanoidRootPart.CFrame.LookVector * 4 + Vector3.new(0, 2, 0) or Vector3.new(0, 0, 0)
				end

				game.Debris:AddItem(part, 2)

				local clone6 = beamPart:Clone()

				clone6.Parent = Character
				game.Debris:AddItem(clone6, 2)

				local clone7 = mainBeam:Clone()

				clone7.Parent = Character
				game.Debris:AddItem(clone7, 2)

				local part3: Part = Instance.new("Part")

				part3.Size = Vector3.new(0, 0, 0)
				part3.Parent = workspace
				part3.Transparency = 1
				part3.CanTouch = false
				part3.CanCollide = false
				part3.Anchored = true
				part3.Position = p3
				game.Debris:AddItem(part3, 2)
				clone7.Attachment0 = clone6.Attachment0
				clone7.Attachment1 = clone6.Attachment1
				clone6.Attachment0.Parent = part
				clone6.Attachment1.Parent = part3
				game.TweenService:Create(clone7, TweenInfo.new(0.2), { Width0 = 4 }):Play()
				game.TweenService:Create(clone7, TweenInfo.new(0.2), { Width1 = 4 }):Play()
				task.spawn(function()
					game.TweenService:Create(clone7, TweenInfo.new(0.1), { CurveSize0 = 0 }):Play()
					game.TweenService:Create(clone7, TweenInfo.new(0.1), { CurveSize1 = 0 }):Play()
					task.wait(0.2)
					game.TweenService:Create(clone7, TweenInfo.new(0.1), { Width0 = 0 }):Play()
					game.TweenService:Create(clone7, TweenInfo.new(0.1), { Width1 = 0 }):Play()
				end)
			end

			for _ = 1, 1 do
				if not Character.Values:FindFirstChild("Optimus") then
					local clone = bullet:Clone()
					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

					clone.Parent = workspace.Effects

					if Character:FindFirstChild("M60") then
						clone.CFrame = Character.M60.CFrame
					else
						local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

						clone.CFrame = humanoidRootPart and humanoidRootPart.CFrame or CFrame.new()
					end

					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber3 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber3, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end
			end

			local clone = game.ReplicatedStorage.Characters.Combat.Smoke.SmokeParticle:Clone()

			if not Character.Values:FindFirstChild("Optimus") then
				if Character:FindFirstChild("M60") then
					clone.Parent = Character.M60
				else
					clone.Parent = Character:FindFirstChild("HumanoidRootPart") or Character
				end
			end

			clone:Emit(3)
			game.Debris:AddItem(clone, 3)

			if Character.Values:FindFirstChild("Optimus") then
				local clone8 = Character.M60.Light:Clone()

				clone8.Parent = Character.LeftHand
				clone8.Parent = Character.M60
				clone8.Enabled = true
				game.Debris:AddItem(clone8, 0.35)
				tweenService:Create(clone8, TweenInfo.new(0.3), { Brightness = 0 }):Play()
			end

			if Character.Values:FindFirstChild("Optimus") then
				return
			end

			if Character:FindFirstChild("M60") and Character.M60:FindFirstChild("FsAt") and Character.M60.FsAt:FindFirstChild("Flash") then
				Character.M60.FsAt.Flash:Emit(1)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Rambo.GunShoot", result)
	end
end)

return true
