-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local tnt = game.ReplicatedStorage.Characters.Steve.Remotes.TNT
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v18 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v20 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v20, 0)
				local n2 = v18 * cFrame * CFrame.new(0, 0, -20).Position + Vector3.new(0, 10, 0)
				local v23 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v23 then
					local instance = v23.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 10, 10)

					local v29 = mathRandom(-180, 180)
					local v30 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v29, v30, mathRandom(-180, 180))
					part.Position = p1.Position

					local v31 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v31, { Position = v23.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v101 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v101, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v102 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v102, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Size = Vector3.new(3, 3, 3)
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v36 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v38 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v40 = math.rad(randomNumber3)
						local v41 = cFrameAngles(v36, v38, v40)

						clone.CFrame = p1.CFrame * v41

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v49 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v51 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v51, 0)
				local n2 = v49 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v54 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v54 then
					local instance = v54.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(3, 2, 3)

					local v60 = mathRandom(-180, 180)
					local v61 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v60, v61, mathRandom(-180, 180))
					part.Position = p2.Position

					local v62 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v62, { Position = v54.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v107 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v107, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v108 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v108, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v67 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v69 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v69, 0)
				local n2 = v67 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v72 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v72 then
					local instance = v72.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v78 = mathRandom(-180, 180)
					local v79 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v78, v79, mathRandom(-180, 180))
					part.Position = p3.Position

					local v80 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v80, { Position = v72.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v113 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v113, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v114 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v114, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local v13 = game.ReplicatedStorage.Characters.Steve.Fx.TNT

		tnt.OnClientEvent:Connect(function(p4, cFrame)
			p4:WaitForChild("Humanoid", 5)

			local clone = v13:Clone()

			clone.Anchored = true
			clone.Parent = workspace
			clone.CFrame = cFrame
			game.Debris:AddItem(clone, 6)
			clone.SmokeStart.Enabled = true
			clone.DirtPlaceSfx:Play()
			clone.TNT_BOOM:Play()

			local descendants = clone:GetDescendants()

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 0.5 }):Play()
				end
			end

			game.TweenService:Create(clone, TweenInfo.new(0.25), { Size = Vector3.new(3.2, 3.2, 3.2) }):Play()
			task.wait(0.25)

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 0 }):Play()
				end
			end

			game.TweenService:Create(clone, TweenInfo.new(0.25), { Size = Vector3.new(3, 3, 3) }):Play()
			task.wait(0.25)

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 0.5 }):Play()
				end
			end

			game.TweenService:Create(clone, TweenInfo.new(0.25), { Size = Vector3.new(3.2, 3.2, 3.2) }):Play()
			task.wait(0.25)

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 0 }):Play()
				end
			end

			game.TweenService:Create(clone, TweenInfo.new(0.25), { Size = Vector3.new(3, 3, 3) }):Play()
			task.wait(0.25)

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 0.5 }):Play()
				end
			end

			game.TweenService:Create(clone, TweenInfo.new(0.4), { Size = Vector3.new(3.3, 3.3, 3.3) }):Play()
			task.wait(0.25)

			for _, v in pairs(descendants) do
				if v:IsA("Decal") then
					game.TweenService:Create(v, TweenInfo.new(0.25), { Transparency = 1 }):Play()
				end
			end

			task.wait(0.25)

			if clone:FindFirstChild("SmokeStart") then
				clone.SmokeStart.Enabled = false
				clone.ExplosionBoom:Emit(20)
				clone.ExplosionSmoke:Emit(40)
				TestRock(clone)
				TestRock2(clone)
				TestRock3(clone)

				for _, v in pairs(descendants) do
					if v:IsA("Decal") or v:IsA("Part") or v:IsA("Texture") then
						v.Transparency = 1
					end
				end

				clone.Transparency = 1
				clone.T1.Transparency = 1
				clone.T2.Transparency = 1
				clone.T3.Transparency = 1
				clone.T4.Transparency = 1
				clone.T5.Transparency = 1
				clone.T6.Transparency = 1
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve.Tnt", result)
	end
end)

return true
