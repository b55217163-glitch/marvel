-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local LocalPlayer = game.Players.LocalPlayer
		local ReplicatedStorage = game.ReplicatedStorage

		local function DashForward(parent, p2)
			local bodyPosition: BodyPosition = Instance.new("BodyPosition")

			bodyPosition.MaxForce = Vector3.new(1000000, 1000000, 1000000)
			bodyPosition.P = 10000
			bodyPosition.D = 3000
			bodyPosition.Position = (p2.CFrame * CFrame.new(0, 0, -900)).Position
			bodyPosition.Parent = parent
			game.Debris:AddItem(bodyPosition, 3)
		end

		local arrowProjectile = game.ReplicatedStorage.Characters.Steve.Fx.ArrowProjectile
		local hitboxPunch = game.ReplicatedStorage.Characters.Combat.Peacemaker.HitboxPunch
		local lightningHit = game.ReplicatedStorage.Characters.TheFlashCw.Remotes.LightningHit

		game.ReplicatedStorage.Characters.Steve.Remotes.BowShoot.OnClientEvent:Connect(function(p3, p4)
			local clone = arrowProjectile:Clone()

			clone.Parent = workspace.Effects
			game.Debris:AddItem(clone, 3)

			local clone2 = hitboxPunch:Clone()

			clone2.Parent = clone

			local weld: Weld = Instance.new("Weld", clone2)

			weld.Part0 = clone
			weld.Part1 = clone2

			local v17 = CFrame.Angles(0, 0, 0)

			weld.C0 = CFrame.new(0, 0, 0) * v17
			clone.CFrame = p3.HumanoidRootPart.CFrame * CFrame.new(0, 0, 1)
			clone.Orientation = clone.Orientation + Vector3.new(0, 90, 90)
			DashForward(clone, p3.HumanoidRootPart)
			task.spawn(function()
				task.wait(2.7)

				if clone:FindFirstChild("Hitbox") then
					clone.SparksCircle.Enabled = false
					clone.Anchored = true
					clone2:Destroy()
				end
			end)
			clone2.Touched:Connect(function(p5)
				if p5 and p5.Parent and not p5:IsDescendantOf(p3) then
					local v19 = p5.Parent
					local v20 = p5.Parent
					local humanoid = v19:FindFirstChild("Humanoid")

					if humanoid and humanoid.Health > 0 and not humanoid.Parent:FindFirstChild("Iframe") then
						local values = p3:FindFirstChild("Values")
						local values2 = v20:FindFirstChild("Values")
						local v24 = values

						if v24 then
							v24 = values:FindFirstChild("TeamColor")
						end

						local teamColor = values2 and values2:FindFirstChild("TeamColor")

						if v24 and teamColor then
							local v26 = v24.Value
							local teamColorValue = teamColor.Value
							local FFAColorValue = game.ReplicatedStorage.FFAColor.Value

							if (teamColorValue ~= v26 or teamColorValue == FFAColorValue and v26 == FFAColorValue) and v19 ~= p3 then
								clone2:Destroy()

								if LocalPlayer == p4 then
									lightningHit:FireServer(v19, p4, p3)
									clone.Transparency = 1
								end

								clone.SparksCircle.Enabled = false
							end

							return
						end

						return
					end

					return
				end
			end)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Steve.BowShot", result)
	end
end)

return true
