-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local disruptedDash = game.ReplicatedStorage.Characters.Pibby.Remotes.DisruptedDash

		game:GetService("TweenService")

		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		disruptedDash.OnClientEvent:Connect(function(_, p2)
			if p2 then
				for _, v in ipairs(p2:GetChildren()) do
					if v.Name == "Attachment" then
						local raycastParams = RaycastParams.new()

						raycastParams.FilterType = Enum.RaycastFilterType.Include
						raycastParams.FilterDescendantsInstances = { workspace.Map }

						local v10 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -6, raycastParams)

						if v10 ~= nil then
							local part: Part = Instance.new("Part")

							part.Position = v10.Position

							local randomNumber = math.random(-0.1, 0.1)
							local partCFrame: CFrame = part.CFrame
							local vector3 = Vector3.new(randomNumber, 0, 0)

							part.CFrame = partCFrame + vector3
							part.Parent = workspace
							part.Anchored = true
							part.Size = Vector3.new(0, 0, 0)
							part.CanCollide = false
							part.CanTouch = false
							game.Debris:AddItem(part, 3)

							local randomNumber2 = math.random(2, 2.5)
							local randomNumber3 = math.random(360)
							local v17 = math.rad(randomNumber3)
							local randomNumber4 = math.random(360)
							local v19 = math.rad(randomNumber4)
							local randomNumber5 = math.random(360)
							local v21 = math.rad(randomNumber5)
							local TweenService = game.TweenService
							local cFrame = CFrame.new(part.Position)
							local v24 = CFrame.Angles(v17, v19, v21)

							TweenService:Create(part, TweenInfo.new(0.25), { CFrame = cFrame * v24 }):Play()

							local TweenService2 = game.TweenService
							local vector32 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

							TweenService2:Create(part, TweenInfo.new(0.25), { Size = vector32 }):Play()
							part.Material = v10.Material
							part.Color = v10.Instance.Color

							local clone = smoke:Clone()

							clone.Parent = part

							local colorSequenceNew = ColorSequence.new
							local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

							clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
							clone:Emit(2)

							if math.random(1, 3) == 1 then
								for _ = 1, 1 do
									local explosionPart: Part = Instance.new("Part")

									explosionPart.Anchored = false
									explosionPart.Name = "ExplosionPart"
									explosionPart.Size = Vector3.new(0, 0, 0)
									explosionPart.Material = part.Material
									explosionPart.CanCollide = true
									explosionPart.CFrame = part.CFrame
									explosionPart.Color = v10.Instance.Color

									local TweenService3 = game.TweenService
									local randomNumber6 = math.random(1.5, 2.5)
									local randomNumber7 = math.random(1.5, 2.5)
									local vector33 = Vector3.new(randomNumber6, randomNumber7, math.random(1.5, 2.5))

									TweenService3:Create(explosionPart, TweenInfo.new(0.15), { Size = vector33 }):Play()

									local randomNumber8 = math.random(-80, 80)
									local randomNumber9 = math.random(0, 80)

									explosionPart.Velocity = Vector3.new(randomNumber8, randomNumber9, math.random(-80, 80))

									local cFrame2 = CFrame.new(part.Position)
									local v39 = CFrame.Angles(v17, v19, v21)

									explosionPart.CFrame = cFrame2 * v39
									explosionPart.Parent = workspace
									game.Debris:AddItem(explosionPart, 3)

									local part2: Part = Instance.new("Part")

									part2.Anchored = false
									part2.Name = "ExplosionPart"
									part2.Size = Vector3.new(0, 0, 0)
									part2.Material = part.Material
									part2.CanCollide = true
									part2.CFrame = part.CFrame
									part2.Color = v10.Instance.Color
									game.TweenService:Create(part2, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

									local randomNumber10 = math.random(-40, 40)
									local randomNumber11 = math.random(0, 40)

									part2.Velocity = Vector3.new(randomNumber10, randomNumber11, math.random(-40, 40))

									local cFrame3 = CFrame.new(part.Position)
									local v44 = CFrame.Angles(v17, v19, v21)

									part2.CFrame = cFrame3 * v44
									part2.Parent = workspace
									game.Debris:AddItem(part2, 3)
									task.delay(2, function()
										game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
										game.TweenService:Create(part2, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									end)
								end
							end

							local randomNumber12 = math.random(2, 2.3)

							task.delay(randomNumber12, function()
								local randomNumber13 = math.random(360)
								local v47 = math.rad(randomNumber13)
								local randomNumber14 = math.random(360)
								local v49 = math.rad(randomNumber14)
								local randomNumber15 = math.random(360)
								local v51 = math.rad(randomNumber15)
								local TweenService4 = game.TweenService
								local cFrame4 = CFrame.new(part.Position)
								local v54 = CFrame.Angles(v47, v49, v51)

								TweenService4:Create(part, TweenInfo.new(0.5), { CFrame = cFrame4 * v54 }):Play()
								game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								game.TweenService:Create(part, TweenInfo.new(0.5), { CFrame = part.CFrame + Vector3.new(0, -3, 0) }):Play()
							end)
						end
					end
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Pibby.MoveFour", result)
	end
end)

return true
