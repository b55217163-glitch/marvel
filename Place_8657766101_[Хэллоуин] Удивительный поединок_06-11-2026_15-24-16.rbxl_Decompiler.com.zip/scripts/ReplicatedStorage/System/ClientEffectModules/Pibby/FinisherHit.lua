-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Pibby.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Pibby.AnimationsExtra.FinisherHit
		local glitch = game.ReplicatedStorage.Characters.Pibby.Fx.Glitch
		local face = game.ReplicatedStorage.Characters.Pibby.Fx.Face
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local partGlitch = game.ReplicatedStorage.Characters.Pibby.Fx.PartGlitch

		game.ReplicatedStorage.Characters.Pibby.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local v15 = animationService.LoadFresh(Character.Humanoid, finisher)
			local v16 = animationService.LoadFresh(p2.Humanoid, finisherHit)

			v15.KeyframeReached:Connect(function(p3)
				if p3 == "Slam" then
					if Character.Head:FindFirstChild("FinisherLine") then
						Character.Head.FinisherLine:Play()
					end

					Character.HumanoidRootPart.Swing:Play()
					v16:Play()
					Character.HumanoidRootPart.Hit:Play()

					for _ = 1, 3 do
						local randomNumber = math.random(15, 30)
						local clone = bloodDrip:Clone()

						clone.Parent = workspace

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber2 = math.random(-2, 2)
						local randomNumber3 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end
			end)
			v16.KeyframeReached:Connect(function(p4)
				if p4 == "GlitchStart" then
					local clone = game.ReplicatedStorage.Characters.Pibby.Fx.Sound:Clone()

					clone.Parent = p2.HumanoidRootPart
					clone:Play()

					local clone2 = partGlitch:Clone()

					clone2.Parent = workspace
					clone2.CFrame = Character.FakeUpperTorso.CFrame * CFrame.new(0, -2.5, 0)
					game.Debris:AddItem(clone2, 10)
					game.TweenService:Create(clone2, TweenInfo.new(4), { Size = Vector3.new(16.442, 0.74, 16.443) }):Play()

					local v27 = glitch:GetChildren()

					for _, v in pairs(v27) do
						local clone3 = v:Clone()

						clone3.Parent = p2.LeftFoot

						local clone4 = v:Clone()

						clone4.Parent = p2.RightFoot
					end

					if p2.HumanoidRootPart:FindFirstChild("Confused") then
						task.spawn(function()
							local clone5 = p2.HumanoidRootPart.Confused:Clone()

							clone5.Parent = p2.Head

							local clone6 = game.ReplicatedStorage.Characters.Pibby.Fx.Echo:Clone()

							clone6.Parent = clone5

							local clone7 = game.ReplicatedStorage.Characters.Pibby.Fx.Filter:Clone()

							clone7.Parent = clone5

							local clone8 = game.ReplicatedStorage.Characters.Pibby.Fx.Pitch:Clone()

							clone8.Parent = clone5
							clone5:Play()
							task.wait(2)

							if p2.Head:FindFirstChild("LongScream") then
								p2.Head:FindFirstChild("LongScream"):Play()
								game.TweenService:Create(clone5, TweenInfo.new(0.4), { Volume = 0 }):Play()

								local clone9 = game.ReplicatedStorage.Characters.Pibby.Fx.Echo:Clone()

								clone9.Parent = p2.Head.LongScream

								local clone10 = game.ReplicatedStorage.Characters.Pibby.Fx.Filter:Clone()

								clone10.Parent = p2.Head.LongScream

								local clone11 = game.ReplicatedStorage.Characters.Pibby.Fx.Pitch:Clone()

								clone11.Parent = p2.Head.LongScream
							end
						end)
					elseif p2.Head:FindFirstChild("LongScream") then
						local clone12 = game.ReplicatedStorage.Characters.Pibby.Fx.Echo:Clone()

						clone12.Parent = p2.Head.LongScream

						local clone13 = game.ReplicatedStorage.Characters.Pibby.Fx.Filter:Clone()

						clone13.Parent = p2.Head.LongScream

						local clone14 = game.ReplicatedStorage.Characters.Pibby.Fx.Pitch:Clone()

						clone14.Parent = p2.Head.LongScream
						p2.Head.LongScream:Play()
					end

					if p2:FindFirstChild("LPupil") then
						p2.LPupil.TextureID = ""
						p2.RPupil.TextureID = ""
						p2.RightEye.TextureID = ""
						p2.LeftEye.TextureID = ""
					end

					if p2:FindFirstChild("FakeHead") then
						local v35 = p2.FakeHead:GetDescendants()

						for _, v in pairs(v35) do
							if v:IsA("Decal") then
								v.Transparency = 1
							end
						end

						v35 = p2.Head:GetDescendants()

						for _, v in pairs(v35) do
							if v:IsA("Decal") then
								v.Transparency = 1
							end
						end

						local clone15 = face:Clone()

						clone15.Parent = p2.FakeHead
					else
						local descendants = p2.Head:GetDescendants()

						for _, v in pairs(descendants) do
							if v:IsA("Decal") then
								v.Transparency = 1
							end
						end

						local clone16 = face:Clone()

						clone16.Parent = p2.Head
					end

					task.wait(0.4)

					for _, v in pairs(v27) do
						local clone17 = v:Clone()

						clone17.Parent = p2.LeftLowerLeg

						local clone18 = v:Clone()

						clone18.Parent = p2.RightLowerLeg
					end

					task.wait(0.3)

					for _, v in pairs(v27) do
						local clone19 = v:Clone()

						clone19.Parent = p2.RightUpperLeg

						local clone20 = v:Clone()

						clone20.Parent = p2.LeftUpperLeg
					end

					task.wait(0.3)

					for _, v in pairs(v27) do
						local clone21 = v:Clone()

						clone21.Parent = p2.LowerTorso

						local clone22 = v:Clone()

						clone22.Parent = p2.RightHand

						local clone23 = v:Clone()

						clone23.Parent = p2.LeftHand
					end

					for _, v in pairs(v27) do
						local clone24 = v:Clone()

						clone24.Parent = p2.RightLowerArm

						local clone25 = v:Clone()

						clone25.Parent = p2.LeftLowerArm
					end

					v27 = glitch:GetChildren()

					for _, v in pairs(v27) do
						local clone26 = v:Clone()

						clone26.Parent = p2.RightUpperArm

						local clone27 = v:Clone()

						clone27.Parent = p2.LeftUpperArm

						local clone28 = v:Clone()

						clone28.Parent = p2.UpperTorso
					end

					task.wait(5)
					game.TweenService:Create(clone2, TweenInfo.new(4), { Size = Vector3.new(0, 0, 0) }):Play()
				end
			end)
			v15:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Pibby.FinisherHit", result)
	end
end)

return true
