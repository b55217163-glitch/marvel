-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local contentProvider: ContentProvider = game:GetService("ContentProvider")
local collectionService: CollectionService = game:GetService("CollectionService")

local function preloadCharacterAssets(p1)
	local t2: {[any]: any} = {}

	for iterFirst, iterSecond in p1:GetDescendants() do
		if iterSecond:IsA("MeshPart") or iterSecond:IsA("SpecialMesh") or iterSecond:IsA("Decal") or iterSecond:IsA("Texture") or iterSecond:IsA("SurfaceAppearance") then
			table.insert(t2, iterSecond)
		end
	end

	if #t2 == 0 then
		return
	end

	pcall(function()
		contentProvider:PreloadAsync(t2)
	end)
end
local function stopAnimatorTracks(p2)
	local animator = p2:FindFirstChildOfClass("Animator")

	if not animator then
		return
	end

	local animationTracks = animator:GetPlayingAnimationTracks()

	for i = 1, #animationTracks do
		pcall(function()
			animationTracks[i]:Stop(0.08)
		end)
	end
end
local function softenClientControl(p3, p4)
	pcall(function()
		p4.AutoRotate = false
		p4.PlatformStand = true
		p4:ChangeState(Enum.HumanoidStateType.Physics)
		p4:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
	end)

	local humanoidRootPart = p3:FindFirstChild("HumanoidRootPart")

	if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
		humanoidRootPart.CanCollide = false
		humanoidRootPart.CanTouch = false
		humanoidRootPart.CanQuery = false
		humanoidRootPart.Transparency = 1
	end
end

local players: Players = game:GetService("Players")

local function preloadWhenSpawned(p5)
	task.defer(function()
		preloadCharacterAssets(p5)
	end)
end

for iterFirst, iterSecond in players:GetPlayers() do
	if iterSecond.Character then
		local Character = iterSecond.Character

		task.defer(function()
			preloadCharacterAssets(Character)
		end)
	end

	iterSecond.CharacterAdded:Connect(preloadWhenSpawned)
end

players.PlayerAdded:Connect(function(player: Player)
	player.CharacterAdded:Connect(preloadWhenSpawned)
end)

local module: {[any]: any} = {
	Play = function(character)
		if not character or not character:IsA("Model") then
			return
		end

		local humanoid = character:FindFirstChildOfClass("Humanoid")

		if not humanoid then
			return
		end

		if collectionService:HasTag(character, "__Client_RagdollDeathVisual_Active") then
			return
		end

		collectionService:AddTag(character, "__Client_RagdollDeathVisual_Active")
		stopAnimatorTracks(humanoid)
		softenClientControl(character, humanoid)
	end
}

replicatedStorage:WaitForChild("Remotes"):WaitForChild("RagdollDeathVisual").OnClientEvent:Connect(function(p8)
	module.Play(p8)
end)

return module
