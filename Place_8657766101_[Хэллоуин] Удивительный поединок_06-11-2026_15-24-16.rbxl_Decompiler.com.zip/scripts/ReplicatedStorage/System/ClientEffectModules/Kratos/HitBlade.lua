-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local hitEffectBlades = game.ReplicatedStorage.Characters.Combat.Remotes.HitEffectBlades
		local hitAt = game.ReplicatedStorage.Characters.Combat.Fx.CombatHit.HitAt
		local bladeHitSound = game.ReplicatedStorage.Characters.CombatFolder.Sounds.BladeHitSound
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2
		local descendants = game.Workspace:GetDescendants()

		for _, v in pairs(descendants) do
			if v:IsA("Humanoid") then
				animationService.GetTrack(v, hit1)
				animationService.GetTrack(v, hit2)
			end
		end

		local debris: Debris = game:GetService("Debris")

		hitEffectBlades.OnClientEvent:Connect(function(p1, _, _)
			local humanoidRootPart = p1:WaitForChild("HumanoidRootPart", 7)

			if not humanoidRootPart then
				return
			end

			local humanoid = p1:WaitForChild("Humanoid", 5)

			if not humanoid then
				return
			end

			local animator = humanoid:FindFirstChildOfClass("Animator")

			if not animator then
				return
			end

			local v21 = animationService.GetTrack(animator, hit1)
			local v22 = animationService.GetTrack(animator, hit2)
			local clone = hitAt:Clone()

			clone.Parent = humanoidRootPart
			clone.Sparks:Emit(2)
			clone.SparksCircle:Emit(2)
			clone.Shock:Emit(1)
			clone.ShockwaveMiddle:Emit(1)
			debris:AddItem(clone, 1)

			local randomNumber = math.random(1, 2)

			if randomNumber == 1 then
				v21:Play()
			elseif randomNumber == 2 then
				v22:Play()
			end

			local clone2 = bladeHitSound:Clone()

			clone2.Parent = humanoidRootPart
			clone2:Play()
			debris:AddItem(clone2, 2)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Kratos.HitBlade", result)
	end
end)

return true
