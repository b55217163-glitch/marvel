-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local boulderColors = game.ReplicatedStorage.Characters.Kratos.Remotes.BoulderColors
		local gameDebris = game.Debris
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v17 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v19 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v19, 0)
				local n2 = v17 * cFrame * CFrame.new(0, 0, -2.5).Position + Vector3.new(0, 10, 0)
				local v22 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v22 then
					local instance = v22.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local children = instance:GetChildren()

					for _, v in ipairs(children) do
						local clone = v:Clone()

						if clone and part then
							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color

					local randomNumber = math.random(1, 2)

					if randomNumber == 1 then
						part.Size = Vector3.new(2, 2, 2)
					elseif randomNumber == 2 then
						part.Size = Vector3.new(1.5, 1.5, 1.5)
					end

					local v30 = mathRandom(-180, 180)
					local v31 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v30, v31, mathRandom(-180, 180))
					part.Position = p1.Position

					local v32 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v32, { Position = v22.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 2)
					task.delay(1, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v38 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v38, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v39 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v39, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local block = game.ReplicatedStorage.Characters["A-Train"].Fx.block

		boulderColors.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local clone = block:Clone()

			clone.Parent = workspace
			clone.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -2.5)
			game.Debris:AddItem(clone, 4)
			TestRock(clone)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Kratos.RockGrab", result)
	end
end)

return true
