-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local finisher = game.ReplicatedStorage.Characters.Kratos.AnimationsExtra.Finisher
		local finisherHit = game.ReplicatedStorage.Characters.Kratos.AnimationsExtra.FinisherHit
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local neckExplode2 = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode2
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip

		game.ReplicatedStorage.Characters.Kratos.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			Character.Head.Time:Play()

			local clone = neckExplode:Clone()

			clone.Parent = p2.UpperTorso

			local v15 = animationService.LoadFresh(Character.Humanoid, finisher)
			local v16 = animationService.GetTrack(p2.Humanoid, finisherHit)

			v15.KeyframeReached:Connect(function(p3)
				if p3 == "ThrowBlade" then
					Character.Head.Throw1:Play()
				end
			end)
			v15.KeyframeReached:Connect(function(p4)
				if p4 == "HitBlade" then
					Character.Head.BladeStab:Play()
					clone.Bl1:Emit(5)
					clone.Bl2:Emit(10)

					for _ = 1, 10 do
						local randomNumber = math.random(15, 30)
						local clone2 = bloodDrip:Clone()

						clone2.Parent = Character
						clone2.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

						clone2.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber2 = math.random(-2, 2)
						local randomNumber3 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber2, randomNumber3, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone2, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end
			end)
			v15.KeyframeReached:Connect(function(p5)
				if p5 == "ChainSound" then
					Character.Head.Chain:Play()
				end
			end)
			v15.KeyframeReached:Connect(function(p6)
				if p6 == "Slide" then
					Character.Head.Slide:Play()
					Character.LowerTorso.LowHit.Smoke.Enabled = true
				end
			end)
			v15.KeyframeReached:Connect(function(p7)
				if p7 == "Tackle" then
					Character.Head.HitShort:Play()
				end
			end)
			v15.KeyframeReached:Connect(function(p8)
				if p8 == "SlideStop" then
					Character.LowerTorso.LowHit.Smoke.Enabled = false
				end
			end)
			v15.KeyframeReached:Connect(function(p9)
				if p9 == "Throw2" then
					Character.Head.Throw2:Play()
				end
			end)
			v15.KeyframeReached:Connect(function(p10)
				if p10 == "BladeHit2" then
					Character.Head.BladeStab2:Play()
					clone.Bl1:Emit(10)
					clone.Bl2:Emit(15)

					for _ = 1, 10 do
						local randomNumber = math.random(15, 30)
						local clone3 = bloodDrip:Clone()

						clone3.Parent = Character
						clone3.LocalScript.Disabled = false

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

						clone3.CFrame = p2.UpperTorso.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * randomNumber
						game.Debris:AddItem(clone3, 3)
						game.Debris:AddItem(bodyVelocity, 0.15)
					end
				end
			end)
			v15.KeyframeReached:Connect(function(p11)
				if p11 == "Land" then
					Character.Head.Land:Play()
					Character.Head.Land2:Play()
				end
			end)
			v16:Play()
			v15:Play()
			Character.Blade1.Transparency = 0
			Character.Blade2.Transparency = 0
			task.wait(2.5)
			Character.Blade1.Transparency = 1
			Character.Blade2.Transparency = 1
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Kratos.Finisher", result)
	end
end)

return true
