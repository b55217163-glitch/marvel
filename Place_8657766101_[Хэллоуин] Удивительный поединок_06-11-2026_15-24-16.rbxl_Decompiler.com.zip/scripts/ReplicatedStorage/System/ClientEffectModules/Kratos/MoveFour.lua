-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local spearRain = replicatedStorage.Characters.Kratos.Remotes.SpearRain
		local fx = replicatedStorage.Characters.Kratos.Fx
		local spear = fx:WaitForChild("Spear")
		local spearImpactPart = fx:WaitForChild("SpearImpactPart")
		local random = Random.new()

		local function removeConnections(p1)
			for iterFirst, iterSecond in p1:GetDescendants() do
				if iterSecond:IsA("Weld") or iterSecond:IsA("Motor6D") or iterSecond:IsA("WeldConstraint") or iterSecond:IsA("RigidConstraint") then
					iterSecond:Destroy()
				end
			end
		end
		local function prepareSpear(name)
			local clone = spear:Clone()

			clone.Name = name
			removeConnections(clone)
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Transparency = 0
			clone.Parent = workspace

			return clone
		end
		local function setFlightEffects(p3, enabled)
			local t1: {[any]: any} = { GlideTrail = true, Swirl = true, SparksSlow = true, Wind = true }

			for iterFirst, iterSecond in p3:GetDescendants() do
				if (iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail")) and t1[iterSecond.Name] then
					iterSecond.Enabled = enabled
				end
			end
		end
		local function emitImpact(p5)
			local clone = spearImpactPart:Clone()

			clone.Name = "SpearImpact"
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Transparency = 1
			clone.CFrame = CFrame.new(p5.Position)
			clone.Parent = workspace

			local oneHitAt = clone:FindFirstChild("OneHitAt")

			if oneHitAt then
				for iterFirst, iterSecond in oneHitAt:GetDescendants() do
					if iterSecond:IsA("ParticleEmitter") then
						local lowerText = string.lower(iterSecond.Name)

						if lowerText == "shock" or lowerText == "shockwavemiddle" then
							iterSecond:Emit(1)
						else
							iterSecond:Emit(8)
						end
					end
				end
			end

			local smokeSlide = clone:FindFirstChild("SmokeSlide")

			if smokeSlide and smokeSlide:IsA("ParticleEmitter") then
				smokeSlide.Color = ColorSequence.new(p5.Color)
				smokeSlide:Emit(10)
			end

			debris:AddItem(clone, 3)
		end
		local function createRocks(p6)
			for _ = 1, random:NextInteger(5, 8) do
				local spearDebris: Part = Instance.new("Part")
				local v38 = random:NextNumber(0.25, 0.65)

				spearDebris.Name = "SpearDebris"

				local v39 = random:NextNumber(0.18, 0.45)

				spearDebris.Size = Vector3.new(v38, v39, v38)
				spearDebris.Color = p6.Color
				spearDebris.Material = p6.Material
				spearDebris.Anchored = false
				spearDebris.CanCollide = false
				spearDebris.CanTouch = false
				spearDebris.CanQuery = false
				spearDebris.Massless = true

				local cFrame = CFrame.new(p6.Position + p6.Normal * 0.2)
				local cFrameAngles = CFrame.Angles
				local v42 = random:NextNumber(-3.141592653589793, 3.141592653589793)
				local v43 = random:NextNumber(-3.141592653589793, 3.141592653589793)

				v39 = cFrameAngles(v42, v43, random:NextNumber(-3.141592653589793, 3.141592653589793))
				spearDebris.CFrame = cFrame * v39
				spearDebris.Parent = workspace

				local v44 = random:NextNumber(-1, 1)
				local vector3 = Vector3.new(v44, 0, random:NextNumber(-1, 1))

				vector3 = if vector3.Magnitude < 0.05 then Vector3.new(1, 0, 0) else vector3.Unit
				v39 = random:NextNumber(7, 14)

				local normal = p6.Normal

				v43 = random:NextNumber(8, 15)
				spearDebris.AssemblyLinearVelocity = vector3 * v39 + normal * v43

				local v47 = random:NextNumber(-10, 10)

				v39 = random:NextNumber(-10, 10)
				spearDebris.AssemblyAngularVelocity = Vector3.new(v47, v39, random:NextNumber(-10, 10))
				task.delay(0.45, function()
					if spearDebris.Parent then
						tweenService:Create(spearDebris, TweenInfo.new(0.35), { Size = Vector3.new(0.05, 0.05, 0.05), Transparency = 1 }):Play()
					end
				end)
				debris:AddItem(spearDebris, 0.85)
			end
		end
		local function fadeSpear(p7)
			task.delay(2, function()
				if not p7.Parent then
					return
				end

				local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In)

				tweenService:Create(p7, tweenInfo, { Transparency = 1 }):Play()
				debris:AddItem(p7, 0.55)
			end)
		end
		local function createFallingSpear(p8)
			local clone = spear:Clone()

			clone.Name = "FallingSpear"
			removeConnections(clone)
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Transparency = 0
			clone.Parent = workspace

			local v51 = CFrame.Angles(0, 0, 3.141592653589793)

			clone.CFrame = CFrame.new(p8.SpawnPosition) * v51
			setFlightEffects(clone, true)

			local v52 = math.max(clone.Size.X, clone.Size.Y, clone.Size.Z)
			local v53 = p8.Position
			local vector3 = Vector3.new(0, v52 * 0.25, 0)
			local tweenInfo = TweenInfo.new(p8.FallTime, Enum.EasingStyle.Linear)
			local cFrame = CFrame.new(v53 - vector3)

			v52 = tweenService:Create(clone, tweenInfo, { CFrame = cFrame * v51 })
			v52:Play()
			v52.Completed:Once(function()
				if not clone.Parent then
					return
				end

				setFlightEffects(clone, false)

				local foundChild = clone:FindFirstChild("SpearHit", true)

				if foundChild and foundChild:IsA("Sound") then
					foundChild.PlaybackSpeed = random:NextNumber(0.85, 1.15)
					foundChild:Play()
				end

				emitImpact(p8)
				createRocks(p8)

				local v68 = clone

				task.delay(2, function()
					if not v68.Parent then
						return
					end

					local tweenInfo2 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In)

					tweenService:Create(v68, tweenInfo2, { Transparency = 1 }):Play()
					debris:AddItem(v68, 0.55)
				end)
			end)
			debris:AddItem(clone, p8.FallTime + 3)
		end

		spearRain.OnClientEvent:Connect(function(_, p10, p11)
			local clone = spear:Clone()

			clone.Name = "ThrownSpear"
			removeConnections(clone)
			clone.Anchored = true
			clone.CanCollide = false
			clone.CanTouch = false
			clone.CanQuery = false
			clone.Transparency = 0
			clone.Parent = workspace
			clone.CFrame = CFrame.new(p10)
			setFlightEffects(clone, true)

			local tweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Linear)
			local cFrame = CFrame.new(p10 + Vector3.new(0, 65, 0))
			local v63: Tween = tweenService:Create(clone, tweenInfo, { CFrame = cFrame })

			v63:Play()
			v63.Completed:Once(function()
				if clone.Parent then
					setFlightEffects(clone, false)
					clone:Destroy()
				end
			end)

			for iterFirst, iterSecond in p11 do
				task.delay(0.4 + iterSecond.Delay, function()
					createFallingSpear(iterSecond)
				end)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Kratos.SpearRain", result)
	end
end)

return true
