-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gameDebris = game.Debris

		game.ReplicatedStorage.Characters.Kratos.Remotes.ShieldCounter.OnClientEvent:Connect(function(p1)
			p1.Shield.Transparency = 0
			p1.Shield.Metal:Play()
			p1.Shield.Bass:Play()
			p1.Shield.HitAt.Shock:Emit(2)
			p1.Shield.HitAt.ShockwaveMiddle:Emit(1)
			p1.Shield.HitAt.Sparks:Emit(15)
			p1.Shield.HitAt.SparksCircle:Emit(15)
			game.TweenService:Create(p1.Shield, TweenInfo.new(0.3), { Size = Vector3.new(2.868, 3.375, 0.439) }):Play()
			task.wait(1)
			game.TweenService:Create(p1.Shield, TweenInfo.new(0.3), { Size = Vector3.new(0, 0, 0) }):Play()
			task.wait(0.3)
			p1.Shield.Transparency = 1
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Kratos.ShieldCounter", result)
	end
end)

return true
