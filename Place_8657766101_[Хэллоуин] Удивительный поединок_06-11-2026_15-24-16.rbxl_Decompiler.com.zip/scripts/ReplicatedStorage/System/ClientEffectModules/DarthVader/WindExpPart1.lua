-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local rockPart = game.ReplicatedStorage.Characters.DarthVader.Fx.RockPart

		game.ReplicatedStorage.Characters.DarthVader.Remotes.WindExplosion1.OnClientEvent:Connect(function(player)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			Character.HumanoidRootPart.Rumble:Play()
			humanoid.WalkSpeed = 0
			humanoid.JumpPower = 0

			local v10 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -6, raycastParams)

			if v10 == nil then
				task.wait(1)
				humanoid.WalkSpeed = 10
				humanoid.JumpPower = 30

				return
			end

			local InstanceColor = v10.Instance.Color
			local clone = rockPart:Clone()

			clone.Parent = workspace
			clone.Position = v10.Position
			clone.Rocks.Color = ColorSequence.new(InstanceColor)

			local randomNumber = math.random(-180, 180)

			clone.Orientation = Vector3.new(0, randomNumber, 0)
			game.Debris:AddItem(clone, 10)
			clone.Rocks.Enabled = true
			task.wait(1)
			clone.Rocks.Enabled = false
			humanoid.WalkSpeed = 10
			humanoid.JumpPower = 30
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DarthVader.WindExpPart1", result)
	end
end)

return true
