-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local players: Players = game:GetService("Players")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")

		game:GetService("TweenService")

		local debris: Debris = game:GetService("Debris")

		if not players.LocalPlayer then
			warn("This script should be a LocalScript, not a ServerScript.")

			return
		end

		local playerTorture = replicatedStorage.Characters.Vecna.AnimationsExtra.PlayerTorture
		local chokeHit = replicatedStorage.Characters.DarthVader.AnimationsExtra.ChokeHit
		local chokeSound = replicatedStorage.Characters.Wanda.Fx.ChokeSound
		local windChoke = replicatedStorage.Characters.Vecna.Fx.Windpart.WindChoke

		replicatedStorage.Characters.DarthVader.Remotes.QuickChoke.OnClientEvent:Connect(function(player, character, p3)
			local Character = player.Character

			if Character and character then
				print("yes")

				local humanoid = Character:FindFirstChildOfClass("Humanoid")
				local humanoid2 = character:FindFirstChildOfClass("Humanoid")

				if humanoid and humanoid2 then
					local animator = humanoid2:FindFirstChildOfClass("Animator")

					if humanoid and animator then
						local v18 = animationService.GetTrack(humanoid, playerTorture)
						local v19 = animationService.GetTrack(animator, chokeHit)

						if not v18.IsPlaying then
							v18:Play(0.2)
						end

						v19:Play()

						if not Character.LeftHand:FindFirstChild("WindPlayer") then
							local clone = windChoke:Clone()

							clone.Parent = Character.LeftHand
							debris:AddItem(clone, 5)
						end

						if not p3 then
							local clone = windChoke:Clone()

							clone.Parent = character.UpperTorso
							debris:AddItem(clone, 3)

							local forceWoosh = Character.HumanoidRootPart:FindFirstChild("ForceWoosh")

							if forceWoosh then
								forceWoosh.PlaybackSpeed = math.random(0.45, 0.55)
								forceWoosh.Parent = character.HumanoidRootPart
								forceWoosh:Play()
								debris:AddItem(forceWoosh, 3)
							end

							humanoid.WalkSpeed = 0
							humanoid.JumpPower = 0
							task.wait(1)

							if clone:FindFirstChild("Wv") then
								clone.Wv.Enabled = true
								clone.Wv2.Enabled = true
								clone.Wv3.Enabled = true
							end

							if Character.LeftHand:FindFirstChild("WindChoke") then
								Character.LeftHand.WindChoke.Wv.Enabled = false
								Character.LeftHand.WindChoke.Wv2.Enabled = false
								Character.LeftHand.WindChoke.Wv3.Enabled = false
							end

							clone.Wv.Enabled = false
							clone.Wv2.Enabled = false
							clone.Wv3.Enabled = false
							task.wait(1)
							humanoid.WalkSpeed = 10
							humanoid.JumpPower = 30
							clone:Destroy()

							return
						end

						local clone = Character.HumanoidRootPart:FindFirstChild("Wind"):Clone()

						if clone then
							clone.Parent = character.UpperTorso
							debris:AddItem(clone, 3)
							clone.Wv.Enabled = true
							clone.Wv2.Enabled = true
							task.wait(1)

							if Character.LeftHand:FindFirstChild("WindChoke") then
								Character.LeftHand.WindChoke.Wv.Enabled = false
								Character.LeftHand.WindChoke.Wv2.Enabled = false
								Character.LeftHand.WindChoke.Wv3.Enabled = false
							end

							clone.Wv.Enabled = false
							clone.Wv2.Enabled = false
							task.wait(0.5)
							clone:Destroy()
						end

						return
					end

					return
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DarthVader.ChokeHit", result)
	end
end)

return true
