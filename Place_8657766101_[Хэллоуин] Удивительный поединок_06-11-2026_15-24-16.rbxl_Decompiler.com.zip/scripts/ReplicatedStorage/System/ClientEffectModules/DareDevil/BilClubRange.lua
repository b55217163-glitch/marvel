-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage

		game.ReplicatedStorage.Characters.DareDevil.Remotes.BilClubRange.OnClientEvent:Connect(function(player)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)
			task.wait(0.3)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Dots:Emit(5)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.HookShootingOut:Emit(5)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Lines:Emit(7)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Smoke_Steam:Emit(3)

			local clone = script.GetBack:Clone()

			clone.Parent = Character.HumanoidRootPart
			clone:Play()
			game.Debris:AddItem(clone, 2)
			task.wait(0.2)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Dots:Emit(5)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.HookShootingOut:Emit(5)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Lines:Emit(7)
			Character.BillyClubLeft.HandleLeft.SparkAttachment.Smoke_Steam:Emit(3)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DareDevil.BilClubRange", result)
	end
end)

return true
