-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local grapple = game.ReplicatedStorage.Characters.DareDevil.Remotes.Grapple

		TweenInfo.new(0.8, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
		game:GetService("RunService")

		local tweenService: TweenService = game:GetService("TweenService")
		local gameDebris = game.Debris

		grapple.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character
			local humanoid = Character:WaitForChild("Humanoid", 5)

			if Character.Values:FindFirstChild("DareDevil") then
				local v13 = animationService.GetTrack(humanoid, script.GrappleAnimation)
				local characterPrimaryPart = Character.PrimaryPart
				local clone = script.Shoot:Clone()

				clone.Parent = Character.HumanoidRootPart
				clone:Play()
				game.Debris:AddItem(clone, 2)
				Character.BillyClubLeft.HandleLeft.SparkAttachment.Dots:Emit(15)
				Character.BillyClubLeft.HandleLeft.SparkAttachment.HookShootingOut:Emit(15)
				Character.BillyClubLeft.HandleLeft.SparkAttachment.Impact:Emit(2)
				Character.BillyClubLeft.HandleLeft.SparkAttachment.Lines:Emit(20)
				Character.BillyClubLeft.HandleLeft.SparkAttachment.Smoke_Steam:Emit(20)
				task.wait(0.2)

				local v16 = Character.BillClubRight:GetChildren()

				for _, v in ipairs(v16) do
					if v:IsA("BasePart") or v:IsA("MeshPart") then
						v.Transparency = 1
					end
				end

				v16 = Character.BillClubRight:GetDescendants()

				for _, v in pairs(v16) do
					if v:IsA("Texture") then
						v.Transparency = 1
					end
				end

				local shootPart: Part = Instance.new("Part")

				shootPart.Name = "ShootPart"
				shootPart.Transparency = 1
				shootPart.Parent = Character
				shootPart.Anchored = true
				shootPart.CanCollide = false
				game.Debris:AddItem(shootPart, 1.1)

				local attachment: Attachment = Instance.new("Attachment")

				attachment.Parent = shootPart

				local clone2 = script.Beam:Clone()

				clone2.Parent = shootPart

				local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

				shootPart.Position = Character.BillClubRight.HandleRight.Position
				clone2.Attachment0 = attachment
				clone2.Attachment1 = Character.BillyClubLeft.HandleLeft.SparkAttachment

				local cFrame = CFrame.new(p2)

				tweenService:Create(shootPart, tweenInfo, { CFrame = cFrame }):Play()
				Character.BillClubRight.String.Visible = false
				task.wait(0.3)

				local tweenInfo2 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

				tweenService:Create(clone2, tweenInfo2, { CurveSize0 = -20 }):Play()

				local clone3 = script.Zipline:Clone()

				clone3.Parent = Character.HumanoidRootPart
				clone3:Play()
				v13:Play()

				local clone4 = game.ReplicatedStorage.Characters.DareDevil.Fx.GrappleHitWall:Clone()

				clone4.Parent = Character
				clone4.Position = Character.ShootPart.Position
				clone4.Attachment.Dots:Emit(15)
				clone4.Attachment.HookShootingOut:Emit(15)
				clone4.Attachment.Impact:Emit(2)
				clone4.Attachment.Lines:Emit(20)
				clone4.Attachment.Smoke_Steam:Emit(20)
				game.Debris:AddItem(clone4, 5)

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(70000, 70000, 70000)
				bodyVelocity.Velocity = (p2 - Character.HumanoidRootPart.Position).Unit * 200
				bodyVelocity.Parent = Character.HumanoidRootPart
				task.wait(0.5)

				local tweenInfo3 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

				tweenService:Create(clone2, tweenInfo3, { CurveSize0 = 0 }):Play()
				tweenService:Create(shootPart, tweenInfo3, { CFrame = Character.HumanoidRootPart.CFrame }):Play()
				task.wait(0.3)
				bodyVelocity:Destroy()
				Character.BillClubRight.String.Visible = true

				local v31 = Character.BillClubRight:GetChildren()

				for _, v in ipairs(v31) do
					if v:IsA("BasePart") or v:IsA("MeshPart") then
						v.Transparency = 0
					end
				end

				v31 = Character.BillClubRight:GetDescendants()

				for _, v in pairs(v31) do
					if v:IsA("Texture") then
						v.Transparency = 0
					end
				end

				Character.BillyClubLeft.HandleLeft.SparkAttachment.Smoke_Steam:Emit(20)

				local clone5 = script.Clang:Clone()

				clone5.Parent = Character.HumanoidRootPart
				clone5:Play()
				game.Debris:AddItem(clone5, 3)
				clone3:Destroy()

				return
			end

			if Character.Values:FindFirstChild("TheBatman") then
				local v37 = animationService.GetTrack(humanoid, script.GrappleAnimation)
				local primaryPart = Character.PrimaryPart
				local clone = script.BatShoot:Clone()

				clone.Parent = Character.HumanoidRootPart
				clone.TimePosition = 0.2
				clone:Play()
				game.Debris:AddItem(clone, 2)
				Character.LeftHand.SparkAttachment.Dots:Emit(15)
				Character.LeftHand.SparkAttachment.HookShootingOut:Emit(15)
				Character.LeftHand.SparkAttachment.Impact:Emit(2)
				Character.LeftHand.SparkAttachment.Lines:Emit(20)
				Character.LeftHand.SparkAttachment.Smoke_Steam:Emit(20)
				task.wait(0.2)

				local part: Part = Instance.new("Part")

				part.Name = "ShootPart"
				part.Transparency = 1
				part.Parent = Character
				part.Anchored = true
				part.CanCollide = false
				game.Debris:AddItem(part, 1.1)

				local attachment: Attachment = Instance.new("Attachment")

				attachment.Parent = part

				local clone6 = script.BatBeam:Clone()

				clone6.Parent = part

				local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

				part.Position = Character.LeftHand.Position
				clone6.Attachment0 = attachment
				clone6.Attachment1 = Character.LeftHand.SparkAttachment

				local cFrame = CFrame.new(p2)

				tweenService:Create(part, tweenInfo, { CFrame = cFrame }):Play()
				task.wait(0.3)
				v37:Play()

				local clone7 = game.ReplicatedStorage.Characters.DareDevil.Fx.GrappleHitWall:Clone()

				clone7.Parent = Character
				clone7.Position = Character.ShootPart.Position
				clone7.Attachment.Dots:Emit(15)
				clone7.Attachment.HookShootingOut:Emit(15)
				clone7.Attachment.Impact:Emit(2)
				clone7.Attachment.Lines:Emit(20)
				clone7.Attachment.Smoke_Steam:Emit(20)
				game.Debris:AddItem(clone7, 5)

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(70000, 70000, 70000)
				bodyVelocity.Velocity = (p2 - Character.HumanoidRootPart.Position).Unit * 200
				bodyVelocity.Parent = Character.HumanoidRootPart
				clone6.Width0 = 2
				clone6.Width1 = 2
				tweenService:Create(clone6, tweenInfo, { TextureLength = 100 }):Play()
				task.wait(0.5)

				local tweenInfo4 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)

				tweenService:Create(clone6, tweenInfo4, { Width0 = 0 }):Play()
				tweenService:Create(clone6, tweenInfo4, { Width1 = 0 }):Play()
				task.wait(0.3)
				bodyVelocity:Destroy()
				Character.LeftHand.SparkAttachment.Smoke_Steam:Emit(20)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "DareDevil.Grapple", result)
	end
end)

return true
