-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local romanReveal = game.ReplicatedStorage.Characters.Ghostface.AnimationsExtra.RomanReveal
		local ethanReveal = game.ReplicatedStorage.Characters.Ghostface.AnimationsExtra.EthanReveal
		local amberReveal = game.ReplicatedStorage.Characters.Ghostface.AnimationsExtra.AmberReveal
		local billyReveal = game.ReplicatedStorage.Characters.Ghostface.AnimationsExtra.BillyReveal
		local stuReveal = game.ReplicatedStorage.Characters.Ghostface.AnimationsExtra.StuReveal
		local finished = game.ReplicatedStorage.Characters.Springbonnie.AnimationsExtra.Finished
		local revealAt = game.ReplicatedStorage.Characters.Billy.Fx.RevealAt

		game.ReplicatedStorage.Characters.Ghostface.Remotes.Reveal.OnClientEvent:Connect(function(p1)
			p1:WaitForChild("Humanoid", 5)

			local clone = revealAt:Clone()

			clone.Parent = p1.HumanoidRootPart

			if p1:FindFirstChild("BillyGhostface") then
				clone.Flare2:Emit(2)
			end

			game.Debris:AddItem(clone, 4)

			if not p1:FindFirstChild("EthanGhostface") and not p1:FindFirstChild("Tate") then
				if p1:FindFirstChild("RomanGhostface") then
					local v15 = animationService.LoadFresh(p1.Humanoid, romanReveal)

					animationService.ConnectMarker(v15, "Start", function(_)
						p1.Mask.Transparency = 0
						p1.GhostFakeHead.Transparency = 0
						p1.GhostFakeHead2.Transparency = 0
						p1.Hood.Transparency = 0
						p1.Head.Reveal:Play()
					end)
					animationService.ConnectMarker(v15, "End", function(_)
						p1.Mask.Transparency = 1
						p1.GhostFakeHead.Transparency = 1
						p1.GhostFakeHead2.Transparency = 1
						p1.Hood.Transparency = 1
					end)
					v15:Play()

					return
				end

				if not p1:FindFirstChild("JillGhostface") and not p1:FindFirstChild("AmberGhostface") then
					if p1:FindFirstChild("333") then
						local v16 = animationService.LoadFresh(p1.Humanoid, billyReveal)

						animationService.ConnectMarker(v16, "Start", function(_)
							p1.baby1.Transparency = 0
							p1.baby2.Transparency = 0
							p1.baby1.Decal.Transparency = 0
							p1.Head.Reveal:Play()
						end)
						animationService.ConnectMarker(v16, "End", function(_)
							p1.baby1.Transparency = 1
							p1.baby1.Decal.Transparency = 1
							p1.baby2.Transparency = 1

							if p1:FindFirstChild("m9") then
								p1.m9.Transparency = 1
							end
						end)
						v16:Play()

						return
					end

					if p1:FindFirstChild("StuGhostface") then
						local v17 = animationService.LoadFresh(p1.Humanoid, stuReveal)

						animationService.ConnectMarker(v17, "Start", function(_)
							p1.Head.Reveal:Play()
						end)
						animationService.ConnectMarker(v17, "FaceChange", function(_)
							game.TweenService:Create(p1.FakeHead.FaceConfused, TweenInfo.new(0.2), { Transparency = 0 }):Play()
							game.TweenService:Create(p1.FakeHead.FaceNormal, TweenInfo.new(0.3), { Transparency = 1 }):Play()
						end)
						animationService.ConnectMarker(v17, "End", function(_)
							game.TweenService:Create(p1.FakeHead.FaceConfused, TweenInfo.new(0.3), { Transparency = 1 }):Play()
							game.TweenService:Create(p1.FakeHead.FaceNormal, TweenInfo.new(0.2), { Transparency = 0 }):Play()
						end)
						v17:Play()

						return
					end

					if p1:FindFirstChild("SpringBonnie") then
						local v18 = animationService.LoadFresh(p1.Humanoid, finished)

						animationService.ConnectMarker(v18, "Start", function(_)
							p1.HumanoidRootPart.FinishedSfx:Play()
							p1.Knife.Transparency = 0
						end)
						animationService.ConnectMarker(v18, "Slash", function(_)
							p1.HumanoidRootPart.Figure.Particle:Emit(2)
							p1.HumanoidRootPart.Figure.Ring:Emit(2)
							p1.HumanoidRootPart.Figure.Ring2:Emit(2)
							wait(0.4)

							if not p1:FindFirstChild("YellowRabbit") then
								p1.Knife.Transparency = 1
							end
						end)
						v18:Play()

						return
					end

					if p1:FindFirstChild("BillyGhostface") then
						local v19 = animationService.LoadFresh(p1.Humanoid, billyReveal)

						animationService.ConnectMarker(v19, "Start", function(_)
							p1.Head.Reveal:Play()
						end)
						animationService.ConnectMarker(v19, "End", function(_)
						end)
						v19:Play()
					end

					return
				end

				local v20 = animationService.LoadFresh(p1.Humanoid, amberReveal)

				animationService.ConnectMarker(v20, "Start", function(_)
					p1.Mask.Transparency = 0
					p1.GhostFakeHead.Transparency = 0
					p1.GhostFakeHead2.Transparency = 0
					p1.Head.Reveal:Play()
				end)
				animationService.ConnectMarker(v20, "End", function(_)
					p1.Mask.Transparency = 1
					p1.GhostFakeHead.Transparency = 1
					p1.GhostFakeHead2.Transparency = 1
				end)
				v20:Play()

				return
			end

			local v21 = animationService.LoadFresh(p1.Humanoid, ethanReveal)

			animationService.ConnectMarker(v21, "Start", function(_)
				p1.Mask.Transparency = 0

				for _, v in ipairs(p1.Mask:GetDescendants()) do
					if v:IsA("Decal") then
						v.Transparency = 0
					end
				end

				for _, v in ipairs(p1.Hood:GetDescendants()) do
					if v:IsA("Decal") then
						v.Transparency = 0.7
					end
				end

				p1.GhostFakeHead.Transparency = 0
				p1.GhostFakeHead2.Transparency = 0

				if p1.FakeHead:FindFirstChild("RevealFace") then
					p1.FakeHead.RevealFace.Transparency = 0
					p1.FakeHead.NormalFace.Transparency = 1
				end

				p1.Hood.Transparency = 0
				p1.Head.Reveal:Play()
			end)
			animationService.ConnectMarker(v21, "End", function(_)
				p1.Mask.Transparency = 1
				p1.GhostFakeHead.Transparency = 1
				p1.GhostFakeHead2.Transparency = 1
				p1.Hood.Transparency = 1

				for _, v in ipairs(p1.Hood:GetDescendants()) do
					if v:IsA("Decal") then
						v.Transparency = 1
					end
				end

				for _, v in ipairs(p1.Mask:GetDescendants()) do
					if v:IsA("Decal") then
						v.Transparency = 1
					end
				end

				if p1.FakeHead:FindFirstChild("RevealFace") then
					p1.FakeHead.RevealFace.Transparency = 1
					p1.FakeHead.NormalFace.Transparency = 0
				end
			end)
			v21:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Billy.Reveal", result)
	end
end)

return true
