-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		require(game.ReplicatedStorage.System.AnimationService)

		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local bombs = replicatedStorage.Characters.Paul.Remotes.Bombs
		local basicCircle = replicatedStorage.Movement.Rocks.Fx.BasicCircle
		local groundBreakDecal = replicatedStorage.Movement.Rocks.Fx.GroundBreakDecal
		local smoke = replicatedStorage.Movement.Rocks.Fx.Smoke
		local shockwave = replicatedStorage.Characters.Combat.Fx.Shockwave
		local airstrikeBoom = replicatedStorage.Characters.Paul.Fx.AirstrikeBoom
		local slamModel = replicatedStorage.Characters.SlamModel
		local medBoom = replicatedStorage.Movement.Rocks.Sfx.MedBoom
		local effects: Instance = workspace:WaitForChild("Effects")
		local random = Random.new()

		local function createGroundParams()
			local map: Instance = workspace:WaitForChild("Map")
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { map }
			raycastParams.IgnoreWater = true

			return raycastParams
		end
		local function tween(p1, p2, p3)
			local v30: Tween = tweenService:Create(p1, p2, p3)

			v30:Play()

			return v30
		end
		local function emitIfExists(p4, p5, p6)
			local foundChild = p4:FindFirstChild(p5)

			if foundChild and foundChild:IsA("ParticleEmitter") then
				foundChild:Emit(p6)
			end
		end
		local function playExplosionAt(p7, p8)
			local clone = airstrikeBoom:Clone()

			clone.Parent = effects
			clone.Position = p7

			local v38 = random:NextInteger(-180, 180)

			clone.Orientation = Vector3.new(0, v38, 0)

			local sound = clone:FindFirstChild("Sound")

			if sound and sound:IsA("Sound") then
				sound.PlaybackSpeed = random:NextNumber(0.96, 1.08)
				sound:Play()
			end

			local attachment = clone:FindFirstChild("Attachment")

			if attachment then
				local rocks = attachment:FindFirstChild("Rocks")
				local smoke = attachment:FindFirstChild("Smoke")

				if p8 then
					if rocks and rocks:IsA("ParticleEmitter") then
						rocks.Color = ColorSequence.new(p8)
					end

					if smoke and smoke:IsA("ParticleEmitter") then
						smoke.Color = ColorSequence.new(p8)
					end
				end

				local explosion = attachment:FindFirstChild("Explosion")

				if explosion and explosion:IsA("ParticleEmitter") then
					explosion:Emit(35)
				end

				local finalWindTest = attachment:FindFirstChild("FinalWindTest")

				if finalWindTest and finalWindTest:IsA("ParticleEmitter") then
					finalWindTest:Emit(5)
				end

				local finalWindTest2 = attachment:FindFirstChild("FinalWindTest2")

				if finalWindTest2 and finalWindTest2:IsA("ParticleEmitter") then
					finalWindTest2:Emit(5)
				end

				local sparkShoot = attachment:FindFirstChild("SparkShoot")

				if sparkShoot and sparkShoot:IsA("ParticleEmitter") then
					sparkShoot:Emit(45)
				end

				local rocks2 = attachment:FindFirstChild("Rocks")

				if rocks2 and rocks2:IsA("ParticleEmitter") then
					rocks2:Emit(30)
				end

				local smoke2 = attachment:FindFirstChild("Smoke")

				if smoke2 and smoke2:IsA("ParticleEmitter") then
					smoke2:Emit(20)
				end
			end

			debris:AddItem(clone, 5)
		end
		local function createShockwave(p9)
			local clone = shockwave:Clone()

			clone.Parent = effects

			if not clone:IsA("Model") then
				if clone:IsA("BasePart") then
					clone.CFrame = CFrame.new(p9)
				end
			elseif clone.PrimaryPart then
				clone:PivotTo(CFrame.new(p9))
			else
				clone:PivotTo(CFrame.new(p9))
			end

			for _, v in ipairs(clone:GetDescendants()) do
				if v:IsA("BasePart") then
					v.Anchored = true
					v.CanCollide = false
					v.CanTouch = false
					v.CanQuery = false

					local vSize = v.Size

					v.Size = Vector3.new(1, v.Size.Y, 1)
					v.Transparency = 0.15

					local tweenInfo = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local vector3 = Vector3.new(43, vSize.Y, 43)

					tweenService:Create(v, tweenInfo, { Transparency = 1, Size = vector3 }):Play()
				elseif v:IsA("ParticleEmitter") then
					v:Emit(12)
				end
			end

			debris:AddItem(clone, 1)
		end
		local function createCraterDecal(p10, p11)
			local paulCraterMark: Part = Instance.new("Part")

			paulCraterMark.Name = "PaulCraterMark"
			paulCraterMark.Anchored = true
			paulCraterMark.CanCollide = false
			paulCraterMark.CanTouch = false
			paulCraterMark.CanQuery = false
			paulCraterMark.Transparency = 1
			paulCraterMark.Size = Vector3.new(1, 1, 1)
			paulCraterMark.Parent = effects

			local unit = p11.Unit
			local v60 = unit:Cross(Vector3.new(0, 0, 1))

			if v60.Magnitude < 0.01 then
				v60 = unit:Cross(Vector3.new(1, 0, 0))
			end

			local v61 = v60.Unit
			local v62 = v61:Cross(unit)
			local v63 = CFrame.fromMatrix(p10 + unit * 0.03, v61, unit, v62.Unit)
			local v64 = CFrame.Angles(1.5707963267948966, 0, random:NextNumber(0, 6.283185307179586))

			paulCraterMark.CFrame = v63 * v64

			local clone = groundBreakDecal:Clone()

			clone.Parent = paulCraterMark

			if clone:IsA("Decal") then
				clone.Transparency = 0.15
				task.delay(1.2, function()
					if clone.Parent then
						tweenService:Create(clone, TweenInfo.new(0.8), { Transparency = 1 }):Play()
					end
				end)
			end

			debris:AddItem(paulCraterMark, 2.2)
		end
		local function createFlyingChunk(p12, material, p14, p15, p16, p17, p18)
			local explosionPart: Part = Instance.new("Part")

			explosionPart.Name = "ExplosionPart"
			explosionPart.Material = material
			explosionPart.Color = p14
			explosionPart.Size = Vector3.new(0, 0, 0)
			explosionPart.Anchored = false
			explosionPart.CanCollide = false
			explosionPart.CanTouch = false
			explosionPart.CanQuery = false

			local cFrame = CFrame.new(p12)
			local cFrameAngles = CFrame.Angles
			local v76 = random:NextInteger(-180, 180)
			local v77 = math.rad(v76)
			local v78 = random:NextInteger(-180, 180)

			v76 = math.rad(v78)

			local v79 = random:NextInteger(-180, 180)

			v78 = math.rad(v79)

			local v80 = cFrameAngles(v77, v76, v78)

			explosionPart.CFrame = cFrame * v80
			explosionPart.Parent = effects

			local v81 = random:NextNumber(p15, p16)
			local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local vector3 = Vector3.new(v81, v81, v81)

			tweenService:Create(explosionPart, tweenInfo, { Size = vector3 }):Play()
			v80 = random:NextNumber(-p18, p18)
			v77 = random:NextNumber(p17, p18)
			explosionPart.AssemblyLinearVelocity = Vector3.new(v80, v77, random:NextNumber(-p18, p18))
			task.delay(1.7, function()
				if explosionPart.Parent then
					local tweenInfo2 = TweenInfo.new(0.5, Enum.EasingStyle.Linear)

					tweenService:Create(explosionPart, tweenInfo2, { Size = Vector3.new(0, 0, 0) }):Play()
				end
			end)
			debris:AddItem(explosionPart, 2.4)
		end
		local function spawnGroundBurst(p19)
			local v85 = createGroundParams()

			for i = 1, 18 do
				local n1: number = 6.283185307179586 * (i / 18)
				local v88 = random:NextNumber(3, 18)
				local cosine = math.cos(n1)
				local sine = math.sin(n1)
				local vector3 = Vector3.new(cosine * v88, 0, sine * v88)

				vector3 = workspace:Raycast(p19 + vector3 + Vector3.new(0, 8, 0), Vector3.new(0, -20, 0), v85)

				if vector3 and vector3.Instance and vector3.Instance:IsA("BasePart") then
					local vector3Position = vector3.Position
					local InstanceColor = vector3.Instance.Color
					local vector3Material = vector3.Material
					local groundChunk: Part = Instance.new("Part")

					groundChunk.Name = "GroundChunk"
					groundChunk.Anchored = true
					groundChunk.CanCollide = false
					groundChunk.CanTouch = false
					groundChunk.CanQuery = false
					groundChunk.Material = vector3Material
					groundChunk.Color = InstanceColor
					groundChunk.Size = Vector3.new(0, 0, 0)

					local cFrameNew = CFrame.new
					local v97 = random:NextNumber(-1, 1)
					local vector32 = Vector3.new(v97, 0, random:NextNumber(-1, 1))
					local cFrame = cFrameNew(vector3Position + vector32)
					local cFrameAngles = CFrame.Angles

					v97 = random:NextInteger(-180, 180)

					local v101 = math.rad(v97)
					local v102 = random:NextInteger(-180, 180)

					v97 = math.rad(v102)

					local v103 = random:NextInteger(-180, 180)

					v102 = math.rad(v103)

					local v104 = cFrameAngles(v101, v97, v102)

					groundChunk.CFrame = cFrame * v104
					groundChunk.Parent = effects

					local v105 = random:NextNumber(1.8, 3.3)
					local tweenInfo = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local vector33 = Vector3.new(v105, v105, v105)

					tweenService:Create(groundChunk, tweenInfo, { Size = vector33 }):Play()

					local clone = smoke:Clone()

					clone.Parent = groundChunk
					clone.Color = ColorSequence.new(groundChunk.Color)
					clone:Emit(random:NextInteger(2, 4))

					if random:NextNumber() <= 0.7 then
						createFlyingChunk(vector3Position, vector3Material, InstanceColor, 1.2, 2.4, 18, 70)
					end

					if random:NextNumber() <= 0.5 then
						createFlyingChunk(vector3Position, vector3Material, InstanceColor, 0.25, 0.6, 10, 40)
					end

					local groundChunkCFrame: CFrame = groundChunk.CFrame
					local n2 = v105 * 0.75
					local taskDelay = task.delay

					v101 = random:NextNumber(1.3, 2)
					taskDelay(v101, function()
						if groundChunk.Parent then
							local tweenInfo3 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
							local vector34 = Vector3.new(0, n2, 0)

							tweenService:Create(groundChunk, tweenInfo3, { CFrame = groundChunkCFrame - vector34 }):Play()

							local tweenInfo4 = TweenInfo.new(0.65, Enum.EasingStyle.Linear)

							tweenService:Create(groundChunk, tweenInfo4, { Size = Vector3.new(0, 0, 0) }):Play()
						end
					end)
					debris:AddItem(groundChunk, 2.4)
				end
			end
		end
		local function createRockRing(p20)
			local v113 = createGroundParams()

			for i = 1, 26 do
				local v115 = math.rad(i * 13.846153846153847)
				local v116 = random:NextNumber(5, 20)
				local cosine = math.cos(v115)
				local sine = math.sin(v115)
				local vector3 = Vector3.new(cosine * v116, 0, sine * v116)
				local v120 = workspace:Raycast(p20 + vector3 + Vector3.new(0, 10, 0), Vector3.new(0, -22, 0), v113)

				if v120 and v120.Instance and v120.Instance:IsA("BasePart") then
					local instance = v120.Instance
					local rockRise: Part = Instance.new("Part")

					rockRise.Name = "RockRise"
					rockRise.Anchored = true
					rockRise.CanCollide = false
					rockRise.CanTouch = false
					rockRise.CanQuery = false
					rockRise.Material = instance.Material
					rockRise.Color = instance.Color

					local v123 = random:NextNumber(1.8, 3.2)
					local v124 = random:NextNumber(1.8, 3.2)

					rockRise.Size = Vector3.new(v123, v124, random:NextNumber(1.8, 3.2))
					v123 = random:NextInteger(-180, 180)
					v124 = random:NextInteger(-180, 180)
					rockRise.Orientation = Vector3.new(v123, v124, random:NextInteger(-180, 180))

					local v125 = random:NextNumber(0.5, 2.2)
					local vector35 = Vector3.new(0, v125, 0)

					rockRise.Position = p20 + vector35

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture")) then
							local clone = v:Clone()

							clone.Parent = rockRise
						end
					end

					rockRise.Parent = effects

					local tweenInfo = TweenInfo.new(0.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					v125 = v120.Position

					local v131 = random:NextNumber(0.3, 1)
					local vector36 = Vector3.new(0, v131, 0)

					tweenService:Create(rockRise, tweenInfo, { Position = v125 + vector36 }):Play()
					task.delay(0.75, function()
						if not rockRise.Parent then
							return
						end

						local v150 = v120.Position
						local v151 = random:NextNumber(0.3, 1)
						local vector37 = Vector3.new(0, v151, 0)
						local n1 = v150 + vector37
						local n2 = rockRise.Size.Y * 0.75
						local tweenInfo5 = TweenInfo.new(0.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService:Create(rockRise, tweenInfo5, { Position = n1 }):Play()
						task.delay(0.75, function()
							if not rockRise.Parent then
								return
							end

							for _, v in ipairs(rockRise:GetChildren()) do
								if v:IsA("Texture") or v:IsA("Decal") then
									local tweenInfo6 = TweenInfo.new(0.35, Enum.EasingStyle.Linear)

									tweenService:Create(v, tweenInfo6, { Transparency = 1 }):Play()
								elseif v:IsA("ParticleEmitter") then
									v.Enabled = false
								end
							end

							local tweenInfo7 = TweenInfo.new(0.55, Enum.EasingStyle.Linear)
							local vector38 = Vector3.new(0, n2, 0)

							tweenService:Create(rockRise, tweenInfo7, { Size = Vector3.new(0, 0, 0), Position = n1 - vector38 }):Play()
						end)
					end)
					debris:AddItem(rockRise, 1.8)
				end
			end
		end

		bombs.OnClientEvent:Connect(function(_, p22)
			local paulMissileCenter: Part = Instance.new("Part")

			paulMissileCenter.Name = "PaulMissileCenter"
			paulMissileCenter.Anchored = true
			paulMissileCenter.CanCollide = false
			paulMissileCenter.CanTouch = false
			paulMissileCenter.CanQuery = false
			paulMissileCenter.Transparency = 1
			paulMissileCenter.Size = Vector3.new(1, 1, 1)
			paulMissileCenter.Position = p22
			paulMissileCenter.Parent = effects
			debris:AddItem(paulMissileCenter, 1)

			local v136 = createGroundParams()
			local v137 = workspace:Raycast(paulMissileCenter.Position + Vector3.new(0, 8, 0), Vector3.new(0, -20, 0), v136)

			v136 = paulMissileCenter.Position

			local vectorValue = Vector3.new(0, 1, 0)
			local v139 = nil

			if v137 then
				v136 = v137.Position
				vectorValue = v137.Normal

				if v137.Instance and v137.Instance:IsA("BasePart") then
					v139 = v137.Instance.Color
				end
			end

			playExplosionAt(v136, v139)
			createShockwave(v136)
			createCraterDecal(v136, vectorValue)
			createRockRing(v136)
			spawnGroundBurst(v136)

			local clone = basicCircle:Clone()

			clone.CFrame = CFrame.new(v136)
			clone.Parent = effects
			debris:AddItem(clone, 2)

			for _, v in ipairs(clone:GetChildren()) do
				if v:IsA("Attachment") and v.Name == "ShockEffect" then
					local ring = v:FindFirstChild("Ring")

					if ring and ring:IsA("ParticleEmitter") then
						ring:Emit(4)
					end

					local shock = v:FindFirstChild("Shock")

					if shock and shock:IsA("ParticleEmitter") then
						shock:Emit(4)
					end
				end
			end

			local clone2 = medBoom:Clone()

			clone2.Parent = clone
			clone2.PlaybackSpeed = random:NextNumber(0.96, 1.08)
			clone2:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Paul.AirStrikeExplosion", result)
	end
end)

return true
