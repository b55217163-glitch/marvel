-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local counter = game.ReplicatedStorage.Characters.Paul.AnimationsExtra.Counter
		local counterHit = game.ReplicatedStorage.Characters.Paul.AnimationsExtra.CounterHit
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode

		game.ReplicatedStorage.Characters.Paul.Remotes.Counter.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local v13 = animationService.LoadFresh(Character.Humanoid, counter)
			local v14 = animationService.GetTrack(p2.Humanoid, counterHit)
			local clone = neckExplode:Clone()

			clone.Parent = Character.FakeUpperTorso
			game.Debris:AddItem(clone, 5)
			animationService.ConnectMarker(v13, "Start", function(_)
				Character.Head.Backstab:Play()
			end)
			animationService.ConnectMarker(v13, "DustOn", function(_)
				local raycastParams = RaycastParams.new()

				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { workspace.Map }

				local v19 = workspace:Raycast(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.CFrame.UpVector * -3, raycastParams)

				if v19 == nil then
					return
				end

				Character.LowerTorso.SmokeAt.Smoke.Color = ColorSequence.new(v19.Instance.Color)
				Character.LowerTorso.SmokeAt.Smoke.Enabled = true
			end)
			animationService.ConnectMarker(v13, "DustOff", function(_)
				Character.LowerTorso.SmokeAt.Smoke.Enabled = false
			end)
			animationService.ConnectMarker(v13, "Stab", function(_)
				v14:Play()
				clone.Bl1:Emit(10)
				clone.Bl2:Emit(30)

				for _ = 1, 20 do
					local clone2 = bloodDrip:Clone()

					clone2.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

					clone2.Parent = workspace.Effects
					clone2.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber2 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone2, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end
			end)
			animationService.ConnectMarker(v13, "StabOut", function(_)
				clone.Bl1:Emit(10)
				clone.Bl2:Emit(30)

				for _ = 1, 40 do
					local clone3 = bloodDrip:Clone()

					clone3.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

					clone3.Parent = workspace.Effects
					clone3.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber3 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber3, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone3, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end
			end)
			v13:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Paul.Counter", result)
	end
end)

return true
