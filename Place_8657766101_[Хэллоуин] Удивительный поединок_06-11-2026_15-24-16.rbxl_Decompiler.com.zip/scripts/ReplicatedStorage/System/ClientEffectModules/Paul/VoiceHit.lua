-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local voiceAtHit = game.ReplicatedStorage.Characters.Paul.Fx.Voice.VoiceAtHit

		game.ReplicatedStorage.Characters.Paul.Remotes.VoiceHit.OnClientEvent:Connect(function(p1)
			local clone = voiceAtHit:Clone()

			clone.Parent = p1.Head
			clone.P1.Enabled = true
			clone.P2.Enabled = true
			task.wait(1)
			clone.P1.Enabled = false
			clone.P2.Enabled = false
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Paul.VoiceHit", result)
	end
end)

return true
