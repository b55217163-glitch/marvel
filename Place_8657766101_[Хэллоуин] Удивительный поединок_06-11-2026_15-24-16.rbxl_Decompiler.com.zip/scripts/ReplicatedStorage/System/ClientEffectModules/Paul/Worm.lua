-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		task.wait(0.1)

		local worm = game.ReplicatedStorage.Characters.Paul.Remotes.Worm

		game:GetService("TweenService")

		local smokeBig = game.ReplicatedStorage.Movement.Rocks.Fx.SmokeBig
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v22 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v24 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v24, 0)
				local n2 = v22 * cFrame * CFrame.new(0, 0, -35).Position + Vector3.new(0, 10, 0)
				local v27 = workspace:Raycast(n2, n2 - Vector3.new(0, 60, 0) - n2, raycastParams)

				n1 += 18

				if v27 then
					local instance = v27.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(20, 20, 20)

					local v33 = mathRandom(-180, 180)
					local v34 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v33, v34, mathRandom(-180, 180))
					part.Position = p1.Position

					local v35 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v35, { Position = v27.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 10)
					task.delay(8, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v153 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v153, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v154 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v154, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)

					for _ = 1, 1 do
						local clone = game.ReplicatedStorage.Characters.Physics.Rock:Clone()

						clone.Parent = workspace
						clone.Material = instance.Material
						clone.Color = instance.Color
						clone.Trail.Color = ColorSequence.new(instance.Color)

						local cFrameAngles = CFrame.Angles
						local randomNumber = math.random(0, 360)
						local v40 = math.rad(randomNumber)
						local randomNumber2 = math.random(0, 360)
						local v42 = math.rad(randomNumber2)
						local randomNumber3 = math.random(0, 360)
						local v44 = math.rad(randomNumber3)
						local v45 = cFrameAngles(v40, v42, v44)

						clone.CFrame = p1.CFrame * v45

						local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone)

						clone.Parent = workspace.Effects
						clone.CFrame = p1.CFrame
						bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

						local randomNumber4 = math.random(-2, 2)
						local randomNumber5 = math.random(-2, 2)

						bodyVelocity.Velocity = Vector3.new(randomNumber4, randomNumber5, math.random(-2, 2)) * 60
						game.Debris:AddItem(clone, 3)
						game.Debris:AddItem(bodyVelocity, 0.3)
					end
				end
			end
		end
		local function TestRock2(p2)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v53 = p2.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v55 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v55, 0)
				local n2 = v53 * cFrame * CFrame.new(0, 0, -10).Position + Vector3.new(0, 10, 0)
				local v58 = workspace:Raycast(n2, n2 - Vector3.new(0, 30, 0) - n2, raycastParams)

				n1 += 18

				if v58 then
					local instance = v58.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(10, 2, 8)

					local v64 = mathRandom(-180, 180)
					local v65 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v64, v65, mathRandom(-180, 180))
					part.Position = p2.Position

					local v66 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v66, { Position = v58.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 10)
					task.delay(8, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v159 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v159, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v160 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v160, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end
		local function TestRock3(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local v71 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v73 = math.rad(n1)
				local cFrame = cFrameFromEulerAnglesXYZ(0, v73, 0)
				local n2 = v71 * cFrame * CFrame.new(0, 0, -5).Position + Vector3.new(0, 10, 0)
				local v76 = workspace:Raycast(n2, n2 - Vector3.new(0, 20, 0) - n2, raycastParams)

				n1 += 18

				if v76 then
					local instance = v76.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Decal") or not not v:IsA("Texture") or not not v:IsA("DataModelMesh") or not not v:IsA("Attachment") or not not v:IsA("ParticleEmitter")) then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(5, 2, 5)

					local v82 = mathRandom(-180, 180)
					local v83 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v82, v83, mathRandom(-180, 180))
					part.Position = p3.Position

					local v84 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v84, { Position = v76.Position }):Play()
					part.Parent = workspaceEffects
					game.Debris:AddItem(part, 10)
					task.delay(8, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v165 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v165, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v166 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v166, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		local smoke = game.ReplicatedStorage.Characters.Vecna.Fx.Smoke
		local tweenService2: TweenService = game:GetService("TweenService")
		local v14 = TweenInfo.new
		local v15 = math.random

		local function Math(p4, p5, p6)
			return p4 + (p5 - p4) * p6
		end
		local function RockSpawn(p7, p8: number, p9, parent, p11, p12, p13)
			if p8 > 180 or p8 < 0 then
				warn("Too high or low of a number!")
				p8 = 15
			end

			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 360 / p8 do
				local v98 = p7.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v100 = math.rad(n1)
				local v101 = cFrameFromEulerAnglesXYZ(0, v100, 0)
				local cFrame = CFrame.new(0, 0, p11)
				local n2 = v98 * v101 * cFrame.Position
				local v104 = p7.CFrame
				local v105 = CFrame.fromEulerAnglesXYZ
				local v106 = math.rad(n1)
				local v107 = v105(0, v106, 0)
				local cFrame2 = CFrame.new(0, 0, -p11 / 1.25)
				local n3 = v104 * v107 * cFrame2.Position
				local vector3 = Vector3.new(0, -p11, 0)
				local v111 = workspace:Raycast(n2, n3 + vector3 - n2, raycastParams)

				n1 += p8

				if v111 then
					local instance = v111.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")
					local cFrame3 = CFrame.new(v111.Position, p7.Position)
					local cFrameAngles = CFrame.Angles
					local v116 = v15(-3.141592653589793, 3.141592653589793)
					local v117 = cFrameAngles(v116, 0, 0)
					local v118 = p7.Position
					local n4 = v118 + (v111.Position - v118) * 0.2
					local magnitude = (p7.Position - v111.Position).Magnitude

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.CFrame = CFrame.new(n4, p7.Position)
					game.Debris:AddItem(part, 14)

					for _, v in pairs(instance:GetChildren()) do
						if v:IsA("Decal") or v:IsA("Texture") then
							local clone = v:Clone()

							clone.Parent = part
						end
					end

					if p13 == true then
						local v124 = v15(p9.Min, p9.Max)
						local v125 = v15(p9.Min, p9.Max)

						part.Size = Vector3.new(v124, v125, v15(p9.Min, p9.Max))
					else
						part.Size = p9
					end

					if p12 == true then
						local v126 = v15(-180, 180)
						local v127 = v15(-180, 180)

						part.Orientation = Vector3.new(v126, v127, v15(-180, 180))

						local v128 = v14(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService2:Create(part, v128, { Position = v111.Position }):Play()
					elseif p12 == false then
						local v129 = v14(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local cFrame4 = CFrame.new(v111.Position, p7.Position)

						tweenService2:Create(part, v129, { CFrame = cFrame4 }):Play()
					elseif p12 == "Middle" then
						local v131 = v14(magnitude / 75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

						tweenService2:Create(part, v131, { CFrame = cFrame3 * v117 }):Play()
					end

					part.Parent = parent
					task.delay(10, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v171 = v14(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService2:Create(v, v171, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v172 = v14(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector32 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService2:Create(part, v172, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector32 }):Play()
						task.wait(1)
					end)
				end
			end
		end

		worm.OnClientEvent:Connect(function(_, p15)
			TestRock(p15)
			TestRock2(p15)
			TestRock3(p15)
			RockSpawn(p15, 120, NumberRange.new(0.5, 2), workspace.Effects, 15, false, true)

			for _, v in ipairs(p15:GetChildren()) do
				if v:IsA("Attachment") then
					local raycastParams = RaycastParams.new()

					raycastParams.FilterType = Enum.RaycastFilterType.Include
					raycastParams.FilterDescendantsInstances = { game.Workspace.Map }

					local v137 = workspace:Raycast(v.WorldPosition, v.CFrame.UpVector * -4, raycastParams)

					if v137 ~= nil then
						local material = v137.Material
						local instance = v137.Instance

						if math.random(1, 10) == 1 then
							for _ = 1, 10 do
								local explosionPart: Part = Instance.new("Part")

								explosionPart.Anchored = false
								explosionPart.Name = "ExplosionPart"
								explosionPart.Size = Vector3.new(0, 0, 0)
								explosionPart.Material = material
								explosionPart.CanCollide = true
								explosionPart.Color = v137.Instance.Color

								local TweenService = game.TweenService
								local randomNumber = math.random(1.5, 2.5)
								local randomNumber6 = math.random(1.5, 2.5)
								local vector3 = Vector3.new(randomNumber, randomNumber6, math.random(1.5, 2.5))

								TweenService:Create(explosionPart, TweenInfo.new(0.15), { Size = vector3 }):Play()

								local randomNumber7 = math.random(-80, 80)
								local randomNumber8 = math.random(0, 80)

								explosionPart.Velocity = Vector3.new(randomNumber7, randomNumber8, math.random(-80, 80))
								explosionPart.CFrame = CFrame.new(v.WorldPosition)
								explosionPart.Parent = workspace
								game.Debris:AddItem(explosionPart, 10)

								local part: Part = Instance.new("Part")

								part.Anchored = false
								part.Name = "ExplosionPart"
								part.Size = Vector3.new(0, 0, 0)
								part.Material = material
								part.CanCollide = true
								part.Position = v137.Position
								part.Color = v137.Instance.Color
								game.TweenService:Create(part, TweenInfo.new(0.15), { Size = Vector3.new(0.3, 0.3, 0.3) }):Play()

								local randomNumber9 = math.random(-40, 40)
								local randomNumber10 = math.random(0, 40)

								part.Velocity = Vector3.new(randomNumber9, randomNumber10, math.random(-40, 40))
								part.Parent = workspace
								game.Debris:AddItem(part, 10)
								task.delay(8, function()
									game.TweenService:Create(explosionPart, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
									game.TweenService:Create(part, TweenInfo.new(1), { Size = Vector3.new(0, 0, 0) }):Play()
								end)
							end
						end
					end
				end
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Paul.Worm", result)
	end
end)

return true
