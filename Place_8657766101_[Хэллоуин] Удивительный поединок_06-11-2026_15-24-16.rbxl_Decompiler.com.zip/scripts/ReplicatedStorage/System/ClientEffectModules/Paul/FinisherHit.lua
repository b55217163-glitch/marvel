-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local gameDebris = game.Debris
		local finisher = game.ReplicatedStorage.Characters.Paul.AnimationsExtra.Finisher
		local bloodDrip = game.ReplicatedStorage.Characters.Combat.Fx.BloodDrip
		local neckExplode = game.ReplicatedStorage.Characters.Patrick.Fx.Part.NeckExplode
		local hit1 = game.ReplicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = game.ReplicatedStorage.Characters.Combat.Animations.Hit2
		local neckStab = game.ReplicatedStorage.Characters.Paul.AnimationsExtra.NeckStab

		game.ReplicatedStorage.Characters.Paul.Remotes.Finisher.OnClientEvent:Connect(function(player, p2)
			local Character = player.Character

			Character:WaitForChild("Humanoid", 5)

			local v16 = animationService.LoadFresh(Character.Humanoid, finisher)
			local v17 = animationService.GetTrack(p2.Humanoid, hit1)
			local v18 = animationService.GetTrack(p2.Humanoid, hit2)
			local v19 = animationService.GetTrack(p2.Humanoid, neckStab)
			local clone = neckExplode:Clone()

			clone.Parent = Character.FakeUpperTorso
			animationService.ConnectMarker(v16, "Start", function(_)
				Character.Head.FinisherVc:Play()
			end)
			animationService.ConnectMarker(v16, "Slash", function(_)
				clone.Bl1:Emit(10)
				clone.Bl2:Emit(30)

				for _ = 1, 20 do
					local clone2 = bloodDrip:Clone()

					clone2.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone2)

					clone2.Parent = workspace.Effects
					clone2.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber2 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone2, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end

				Character.FakeUpperTorso.Chop.Flare:Emit(5)
				Character.FakeUpperTorso.Chop.Flare2:Emit(5)
				v17:Play()
			end)
			animationService.ConnectMarker(v16, "Slash2", function(_)
				clone.Bl1:Emit(10)
				clone.Bl2:Emit(30)

				for _ = 1, 20 do
					local clone3 = bloodDrip:Clone()

					clone3.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone3)

					clone3.Parent = workspace.Effects
					clone3.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber3 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber3, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone3, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end

				Character.FakeUpperTorso.Chop.Flare:Emit(5)
				Character.FakeUpperTorso.Chop.Flare2:Emit(5)
				v18:Play()
			end)
			animationService.ConnectMarker(v16, "NeckStab", function(_)
				clone.Bl1:Emit(5)
				clone.Bl2:Emit(10)

				for _ = 1, 10 do
					local clone4 = bloodDrip:Clone()

					clone4.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone4)

					clone4.Parent = workspace.Effects
					clone4.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber4 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber4, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone4, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end

				v19:Play()
			end)
			animationService.ConnectMarker(v16, "KnifeOut", function(_)
				clone.Bl1:Emit(20)
				clone.Bl2:Emit(30)

				for _ = 1, 40 do
					local clone5 = bloodDrip:Clone()

					clone5.Parent = workspace

					local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity", clone5)

					clone5.Parent = workspace.Effects
					clone5.CFrame = Character.FakeUpperTorso.CFrame
					bodyVelocity.MaxForce = Vector3.new(inf, inf, inf) * math.huge

					local randomNumber = math.random(-2, 2)
					local randomNumber5 = math.random(-2, 2)

					bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber5, math.random(-2, 2)) * 15
					game.Debris:AddItem(clone5, 3)
					game.Debris:AddItem(bodyVelocity, 0.05)
				end
			end)
			v16:Play()
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Paul.FinisherHit", result)
	end
end)

return true
