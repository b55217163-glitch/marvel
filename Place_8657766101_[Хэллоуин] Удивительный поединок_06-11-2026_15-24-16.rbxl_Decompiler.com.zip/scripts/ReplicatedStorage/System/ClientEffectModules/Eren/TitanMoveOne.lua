-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local titanStomp = game.ReplicatedStorage.Characters.Eren.Remotes.TitanStomp
		local tweenService: TweenService = game:GetService("TweenService")
		local workspaceEffects = workspace.Effects
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new
		local basicCircle = game.ReplicatedStorage.Movement.Rocks.Fx.BasicCircle

		local function RockPlace(p1, p2)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { p2 }

			if workspace:Raycast(p1.Position, p1.CFrame.UpVector * -90, raycastParams) == nil then
			end
		end
		local function TestRock(p3)
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			local function groundBase(p4, p5)
				local v69 = workspace:Raycast(p4 + Vector3.new(0, 50, 0), Vector3.new(0, -200, 0), raycastParams)

				if not v69 then
					return nil
				end

				local unit = v69.Normal.Unit
				local v71 = unit:Cross(Vector3.new(0, 1, 0))

				if v71.Magnitude < 0.001 then
					v71 = unit:Cross(Vector3.new(1, 0, 0))
				end

				local v72 = v71.Unit
				local v73 = unit:Cross(v72)
				local v74 = math.clamp(p5 * 0.2, 0.2, 1.2)

				return CFrame.fromMatrix(v69.Position + unit * (p5 * 0.5 - v74), v72, unit), v69, unit, v72, v73
			end

			for _ = 1, 30 do
				local randomNumber = math.random(10, 45)
				local randomNumber2 = math.random(3, 6)
				local vector3 = Vector3.new(randomNumber2, randomNumber2, randomNumber2)
				local v24 = p3.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v26 = math.rad(n1)
				local v27 = cFrameFromEulerAnglesXYZ(0, v26, 0)
				local cFrame = CFrame.new(0, 0, -randomNumber)

				n1 += 12

				local v29, v30, v31, v32, v33 = groundBase((v24 * v27 * cFrame).Position, vector3.Y)

				if v29 then
					local v34 = select(1, groundBase(p3.Position, vector3.Y)) or v29
					local randomNumber3 = math.random(-3, 3)
					local vector32 = Vector3.new(randomNumber3, 0, math.random(-3, 3))
					local n2 = v29 + vector32

					local function randomGroundedTilt()
						local randomNumber4 = math.random(-50, 50)
						local v76 = math.rad(randomNumber4)
						local randomNumber5 = math.random(-50, 50)
						local v78 = math.rad(randomNumber5)
						local randomNumber6 = math.random(-180, 180)
						local v80 = math.rad(randomNumber6)
						local v81 = CFrame.fromAxisAngle(v32, v76)
						local v82 = CFrame.fromAxisAngle(v33, v78)
						local v83 = CFrame.fromAxisAngle(v31, v80)

						return v81 * v82 * v83
					end

					local v39 = randomGroundedTilt()
					local v40 = randomGroundedTilt()

					randomGroundedTilt = v30 and v30.Instance

					if not randomGroundedTilt then
						warn("No hit instance from ray")
					else
						local stompRock: Part = Instance.new("Part")

						stompRock.Name = "StompRock"
						stompRock.Anchored = true
						stompRock.CanCollide = false
						stompRock.CanTouch = false
						stompRock.Material = randomGroundedTilt.Material
						stompRock.Color = randomGroundedTilt.Color
						stompRock.Size = vector3
						stompRock.CFrame = v34 * v39
						stompRock.Parent = workspaceEffects
						game.Debris:AddItem(stompRock, 4)

						for _, v in ipairs(randomGroundedTilt:GetChildren()) do
							if not v:IsA("SurfaceAppearance") then
								if v:IsA("Decal") or v:IsA("Texture") then
									local clone = v:Clone()

									clone.Parent = stompRock
								elseif v:IsA("Attachment") then
									local clone = v:Clone()

									clone.Parent = stompRock

									for _, iterValue in ipairs(v:GetChildren()) do
										if iterValue:IsA("ParticleEmitter") or iterValue:IsA("Trail") or iterValue:IsA("Beam") then
											local clone2 = iterValue:Clone()

											clone2.Parent = clone
										end
									end
								end
							end
						end

						stompRock.CanCollide = false
						stompRock.CanTouch = false
						stompRock.Material = randomGroundedTilt.Material
						stompRock.Color = randomGroundedTilt.Color
						stompRock.Size = vector3
						stompRock.CFrame = v34 * v39
						stompRock.Parent = workspaceEffects
						game.Debris:AddItem(stompRock, 4)

						local v49 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
						local v50: Tween = tweenService:Create(stompRock, v49, { CFrame = n2 * v40 })

						v50:Play()
						v50.Completed:Connect(function()
							local n1 = stompRock.CFrame + v31 * -0.05
							local v85 = tweenInfoNew(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

							tweenService:Create(stompRock, v85, { CFrame = n1 }):Play()
						end)

						for _ = 1, math.random(2, 4) do
							local part: Part = Instance.new("Part")

							part.Anchored = true
							part.CanCollide = false

							local randomNumber7 = math.random(1, 2)
							local randomNumber8 = math.random(1, 2)

							part.Size = Vector3.new(randomNumber7, randomNumber8, math.random(1, 2))
							part.Material = randomGroundedTilt.Material
							part.Color = randomGroundedTilt.Color
							part.Parent = workspaceEffects

							local n3 = n2 + v31 * 0.15

							part.CFrame = n3

							local randomNumber9 = math.random(0, 360)
							local v57 = math.rad(randomNumber9)
							local cosine = math.cos(v57)
							local sine = math.sin(v57)
							local vector33 = Vector3.new(cosine, 0, sine)
							local randomNumber10 = math.random(5, 9)
							local randomNumber11 = math.random()
							local n4 = n3.Position + vector33 * randomNumber10
							local v64 = tweenInfoNew(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

							tweenService:Create(part, v64, { Position = n4 + v31 * (0.6 + randomNumber11 * 0.4) }):Play()
							task.delay(0.18, function()
								local v86 = tweenInfoNew(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

								tweenService:Create(part, v86, { Position = n4 }):Play()
							end)
							v64 = tweenInfoNew(0.8)
							tweenService:Create(part, v64, { Transparency = 1, Size = Vector3.new() }):Play()
							game.Debris:AddItem(part, 1.2)
						end

						task.delay(2, function()
							for _ = 1, math.random(2, 3) do
								local clone: Instance = stompRock:Clone()

								clone.Size = stompRock.Size * 0.4

								local randomNumber12 = math.random(0, 360)
								local v90 = math.rad(randomNumber12)
								local cosine2 = math.cos(v90)
								local sine2 = math.sin(v90)
								local vector34 = Vector3.new(cosine2, 0, sine2)
								local randomNumber13 = math.random(1, 3)

								clone.CFrame = stompRock.CFrame + vector34 * randomNumber13
								clone.Parent = workspaceEffects

								local v95 = tweenInfoNew(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

								tweenService:Create(clone, v95, { Transparency = 1, Size = Vector3.new() }):Play()
								game.Debris:AddItem(clone, 0.7)
							end

							local v96 = tweenInfoNew(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

							tweenService:Create(stompRock, v96, { Transparency = 1, Size = Vector3.new() }):Play()
						end)
					end
				end
			end
		end

		titanStomp.OnClientEvent:Connect(function(player)
			local Character = player.Character

			TestRock(Character.FakeUpperTorso)
			RockPlace(Character.FakeUpperTorso, game.Workspace.Map)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Eren.TitanMoveOne", result)
	end
end)

return true
