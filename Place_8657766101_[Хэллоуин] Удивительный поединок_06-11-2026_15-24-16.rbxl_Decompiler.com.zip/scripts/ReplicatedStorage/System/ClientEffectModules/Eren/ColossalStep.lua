-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local runService: RunService = game:GetService("RunService")
		local LocalPlayer: Player = game:GetService("Players").LocalPlayer
		local CurrentCamera: Camera = workspace.CurrentCamera
		local rumblingStepFX = replicatedStorage.Characters.Eren.Remotes:WaitForChild("RumblingStepFX")
		local v10 = workspace:FindFirstChild("Effects") or workspace
		local groundhit = replicatedStorage.Characters.Eren.Fx:WaitForChild("Groundhit")
		local rocks = groundhit:WaitForChild("Rocks")
		local smoke = groundhit:WaitForChild("Smoke")
		local groundSfx = groundhit:WaitForChild("GroundSfx")
		local raycastParams = RaycastParams.new()

		raycastParams.FilterType = Enum.RaycastFilterType.Include
		raycastParams.IgnoreWater = true

		local t1: {[any]: any} = {}
		local connection = nil

		local function refreshMapFilter()
			local map: Instance = workspace:FindFirstChild("Map")

			t1[1] = map or workspace
			raycastParams.FilterDescendantsInstances = { t1[1] }

			if connection then
				connection:Disconnect()
				connection = nil
			end

			if map then
				connection = map.AncestryChanged:Connect(function(_: Instance, p2: Instance)
					if p2 == nil then
						refreshMapFilter()
					end
				end)
			end
		end

		refreshMapFilter()
		workspace.ChildAdded:Connect(function(child: Instance)
			if child.Name == "Map" then
				task.defer(refreshMapFilter)
			end
		end)
		workspace.ChildRemoved:Connect(function(child: Instance)
			if child.Name == "Map" then
				task.defer(refreshMapFilter)
			end
		end)

		local vector2 = Vector2.new(2, 4)
		local vector22 = Vector2.new(1, 2)
		local vector23 = Vector2.new(0, 0)
		local vector24 = Vector2.new(10, 45)
		local vector25 = Vector2.new(3, 10)

		local function Ti(p5, p6, p7)
			return TweenInfo.new(p5, p6 or Enum.EasingStyle.Quad, p7 or Enum.EasingDirection.Out)
		end

		local t2: {[any]: any} = {}

		t2.__index = t2

		function t2.new(p8)
			return (setmetatable({
				bin = {},
				props = p8 or {}
			}, t2))
		end
		function t2.acquire(p9)
			local v47 = table.remove(p9.bin)

			if not v47 then
				v47 = Instance.new("Part")
				v47.Anchored = true
				v47.CanCollide = false
				v47.CanTouch = false
				v47.CanQuery = false
				v47.Name = p9.props.name or "_RumblingRock"
				v47.CastShadow = true
				v47.Material = Enum.Material.Slate
				v47.Parent = v10
			end

			v47.Transparency = 0
			v47.Size = p9.props.defaultSize or Vector3.new(1, 1, 1)

			for _, v in ipairs(v47:GetChildren()) do
				if v:IsA("Texture") or v:IsA("Decal") then
					v:Destroy()
				end
			end

			v47:SetAttribute("RumblingExpiresAt", nil)

			return v47
		end
		function t2.release(p10, p11)
			if not p11 or not p11.Parent then
				return
			end

			p11:SetAttribute("RumblingExpiresAt", nil)
			table.insert(p10.bin, p11)
		end

		local v26 = t2.new({ name = "_RumblingRock" })
		local v27 = t2.new({ name = "_RumblingPebble", defaultSize = Vector3.new(1, 1, 1) })

		local function cleanupAllNow()
			for _, v in ipairs(v10:GetChildren()) do
				if v:IsA("BasePart") and (v.Name == "_RumblingRock" or v.Name == "_RumblingPebble" or v.Name:match("^_RumblingFoot_")) then
					v:Destroy()
				end
			end

			v26.bin = {}
			v27.bin = {}
		end
		local function basisFromRay(p12, p13)
			if not p12 then
				return
			end

			local unit = p12.Normal.Unit
			local v57 = unit:Cross(Vector3.new(0, 1, 0))

			if v57.Magnitude < 0.001 then
				v57 = unit:Cross(Vector3.new(1, 0, 0))
			end

			local v58 = v57.Unit
			local v59 = unit:Cross(v58)
			local v60 = math.clamp(p13 * 0.2, 0.2, 1.2)

			return CFrame.fromMatrix(p12.Position + unit * (p13 * 0.5 - v60), v58, unit), unit, v58, v59
		end
		local function randomTilt(p14, p15, p16)
			local randomNumber = math.random(-50, 50)
			local v65 = math.rad(randomNumber)
			local randomNumber2 = math.random(-50, 50)
			local v67 = math.rad(randomNumber2)
			local randomNumber3 = math.random(-180, 180)
			local v69 = math.rad(randomNumber3)
			local v70 = CFrame.fromAxisAngle(p15, v65)
			local v71 = CFrame.fromAxisAngle(p16, v67)
			local v72 = CFrame.fromAxisAngle(p14, v69)

			return v70 * v71 * v72
		end
		local function copySurfaceLook(p17, parent, p19)
			if p17 and p17:IsA("BasePart") then
				parent.Material = p17.Material
				parent.Color = p17.Color

				if p19 then
					pcall(function()
						parent.MaterialVariant = p17.MaterialVariant
					end)

					for _, v in ipairs(p17:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and (not not v:IsA("Texture") or not not v:IsA("Decal")) then
							local clone = v:Clone()

							clone.Parent = parent
						end
					end
				end
			end
		end
		local function fadeChildSurfaces(p20, p21)
			for _, v in ipairs(p20:GetChildren()) do
				if v:IsA("Texture") or v:IsA("Decal") then
					pcall(function()
						local tweenInfo = TweenInfo.new(p21, Enum.EasingStyle.Quad or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

						tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
					end)
				end
			end
		end
		local function attachAndBurstParticles(parent, p23, p24, p25)
			local clone = rocks:Clone()
			local clone2 = smoke:Clone()

			clone.Rate = 0
			clone2.Rate = 0
			clone.Color = ColorSequence.new(p23)
			clone2.Color = ColorSequence.new(p23)
			clone.Parent = parent
			clone2.Parent = parent
			clone:Emit(p24 or 10)
			clone2:Emit(p25 or 5)
			debris:AddItem(clone, 10)
			debris:AddItem(clone2, 10)
		end
		local function playFootSfx(p26, p27, _)
			local part: Part = Instance.new("Part")

			part.Name = "_RumblingFoot_" .. tostring(p27 or "Unknown")
			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Transparency = 1
			part.Size = Vector3.new(0.2, 0.2, 0.2)
			part.CFrame = CFrame.new(p26)
			part.Parent = v10

			local clone = groundSfx:Clone()

			clone.Parent = part
			clone.RollOffMode = Enum.RollOffMode.Linear
			pcall(function()
				clone.EmitterSize = 12
			end)
			pcall(function()
				if clone.RollOffMaxDistance ~= nil then
					clone.RollOffMaxDistance = 900
				end
			end)
			clone.PlaybackSpeed = math.random(100, 130) / 100
			clone.TimePosition = 0
			clone:Play()

			local u94: boolean = false

			local function nuke()
				if u94 then
					return
				end

				u94 = true

				if clone.IsPlaying then
					pcall(function()
						clone:Stop()
					end)
				end

				part:Destroy()
			end

			clone.Ended:Connect(nuke)
			task.delay(20, nuke)
		end
		local function makeAngles(p29)
			local v97 = table.create(p29)

			for i = 1, p29 do
				v97[i] = math.rad((i - 1) * (360 / p29))
			end

			return v97
		end

		local t3: {[any]: any} = {}

		runService.Heartbeat:Connect(function()
			local v99 = os.clock()

			for _, v in ipairs(v10:GetChildren()) do
				if v:IsA("BasePart") and (v.Name == "_RumblingRock" or v.Name == "_RumblingPebble") and typeof((v:GetAttribute("RumblingExpiresAt"))) == "number" and v99 >= v:GetAttribute("RumblingExpiresAt") then
					if v.Name == "_RumblingRock" then
						v26:release(v)
					else
						v27:release(v)
					end
				end
			end
		end)
		LocalPlayer.CharacterAdded:Connect(function(character: Model)
			local humanoid: Instance = character:FindFirstChildOfClass("Humanoid")

			if humanoid then
				humanoid.Died:Once(function()
					cleanupAllNow()
				end)
			end
		end)

		local humanoid = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid")

		if humanoid then
			humanoid.Died:Once(function()
				cleanupAllNow()
			end)
		end

		local function spawnRocksAt(p31, p32, p33, p34)
			local magnitude = ((CurrentCamera and CurrentCamera.CFrame.Position or p31) - p31).Magnitude
			local n1
			local v110

			if magnitude <= 120 then
				n1 = 30
				v110 = vector2
			elseif magnitude <= 250 then
				n1 = 18
				v110 = vector22
			else
				n1 = 10
				v110 = vector23
			end

			if p34 then
				playFootSfx(p34, p33 or "Unknown", p32)
			end

			local v111 = t3[n1]

			if not v111 then
				v111 = table.create(n1)

				for i = 1, n1 do
					v111[i] = math.rad((i - 1) * (360 / n1))
				end

				t3[n1] = v111
			end

			local n2: number = 0

			for i = 1, n1 do
				n2 += 1

				if n2 % 8 == 0 then
					task.wait()
				end

				local v115 = v111[i]
				local randomNumber = math.random(vector24.X, vector24.Y)
				local sine = math.sin(v115)
				local cosine = math.cos(v115)
				local vector3 = Vector3.new(sine * randomNumber, 0, cosine * randomNumber)
				local v120 = workspace:Raycast(p31 + vector3 + Vector3.new(0, 50, 0), Vector3.new(0, -80, 0), raycastParams)

				if v120 then
					local randomNumber4 = math.random(vector25.X, vector25.Y)
					local vector32 = Vector3.new(randomNumber4, randomNumber4, randomNumber4)
					local v123, v124, v125, v126 = basisFromRay(v120, vector32.Y)

					if not v123 then
						continue
					end

					local cFrameNew = CFrame.new
					local randomNumber5 = math.random(-2, 2)
					local vector33 = Vector3.new(randomNumber5, 1.5, math.random(-2, 2))
					local cFrame = cFrameNew(p31 + vector33)
					local v131 = randomTilt(v124, v125, v126)
					local v132 = randomTilt(v124, v125, v126)
					local instance = v120.Instance
					local v134 = v26:acquire()

					v134.Size = vector32
					v134.CFrame = cFrame * v131
					v134.Parent = v10

					if instance and instance:IsA("BasePart") then
						copySurfaceLook(instance, v134, magnitude <= 120)
					else
						v134.Material = v120.Material
						v134.Color = Color3.fromRGB(90, 90, 90)
					end

					v131 = if magnitude > 250 then 5 else 10
					attachAndBurstParticles(v134, v134.Color, v131, if magnitude > 250 then 3 else 5)

					local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Exponential or Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

					tweenService:Create(v134, tweenInfo, { CFrame = v123 * v132 }):Play()
					task.delay(0.5, function()
						if v134.Parent then
							pcall(function()
								local tweenInfo2 = TweenInfo.new(0.12, Enum.EasingStyle.Quad or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

								tweenService:Create(v134, tweenInfo2, { CFrame = v134.CFrame + v124 * -0.05 }):Play()
							end)
						end
					end)

					local v136 = os.clock()

					v134:SetAttribute("RumblingExpiresAt", v136 + p32)

					for _ = 1, math.random(v110.X, v110.Y) do
						local v138 = v27:acquire()
						local randomNumber6 = math.random(1, 2)
						local randomNumber7 = math.random(1, 2)

						v138.Size = Vector3.new(randomNumber6, randomNumber7, math.random(1, 2))
						v138.CFrame = v123 + v124 * 0.15

						if not instance or not instance:IsA("BasePart") then
							v138.Material = v134.Material
							v138.Color = v134.Color
						elseif instance and instance:IsA("BasePart") then
							v138.Material = instance.Material
							v138.Color = instance.Color
						end

						v138.Parent = v10

						local v141 = v138.Color
						local floored = math.floor(v131 * 0.25)
						local v143 = math.max(2, floored)

						attachAndBurstParticles(v138, v141, v143, 1)

						local randomNumber8 = math.random(0, 360)
						local v145 = math.rad(randomNumber8)
						local cosine2 = math.cos(v145)
						local sine2 = math.sin(v145)
						local vector34 = Vector3.new(cosine2, 0, sine2)
						local randomNumber9 = math.random(5, 9)
						local randomNumber10 = math.random()
						local n3 = v138.Position + vector34 * randomNumber9
						local tweenInfo3 = TweenInfo.new(0.18, Enum.EasingStyle.Quad or Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

						tweenService:Create(v138, tweenInfo3, { Position = n3 + v124 * (0.6 + randomNumber10 * 0.4) }):Play()
						task.delay(0.18, function()
							if v138.Parent then
								local tweenInfo4 = TweenInfo.new(0.18, Enum.EasingStyle.Quad or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

								tweenService:Create(v138, tweenInfo4, { Position = n3 }):Play()
							end
						end)

						local tweenInfo5 = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

						tweenService:Create(v138, tweenInfo5, { Transparency = 1, Size = Vector3.new() }):Play()

						local v154 = os.clock()

						v138:SetAttribute("RumblingExpiresAt", v154 + 0.8)
						task.delay(0.8, function()
							if v138.Parent then
								v138.Transparency = 1
								v138.Size = Vector3.new(1, 1, 1)
								v27:release(v138)
							end
						end)
					end

					local taskDelay = task.delay
					local v156 = math.max(p32 - 1, 0.5)

					taskDelay(v156, function()
						if not v134.Parent then
							return
						end

						fadeChildSurfaces(v134, 0.5)

						local tweenInfo6 = TweenInfo.new(0.5, Enum.EasingStyle.Quad or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

						tweenService:Create(v134, tweenInfo6, { Transparency = 0.7 }):Play()
					end)
					task.delay(p32, function()
						if v134.Parent then
							v134.Transparency = 1
							v26:release(v134)
						end
					end)
				end
			end
		end

		rumblingStepFX.OnClientEvent:Connect(function(p35, _, p37, p38, p39)
			local typeName: string = typeof(p37)

			spawnRocksAt(p35, typeName == "number" and p37 or 10, p38, p39)
		end)
		cleanupAllNow()
	end)

	if not ok then
		warn("[OldClientEffects2Module] failed:", "Eren.ColossalStep", result)
	end
end)

return true
