-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage

		game.ReplicatedStorage.Characters.Eren.Remotes.MoveE.OnClientEvent:Connect(function(player)
			local Character = player.Character
			local HumanoidRootPart = player.Character.HumanoidRootPart
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Eren.TitanDecoy", result)
	end
end)

return true
