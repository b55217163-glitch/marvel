-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local Players = game.Players
		local ReplicatedStorage = game.ReplicatedStorage
		local moveFourTitan = game.ReplicatedStorage.Characters.Eren.Remotes.MoveFourTitan
		local tweenService: TweenService = game:GetService("TweenService")
		local mathRandom = math.random
		local tweenInfoNew = TweenInfo.new

		local function TestRock(p1)
			local effects: Instance = workspace:WaitForChild("Effects")
			local n1: number = 0
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }
			raycastParams.IgnoreWater = true

			for _ = 1, 20 do
				local randomNumber = math.random(10, 45)
				local randomNumber2 = math.random(2, 4)
				local v17 = p1.CFrame
				local cFrameFromEulerAnglesXYZ = CFrame.fromEulerAnglesXYZ
				local v19 = math.rad(n1)
				local v20 = cFrameFromEulerAnglesXYZ(0, v19, 0)
				local cFrame = CFrame.new(0, 0, -randomNumber)
				local n2 = v17 * v20 * cFrame.Position + Vector3.new(0, 10, 0)
				local v23 = workspace:Raycast(n2, n2 - Vector3.new(0, 90, 0) - n2, raycastParams)

				n1 += 18

				if v23 then
					local instance = v23.Instance

					if not instance or not instance:IsA("BasePart") or not instance.Parent then
						continue
					end

					local part: Part = Instance.new("Part")

					for _, v in ipairs(instance:GetChildren()) do
						if not v:IsA("SurfaceAppearance") and v and v.Parent then
							local ok2, result2 = pcall(function()
								return v:Clone()
							end)

							if ok2 and result2 and not result2:IsA("SurfaceAppearance") then
								result2.Parent = part
							end
						end
					end

					part.Anchored = true
					part.CanCollide = false
					part.CanTouch = false
					part.Material = instance.Material
					part.Color = instance.Color
					part.Size = Vector3.new(randomNumber2, randomNumber2, randomNumber2)

					local v30 = mathRandom(-180, 180)
					local v31 = mathRandom(-180, 180)

					part.Orientation = Vector3.new(v30, v31, mathRandom(-180, 180))
					part.Position = p1.Position + Vector3.new(0, -30, 0)

					local v32 = tweenInfoNew(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)

					tweenService:Create(part, v32, { Position = v23.Position }):Play()
					part.Parent = effects
					game.Debris:AddItem(part, 2)
					task.delay(0.5, function()
						for _, v in pairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v38 = tweenInfoNew(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)

								tweenService:Create(v, v38, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local v39 = tweenInfoNew(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
						local partPosition: Vector3 = part.Position
						local vector3 = Vector3.new(0, part.Size.X / 2, 0)

						tweenService:Create(part, v39, { Size = Vector3.new(0, 0, 0), Position = partPosition - vector3 }):Play()
					end)
				end
			end
		end

		moveFourTitan.OnClientEvent:Connect(function(player)
			local v34 = player.Character or player.CharacterAdded:Wait()

			if not v34 then
				return
			end

			if not v34:WaitForChild("Humanoid", 5) then
				return
			end

			local humanoidRootPart = v34:WaitForChild("HumanoidRootPart", 5)

			if not humanoidRootPart then
				return
			end

			TestRock(humanoidRootPart)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Eren.TitanMoveFour", result)
	end
end)

return true
