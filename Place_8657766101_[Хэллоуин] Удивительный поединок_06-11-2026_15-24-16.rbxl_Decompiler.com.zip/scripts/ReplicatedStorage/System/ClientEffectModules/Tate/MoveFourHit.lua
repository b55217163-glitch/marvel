-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local animationService = require(game.ReplicatedStorage.System.AnimationService)
		local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local tate = replicatedStorage.Characters.Tate
		local fire = tate.Fx.Fire
		local fireSparks = tate.Fx.FireSparks
		local fireOne = tate.Fx.FireOne
		local oilHit = tate.Fx.Oil.OilHit
		local fireAt = tate.Fx.Oil.FireAt
		local fireworkHit = replicatedStorage.Characters.HitAnimations.Steve_H.FireworkHit
		local hit1 = replicatedStorage.Characters.Combat.Animations.Hit1
		local hit2 = replicatedStorage.Characters.Combat.Animations.Hit2
		local fourHit = tate.Fx.FourHit
		local t1: {[any]: any} = {
			20,
			10,
			8,
			5,
			4,
			3,
			4,
			3,
			4,
			3,
			4,
			5,
			4,
			3,
			4,
			3,
			4,
			3,
			4
		}

		local function playRandomHitAnims(p1)
			local v21 = animationService.GetTrack(p1, hit1)
			local v22 = animationService.GetTrack(p1, hit2)

			task.spawn(function()
				for _ = 1, 6 do
					task.wait(0.25)

					if math.random(1, 2) == 1 then
						v21:Play()
					else
						v22:Play()
					end
				end
			end)

			return v21, v22
		end
		local function spawnFireParts(parent, p3)
			for _ = 1, 2 do
				local clone = fireOne:Clone()

				clone.CFrame = p3.CFrame
				clone.Parent = parent

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

				local randomNumber = math.random(-2, 2)
				local randomNumber2 = math.random(-2, 2)

				bodyVelocity.Velocity = Vector3.new(randomNumber, randomNumber2, math.random(-2, 2)) * 19
				bodyVelocity.Parent = clone
				debris:AddItem(bodyVelocity, 0.15)
				debris:AddItem(clone, 6)
				task.delay(2, function()
					local v47 = clone and clone.Parent and clone:FindFirstChild("Fire")

					if v47 then
						v47.Enabled = false
					end
				end)
			end
		end

		tate.Remotes.BezineHit.OnClientEvent:Connect(function(p4, character)
			if p4 and character then
				local humanoid = character:FindFirstChildOfClass("Humanoid")
				local lowerTorso = character:FindFirstChild("LowerTorso")

				if humanoid and lowerTorso then
					animationService.GetTrack(humanoid, fireworkHit):Play()

					local clone = fourHit:Clone()

					clone.Parent = character.Head
					clone:Play()
					debris:AddItem(clone, 6)

					local clone2 = oilHit:Clone()

					clone2.Parent = lowerTorso
					debris:AddItem(clone2, 3)

					for i, v in ipairs(t1) do
						if clone2.Parent and clone2:FindFirstChild("Splash") then
							clone2.Splash:Emit(v)
						end

						if i == 1 then
							if clone2:FindFirstChild("Ring") then
								clone2.Ring:Emit(3)
							end

							if clone2:FindFirstChild("Ring2") then
								clone2.Ring2:Emit(3)
							end
						end

						task.wait(if i == 1 then 0.1 else 0.1)
					end

					local v38 = animationService.GetTrack(humanoid, hit1)
					local v39 = animationService.GetTrack(humanoid, hit2)

					task.spawn(function()
						for _ = 1, 6 do
							task.wait(0.25)

							if math.random(1, 2) == 1 then
								v38:Play()
							else
								v39:Play()
							end
						end
					end)

					local clone3 = fireAt:Clone()

					clone3.Parent = lowerTorso
					debris:AddItem(clone3, 5)

					local pointLight = clone3:FindFirstChild("PointLight")
					local surfaceLight = clone3:FindFirstChild("SurfaceLight")

					if pointLight then
						tweenService:Create(pointLight, TweenInfo.new(0.3), { Brightness = 3 }):Play()
					end

					if surfaceLight then
						tweenService:Create(surfaceLight, TweenInfo.new(0.3), { Brightness = 6 }):Play()
					end

					local clone4 = fire:Clone()

					clone4.Parent = lowerTorso
					clone4.Enabled = true
					debris:AddItem(clone4, 4)

					local clone5 = fireSparks:Clone()

					clone5.Parent = lowerTorso
					clone5.Enabled = true
					debris:AddItem(clone5, 4)

					for _ = 1, 7 do
						task.wait(0.2)
						spawnFireParts(p4, lowerTorso)
					end

					if clone4 then
						clone4.Enabled = false
					end

					if clone5 then
						clone5.Enabled = false
					end

					if pointLight then
						tweenService:Create(pointLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
					end

					if surfaceLight then
						tweenService:Create(surfaceLight, TweenInfo.new(0.3), { Brightness = 0 }):Play()
					end

					return
				end

				return
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Tate.MoveFourHit", result)
	end
end)

return true
