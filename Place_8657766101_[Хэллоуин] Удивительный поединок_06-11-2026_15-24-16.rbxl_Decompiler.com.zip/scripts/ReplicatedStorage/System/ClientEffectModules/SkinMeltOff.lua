-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local u1 = nil

local function __ApplyCentralDamage(p1, p2, p3, p4)
	local ok, result = pcall(game.GetService, game, "ServerScriptService")

	if not ok or not result then
		return nil
	end

	if not u1 then
		local combatModules = result:FindFirstChild("CombatModules")
		local damageService = combatModules and combatModules:FindFirstChild("DamageService")

		if not damageService then
			return nil
		end

		local ok2, result2 = pcall(require, damageService)

		if not ok2 then
			return nil
		end

		u1 = result2

		return u1.ApplyDamage(p1, p2, p3, p4)
	end

	return u1.ApplyDamage(p1, p2, p3, p4)
end

local debris: Debris = game:GetService("Debris")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local system: Instance = replicatedStorage:WaitForChild("System")
local animationService = require(system:WaitForChild("AnimationService"))
local v8 = script
local t1: {[any]: any} = {}
local remotes: Instance = replicatedStorage:FindFirstChild("Remotes")
local skinMeltOff: Instance = remotes and remotes:FindFirstChild("SkinMeltOff")

local function getCharacterFromPayload(player)
	if typeof(player) == "Instance" then
		if player:IsA("Model") then
			return player
		end

		if player:IsA("Player") then
			return player.Character
		end
	elseif typeof(player) == "table" then
		local v46 = player.Character or player.character or player.Target or player.target

		if typeof(v46) == "Instance" then
			if v46:IsA("Model") then
				return v46
			end

			if v46:IsA("Player") then
				return v46.Character
			end
		end
	end

	return nil
end
local function getModeFromPayload(p6)
	if typeof(p6) == "table" then
		local v48 = p6.Mode or p6.mode or p6.EffectMode or p6.effectMode

		if typeof(v48) == "string" then
			return v48
		end

		return nil
	end

	return nil
end
local function getDeathAnimation()
	local stormMeltAnimation = v8:FindFirstChild("StormMeltAnimation")

	if stormMeltAnimation and stormMeltAnimation:IsA("Animation") then
		stormMeltAnimation.AnimationId = "rbxassetid://100503354414306"

		return stormMeltAnimation
	end

	local stormMeltAnimation: Animation = Instance.new("Animation")

	stormMeltAnimation.Name = "StormMeltAnimation"
	stormMeltAnimation.AnimationId = "rbxassetid://100503354414306"
	stormMeltAnimation.Parent = v8

	return stormMeltAnimation
end
local function playDeathAnimation(_, parent)
	local stormMeltAnimation = v8:FindFirstChild("StormMeltAnimation")
	local v54

	if stormMeltAnimation and stormMeltAnimation:IsA("Animation") then
		stormMeltAnimation.AnimationId = "rbxassetid://100503354414306"
		v54 = stormMeltAnimation
	else
		local stormMeltAnimation: Animation = Instance.new("Animation")

		stormMeltAnimation.Name = "StormMeltAnimation"
		stormMeltAnimation.AnimationId = "rbxassetid://100503354414306"
		stormMeltAnimation.Parent = v8
		v54 = stormMeltAnimation
	end

	if not v54 then
		return nil
	end

	local v56 = nil

	local ok, result = pcall(function()
		return animationService.LoadFresh(parent, v54)
	end)

	if ok then
		v56 = result
	end

	if not v56 then
		local animator = parent:FindFirstChildOfClass("Animator")
		local animator2

		if animator then
			animator2 = animator
		else
			animator2 = Instance.new("Animator")
			animator2.Parent = parent
		end

		local ok3, result3 = pcall(function()
			return animator2:LoadAnimation(v54)
		end)

		if ok3 then
			v56 = result3
		end
	end

	if v56 then
		v56.Priority = Enum.AnimationPriority.Action4
		v56.Looped = false
		v56:Play(0.08)
	end

	return v56
end
local function getOrCreateEffectsFolder()
	local effects: Instance = workspace:FindFirstChild("Effects")

	if effects then
		return effects
	end

	local effects: Folder = Instance.new("Folder")

	effects.Name = "Effects"
	effects.Parent = workspace

	return effects
end
local function setParticleColor(p9, p10)
	p9.Color = ColorSequence.new(p10)
end
local function setSkeletonPartInitialState(p11)
	p11.Anchored = false
	p11.Massless = true
	p11.CanCollide = false
	p11.CanQuery = false
	p11.CanTouch = false
	p11.Transparency = 1
end

local t2: {[any]: any} = {
	Head = true,
	UpperTorso = true,
	LowerTorso = true,
	Torso = true,
	LeftUpperArm = true,
	LeftLowerArm = true,
	LeftHand = true,
	RightUpperArm = true,
	RightLowerArm = true,
	RightHand = true,
	LeftUpperLeg = true,
	LeftLowerLeg = true,
	LeftFoot = true,
	RightUpperLeg = true,
	RightLowerLeg = true,
	RightFoot = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true
}

local function cloneAndMotorSkeleton(p12)
	local skinMeltSkeleton = v8:FindFirstChild("SkinMeltSkeleton")

	if not skinMeltSkeleton or not skinMeltSkeleton:IsA("Model") then
		skinMeltSkeleton = replicatedStorage:FindFirstChild("Characters") and replicatedStorage.Characters:FindFirstChild("A-Train") and replicatedStorage.Characters["A-Train"]:FindFirstChild("Fx") and replicatedStorage.Characters["A-Train"].Fx:FindFirstChild("Skeleton")
	end

	if not skinMeltSkeleton or not skinMeltSkeleton:IsA("Model") then
		return nil
	end

	local clone = skinMeltSkeleton:Clone()

	clone.Name = p12.Name .. "_StormSkinMeltSkeleton"
	clone:PivotTo(p12:GetPivot())

	local effects: Instance = workspace:FindFirstChild("Effects")
	local v72

	if effects then
		v72 = effects
	else
		local effects: Folder = Instance.new("Folder")

		effects.Name = "Effects"
		effects.Parent = workspace
		v72 = effects
	end

	clone.Parent = v72

	for iterFirst, iterSecond in clone:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			iterSecond.Anchored = false
			iterSecond.Massless = true
			iterSecond.CanCollide = false
			iterSecond.CanQuery = false
			iterSecond.CanTouch = false
			iterSecond.Transparency = 1

			local foundChild = p12:FindFirstChild(iterSecond.Name)

			if foundChild and foundChild:IsA("BasePart") and t2[iterSecond.Name] then
				iterSecond.CFrame = foundChild.CFrame

				local motor6D: Motor6D = Instance.new("Motor6D")

				motor6D.Name = "StormSkeletonMotor_" .. iterSecond.Name
				motor6D.Part0 = foundChild
				motor6D.Part1 = iterSecond
				motor6D.C0 = CFrame.new()
				motor6D.C1 = CFrame.new()
				motor6D.Parent = foundChild
			end
		elseif iterSecond:IsA("ParticleEmitter") then
			iterSecond.Enabled = false
		end
	end

	debris:AddItem(clone, 5.62)

	return clone
end
local function attachFlames(p13)
	local t4: {[any]: any} = {}
	local flameLow = v8:FindFirstChild("FlameLow")

	if not flameLow or not flameLow:IsA("ParticleEmitter") then
		return t4
	end

	for iterFirst, iterSecond in p13:GetDescendants() do
		if iterSecond:IsA("BasePart") and iterSecond.Name ~= "HumanoidRootPart" then
			local clone = flameLow:Clone()

			clone.Enabled = true
			clone.Parent = iterSecond
			table.insert(t4, clone)
		end
	end

	return t4
end
local function fadeCharacterOut(p14)
	for iterFirst, iterSecond in p14:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			tweenService:Create(iterSecond, TweenInfo.new(1), { LocalTransparencyModifier = 1, Color = Color3.new(0, 0, 0) }):Play()
		elseif not iterSecond:IsA("Decal") and not iterSecond:IsA("Texture") then
			if iterSecond:IsA("BillboardGui") then
				for iterFirst2, iterSecond2 in iterSecond:GetDescendants() do
					if not iterSecond2:IsA("TextLabel") and not iterSecond2:IsA("TextButton") and not iterSecond2:IsA("TextBox") then
						if iterSecond2:IsA("ImageLabel") or iterSecond2:IsA("ImageButton") then
							tweenService:Create(iterSecond2, TweenInfo.new(1), { ImageTransparency = 1, BackgroundTransparency = 1 }):Play()
						elseif iterSecond2:IsA("Frame") then
							tweenService:Create(iterSecond2, TweenInfo.new(1), { BackgroundTransparency = 1 }):Play()
						end
					else
						tweenService:Create(iterSecond2, TweenInfo.new(1), { TextTransparency = 1, BackgroundTransparency = 1 }):Play()
					end
				end

				task.delay(1, function()
					if iterSecond and iterSecond.Parent then
						iterSecond.Enabled = false
					end
				end)
			end
		else
			tweenService:Create(iterSecond, TweenInfo.new(1), { Transparency = 1 }):Play()
		end
	end
end
local function revealSkeleton(p15)
	for iterFirst, iterSecond in p15:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			tweenService:Create(iterSecond, TweenInfo.new(1), { Transparency = 0 }):Play()
		elseif iterSecond:IsA("ParticleEmitter") then
			iterSecond.Enabled = true
		end
	end
end
local function blackenSkeleton(p16)
	for iterFirst, iterSecond in p16:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			tweenService:Create(iterSecond, TweenInfo.new(0.12), { Color = Color3.new(0, 0, 0) }):Play()
		elseif iterSecond:IsA("ParticleEmitter") then
			iterSecond.Color = ColorSequence.new((Color3.new(0, 0, 0)))
		end
	end
end
local function disableSkeletonParticles(p17)
	for iterFirst, iterSecond in p17:GetDescendants() do
		if iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail") or iterSecond:IsA("Beam") then
			iterSecond.Enabled = false
		end
	end
end
local function fadeSkeletonOut(p18)
	for iterFirst, iterSecond in p18:GetDescendants() do
		if iterSecond:IsA("BasePart") or iterSecond:IsA("Decal") or iterSecond:IsA("Texture") then
			tweenService:Create(iterSecond, TweenInfo.new(0.75), { Transparency = 1 }):Play()
		end
	end
end
local function instantHideAndBlackenCharacter(p19)
	for iterFirst, iterSecond in p19:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			iterSecond.LocalTransparencyModifier = 1
			iterSecond.Color = Color3.new(0, 0, 0)
		elseif not iterSecond:IsA("Decal") and not iterSecond:IsA("Texture") then
			if iterSecond:IsA("BillboardGui") then
				iterSecond.Enabled = false
			end
		else
			iterSecond.Transparency = 1
		end
	end
end
local function revealInstantBlackSkeleton(p20)
	for iterFirst, iterSecond in p20:GetDescendants() do
		if iterSecond:IsA("BasePart") then
			iterSecond.Transparency = 0
			iterSecond.Color = Color3.new(0, 0, 0)
		elseif not iterSecond:IsA("Decal") and not iterSecond:IsA("Texture") then
			if iterSecond:IsA("ParticleEmitter") or iterSecond:IsA("Trail") or iterSecond:IsA("Beam") then
				iterSecond.Enabled = false
			end
		else
			iterSecond.Transparency = 0
		end
	end
end
local function playHalExplosionInstant(character)
	if not character or not character.Parent then
		return
	end

	if t1[character] then
		return
	end

	t1[character] = true

	if not character:FindFirstChildOfClass("Humanoid") then
		t1[character] = nil

		return
	end

	local v108 = cloneAndMotorSkeleton(character)

	instantHideAndBlackenCharacter(character)

	if v108 and v108.Parent then
		disableSkeletonParticles(v108)
		revealInstantBlackSkeleton(v108)
	end

	task.delay(1.35, function()
		if v108 and v108.Parent then
			disableSkeletonParticles(v108)
			fadeSkeletonOut(v108)
		end
	end)
	task.delay(2.45, function()
		t1[character] = nil

		if v108 and v108.Parent then
			v108.Parent = nil
		end
	end)
end
local function stopFlames(p22)
	for i = 1, #p22 do
		local v111 = p22[i]

		if v111:IsA("ParticleEmitter") then
			v111.Enabled = false
		end

		debris:AddItem(v111, 1)
	end
end
local function playStormDeathSfx(p23)
	local head = p23:FindFirstChild("Head")
	local parent = if head and head:IsA("BasePart") then head else p23:FindFirstChild("HumanoidRootPart")

	if not parent then
		return nil
	end

	local stormSkinMeltSfx: Sound = Instance.new("Sound")

	stormSkinMeltSfx.Name = "StormSkinMeltSfx"
	stormSkinMeltSfx.SoundId = "rbxassetid://128173894564124"
	stormSkinMeltSfx.Volume = 1
	stormSkinMeltSfx.RollOffMode = Enum.RollOffMode.Inverse
	stormSkinMeltSfx.RollOffMinDistance = 10
	stormSkinMeltSfx.RollOffMaxDistance = 120
	stormSkinMeltSfx.Parent = parent
	stormSkinMeltSfx:Play()
	debris:AddItem(stormSkinMeltSfx, 8)

	return stormSkinMeltSfx
end
local function playLongScreamForOneSecond(p24)
	local head = p24:FindFirstChild("Head")
	local longScream = head and head:FindFirstChild("LongScream")

	if not longScream or not longScream:IsA("Sound") then
		return
	end

	longScream.TimePosition = 0
	longScream.Volume = math.max(longScream.Volume, 1)
	longScream:Play()
	task.delay(1, function()
		if not longScream or not longScream.Parent then
			return
		end

		longScream.TimePosition = 1

		local v128: Tween = tweenService:Create(longScream, TweenInfo.new(0.75), { Volume = 0 })

		v128:Play()
		v128.Completed:Once(function()
			if longScream and longScream.Parent then
				longScream:Stop()
			end
		end)
	end)
end
local function play(character)
	if not character or not character.Parent then
		return
	end

	if t1[character] then
		return
	end

	t1[character] = true

	local humanoid = character:FindFirstChildOfClass("Humanoid")

	if not humanoid then
		t1[character] = nil

		return
	end

	playDeathAnimation(character, humanoid)
	playStormDeathSfx(character)
	playLongScreamForOneSecond(character)

	local v121 = cloneAndMotorSkeleton(character)
	local v122 = attachFlames(character)

	task.delay(1, function()
		if not character or not character.Parent then
			return
		end

		stopFlames(v122)
		fadeCharacterOut(character)

		if v121 and v121.Parent then
			revealSkeleton(v121)
		end
	end)
	task.delay(2.5, function()
		if v121 and v121.Parent then
			blackenSkeleton(v121)
		end
	end)
	task.delay(3.37, function()
		if v121 and v121.Parent then
			disableSkeletonParticles(v121)
			fadeSkeletonOut(v121)
		end
	end)
	task.delay(4.62, function()
		t1[character] = nil

		if v121 and v121.Parent then
			v121.Parent = nil
		end
	end)
end

local module: {[any]: any} = {
	Play = function(p26)
		local v124 = getCharacterFromPayload(p26)
		local v125

		if typeof(p26) == "table" then
			local v126 = p26.Mode or p26.mode or p26.EffectMode or p26.effectMode

			v125 = if typeof(v126) == "string" then v126 else nil
		else
			v125 = nil
		end

		if v125 == "HalExplosionInstant" then
			playHalExplosionInstant(v124)

			return
		end

		play(v124)
	end
}

if skinMeltOff and skinMeltOff:IsA("RemoteEvent") then
	skinMeltOff.OnClientEvent:Connect(function(p27)
		module.Play(p27)
	end)
end

return module
