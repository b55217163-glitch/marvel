-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local moveOne = game.ReplicatedStorage.Characters.Conquest.Remotes.MoveOne
		local tweenService: TweenService = game:GetService("TweenService")
		local debris: Debris = game:GetService("Debris")
		local smoke = game.ReplicatedStorage.Movement.Rocks.Fx.Smoke

		local function randf(p1, p2)
			local randomNumber = math.random()

			return p1 + (p2 - p1) * randomNumber
		end
		local function shuffleArray(p3)
			for i = #p3, 2, -1 do
				local randomNumber = math.random(1, i)
				local v25 = p3[i]

				p3[i] = p3[randomNumber]
				p3[randomNumber] = v25
			end
		end
		local function getDashLength(p4)
			return p4.Size.Z
		end
		local function getGroundHit(p5)
			local raycastParams = RaycastParams.new()

			raycastParams.FilterType = Enum.RaycastFilterType.Include
			raycastParams.FilterDescendantsInstances = { workspace.Map }

			return workspace:Raycast(p5, Vector3.new(0, -6, 0), raycastParams)
		end
		local function getAttachments(p6)
			local t1: {[any]: any} = {}

			for _, v in ipairs(p6:GetDescendants()) do
				if v:IsA("Attachment") then
					table.insert(t1, v)
				end
			end

			return t1
		end
		local function getLocalZ(p7, p8)
			return p7.CFrame:PointToObjectSpace(p8.WorldPosition).Z
		end
		local function sortBackToFront(p9, p10)
			table.sort(p10, function(p11, p12)
				local z = p9.CFrame:PointToObjectSpace(p11.WorldPosition).Z
				local v116 = p9.CFrame:PointToObjectSpace(p12.WorldPosition)

				return z > v116.Z
			end)
		end
		local function isMidAttachment(p13)
			return p13.Name == "MidAttachment"
		end
		local function emitWindFromAttachment(p14)
			local windF = p14:FindFirstChild("WindF")

			if windF and windF:IsA("ParticleEmitter") then
				windF:Emit(1)
			end
		end
		local function getRandomRockSize()
			local randomNumber = math.random(1, 100)

			if randomNumber <= 55 then
				local randomNumber2 = math.random()
				local randomNumber3 = math.random()
				local randomNumber4 = math.random()
				local vector3 = Vector3.new(1.1 + 1.5 * randomNumber2, 1 + 1.2999999999999998 * randomNumber3, 1 + 1.5 * randomNumber4)

				return vector3
			end

			if randomNumber <= 80 then
				local randomNumber5 = math.random()
				local randomNumber6 = math.random()
				local randomNumber7 = math.random()
				local vector3 = Vector3.new(1.6 + 1.4 * randomNumber5, 0.45 + 0.6500000000000001 * randomNumber6, 1.2 + 1.2 * randomNumber7)

				return vector3
			end

			local randomNumber8 = math.random()
			local randomNumber9 = math.random()
			local randomNumber10 = math.random()
			local vector3 = Vector3.new(0.7 + 0.8 * randomNumber8, 1.5 + 1.7000000000000002 * randomNumber9, 0.8 + 1 * randomNumber10)

			return vector3
		end
		local function getRandomTinySizeFrom(p15)
			local x = p15.X
			local randomNumber = math.random()
			local v56 = math.max(0.05, x * (0.08 + 0.08 * randomNumber))
			local y = p15.Y
			local randomNumber11 = math.random()
			local v59 = math.max(0.05, y * (0.08 + 0.08 * randomNumber11))
			local z = p15.Z
			local randomNumber12 = math.random()
			local v62 = math.max(0.05, z * (0.08 + 0.08 * randomNumber12))
			local vector3 = Vector3.new(v56, v59, v62)

			return vector3
		end
		local function makeRockBurstFromAttachment(p16)
			if p16.Name == "MidAttachment" then
				return
			end

			local v65 = getGroundHit(p16.WorldPosition)

			if not v65 then
				return
			end

			local v66 = getRandomRockSize()
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.CanQuery = false
			part.Material = v65.Material
			part.Color = v65.Instance.Color
			part.Size = getRandomTinySizeFrom(v66)

			local v68 = v65.Position
			local randomNumber = math.random()
			local randomNumber13 = math.random()
			local vector3 = Vector3.new(-0.15 + 0.3 * randomNumber, 0, -0.15 + 0.3 * randomNumber13)

			part.Position = v68 + vector3

			local cFrame = CFrame.new(part.Position)
			local cFrameAngles = CFrame.Angles
			local randomNumber14 = math.random(-35, 35)
			local v75 = math.rad(randomNumber14)
			local randomNumber15 = math.random(0, 180)
			local v77 = math.rad(randomNumber15)
			local randomNumber16 = math.random(-35, 35)
			local v79 = math.rad(randomNumber16)
			local v80 = cFrameAngles(v75, v77, v79)

			part.CFrame = cFrame * v80
			part.Parent = workspace
			debris:AddItem(part, 3)

			local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			tweenService:Create(part, tweenInfo, { Size = v66 }):Play()

			local clone = smoke:Clone()

			clone.Parent = part

			local colorSequenceNew = ColorSequence.new
			local colorSequenceKeypoint = ColorSequenceKeypoint.new(0, part.Color)

			clone.Color = colorSequenceNew({ colorSequenceKeypoint, ColorSequenceKeypoint.new(1, part.Color) })
			clone:Emit(math.random(2, 4))
			debris:AddItem(clone, 2)

			if math.random(1, 3) == 1 then
				local v85 = getRandomRockSize()
				local explosionPart: Part = Instance.new("Part")

				explosionPart.Anchored = false
				explosionPart.Name = "ExplosionPart"
				explosionPart.Size = getRandomTinySizeFrom(v85)
				explosionPart.Material = part.Material
				explosionPart.CanCollide = true
				explosionPart.Color = part.Color

				local partCFrame: CFrame = part.CFrame
				local angles = CFrame.Angles
				local randomNumber17 = math.random(-25, 25)
				local v90 = math.rad(randomNumber17)
				local randomNumber18 = math.random(-25, 25)
				local v92 = math.rad(randomNumber18)
				local randomNumber19 = math.random(-25, 25)
				local v94 = math.rad(randomNumber19)
				local v95 = angles(v90, v92, v94)

				explosionPart.CFrame = partCFrame * v95
				explosionPart.Parent = workspace

				local tweenInfo2 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

				tweenService:Create(explosionPart, tweenInfo2, { Size = v85 }):Play()

				local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

				bodyVelocity.MaxForce = Vector3.new(100000, 100000, 100000)

				local randomNumber20 = math.random(-45, 45)
				local randomNumber21 = math.random(18, 42)

				bodyVelocity.Velocity = Vector3.new(randomNumber20, randomNumber21, math.random(-45, 45))
				bodyVelocity.Parent = explosionPart
				debris:AddItem(bodyVelocity, 0.15)
				debris:AddItem(explosionPart, 2.2)
				task.delay(1.5, function()
					if explosionPart and explosionPart.Parent then
						explosionPart.Anchored = true

						local tweenInfo3 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						local v118 = getRandomTinySizeFrom(v85)
						local explosionPartCFrame: CFrame = explosionPart.CFrame
						local cFrameAngles = CFrame.Angles
						local randomNumber22 = math.random(-20, 20)
						local v122 = math.rad(randomNumber22)
						local randomNumber23 = math.random(-60, 60)
						local v124 = math.rad(randomNumber23)
						local randomNumber24 = math.random(-20, 20)
						local v126 = math.rad(randomNumber24)
						local cFrame = cFrameAngles(v122, v124, v126)

						tweenService:Create(explosionPart, tweenInfo3, {
							Size = v118,
							CFrame = explosionPartCFrame * cFrame + Vector3.new(0, -2, 0)
						}):Play()
					end
				end)
			end

			local taskDelay = task.delay
			local randomNumber25 = math.random()

			taskDelay(1.6 + 0.3999999999999999 * randomNumber25, function()
				if part and part.Parent then
					local tweenInfo4 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					local v129 = getRandomTinySizeFrom(v66)
					local partCFrame: CFrame = part.CFrame
					local cFrameAngles = CFrame.Angles
					local randomNumber26 = math.random(-20, 20)
					local v133 = math.rad(randomNumber26)
					local randomNumber27 = math.random(-60, 60)
					local v135 = math.rad(randomNumber27)
					local randomNumber28 = math.random(-20, 20)
					local v137 = math.rad(randomNumber28)
					local cFrame = cFrameAngles(v133, v135, v137)

					tweenService:Create(part, tweenInfo4, { Size = v129, CFrame = partCFrame * cFrame + Vector3.new(0, -2.5, 0) }):Play()
				end
			end)
		end

		moveOne.OnClientEvent:Connect(function(_, p18)
			if not p18 or not p18.Parent then
				return
			end

			local v104 = getAttachments(p18)

			if #v104 == 0 then
				return
			end

			local v105 = math.clamp(p18.Size.Z / 40, 0, 1)
			local t2

			if v105 >= 0.95 then
				t2 = v104
			else
				local v107 = math.max(0.2, v105)
				local floored = math.floor(#v104 * v107 + 0.5)
				local v109 = math.clamp(floored, 1, #v104)

				shuffleArray(v104)
				t2 = {}

				for i = 1, v109 do
					table.insert(t2, v104[i])
				end
			end

			table.sort(t2, function(p19, p20)
				local z = p18.CFrame:PointToObjectSpace(p19.WorldPosition).Z
				local v142 = p18.CFrame:PointToObjectSpace(p20.WorldPosition)

				return z > v142.Z
			end)
			v105 = 0

			if #t2 > 1 then
				v105 = 0.18 / (#t2 - 1)
			end

			for i, v in ipairs(t2) do
				task.delay((i - 1) * v105, function()
					if v and v.Parent and p18 and p18.Parent then
						local windF = v:FindFirstChild("WindF")

						if windF and windF:IsA("ParticleEmitter") then
							windF:Emit(1)
						end

						if v.Name ~= "MidAttachment" then
							makeRockBurstFromAttachment(v)
						end
					end
				end)
			end
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Conquest.MoveFour", result)
	end
end)

return true
