-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
task.spawn(function()
	local ok, result = pcall(function()
		local counter = game.ReplicatedStorage.Characters.Conquest.Remotes.Counter
		local debris: Debris = game:GetService("Debris")
		local tweenService: TweenService = game:GetService("TweenService")
		local counterStop = game.ReplicatedStorage.Characters.Conquest.Fx.CounterStop
		local rock = game.ReplicatedStorage:WaitForChild("Characters"):WaitForChild("Physics"):WaitForChild("Rock")

		local function tween(p1, p2, p3, p4, p5)
			local tweenInfo = TweenInfo.new(p2, p4 or Enum.EasingStyle.Quad, p5 or Enum.EasingDirection.Out)
			local v27: Tween = tweenService:Create(p1, tweenInfo, p3)

			v27:Play()

			return v27
		end
		local function copySurfaceLook(p6, parent)
			if not p6 or not parent or not p6:IsA("BasePart") or not parent:IsA("BasePart") then
				return
			end

			for _, v in ipairs(p6:GetChildren()) do
				if v:IsA("Decal") or v:IsA("Texture") or v:IsA("DataModelMesh") or v:IsA("Attachment") or v:IsA("ParticleEmitter") then
					local clone = v:Clone()

					clone.Parent = parent
				end
			end
		end
		local function getGroundHit(p8)
			local map: Instance = workspace:FindFirstChild("Map")
			local humanoidRootPart = p8 and p8:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return nil
			end

			local raycastParams = RaycastParams.new()

			raycastParams.IgnoreWater = true

			if map then
				raycastParams.FilterType = Enum.RaycastFilterType.Include
				raycastParams.FilterDescendantsInstances = { map }
			else
				raycastParams.FilterType = Enum.RaycastFilterType.Exclude
				raycastParams.FilterDescendantsInstances = { p8 }
			end

			return workspace:Raycast(humanoidRootPart.Position + Vector3.new(0, 6, 0), Vector3.new(0, -30, 0), raycastParams)
		end
		local function getEffectsFolder()
			local effects = workspace:FindFirstChild("Effects")

			if not effects then
				effects = Instance.new("Folder")
				effects.Name = "Effects"
				effects.Parent = workspace
			end

			return effects
		end
		local function emitIfExists(p9, p10, p11)
			local v41 = p9 and p9:FindFirstChild(p10, true)

			if v41 and v41:IsA("ParticleEmitter") then
				v41:Emit(p11)
			end
		end
		local function setParticleColor(p12, p13)
			if not p12 or not p12:IsA("ParticleEmitter") then
				return
			end

			p12.Color = ColorSequence.new(p13)
		end
		local function recolorNamedEmitters(p14, p15, p16)
			if not p14 then
				return
			end

			local t1: {[any]: any} = {}

			for _, v in ipairs(p15) do
				t1[v] = true
			end

			for _, v in ipairs(p14:GetDescendants()) do
				if v:IsA("ParticleEmitter") and t1[v.Name] and v and v:IsA("ParticleEmitter") then
					v.Color = ColorSequence.new(p16)
				end
			end
		end
		local function setModelToGround(p17, p18, p19)
			if not p17 or not p17:IsA("Model") then
				return
			end

			local v55 = p19 or Vector3.new(0, 1, 0)
			local vectorValue = Vector3.new(0, 0, -1)
			local v57 = v55:Dot(vectorValue)

			if math.abs(v57) > 0.98 then
				vectorValue = Vector3.new(1, 0, 0)
			end

			local unit = vectorValue:Cross(v55).Unit

			v57 = v55:Cross(unit)
			v57 = CFrame.fromMatrix(p18, unit, v55, -v57.Unit)
			p17:PivotTo(v57)
		end
		local function fadeChildrenAndRemove(p20, p21, p22, p23, p24)
			local taskDelay = task.delay
			local v65 = math.max(0, p21 - p22)

			taskDelay(v65, function()
				if not p20 or not p20.Parent then
					return
				end

				for _, v in ipairs(p20:GetChildren()) do
					if v:IsA("Texture") or v:IsA("Decal") then
						local v147 = math.min(0.45, p22)
						local tweenInfo = TweenInfo.new(v147, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						tweenService:Create(v, tweenInfo, { Transparency = 1 }):Play()
					elseif v:IsA("ParticleEmitter") then
						v.Enabled = false
					end
				end

				local t2: {[any]: any} = { Transparency = 1 }

				if p23 and p23 ~= 0 then
					local cFrame = p20.CFrame
					local vector3 = Vector3.new(0, p23, 0)

					t2.CFrame = cFrame - vector3
				end

				if p24 then
					local v152 = math.max(0.01, p20.Size.X * p24)
					local v153 = math.max(0.01, p20.Size.Y * p24)
					local v154 = math.max(0.01, p20.Size.Z * p24)

					t2.Size = Vector3.new(v152, v153, v154)
				end

				local tweenInfo = TweenInfo.new(p22, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

				tweenService:Create(p20, tweenInfo, t2):Play()
			end)
			debris:AddItem(p20, p21)
		end
		local function createGroundChunk(p25, material, p27, p28, _, cFrame, parent)
			local part: Part = Instance.new("Part")

			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Material = material
			part.Color = p27
			part.Size = p28
			part.CFrame = cFrame
			part.Parent = parent

			if p25 then
				copySurfaceLook(p25, part)
			end

			return part
		end
		local function createCraterRing(p32, p33, p34, p35, p36, p37, p38, p39)
			local u82 = p38 or 1
			local u83 = p39 or 1
			local v84 = math.max(1, u82 * 0.9)
			local floored = math.floor(v84 * 44)
			local n1 = 8 * u82
			local n2 = 20 * u82

			for i = 1, floored do
				local taskDelay = task.delay
				local randomNumber = math.random()

				taskDelay((i - 1) * 0.003 + randomNumber * 0.012, function()
					local randomNumber2 = math.random(-10, 10)
					local v157 = math.rad(360 / floored * i + randomNumber2)
					local cosine = math.cos(v157)
					local sine = math.sin(v157)
					local vector3 = Vector3.new(cosine, 0, sine)
					local randomNumber3 = math.random()
					local n9 = if u82 <= 1.05 then n1 + (n2 - n1) * randomNumber3 ^ 2.4 else n1 + (n2 - n1) * randomNumber3 ^ 1.2
					local randomNumber4 = math.random(-20, 20)
					local n10 = p32 + vector3 * (n9 + randomNumber4 / 10 * u82) + p33 * 0.12
					local n3 = math.random(28, 54) / 10 * u83
					local n4 = math.random(12, 24) / 10 * u83
					local randomNumber5 = math.random(22, 44)
					local vector32 = Vector3.new(n3, n4, randomNumber5 / 10 * u83)
					local cFrame = CFrame.new(n10, n10 + vector3)
					local cFrameAngles = CFrame.Angles
					local randomNumber6 = math.random(-16, 16)

					n3 = math.rad(randomNumber6)

					local randomNumber7 = math.random(-35, 35)

					n4 = math.rad(randomNumber7)

					local randomNumber8 = math.random(-35, 35)
					local v174 = math.rad(randomNumber8)
					local v175 = cFrameAngles(n3, n4, v174)
					local n5 = cFrame * v175

					v175 = p34

					local vector33 = Vector3.new(0, vector32.Y * 0.45, 0)
					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanQuery = false
					part.CanTouch = false
					part.Material = p35
					part.Color = p36
					part.Size = Vector3.new(0.08, 0.08, 0.08)
					part.CFrame = n5 - vector33
					part.Parent = p37

					if v175 then
						copySurfaceLook(v175, part)
					end

					local tweenInfo = TweenInfo.new(0.12, Enum.EasingStyle.Back or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

					tweenService:Create(part, tweenInfo, { Size = vector32, CFrame = n5 }):Play()

					local n6 = 1.1 * u83
					local n7: number = 0.75
					local n8: number = 0.08

					task.delay(5.25, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v235 = math.min(0.45, n7)
								local tweenInfo2 = TweenInfo.new(v235, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

								tweenService:Create(v, tweenInfo2, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local t3: {[any]: any} = { Transparency = 1 }

						if n6 and n6 ~= 0 then
							local partCFrame: CFrame = part.CFrame
							local vector34 = Vector3.new(0, n6, 0)

							t3.CFrame = partCFrame - vector34
						end

						if n8 then
							local v240 = math.max(0.01, part.Size.X * n8)
							local v241 = math.max(0.01, part.Size.Y * n8)
							local v242 = math.max(0.01, part.Size.Z * n8)

							t3.Size = Vector3.new(v240, v241, v242)
						end

						local tweenInfo3 = TweenInfo.new(n7, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						tweenService:Create(part, tweenInfo3, t3):Play()
					end)
					debris:AddItem(part, 6)
				end)
			end
		end
		local function createFlyingRockProjectile(p40, material, p42, parent, p44, p45)
			local clone = rock:Clone()

			clone.Parent = parent

			if clone:IsA("BasePart") then
				clone.Material = material
				clone.Color = p42
				clone.CanCollide = false
				clone.CanTouch = false
				clone.CanQuery = false

				if clone:FindFirstChild("Trail") and clone.Trail:IsA("Trail") then
					clone.Trail.Color = ColorSequence.new(p42)
				end

				local randomNumber = math.random(85, 130)

				clone.Size = clone.Size * (randomNumber / 100) * (p44 or 1)

				local cFrameAngles = CFrame.Angles
				local randomNumber9 = math.random(0, 360)
				local v101 = math.rad(randomNumber9)
				local randomNumber10 = math.random(0, 360)
				local v103 = math.rad(randomNumber10)
				local randomNumber11 = math.random(0, 360)
				local v105 = math.rad(randomNumber11)
				local cFrame = cFrameAngles(v101, v103, v105)

				clone.CFrame = p40 * cFrame
			end

			local bodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

			bodyVelocity.MaxForce = Vector3.new(inf, inf, inf)

			local randomNumber = math.random(-2, 2)
			local randomNumber12 = math.random(1, 3)
			local vector3 = Vector3.new(randomNumber, randomNumber12, math.random(-2, 2))

			if vector3.Magnitude < 0.1 then
				vector3 = Vector3.new(1, 2, 0)
			end

			local vector3Unit = vector3.Unit
			local randomNumber13 = math.random(85, 125)

			bodyVelocity.Velocity = vector3Unit * randomNumber13 * (p45 or 1)
			bodyVelocity.Parent = clone
			debris:AddItem(bodyVelocity, 0.22)
			debris:AddItem(clone, 3)
		end
		local function createMeteorDebris(p46, p47, p48, p49, p50, p51, p52, p53)
			local u121 = p52 or 1
			local u122 = p53 or 1
			local v123 = math.max(1, u121 * 0.9)

			for i = 1, math.floor(v123 * 30) do
				local taskDelay = task.delay
				local randomNumber = math.random()

				taskDelay((i - 1) * 0.002 + randomNumber * 0.012, function()
					local randomNumber14 = math.random(0, 359)
					local v184 = math.rad(randomNumber14)
					local cosine = math.cos(v184)
					local sine = math.sin(v184)
					local unit = Vector3.new(cosine, 0, sine).Unit
					local n1 = math.random(14, 28) / 10 * u122
					local n2 = math.random(12, 22) / 10 * u122
					local randomNumber15 = math.random(14, 28)
					local vector3 = Vector3.new(n1, n2, randomNumber15 / 10 * u122)
					local vector35 = Vector3.new(0, vector3.Y * 0.8, 0)

					n1 = math.random(120, 430) / 10 * u121

					local randomNumber16 = math.random(28, 42)
					local n3 = math.random(7, 12) * u122
					local randomNumber17 = math.random(-25, 25)
					local randomNumber18 = math.random(-25, 25)
					local vector36 = Vector3.new(randomNumber17 / 10, 0, randomNumber18 / 10)
					local vector37 = Vector3.new(0, n3, 0)
					local randomNumber19 = math.random(-50, 50)
					local randomNumber20 = math.random(0, 8)
					local randomNumber21 = math.random(-50, 50)
					local vector38 = Vector3.new(randomNumber19 / 10, randomNumber20 / 100, randomNumber21 / 10)
					local vector39 = Vector3.new(0, vector3.Y * 0.35, 0)
					local n4 = p46 + unit * n1 + vector38 - vector39
					local randomNumber22 = math.random(-180, 180)
					local randomNumber23 = math.random(-180, 180)
					local vector310 = Vector3.new(randomNumber22, randomNumber23, math.random(-180, 180))
					local randomNumber24 = math.random(55, 110)
					local randomNumber25 = math.random(55, 110)
					local vector311 = Vector3.new(randomNumber24, randomNumber25, math.random(55, 110))

					n2 = vector310 + vector311

					local randomNumber26 = math.random(90, 170)
					local randomNumber27 = math.random(90, 170)
					local vector312 = Vector3.new(randomNumber26, randomNumber27, math.random(90, 170))
					local n5 = n2 + vector312
					local v215 = p48
					local cFrame = CFrame.new(p46 + p47 * 0.08 - vector35)
					local cFrameAngles = CFrame.Angles
					local v218 = math.rad(vector310.X)
					local v219 = math.rad(vector310.Y)
					local v220 = math.rad(vector310.Z)
					local v221 = cFrameAngles(v218, v219, v220)
					local part: Part = Instance.new("Part")

					part.Anchored = true
					part.CanCollide = false
					part.CanQuery = false
					part.CanTouch = false
					part.Material = p49
					part.Color = p50
					part.Size = vector3
					part.CFrame = cFrame * v221
					part.Parent = p51

					if v215 then
						copySurfaceLook(v215, part)
					end

					local randomNumber28 = math.random(8, 11)
					local n6 = math.random(30, 40) / 100

					createFlyingRockProjectile(part.CFrame, p49, p50, p51, u122, if u121 <= 1.05 then 0.9 else 1.15)

					local cFrame2 = CFrame.new(p46 + unit * (n1 * (randomNumber16 / 100)) + vector36 + vector37)
					local angles = CFrame.Angles
					local v227 = math.rad(n2.X)

					v221 = math.rad(n2.Y)
					v218 = math.rad(n2.Z)

					local v228 = angles(v227, v221, v218)
					local tweenInfo = TweenInfo.new(randomNumber28 / 100, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

					v184 = tweenService:Create(part, tweenInfo, { CFrame = cFrame2 * v228 })
					v184:Play()

					if v184 then
						v184.Completed:Connect(function()
							if not part or not part.Parent then
								return
							end

							local cFrame3 = CFrame.new(n4)
							local cFrameAngles = CFrame.Angles
							local v246 = math.rad(n5.X)
							local v247 = math.rad(n5.Y)
							local v248 = math.rad(n5.Z)
							local cFrame = cFrameAngles(v246, v247, v248)
							local tweenInfo4 = TweenInfo.new(n6, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.In or Enum.EasingDirection.Out)

							tweenService:Create(part, tweenInfo4, { CFrame = cFrame3 * cFrame }):Play()
						end)
					end

					local n7 = 1.1 * u122
					local n8: number = 0.8
					local n9: number = 0.08

					task.delay(5.2, function()
						if not part or not part.Parent then
							return
						end

						for _, v in ipairs(part:GetChildren()) do
							if v:IsA("Texture") or v:IsA("Decal") then
								local v253 = math.min(0.45, n8)
								local tweenInfo5 = TweenInfo.new(v253, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

								tweenService:Create(v, tweenInfo5, { Transparency = 1 }):Play()
							elseif v:IsA("ParticleEmitter") then
								v.Enabled = false
							end
						end

						local t4: {[any]: any} = { Transparency = 1 }

						if n7 and n7 ~= 0 then
							local partCFrame: CFrame = part.CFrame
							local vector313 = Vector3.new(0, n7, 0)

							t4.CFrame = partCFrame - vector313
						end

						if n9 then
							local v258 = math.max(0.01, part.Size.X * n9)
							local v259 = math.max(0.01, part.Size.Y * n9)
							local v260 = math.max(0.01, part.Size.Z * n9)

							t4.Size = Vector3.new(v258, v259, v260)
						end

						local tweenInfo6 = TweenInfo.new(n8, Enum.EasingStyle.Linear or Enum.EasingStyle.Quad, Enum.EasingDirection.Out or Enum.EasingDirection.Out)

						tweenService:Create(part, tweenInfo6, t4):Play()
					end)
					debris:AddItem(part, 6)
				end)
			end
		end

		counter.OnClientEvent:Connect(function(p54, p55)
			if not p54 or not p54.Parent then
				return
			end

			local humanoidRootPart = p54:FindFirstChild("HumanoidRootPart")

			if not humanoidRootPart then
				return
			end

			local effects = workspace:FindFirstChild("Effects")

			if not effects then
				effects = Instance.new("Folder")
				effects.Name = "Effects"
				effects.Parent = workspace
			end

			local clone = counterStop:Clone()

			clone.Parent = effects

			local v132 = getGroundHit(p54)
			local u133 = Enum.Material.Concrete
			local color3 = Color3.fromRGB(90, 90, 90)
			local u135 = nil
			local u136
			local vectorValue

			if v132 then
				u136 = v132.Position
				vectorValue = v132.Normal
				u133 = v132.Material

				if v132.Instance and v132.Instance:IsA("BasePart") then
					color3 = v132.Instance.Color
					u135 = v132.Instance
				end
			else
				u136 = humanoidRootPart.Position - Vector3.new(0, 3, 0)
				vectorValue = Vector3.new(0, 1, 0)
			end

			recolorNamedEmitters(clone, { "Smoke", "SmokeSlide" }, color3)

			if clone:IsA("BasePart") then
				clone.CFrame = CFrame.new(u136 + vectorValue * 0.05)
			elseif clone:IsA("Model") then
				setModelToGround(clone, u136 + vectorValue * 0.05, vectorValue)
			end

			local hitAt = clone:FindFirstChild("HitAt")

			if hitAt then
				local v139 = hitAt

				if v139 then
					v139 = hitAt:FindFirstChild("Shock", true)
				end

				if v139 and v139:IsA("ParticleEmitter") then
					v139:Emit(4)
				end

				local shockwaveMiddle = hitAt and hitAt:FindFirstChild("ShockwaveMiddle", true)

				if shockwaveMiddle and shockwaveMiddle:IsA("ParticleEmitter") then
					shockwaveMiddle:Emit(1)
				end

				local sparksCircle = hitAt and hitAt:FindFirstChild("SparksCircle", true)

				if sparksCircle and sparksCircle:IsA("ParticleEmitter") then
					sparksCircle:Emit(3)
				end
			end

			if p55 then
				local hitAt2 = clone:FindFirstChild("HitAt2")

				if hitAt2 then
					local smokeSlide = hitAt2 and hitAt2:FindFirstChild("SmokeSlide", true)

					if smokeSlide and smokeSlide:IsA("ParticleEmitter") then
						smokeSlide:Emit(30)
					end
				end

				createCraterRing(u136, vectorValue, u135, u133, color3, effects, 2, 2)
				task.delay(0.03, function()
					createMeteorDebris(u136, vectorValue, u135, u133, color3, effects, 2, 2)
				end)
			else
				local smoke = clone and clone:FindFirstChild("Smoke", true)

				if smoke and smoke:IsA("ParticleEmitter") then
					smoke:Emit(30)
				end

				createCraterRing(u136, vectorValue, u135, u133, color3, effects, 1, 1)
				task.delay(0.015, function()
					createMeteorDebris(u136, vectorValue, u135, u133, color3, effects, 1, 1)
				end)
			end

			debris:AddItem(clone, 8)
		end)
	end)

	if not ok then
		warn("[OldClientEffectsModule] failed:", "Conquest.Counter", result)
	end
end)

return true
