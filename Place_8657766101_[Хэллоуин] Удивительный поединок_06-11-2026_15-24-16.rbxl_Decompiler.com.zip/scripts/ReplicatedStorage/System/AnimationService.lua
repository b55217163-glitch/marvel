-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local keyframeSequenceProvider: KeyframeSequenceProvider = game:GetService("KeyframeSequenceProvider")
local object = setmetatable({}, { __mode = "k" })
local object2 = setmetatable({}, { __mode = "k" })
local n1: number = 0

local function normalizeAnimationId(p1)
	if type(p1) == "string" and p1 ~= "" then
		local v24 = p1:match("%d+")

		if v24 then
			return "rbxassetid://" .. v24
		end

		return p1
	end

	return nil
end
local function getAnimationKey(p2)
	if not p2 then
		return nil
	end

	if typeof(p2) ~= "Instance" or not p2:IsA("Animation") then
		if type(p2) == "string" and p2 ~= "" then
			if type(p2) == "string" and p2 ~= "" then
				local v26 = p2:match("%d+")

				if v26 then
					return "rbxassetid://" .. v26
				end

				return p2
			end

			return nil
		end

		return nil
	end

	if p2.AnimationId and p2.AnimationId ~= "" then
		local animationId = p2.AnimationId

		if type(animationId) == "string" and animationId ~= "" then
			local v28 = animationId:match("%d+")

			if v28 then
				return "rbxassetid://" .. v28
			end

			return animationId
		end

		return nil
	end

	local v29 = object2[p2]

	if not v29 then
		n1 += 1
		v29 = "animation-instance:" .. tostring(n1)
		object2[p2] = v29
	end

	return v29
end

local object3 = setmetatable({}, { __mode = "k" })
local t1: {[any]: any} = {}

local function getMarkerTimesForAnimation(p3, p4)
	if type(p3) == "string" and p3 ~= "" and type(p4) == "string" and p4 ~= "" then
		local s1: string = p3 .. "::" .. p4

		if t1[s1] == nil then
			local t3: {[any]: any} = {}

			local ok, result = pcall(function()
				return keyframeSequenceProvider:GetKeyframeSequenceAsync(p3)
			end)

			if ok and result then
				local v36 = result:GetKeyframes()

				table.sort(v36, function(p5, p6)
					return p5.Time < p6.Time
				end)

				for _, v in ipairs(v36) do
					for _, iterValue in ipairs(v:GetMarkers()) do
						if p4 == iterValue.Name then
							table.insert(t3, v.Time)
						end
					end
				end

				result:Destroy()
			end

			t1[s1] = t3

			return t3
		end

		return t1[s1]
	end

	return nil
end
local function getOrCreateAnimationInstance(p7)
	if typeof(p7) == "Instance" and p7:IsA("Animation") then
		return p7, false
	end

	if type(p7) == "string" and p7 ~= "" then
		local animation: Animation = Instance.new("Animation")
		local v43

		if type(p7) == "string" and p7 ~= "" then
			local v44 = p7:match("%d+")

			v43 = if v44 then "rbxassetid://" .. v44 else p7
		else
			v43 = nil
		end

		animation.AnimationId = v43 or p7

		return animation, true
	end

	return nil, false
end
local function getAnimator(p8)
	if not p8 then
		return nil
	end

	if p8:IsA("Animator") then
		return p8
	end

	if not p8:IsA("Humanoid") and not p8:IsA("AnimationController") then
		return nil
	end

	local animator = p8:FindFirstChildOfClass("Animator")

	if animator then
		return animator
	end

	for _ = 1, 20 do
		task.wait(0.05)

		local animator2 = p8:FindFirstChildOfClass("Animator")

		if animator2 then
			return animator2
		end
	end

	local ok, result = pcall(function()
		local animator3: Animator = Instance.new("Animator")

		animator3.Parent = p8

		return animator3
	end)

	if ok then
		return result
	end

	return nil
end
local function isAnimationTrack(p9)
	local u52 = false

	if typeof(p9) == "Instance" then
		u52 = p9:IsA("AnimationTrack")
	end

	return u52
end
local function isTrackValid(p10)
	local u54 = false

	if typeof(p10) == "Instance" then
		u54 = p10:IsA("AnimationTrack")
	end

	return u54
end
local function destroyTrack(p11)
	local u56 = false

	if typeof(p11) == "Instance" then
		u56 = p11:IsA("AnimationTrack")
	end

	if not u56 then
		return
	end

	pcall(function()
		p11:Stop(0)
	end)
	pcall(function()
		p11:Destroy()
	end)
end
local function resetTrack(p12)
	local u58 = false

	if typeof(p12) == "Instance" then
		u58 = p12:IsA("AnimationTrack")
	end

	if not u58 then
		return false
	end

	pcall(function()
		p12:Stop(0)
	end)
	pcall(function()
		p12.TimePosition = 0
	end)
	pcall(function()
		p12:AdjustSpeed(1)
	end)

	return true
end
local function getAnimatorCache(p13)
	local t4 = object[p13]

	if not t4 then
		t4 = {
			Tracks = {},
			LastUsed = {}
		}
		object[p13] = t4

		local u61 = p13.Parent

		if not u61 or not u61:IsA("Humanoid") and not u61:IsA("AnimationController") then
			u61 = nil
		end

		local u62 = nil

		if u61 and u61.Parent and u61.Parent:IsA("Model") then
			u62 = u61.Parent
		end

		local u63 = nil
		local connection = nil
		local u65 = nil
		local connection2 = nil
		local u67 = nil
		local connection3 = nil
		local u69: boolean = false

		local function disconnectCleanupConnections()
			if u63 then
				u63:Disconnect()
				u63 = nil
			end

			if connection then
				connection:Disconnect()
				connection = nil
			end

			if u65 then
				u65:Disconnect()
				u65 = nil
			end

			if connection2 then
				connection2:Disconnect()
				connection2 = nil
			end

			if u67 then
				u67:Disconnect()
				u67 = nil
			end

			if connection3 then
				connection3:Disconnect()
				connection3 = nil
			end
		end
		local function cleanupAnimator()
			if u69 then
				return
			end

			u69 = true

			local v150 = object[p13]

			if v150 then
				for k, v in pairs(v150.Tracks) do
					v150.Tracks[k] = nil
					v150.LastUsed[k] = nil
					destroyTrack(v)
				end

				for iterKey in pairs(v150.LastUsed) do
					v150.LastUsed[iterKey] = nil
				end
			end

			object[p13] = nil
			disconnectCleanupConnections()
		end

		u63 = p13.Destroying:Once(function()
			cleanupAnimator()
		end)
		connection = p13.AncestryChanged:Connect(function()
			task.delay(0.1, function()
				if u69 then
					return
				end

				local u170 = false

				pcall(function()
					u170 = p13:IsDescendantOf(game)
				end)
				cleanupAnimator()
			end)
		end)

		if u61 then
			u65 = u61.Destroying:Once(function()
				cleanupAnimator()
			end)
			connection2 = u61.AncestryChanged:Connect(function()
				task.delay(0.1, function()
					if u69 then
						return
					end

					local u171 = false

					pcall(function()
						u171 = u61:IsDescendantOf(game)
					end)
					cleanupAnimator()
				end)
			end)
		end

		if u62 then
			u67 = u62.Destroying:Once(function()
				cleanupAnimator()
			end)
			connection3 = u62.AncestryChanged:Connect(function()
				task.delay(0.1, function()
					if u69 then
						return
					end

					local u172 = false

					pcall(function()
						u172 = u62:IsDescendantOf(game)
					end)
					cleanupAnimator()
				end)
			end)
		end
	end

	return t4
end
local function cleanCache(p14)
	local v73 = object[p14]

	if not v73 then
		return
	end

	local tracks = v73.Tracks
	local lastUsed = v73.LastUsed

	for k, v in pairs(tracks) do
		local u78 = false

		if typeof(v) == "Instance" then
			u78 = v:IsA("AnimationTrack")
		end

		if not u78 then
			tracks[k] = nil
			lastUsed[k] = nil
		end
	end

	v73 = 0

	for iterKey in pairs(tracks) do
		v73 += 1
	end

	if v73 < 40 then
		return
	end

	local t5: {[any]: any} = {}

	for k, v in pairs(tracks) do
		local u83 = false

		if typeof(v) == "Instance" then
			u83 = v:IsA("AnimationTrack")
		end

		if u83 and not v.IsPlaying then
			table.insert(t5, { Key = k, Track = v, LastUsed = lastUsed[k] or 0 })
		end
	end

	table.sort(t5, function(p15, p16)
		return p15.LastUsed < p16.LastUsed
	end)

	for _, v in ipairs(t5) do
		if v73 < 40 then
			break
		end

		tracks[v.Key] = nil
		lastUsed[v.Key] = nil
		destroyTrack(v.Track)
		v73 -= 1
	end
end

local module: {[any]: any} = {
	GetTrack = function(p17, p18)
		if p17 and p18 then
			local v88 = getAnimator(p17)

			if not v88 then
				return nil
			end

			local v89 = getAnimationKey(p18)

			if not v89 then
				return nil
			end

			local v90 = getAnimatorCache(v88)
			local tracks = v90.Tracks
			local v92 = tracks[v89]
			local u93 = false

			if typeof(v92) == "Instance" then
				u93 = v92:IsA("AnimationTrack")
			end

			if u93 then
				v90.LastUsed[v89] = os.clock()
				resetTrack(v92)

				return v92
			end

			tracks[v89] = nil
			v90.LastUsed[v89] = nil
			cleanCache(v88)

			local v94, v95 = getOrCreateAnimationInstance(p18)

			if not v94 then
				return nil
			end

			local ok, result = pcall(function()
				return v88:LoadAnimation(v94)
			end)

			if v95 then
				v94:Destroy()
			end

			if ok and result then
				object3[result] = getAnimationKey(v94)
				tracks[v89] = result
				v90.LastUsed[v89] = os.clock()
				result.Stopped:Connect(function()
					if tracks[v89] == result then
						v90.LastUsed[v89] = os.clock()
					end
				end)
				resetTrack(result)

				return result
			end

			return nil
		end

		return nil
	end
}

function module.Load(p19, p20)
	return module.GetTrack(p19, p20)
end
function module.LoadFresh(p21, p22)
	if p21 and p22 then
		local v102 = getAnimator(p21)

		if not v102 then
			return nil
		end

		cleanCache(v102)

		local v103, v104 = getOrCreateAnimationInstance(p22)

		if not v103 then
			return nil
		end

		local ok, result = pcall(function()
			return v102:LoadAnimation(v103)
		end)

		if v104 then
			v103:Destroy()
		end

		if ok and result then
			object3[result] = getAnimationKey(v103)
			resetTrack(result)

			local u107: boolean = false

			result.Stopped:Once(function()
				if u107 then
					return
				end

				u107 = true
				task.defer(function()
					destroyTrack(result)
				end)
			end)

			return result
		end

		return nil
	end

	return nil
end
function module.Play(p23, p24, p25, p26, p27)
	local v113 = module.GetTrack(p23, p24)

	if not v113 then
		return nil
	end

	pcall(function()
		v113:Play(p25 or 0.1, p26 or 1, p27 or 1)
	end)

	return v113
end
function module.StopAll(p28, p29)
	local v116 = getAnimator(p28)

	if not v116 then
		return
	end

	for _, v in ipairs(v116:GetPlayingAnimationTracks()) do
		pcall(function()
			v:Stop(p29 or 0)
		end)
	end
end
function module.Clear(p30, p31)
	local v121 = getAnimator(p30)

	if not v121 then
		return
	end

	local v122 = object[v121]

	if v122 and p31 then
		for _, v in pairs(v122.Tracks) do
			destroyTrack(v)
		end
	end

	object[v121] = nil
end

local object4 = setmetatable({}, { __mode = "k" })
local object5 = setmetatable({}, { __mode = "k" })

local function disconnectMarkerConnection(p32)
	if p32 then
		pcall(function()
			p32:Disconnect()
		end)
	end
end
local function clearMarkerConnections(p33)
	local v127 = object4[p33]

	if v127 then
		for k, v in pairs(v127) do
			v127[k] = nil

			if v then
				pcall(function()
					v:Disconnect()
				end)
			end
		end
	end

	object4[p33] = nil

	local v130 = object5[p33]

	if v130 then
		object5[p33] = nil

		if v130 then
			pcall(function()
				v130:Disconnect()
			end)
		end
	end
end
function module.ClearMarkers(p34)
	local u132 = false

	if typeof(p34) == "Instance" then
		u132 = p34:IsA("AnimationTrack")
	end

	if not u132 then
		return
	end

	clearMarkerConnections(p34)
end
function module.ConnectMarker(p35, p36, p37, p38)
	local u137 = false

	if typeof(p35) == "Instance" then
		u137 = p35:IsA("AnimationTrack")
	end

	if u137 and type(p36) == "string" and type(p37) == "function" then
		local s1: string = "unknown"
		local n1 = 0

		pcall(function()
			local v156, v157 = debug.info(2, "sl")

			s1 = tostring(v156 or s1)
			n1 = tonumber(v157) or n1
		end)

		local v140 = p38

		if not v140 then
			local s2: string = s1
			local text: string = tostring(n1)

			v140 = s2 .. ":" .. text .. ":" .. p36
		end

		local text: string = tostring(v140)

		v140 = object4[p35]

		if not v140 then
			v140 = {}
			object4[p35] = v140
		end

		local v144 = v140[text]

		if v144 then
			pcall(function()
				v144:Disconnect()
			end)
		end

		local u145: boolean = false

		local connection = p35:GetMarkerReachedSignal(p36):Connect(function(p39)
			u145 = true
			p37(p39)
		end)

		v140[text] = connection
		task.spawn(function()
			local v159 = object3[p35]
			local v160 = v159 and getMarkerTimesForAnimation(v159, p36)

			if not v160 or #v160 == 0 then
				return
			end

			v159 = os.clock()

			while true do
				local v161 = p35
				local u162 = false

				if typeof(v161) == "Instance" then
					u162 = v161:IsA("AnimationTrack")
				end

				if not u162 or not not p35.IsPlaying or not (os.clock() - v159 < 2) then
					break
				end

				task.wait(0.01)
			end

			local v163 = p35
			local u164 = false

			if typeof(v163) == "Instance" then
				u164 = v163:IsA("AnimationTrack")
			end

			if not u164 or not p35.IsPlaying then
				return
			end

			v159 = {}

			while true do
				local v165 = p35
				local u166 = false

				if typeof(v165) == "Instance" then
					u166 = v165:IsA("AnimationTrack")
				end

				if u166 and p35.IsPlaying then
					local n1 = 0

					pcall(function()
						n1 = p35.TimePosition
					end)

					for i, v in ipairs(v160) do
						if not v159[i] and not u145 and n1 >= math.max(v - 0.03, 0) then
							v159[i] = true
							task.spawn(p37, "")
						end
					end

					if n1 > v160[#v160] + 0.35 then
						return
					end

					task.wait(0.03)

					continue
				end

				return
			end
		end)

		return connection
	end

	return nil
end

return module
