-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
return {
	["2099"] = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Unmasked",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Upgraded",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	["A-Train"] = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Africa",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Marathon",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Quicksilver",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Sportacus",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Quickster",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Shockwave",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "RedRush",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Reggie",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Amazo = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Crisis",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "DCAU",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "DCAU Returned",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Anakin = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Robed",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Ep 2",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Bananakin",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Bird",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Kenobi",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	AtomEve = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Resistance",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Y2K",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Laundry Day",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Billy = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Stu",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Jill",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Roman",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Amber",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Ethan",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Hallucination",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Brian = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Biney",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Married",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Casual",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Angel",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Original Sin",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Father Knows Best",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Hallucination",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Nebreska",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	DarthVader = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "White",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Christmas",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Hot Pink",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Knight",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Deep = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Comic",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Aquarus",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Demogorgon = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Shock Jock",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "The Rake",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Hyde",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "The Alien",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "The Robot",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "The Immortal",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "The Lizard",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "The Monster",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Dexter = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Mouse Ears",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Spatter Analyst",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Dark Defender",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "New Blood",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Original Sin",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Blinded Light",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Red",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	DoctorStrange = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Sinister",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Defender",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Wong",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Zombie",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Eddie = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "School",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Bonding",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Suspect",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Dustin",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Eleven = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Blonde",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Bithing",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Mall",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "A New End",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "BlueBandana",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "The Rightside Up",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Fantastic",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Carrie",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Eren = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Hobo",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "The Paths",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Marley",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Mountain",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Cabin",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Freida",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Freddy = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Foxy",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Chica",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	FrontMan = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Front Man",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "132",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "'Thanos'",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "120",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Kang No-eul",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Seong Gi-hun",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "100",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "We are not horses",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Ghostface = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Stab",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Scary Movie",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Old Suit",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Babyface",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	GigaChad = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Pepsi",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Saitama",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "All Might",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Terence",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Squid",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Red Hulk",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "MX",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "The Thing",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Hal = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Special Occasion",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Halogram",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Legend",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Junior",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Guy",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Homelander = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Disguise",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Turkish",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Brightburn",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Clone",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	HumanTorch = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Casual",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Multiverse",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Classic",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Invincible = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Blue Suit",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Oliver",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Recovering",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Immortal",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Iris = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Robot",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Sue",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Debra",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	IronMan = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Superior",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Tech",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Illusion",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Jeff = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Jack",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "This Man",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Jane",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Sleep",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Soup",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Mouse",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Mother Bird",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Bear",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Joe = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Henderson",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Billionaire",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Eat the rich",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Love",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Paris",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Intruding",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Intensity",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Consequences ",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Kira = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Final",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "V Sweater",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Snowy Day",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Mikami",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Misa",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Kratos = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Messi",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Black Bear",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Kong",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Lawliet = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Church",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Christmas",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Beyond",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Near",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Luffy = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Hawaii",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "White and Red",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Cooking",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Little Garden",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Waistband",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Plastic",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Michael = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Off The Wall",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Motown 25",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Beat It",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "8 Grammys",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Bad",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Walk of Fame",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Arcade",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Thriller",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Miles = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Leap of Faith",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Storebought",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Across",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Prowler",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Ps5",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Spider Within",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Gwen",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Mohawk = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Napkin",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Lensless",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Viltrumite",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Prisoner",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Sinister",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Fully Masked",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Omni-Mark",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Bug Eyed",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	MoonKnight = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Cairo",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Survivor",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Lockley",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Gift Shopist",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Undercover",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Lunatic",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Tomb Buster",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Desert",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	MrFantastic = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "2005",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Fant4stic",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Elongated",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "The Maker",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Madness",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Myers = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "The Clown",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Ghost Bob",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Escape",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "The Return",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "The Boogeyman",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "The Shape",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Crystal Lake",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "The Teacher",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Nikki = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Trivia",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "No No No...",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Red Dress",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Work",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Sarah",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Bear",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Mary",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	OmniMan = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Nolan",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Prisoner",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Thraxa",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Planets",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Depressed",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Adulthood",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Patrick = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Raincoat",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Sunglasses",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Brown Overcoat",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Morning Routine",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Book",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Paul = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Home",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Wonka",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Muad'dib",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Armor",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Sandworm",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Peacemaker = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Underwear",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Jetpack",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Pennywise = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Neibolt",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Derry",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Resting",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "1935",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Old School",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Pibby = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Battle-Worn",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Monika",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Finn",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Fantastic",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "XP",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Pomni",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Rambo = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Punisher",
			SortOrder = 1
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	ReverseFlash = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Wells",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "2049",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Dark Flash",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Metal",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Earth X",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "DCAMU",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Flashpoint",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Resurrection",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Riddler = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Pumpkin Pie",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Asylum",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Kramer",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	["SCP-173"] = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Captain",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Tinky",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	SCPGuard = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Pestilence Reanimated",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Containment Breacher",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Red-Eye Operative",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Possessed by 035",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Async",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Sidney = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Windsor",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Return",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Ladder",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Opening",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Carpenter",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Core Four",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Halloween",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Laurie",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	SoldierBoy = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Helmet",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "WW2",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Rising",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Russia",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Sonic = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Sanic",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Excalibur",
			SortOrder = 2
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Speed = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Ben",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Low Tier",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Prime",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "RBLX",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Brazil",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Monk",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "World Cup",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	SpiderMan = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Webweaver",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "PS5",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Spider",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Homemade",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Raimi",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Spectacular",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Tasm2",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Springbonnie = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Yellow Rabbit",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Unmasked",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Media",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Arcade",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "The Rabbit",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Raglan",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Springtrap = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Scraptrap",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Plushtrap",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Clowntrap",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Purple Guy",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Bon",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	StarLight = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "New Suit",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Starlighters",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Undercover",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Fire",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Joi",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Steve = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Pumpkin",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Zombie",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Herobrine",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Alex",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Don't Mine At Night",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Jack",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Steve_H = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Messed Up",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Tunnel Bandit",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Ahoy",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Ugly Sweater",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Upside Down",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Demodogs",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "The Rightside Up",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Lake",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	SuperMan = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Ultraman",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Supergirl",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Hammer of Boravia",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Starman",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Tate = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Breaking Point",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Last Blow",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Skull Face",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Go Away Tate!",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Thirteen",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Thanos = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Philosopher",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Farmer",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Punisher",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Captain",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Ultron",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Evil Morty",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	TheBatman = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "The Drifter",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Caped Crusader",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Dark Knight",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Bat of Gotham",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Arkham Knight",
			SortOrder = 5
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	TheFlashCW = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "First Run",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Upgraded",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Golden Boots",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Past Future",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Kid Flash",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "ZSJL",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Batsuit",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Channeled",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Thragg = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Battle-Worn",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Pure Viltrumite",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Conquest",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Escape",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Lucan",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Anissa",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Thula",
			SortOrder = 7
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	TomSpider = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Homemade",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Homecoming",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Iron Spider",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Illusions",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Inside Out",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Peter-One",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Winter",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Small Potato Stuff",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Trinity = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Frank",
			SortOrder = 1
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Vecna = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "001",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Mr. Whatsit",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "The Sorcerer",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "The Forest",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "The Pit",
			SortOrder = 5
		}
	},
	Vigilante = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Arrow",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Deadpool",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Black Noir",
			SortOrder = 3
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Walter = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Pilot",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Heisenburg",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Hazardous",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Joker",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Masuka",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "Bones",
			SortOrder = 6
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Wanda = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Corrupted",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Halloween",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "838",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Zombie",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Avengers",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "60s",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Infinity War",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Cure",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Wednesday = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Goody",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Roommate",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "Dress",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Black Cats",
			SortOrder = 4
		},
		{
			Id = "Skin5",
			ModelName = "Skin5",
			FrameName = "Skin5",
			DisplayText = "Pilgrim",
			SortOrder = 5
		},
		{
			Id = "Skin6",
			ModelName = "Skin6",
			FrameName = "Skin6",
			DisplayText = "School",
			SortOrder = 6
		},
		{
			Id = "Skin7",
			ModelName = "Skin7",
			FrameName = "Skin7",
			DisplayText = "Blindfolded",
			SortOrder = 7
		},
		{
			Id = "Skin8",
			ModelName = "Skin8",
			FrameName = "Skin8",
			DisplayText = "Bodyswap",
			SortOrder = 8
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	},
	Zoom = {
		{
			Id = "Skin1",
			ModelName = "Skin1",
			FrameName = "Skin1",
			DisplayText = "Unmasked",
			SortOrder = 1
		},
		{
			Id = "Skin2",
			ModelName = "Skin2",
			FrameName = "Skin2",
			DisplayText = "Black Flash",
			SortOrder = 2
		},
		{
			Id = "Skin3",
			ModelName = "Skin3",
			FrameName = "Skin3",
			DisplayText = "EXE",
			SortOrder = 3
		},
		{
			Id = "Skin4",
			ModelName = "Skin4",
			FrameName = "Skin4",
			DisplayText = "Fake Garrick",
			SortOrder = 4
		},
		{
			Id = "Golden",
			ModelName = "Golden",
			FrameName = "Golden",
			DisplayText = "Golden",
			SortOrder = 9999
		}
	}
}
