-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local tweenService: TweenService = game:GetService("TweenService")
local uDim2 = UDim2.new(0, 0, 0, 0)
local uDim22 = UDim2.new(0, 0, 0.849, 0)
local uDim23 = UDim2.new(0, 0, -0.2, 0)
local uDim24 = UDim2.new(0, 0, 1, 0)

local function markRunStarted(p1, p2)
	local v11 = os.clock()
	local guiCopActiveRuns = p1:GetAttribute("GuiCopActiveRuns")

	if typeof(guiCopActiveRuns) ~= "number" then
		guiCopActiveRuns = 0
	end

	local v13 = math.max(0, guiCopActiveRuns)

	p1:SetAttribute("GuiCopActiveRuns", v13 + 1)
	p1:SetAttribute("GuiCopLastRunStartedAt", v11)
	p1:SetAttribute("GuiCopRunDeadlineAt", v11 + p2 + 1.5)
end
local function markRunEnded(p3)
	local guiCopActiveRuns = p3:GetAttribute("GuiCopActiveRuns")

	if typeof(guiCopActiveRuns) ~= "number" then
		guiCopActiveRuns = 0
	end

	local v16 = math.max(0, guiCopActiveRuns - 1)

	p3:SetAttribute("GuiCopActiveRuns", v16)
	p3:SetAttribute("GuiCopLastRunEndedAt", os.clock())

	if v16 <= 0 then
		p3:SetAttribute("GuiCopRunDeadlineAt", nil)
	end
end
local function tweenLine(p4, p5, p6)
	if not p4 or not p4:IsA("GuiObject") then
		return nil
	end

	local tweenInfo = TweenInfo.new(p6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
	local v21: Tween = tweenService:Create(p4, tweenInfo, { Position = p5 })

	v21:Play()

	return v21
end

return {
	Play = function(p7, p8, p9, p10)
		if typeof(p7) ~= "Instance" or not p7:IsA("Player") then
			return nil
		end

		if not p8 or not p8:IsA("ScreenGui") then
			return nil
		end

		local playerGui = p7:FindFirstChildOfClass("PlayerGui")

		if not playerGui then
			return nil
		end

		local numberValue: number? = tonumber(p9)
		local v28 = math.max(0, numberValue or 3)

		markRunStarted(playerGui, v28 + 0.75)

		local clone = p8:Clone()

		clone.Name = p10 or p8.Name
		clone.ResetOnSpawn = false
		clone:SetAttribute("BlackLineCinematicActive", true)
		clone.Parent = playerGui

		local foundChild = clone:FindFirstChild("BlackLineUp", true)
		local foundChild2 = clone:FindFirstChild("BlackLineDown", true)

		if foundChild and foundChild2 then
			tweenLine(foundChild, uDim2, 0.25)
			tweenLine(foundChild2, uDim22, 0.25)
			task.delay(v28, function()
				if not clone.Parent then
					markRunEnded(playerGui)

					return
				end

				tweenLine(foundChild, uDim23, 0.25)
				tweenLine(foundChild2, uDim24, 0.25)
				task.delay(0.35, function()
					if clone.Parent then
						clone.Parent = nil
					end

					markRunEnded(playerGui)
				end)
			end)

			return clone
		end

		clone.Parent = nil
		markRunEnded(playerGui)

		return nil
	end
}
