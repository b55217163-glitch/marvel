-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local color3 = Color3.fromRGB(65, 105, 225)
local color32 = Color3.fromRGB(65, 145, 255)
local color33 = Color3.fromRGB(230, 190, 85)
local color34 = Color3.fromRGB(90, 175, 255)
local color35 = Color3.fromRGB(255, 110, 185)
local color36 = Color3.fromRGB(120, 210, 255)
local color37 = Color3.fromRGB(170, 35, 45)
local color38 = Color3.fromRGB(255, 45, 45)
local color39 = Color3.fromRGB(45, 180, 125)
local color310 = Color3.fromRGB(65, 220, 145)
local color311 = Color3.fromRGB(180, 80, 85)
local color312 = Color3.fromRGB(205, 45, 45)
local color313 = Color3.fromRGB(255, 155, 45)
local color314 = Color3.fromRGB(120, 210, 255)
local color315 = Color3.fromRGB(230, 95, 135)
local color316 = Color3.fromRGB(90, 170, 105)
local color317 = Color3.fromRGB(185, 65, 55)
local color318 = Color3.fromRGB(145, 150, 160)
local color319 = Color3.fromRGB(235, 235, 240)
local color320 = Color3.fromRGB(255, 210, 95)
local color321 = Color3.fromRGB(235, 65, 65)
local color322 = Color3.fromRGB(23, 222, 99)
local color323 = Color3.fromRGB(255, 125, 30)
local color324 = Color3.fromRGB(255, 220, 60)
local color325 = Color3.fromRGB(120, 210, 255)
local color326 = Color3.fromRGB(235, 65, 50)
local color327 = Color3.fromRGB(120, 210, 255)
local color328 = Color3.fromRGB(130, 155, 110)
local color329 = Color3.fromRGB(220, 55, 55)
local color330 = Color3.fromRGB(95, 75, 150)
local color331 = Color3.fromRGB(205, 60, 55)
local color332 = Color3.fromRGB(220, 225, 235)
local color333 = Color3.fromRGB(245, 70, 60)
local color334 = Color3.fromRGB(120, 210, 255)
local color335 = Color3.fromRGB(235, 55, 75)
local color336 = Color3.fromRGB(120, 210, 255)
local color337 = Color3.fromRGB(235, 235, 220)
local color338 = Color3.fromRGB(75, 150, 255)
local color339 = Color3.fromRGB(190, 205, 220)
local color340 = Color3.fromRGB(120, 210, 255)
local color341 = Color3.fromRGB(220, 65, 65)
local color342 = Color3.fromRGB(155, 180, 215)
local color343 = Color3.fromRGB(120, 210, 255)
local color344 = Color3.fromRGB(235, 65, 55)
local color345 = Color3.fromRGB(255, 135, 55)
local color346 = Color3.fromRGB(105, 190, 255)
local color347 = Color3.fromRGB(150, 165, 85)
local color348 = Color3.fromRGB(255, 215, 40)
local color349 = Color3.fromRGB(95, 185, 85)
local color350 = Color3.fromRGB(205, 190, 155)
local color351 = Color3.fromRGB(111, 156, 196)
local color352 = Color3.fromRGB(160, 185, 225)
local color353 = Color3.fromRGB(100, 155, 85)
local color354 = Color3.fromRGB(50, 135, 255)
local color355 = Color3.fromRGB(240, 55, 65)
local color356 = Color3.fromRGB(255, 55, 55)
local color357 = Color3.fromRGB(225, 190, 65)
local color358 = Color3.fromRGB(145, 165, 65)
local color359 = Color3.fromRGB(255, 230, 130)
local color360 = Color3.fromRGB(50, 205, 205)
local color361 = Color3.fromRGB(100, 165, 230)
local color362 = Color3.fromRGB(65, 140, 255)
local color363 = Color3.fromRGB(120, 210, 255)
local color364 = Color3.fromRGB(165, 175, 190)
local color365 = Color3.fromRGB(240, 60, 50)
local color366 = Color3.fromRGB(205, 80, 85)
local color367 = Color3.fromRGB(160, 100, 255)
local color368 = Color3.fromRGB(245, 65, 55)
local color369 = Color3.fromRGB(120, 210, 255)
local color370 = Color3.fromRGB(185, 75, 75)
local color371 = Color3.fromRGB(60, 185, 205)
local color372 = Color3.fromRGB(175, 205, 65)
local color373 = Color3.fromRGB(255, 75, 125)
local color374 = Color3.fromRGB(41, 29, 53)
local color375 = Color3.fromRGB(75, 155, 255)

local function makeId(p1)
	return "Character_" .. tostring(p1):gsub("%W", "")
end
local function makeTierId(p2, p3)
	local replacedText = tostring(p2):gsub("%W", "")
	local numberValue: number? = tonumber(p3)
	local floored = math.floor(numberValue or 0)
	local v87 = math.max(0, floored)
	local text: string = tostring(v87)

	return "Character_" .. replacedText .. "_Tier_" .. text
end
local function normalizeTier(p4, p5, p6, p7)
	if typeof(p5) == "table" then
		local v93 = tonumber(p5.KillsRequired) or p6 or 1000
		local floored = math.floor(v93)
		local v95 = math.max(0, floored)
		local v96 = typeof(p5.TagText) == "string" and p5.TagText ~= "" and p5.TagText

		if not v96 then
			v96 = typeof(p4.TagText) == "string" and p4.TagText ~= "" and p4.TagText or p4.CharacterName
		end

		local v97 = typeof(p5.TagColor) == "Color3" and p5.TagColor

		if not v97 then
			v97 = typeof(p4.TagColor) == "Color3" and p4.TagColor or Color3.fromRGB(120, 210, 255)
		end

		local replacedText = tostring(p4.CharacterName):gsub("%W", "")
		local numberValue: number? = tonumber(v95)
		local floored2 = math.floor(numberValue or 0)
		local v101 = math.max(0, floored2)
		local text: string = tostring(v101)

		return {
			Id = "Character_" .. replacedText .. "_Tier_" .. text,
			Text = v96,
			Color = v97,
			KillsRequired = v95,
			Order = p7 or v95
		}
	end

	return nil
end
local function buildTiers(p8, p9)
	local t2: {[any]: any} = {}

	if typeof(p8.Tiers) == "table" then
		for i = 1, #p8.Tiers do
			local v107 = normalizeTier(p8, p8.Tiers[i], p9, i)

			if v107 then
				t2[#t2 + 1] = v107
			end
		end
	end

	if #t2 == 0 then
		t2[1] = normalizeTier(p8, { KillsRequired = p9, TagText = p8.TagText, TagColor = p8.TagColor }, p9, 1)
	end

	table.sort(t2, function(p10, p11)
		if p10.KillsRequired == p11.KillsRequired then
			return p10.Order < p11.Order
		end

		return p10.KillsRequired < p11.KillsRequired
	end)

	return t2
end

local module: {[any]: any} = {
	List = {
		{
			CharacterName = "2099",
			TagText = "2099",
			TagColor = color3,
			Tiers = {
				{ KillsRequired = 1000, TagText = "2099" },
				{ KillsRequired = 2000, TagText = "BluePanther" },
				{ KillsRequired = 3000, TagText = "MachoLibre" }
			}
		},
		{
			CharacterName = "A-Train",
			TagText = "A-Train",
			TagColor = color32,
			Tiers = {
				{ KillsRequired = 1000, TagText = "A-Train" },
				{ KillsRequired = 2000, TagText = "MrFleetFeet" },
				{ KillsRequired = 3000, TagText = "Slipstream" }
			}
		},
		{
			CharacterName = "Amazo",
			TagText = "A.m.a.z.o.",
			TagColor = color33,
			Tiers = {
				{ KillsRequired = 1000, TagText = "A.m.a.z.o." },
				{ KillsRequired = 2000, TagText = "Android" },
				{ KillsRequired = 3000, TagText = "AmazoPrime" }
			}
		},
		{
			CharacterName = "Anakin",
			TagText = "Anakin",
			TagColor = color34,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Anakin" },
				{ KillsRequired = 2000, TagText = "FallenAngel" },
				{ KillsRequired = 3000, TagText = "LordVader" }
			}
		},
		{
			CharacterName = "AtomEve",
			TagText = "AtomEve",
			TagColor = color35,
			Tiers = {
				{ KillsRequired = 1000, TagText = "AtomEve" },
				{ KillsRequired = 2000, TagText = "PhaseOne" },
				{ KillsRequired = 3000, TagText = "TheMighty" }
			}
		},
		{
			CharacterName = "Billy",
			TagText = "Billy",
			TagColor = color36,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Billy" },
				{ KillsRequired = 2000, TagText = "Wanted" },
				{ KillsRequired = 3000, TagText = "WoodsboroKiller" }
			}
		},
		{
			CharacterName = "Brian",
			TagText = "Brian",
			TagColor = color37,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Brian" },
				{ KillsRequired = 2000, TagText = "RudyCooper" },
				{ KillsRequired = 3000, TagText = "IceTruckKiller" }
			}
		},
		{
			CharacterName = "DarthVader",
			TagText = "DarthVader",
			TagColor = color38,
			Tiers = {
				{ KillsRequired = 1000, TagText = "DarthVader" },
				{ KillsRequired = 2000, TagText = "SithLord" },
				{ KillsRequired = 3000, TagText = "ChosenOne" }
			}
		},
		{
			CharacterName = "Deep",
			TagText = "Deep",
			TagColor = color39,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Deep" },
				{ KillsRequired = 2000, TagText = "LordSevenSeas" },
				{ KillsRequired = 3000, TagText = "PeakOfEvolution" }
			}
		},
		{
			CharacterName = "Deku",
			TagText = "Deku",
			TagColor = color310,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Deku" },
				{ KillsRequired = 2000, TagText = "Midoriya" },
				{ KillsRequired = 3000, TagText = "TheNinth" }
			}
		},
		{
			CharacterName = "Demogorgon",
			TagText = "Demogorgon",
			TagColor = color311,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Demogorgon" },
				{ KillsRequired = 2000, TagText = "TheMonster" },
				{ KillsRequired = 3000, TagText = "UpsideDown" }
			}
		},
		{
			CharacterName = "Dexter",
			TagText = "Dexter",
			TagColor = color312,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Dexter" },
				{ KillsRequired = 2000, TagText = "DarkPassenger" },
				{ KillsRequired = 3000, TagText = "BayHarborButcher" }
			}
		},
		{
			CharacterName = "DoctorStrange",
			TagText = "DoctorStrange",
			TagColor = color313,
			Tiers = {
				{ KillsRequired = 1000, TagText = "DoctorStrange" },
				{ KillsRequired = 2000, TagText = "MysticMaster" },
				{ KillsRequired = 3000, TagText = "SorcererSupreme" }
			}
		},
		{
			CharacterName = "Eddie",
			TagText = "Eddie",
			TagColor = color314,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Eddie" },
				{ KillsRequired = 2000, TagText = "EddieMunson" },
				{ KillsRequired = 3000, TagText = "TheBanished" }
			}
		},
		{
			CharacterName = "Eleven",
			TagText = "Eleven",
			TagColor = color315,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Eleven" },
				{ KillsRequired = 2000, TagText = "JHopper" },
				{ KillsRequired = 3000, TagText = "011" }
			}
		},
		{
			CharacterName = "Eren",
			TagText = "Eren",
			TagColor = color316,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Eren" },
				{ KillsRequired = 2000, TagText = "Yeagerist" },
				{ KillsRequired = 3000, TagText = "FoundingTitan" }
			}
		},
		{
			CharacterName = "Freddy",
			TagText = "Freddy",
			TagColor = color317,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Freddy" },
				{ KillsRequired = 2000, TagText = "Animatronic" },
				{ KillsRequired = 3000, TagText = "Fazbear" }
			}
		},
		{
			CharacterName = "FrontMan",
			TagText = "FrontMan",
			TagColor = color318,
			Tiers = {
				{ KillsRequired = 1000, TagText = "FrontMan" },
				{ KillsRequired = 2000, TagText = "132" },
				{ KillsRequired = 3000, TagText = "InHo" }
			}
		},
		{
			CharacterName = "Ghostface",
			TagText = "Ghostface",
			TagColor = color319,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Ghostface" },
				{ KillsRequired = 2000, TagText = "Scream" },
				{ KillsRequired = 3000, TagText = "FatherDeath" }
			}
		},
		{
			CharacterName = "GigaChad",
			TagText = "GigaChad",
			RequiresCharacterOwnership = true,
			KillsRequired = 1500,
			TagColor = color320,
			Tiers = {
				{ KillsRequired = 1500, TagText = "GigaChad" },
				{ KillsRequired = 2500, TagText = "Chad" },
				{ KillsRequired = 3500, TagText = "CanYouFeelMyHeart" }
			}
		},
		{
			CharacterName = "Homelander",
			TagText = "Homelander",
			TagColor = color321,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Homelander" },
				{ KillsRequired = 2000, TagText = "ImBetter" },
				{ KillsRequired = 3000, TagText = "ManInTheSky" }
			}
		},
		{
			CharacterName = "Hal",
			TagText = "Hal",
			TagColor = color322,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Hal" },
				{ KillsRequired = 2000, TagText = "JordanBoy" },
				{ KillsRequired = 3000, TagText = "Lantern" }
			}
		},
		{
			CharacterName = "HumanTorch",
			TagText = "JohnnyStorm",
			TagColor = color323,
			Tiers = {
				{ KillsRequired = 1000, TagText = "JohnnyStorm" },
				{ KillsRequired = 2000, TagText = "HumanTorch" },
				{ KillsRequired = 3000, TagText = "Supernova" }
			}
		},
		{
			CharacterName = "Invincible",
			TagText = "Invincible",
			TagColor = color324,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Invincible" },
				{ KillsRequired = 2000, TagText = "TitleCard" },
				{ KillsRequired = 3000, TagText = "EmperorMark" }
			}
		},
		{
			CharacterName = "Iris",
			TagText = "Iris",
			TagColor = color325,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Iris" },
				{ KillsRequired = 2000, TagText = "BeepBoop" },
				{ KillsRequired = 3000, TagText = "Companion" }
			}
		},
		{
			CharacterName = "IronMan",
			TagText = "IronMan",
			TagColor = color326,
			Tiers = {
				{ KillsRequired = 1000, TagText = "IronMan" },
				{ KillsRequired = 2000, TagText = "Stark" },
				{ KillsRequired = 3000, TagText = "BillionairePlayboy" }
			}
		},
		{
			CharacterName = "Jeff",
			TagText = "JeffTheKiller",
			TagColor = color327,
			Tiers = {
				{ KillsRequired = 1000, TagText = "JeffTheKiller" },
				{ KillsRequired = 2000, TagText = "Bleached" },
				{ KillsRequired = 3000, TagText = "UrbanMyth" }
			}
		},
		{
			CharacterName = "Joe",
			TagText = "Joe",
			TagColor = color328,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Joe" },
				{ KillsRequired = 2000, TagText = "Bettelheim" },
				{ KillsRequired = 3000, TagText = "EatTheRich" }
			}
		},
		{
			CharacterName = "Kira",
			TagText = "Light",
			TagColor = color329,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Light" },
				{ KillsRequired = 2000, TagText = "Kira" },
				{ KillsRequired = 3000, TagText = "NewWorldGod" }
			}
		},
		{ CharacterName = "Ryuk", TagText = "Ryuk", TagColor = color330 },
		{
			CharacterName = "Kratos",
			TagText = "Kratos",
			TagColor = color331,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Kratos" },
				{ KillsRequired = 2000, TagText = "GhostOfSparta" },
				{ KillsRequired = 3000, TagText = "GodOfWar" }
			}
		},
		{
			CharacterName = "Lawliet",
			TagText = "Lawliet",
			TagColor = color332,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Lawliet" },
				{ KillsRequired = 2000, TagText = "L" },
				{ KillsRequired = 3000, TagText = "GreatDetective" }
			}
		},
		{
			CharacterName = "Luffy",
			TagText = "Luffy",
			TagColor = color333,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Luffy" },
				{ KillsRequired = 2000, TagText = "StrawHat" },
				{ KillsRequired = 3000, TagText = "PirateKing" }
			}
		},
		{
			CharacterName = "Michael",
			TagText = "Michael",
			TagColor = color334,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Michael" },
				{ KillsRequired = 2000, TagText = "SmoothCriminal" },
				{ KillsRequired = 3000, TagText = "KingOfPop" }
			}
		},
		{
			CharacterName = "Miles",
			TagText = "Miles",
			TagColor = color335,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Miles" },
				{ KillsRequired = 2000, TagText = "Venomous" },
				{ KillsRequired = 3000, TagText = "LeapOfFaith" }
			}
		},
		{
			CharacterName = "Mohawk",
			TagText = "Mohawk",
			TagColor = color336,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Mohawk" },
				{ KillsRequired = 2000, TagText = "Sanguinary" },
				{ KillsRequired = 3000, TagText = "Conqueror" }
			}
		},
		{
			CharacterName = "MoonKnight",
			TagText = "MoonKnight",
			TagColor = color337,
			Tiers = {
				{ KillsRequired = 1000, TagText = "MoonKnight" },
				{ KillsRequired = 2000, TagText = "Lunatic" },
				{ KillsRequired = 3000, TagText = "FistOfKhonshu" }
			}
		},
		{
			CharacterName = "MrFantastic",
			TagText = "MrFantastic",
			TagColor = color338,
			Tiers = {
				{ KillsRequired = 1000, TagText = "MrFantastic" },
				{ KillsRequired = 2000, TagText = "ReedRichards" },
				{ KillsRequired = 3000, TagText = "SmartestMan" }
			}
		},
		{
			CharacterName = "Myers",
			TagText = "Myers",
			TagColor = color339,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Myers" },
				{ KillsRequired = 2000, TagText = "Boogeyman" },
				{ KillsRequired = 3000, TagText = "TheShape" }
			}
		},
		{
			CharacterName = "Nikki",
			TagText = "Nikki",
			TagColor = color340,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Nikki" },
				{ KillsRequired = 2000, TagText = "WishWillow" },
				{ KillsRequired = 3000, TagText = "Freaky" }
			}
		},
		{
			CharacterName = "OmniMan",
			TagText = "OmniMan",
			TagColor = color341,
			Tiers = {
				{ KillsRequired = 1000, TagText = "OmniMan" },
				{ KillsRequired = 2000, TagText = "NolanGrayson" },
				{ KillsRequired = 3000, TagText = "GreatNolan" }
			}
		},
		{
			CharacterName = "Patrick",
			TagText = "Patrick",
			TagColor = color342,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Patrick" },
				{ KillsRequired = 2000, TagText = "PaulAllen" },
				{ KillsRequired = 3000, TagText = "AmericanPsycho" }
			}
		},
		{
			CharacterName = "Paul",
			TagText = "Paul",
			TagColor = color343,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Paul" },
				{ KillsRequired = 2000, TagText = "MuadDib" },
				{ KillsRequired = 3000, TagText = "LisanAlGaib" }
			}
		},
		{
			CharacterName = "Peacemaker",
			TagText = "Peacemaker",
			TagColor = color344,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Peacemaker" },
				{ KillsRequired = 2000, TagText = "Poser" },
				{ KillsRequired = 3000, TagText = "Invisible" }
			}
		},
		{
			CharacterName = "Pennywise",
			TagText = "Pennywise",
			TagColor = color345,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Pennywise" },
				{ KillsRequired = 2000, TagText = "DancingClown" },
				{ KillsRequired = 3000, TagText = "IT" }
			}
		},
		{
			CharacterName = "Pibby",
			TagText = "Pibby",
			TagColor = color346,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Pibby" },
				{ KillsRequired = 2000, TagText = "Survivor" },
				{ KillsRequired = 3000, TagText = "Darkness" }
			}
		},
		{
			CharacterName = "Rambo",
			TagText = "Rambo",
			TagColor = color347,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Rambo" },
				{ KillsRequired = 2000, TagText = "JohnRambo" },
				{ KillsRequired = 3000, TagText = "FirstBlood" }
			}
		},
		{
			CharacterName = "ReverseFlash",
			TagText = "ReverseFlash",
			TagColor = color348,
			Tiers = {
				{ KillsRequired = 1000, TagText = "ReverseFlash" },
				{ KillsRequired = 2000, TagText = "Thawne" },
				{ KillsRequired = 3000, TagText = "NegativeForce" }
			}
		},
		{
			CharacterName = "Riddler",
			TagText = "Riddler",
			TagColor = color349,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Riddler" },
				{ KillsRequired = 2000, TagText = "RiddleMeThis" },
				{ KillsRequired = 3000, TagText = "<?>" }
			}
		},
		{
			CharacterName = "SCP-173",
			TagText = "SCP-173",
			TagColor = color350,
			Tiers = {
				{ KillsRequired = 1000, TagText = "SCP-173" },
				{ KillsRequired = 2000, TagText = "TheSculpture" },
				{ KillsRequired = 3000, TagText = "NeckBreaker" }
			}
		},
		{
			CharacterName = "SCPGuard",
			TagText = "SCPGuard",
			TagColor = color351,
			Tiers = {
				{ KillsRequired = 1000, TagText = "SCPGuard" },
				{ KillsRequired = 2000, TagText = "RRT" },
				{ KillsRequired = 3000, TagText = "MTF" }
			}
		},
		{
			CharacterName = "Sidney",
			TagText = "Sidney",
			TagColor = color352,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Sidney" },
				{ KillsRequired = 2000, TagText = "FinalGirl" },
				{ KillsRequired = 3000, TagText = "ScreamQueen" }
			}
		},
		{
			CharacterName = "SoldierBoy",
			TagText = "SoldierBoy",
			TagColor = color353,
			Tiers = {
				{ KillsRequired = 1000, TagText = "SoldierBoy" },
				{ KillsRequired = 2000, TagText = "FirstSupe" },
				{ KillsRequired = 3000, TagText = "GrandDad" }
			}
		},
		{
			CharacterName = "Sonic",
			TagText = "Sonic",
			TagColor = color354,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Sonic" },
				{ KillsRequired = 2000, TagText = "BlueBlur" },
				{ KillsRequired = 3000, TagText = "BlueJustice" }
			}
		},
		{
			CharacterName = "SpiderMan",
			TagText = "SpiderMan",
			TagColor = color355,
			Tiers = {
				{ KillsRequired = 1000, TagText = "SpiderMan" },
				{ KillsRequired = 2000, TagText = "PeterParker" },
				{ KillsRequired = 3000, TagText = "WebSlinger" }
			}
		},
		{
			CharacterName = "Speed",
			TagText = "Speed",
			RequiresCharacterOwnership = true,
			KillsRequired = 1500,
			TagColor = color356,
			Tiers = {
				{ KillsRequired = 1500, TagText = "Speed" },
				{ KillsRequired = 2500, TagText = "IShowSpeed" },
				{ KillsRequired = 3500, TagText = "SUI" }
			}
		},
		{
			CharacterName = "Springbonnie",
			TagText = "Springbonnie",
			TagColor = color357,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Springbonnie" },
				{ KillsRequired = 2000, TagText = "Afton" },
				{ KillsRequired = 3000, TagText = "BehindSlaughter" }
			}
		},
		{
			CharacterName = "Springtrap",
			TagText = "Springtrap",
			TagColor = color358,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Springlocked" },
				{ KillsRequired = 2000, TagText = "TheYellowRabbit" },
				{ KillsRequired = 3000, TagText = "Everlasting" }
			}
		},
		{
			CharacterName = "StarLight",
			TagText = "StarLight",
			TagColor = color359,
			Tiers = {
				{ KillsRequired = 1000, TagText = "StarLight" },
				{ KillsRequired = 2000, TagText = "January" },
				{ KillsRequired = 3000, TagText = "Glowing" }
			}
		},
		{
			CharacterName = "Steve",
			TagText = "Steve",
			TagColor = color360,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Steve" },
				{ KillsRequired = 2000, TagText = "CreativeMode" },
				{ KillsRequired = 3000, TagText = "Herobrine" }
			}
		},
		{
			CharacterName = "Steve_H",
			TagText = "Steve_H",
			TagColor = color361,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Steve_H" },
				{ KillsRequired = 2000, TagText = "TheBabysitter" },
				{ KillsRequired = 3000, TagText = "KingSteve" }
			}
		},
		{
			CharacterName = "SuperMan",
			TagText = "SuperMan",
			TagColor = color362,
			Tiers = {
				{ KillsRequired = 1000, TagText = "SuperMan" },
				{ KillsRequired = 2000, TagText = "LastSon" },
				{ KillsRequired = 3000, TagText = "ManOfTomorrow" }
			}
		},
		{
			CharacterName = "Tate",
			TagText = "Tate",
			TagColor = color363,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Tate" },
				{ KillsRequired = 2000, TagText = "Langdon" },
				{ KillsRequired = 3000, TagText = "RubberMan" }
			}
		},
		{
			CharacterName = "TheBatman",
			TagText = "TheBatman",
			TagColor = color364,
			Tiers = {
				{ KillsRequired = 1000, TagText = "TheBatman" },
				{ KillsRequired = 2000, TagText = "Vengeance" },
				{ KillsRequired = 3000, TagText = "DarkKnight" }
			}
		},
		{
			CharacterName = "TheFlashCW",
			TagText = "TheFlash",
			TagColor = color365,
			Tiers = {
				{ KillsRequired = 1000, TagText = "TheFlash" },
				{ KillsRequired = 2000, TagText = "SpeedForce" },
				{ KillsRequired = 3000, TagText = "FastestMan" }
			}
		},
		{
			CharacterName = "Thragg",
			TagText = "Thragg",
			TagColor = color366,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Thragg" },
				{ KillsRequired = 2000, TagText = "ViltrumLeader" },
				{ KillsRequired = 3000, TagText = "GrandRegent" }
			}
		},
		{
			CharacterName = "Thanos",
			TagText = "Thanos",
			RequiresCharacterOwnership = true,
			KillsRequired = 2000,
			TagColor = color367,
			Tiers = {
				{ KillsRequired = 2000, TagText = "Thanos" },
				{ KillsRequired = 3000, TagText = "MadTitan" },
				{ KillsRequired = 4000, TagText = "Inevitable" }
			}
		},
		{
			CharacterName = "TomSpider",
			TagText = "TomSpider",
			TagColor = color368,
			Tiers = {
				{ KillsRequired = 1000, TagText = "TomSpider" },
				{ KillsRequired = 2000, TagText = "Maynard" },
				{ KillsRequired = 3000, TagText = "PeterOne" }
			}
		},
		{
			CharacterName = "Trinity",
			TagText = "Trinity",
			TagColor = color369,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Trinity" },
				{ KillsRequired = 2000, TagText = "FamilyMan" },
				{ KillsRequired = 3000, TagText = "ManOfThree" }
			}
		},
		{
			CharacterName = "Vecna",
			TagText = "Vecna",
			TagColor = color370,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Vecna" },
				{ KillsRequired = 2000, TagText = "HenryCreel" },
				{ KillsRequired = 3000, TagText = "One" }
			}
		},
		{
			CharacterName = "Vigilante",
			TagText = "Vigilante",
			TagColor = color371,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Vigilante" },
				{ KillsRequired = 2000, TagText = "DCDeadpool" },
				{ KillsRequired = 3000, TagText = "Mermaid" }
			}
		},
		{
			CharacterName = "Walter",
			TagText = "Walter",
			TagColor = color372,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Walter" },
				{ KillsRequired = 2000, TagText = "Heisenberg" },
				{ KillsRequired = 3000, TagText = "OneWhoKnocks" }
			}
		},
		{
			CharacterName = "Wanda",
			TagText = "Maximoff",
			RequiresCharacterOwnership = true,
			KillsRequired = 1500,
			TagColor = color373,
			Tiers = {
				{ KillsRequired = 1500, TagText = "Maximoff" },
				{ KillsRequired = 2500, TagText = "ScarletWitch" },
				{ KillsRequired = 3500, TagText = "QueenOfChaos" }
			}
		},
		{
			CharacterName = "Wednesday",
			TagText = "Wednesday",
			TagColor = color374,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Wednesday" },
				{ KillsRequired = 2000, TagText = "Bombita" },
				{ KillsRequired = 3000, TagText = "ChildOfWoe" }
			}
		},
		{
			CharacterName = "Zoom",
			TagText = "Zoom",
			TagColor = color375,
			Tiers = {
				{ KillsRequired = 1000, TagText = "Zoom" },
				{ KillsRequired = 2000, TagText = "SpeedAddict" },
				{ KillsRequired = 3000, TagText = "SpeedDemon" }
			}
		}
	},
	GetId = function(p12)
		return "Character_" .. tostring(p12):gsub("%W", "")
	end,
	GetTierId = function(p13, p14)
		local replacedText = tostring(p13):gsub("%W", "")
		local numberValue: number? = tonumber(p14)
		local floored = math.floor(numberValue or 0)
		local v114 = math.max(0, floored)
		local text: string = tostring(v114)

		return "Character_" .. replacedText .. "_Tier_" .. text
	end,
	GetTierForKills = function(p15, p16)
		if typeof(p15) == "table" then
			local v118 = typeof(p15.Tiers) == "table" and p15.Tiers or nil

			if v118 and #v118 ~= 0 then
				local numberValue: number? = tonumber(p16)
				local floored = math.floor(numberValue or 0)
				local v121 = math.max(0, floored)
				local v122 = nil

				for i = 1, #v118 do
					local v124 = v118[i]
					local numberValue2: number? = tonumber(v124.KillsRequired)
					local floored3 = math.floor(numberValue2 or 0)
					local v127 = math.max(0, floored3)

					if not (v121 >= v127) then
						break
					end

					v122 = v124
				end

				return v122
			end

			return nil
		end

		return nil
	end,
	GetNextTierForKills = function(p17, p18)
		if typeof(p17) == "table" then
			local v130 = typeof(p17.Tiers) == "table" and p17.Tiers or nil

			if v130 and #v130 ~= 0 then
				local numberValue: number? = tonumber(p18)
				local floored = math.floor(numberValue or 0)
				local v133 = math.max(0, floored)

				for i = 1, #v130 do
					local v135 = v130[i]
					local numberValue3: number? = tonumber(v135.KillsRequired)
					local floored4 = math.floor(numberValue3 or 0)
					local v138 = math.max(0, floored4)

					if v133 < v138 then
						return v135
					end
				end

				return nil
			end

			return nil
		end

		return nil
	end
}

function module.GetAll()
	local t3: {[any]: any} = {}

	for i = 1, #module.List do
		local v141 = module.List[i]

		if typeof(v141) == "table" and typeof(v141.CharacterName) == "string" and v141.CharacterName ~= "" then
			local numberValue: number? = tonumber(v141.KillsRequired)
			local floored = math.floor(numberValue or 1000)
			local v144 = math.max(0, floored)
			local v145 = buildTiers(v141, v144)

			for j = 1, #v145 do
				local v147 = v145[j]

				t3[#t3 + 1] = {
					Kind = "Character",
					Id = j == 1 and "Character_" .. tostring(v141.CharacterName):gsub("%W", "") or v147.Id,
					CharacterName = v141.CharacterName,
					Text = v147.Text,
					Color = v147.Color,
					RequiresCharacterOwnership = if v141.RequiresCharacterOwnership == true then true else false,
					KillsRequired = v147.KillsRequired,
					TierIndex = j,
					Order = i + 40 + (j - 1) / 10
				}
			end
		end
	end

	return t3
end

return module
