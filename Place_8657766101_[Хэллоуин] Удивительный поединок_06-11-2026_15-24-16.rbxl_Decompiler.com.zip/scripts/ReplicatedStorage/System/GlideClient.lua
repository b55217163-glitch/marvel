-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local tweenService: TweenService = game:GetService("TweenService")
local workspace: Workspace = game:GetService("Workspace")
local wind: Instance = game:GetService("ReplicatedStorage"):WaitForChild("System"):WaitForChild("ClientEffectModules"):WaitForChild("TheBatman"):WaitForChild("Glide"):FindFirstChild("Wind")

local function callGetter(p1, p2)
	if typeof(p1) == "function" then
		local ok, result = pcall(p1)

		if ok then
			return result
		end

		return p2
	end

	return p2
end
local function callSetter(p3, p4)
	if typeof(p3) == "function" then
		pcall(p3, p4)
	end
end
local function isAccessoryDescendant(p5)
	local v23 = p5

	while v23 and v23 ~= workspace do
		if v23:IsA("Accessory") then
			return true
		end

		v23 = v23.Parent
	end

	return false
end
local function cleanupBodyMovers(p6)
	if not p6 then
		return
	end

	for _, v in ipairs(p6:GetDescendants()) do
		local v27 = v
		local u28

		while v27 and v27 ~= workspace do
			if v27:IsA("Accessory") then
				u28 = true

				break
			end

			v27 = v27.Parent
		end

		if not v27 or v27 == workspace then
			u28 = false
		end

		if not u28 and (not not v:IsA("BodyVelocity") or not not v:IsA("BodyPosition") or not not v:IsA("BodyForce")) then
			v:Destroy()
		end
	end
end
local function getCharacterMass(p7)
	local n1 = 0

	for _, v in ipairs(p7:GetDescendants()) do
		if v:IsA("BasePart") then
			local v33 = v:GetMass()

			n1 += v33
		end
	end

	return n1
end
local function isTooCloseToGround(p8, p9)
	local humanoidRootPart = p8 and p8:FindFirstChild("HumanoidRootPart")

	if not humanoidRootPart then
		return true
	end

	local raycastParams = RaycastParams.new()

	raycastParams.FilterType = Enum.RaycastFilterType.Exclude
	raycastParams.FilterDescendantsInstances = { p8 }
	raycastParams.IgnoreWater = true

	local humanoidRootPartPosition = humanoidRootPart.Position
	local vector3 = Vector3.new(0, -p9, 0)

	return workspace:Raycast(humanoidRootPartPosition, vector3, raycastParams) ~= nil
end
local function hasGroundBelow(p10, p11)
	local humanoidRootPart = p10 and p10:FindFirstChild("HumanoidRootPart")

	if not humanoidRootPart then
		return false
	end

	local raycastParams = RaycastParams.new()

	raycastParams.FilterType = Enum.RaycastFilterType.Exclude
	raycastParams.FilterDescendantsInstances = { p10 }
	raycastParams.IgnoreWater = true

	local humanoidRootPartPosition = humanoidRootPart.Position
	local vector3 = Vector3.new(0, -p11, 0)

	return workspace:Raycast(humanoidRootPartPosition, vector3, raycastParams) ~= nil
end
local function getFlatDirection(p12, p13)
	local vector3 = Vector3.new(p12.X, 0, p12.Z)

	if vector3.Magnitude > 0.05 then
		return vector3.Unit
	end

	local vector32 = Vector3.new(p13.X, 0, p13.Z)

	if vector32.Magnitude > 0.05 then
		return vector32.Unit
	end

	return Vector3.new(0, 0, -1)
end
local function getGlideVelocity(p14, p15, p16, p17)
	local lookVector = p15.CFrame.LookVector
	local v55 = math.clamp(lookVector.Y, -1, 1)
	local v56 = math.clamp(-v55, 0, 1)
	local v57 = math.clamp(v55, 0, 1)
	local v58 = p14.CFrame.LookVector
	local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)
	local v60

	if vector3.Magnitude > 0.05 then
		v60 = vector3.Unit
	else
		local vector33 = Vector3.new(v58.X, 0, v58.Z)

		v60 = if vector33.Magnitude > 0.05 then vector33.Unit else Vector3.new(0, 0, -1)
	end

	local v62 = math.max(0.35, 1 + v56 * (p17.DiveForwardBoost or 0.45) - v57 * (p17.ClimbForwardPenalty or 0.35))
	local v63 = p17.MinDescentSpeed or 8
	local v64 = math.min(-v63 - v56 * (p17.DiveDescentBoost or 70) + v57 * v63 * 0.75, p17.MaxUpwardSpeed or -2)
	local vector34 = Vector3.new(0, v64, 0)

	return v60 * (p16 * v62) + vector34
end
local function setCameraFov(p18, p19)
	local CurrentCamera: Camera = workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local tweenInfo = TweenInfo.new(p19, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

	tweenService:Create(CurrentCamera, tweenInfo, { FieldOfView = p18 }):Play()
end
local function startGlideWindLoop(p20, p21, p22)
	if p22.PlayWindLoop == false then
		return nil
	end

	local v73 = p22.WindSound or p22.WindSoundTemplate or wind

	if not v73 or not v73:IsA("Sound") then
		return nil
	end

	local parent = p22.WindSoundParent or p21 or p20:FindFirstChild("HumanoidRootPart") or p20:FindFirstChild("Head")

	if not parent then
		return nil
	end

	local foundChild = parent:FindFirstChild(p22.WindSoundName or "GlideWindLoop")

	if foundChild and foundChild:IsA("Sound") then
		foundChild:Stop()
		foundChild.Parent = nil
	end

	local clone = v73:Clone()

	clone.Name = p22.WindSoundName or "GlideWindLoop"
	clone.Looped = true

	local v77 = clone.Volume

	if p22.WindVolume then
		v77 = p22.WindVolume
	elseif v77 <= 0 then
		v77 = 0.45
	end

	clone.Volume = 0
	clone.Parent = parent
	clone:Play()

	local tweenInfo = TweenInfo.new(p22.WindFadeInTime or 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

	tweenService:Create(clone, tweenInfo, { Volume = v77 }):Play()

	return clone
end
local function stopGlideWindLoop(p23, p24)
	if not p23 then
		return
	end

	local tweenInfo = TweenInfo.new(p24 and p24.WindFadeOutTime or 0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v82: Tween = tweenService:Create(p23, tweenInfo, { Volume = 0 })

	v82:Play()
	v82.Completed:Wait()

	if p23 then
		p23:Stop()
		p23.Parent = nil
	end
end

return {
	Start = function(p25)
		local t1 = p25 or {}
		local Character = t1.Character
		local Humanoid = t1.Humanoid
		local player = t1.Player
		local v88 = t1.Skydive or t1.Remote
		local v89 = t1.GlideTrack or t1.GlideAnimation
		local UserInputService = t1.UserInputService
		local v91 = t1.GroundRayDistance or 10
		local v92 = t1.StopGroundRayDistance or 5

		if Character and Humanoid then
			local humanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
			local head = Character:FindFirstChild("Head")

			if humanoidRootPart and head then
				if Humanoid:GetState() ~= Enum.HumanoidStateType.Freefall then
					return false, "Not in freefall."
				end

				local getGlideCd = t1.GetGlideCd
				local v96

				if typeof(getGlideCd) == "function" then
					local ok, result = pcall(getGlideCd)

					v96 = if ok then result else false
				else
					v96 = false
				end

				if not v96 then
					local getCantGlide = t1.GetCantGlide
					local v100

					if typeof(getCantGlide) == "function" then
						local ok, result = pcall(getCantGlide)

						v100 = if ok then result else false
					else
						v100 = false
					end

					if not v100 and not Character:FindFirstChild("Hanging") then
						local getDeb = t1.GetDeb
						local v104

						if typeof(getDeb) == "function" then
							local ok, result = pcall(getDeb)

							v104 = if ok then result else false
						else
							v104 = false
						end

						if not v104 and not Character:FindFirstChild("Cantattack") and not Character:FindFirstChild("CantAttack") then
							local getGlide = t1.GetGlide
							local v108

							if typeof(getGlide) == "function" then
								local ok, result = pcall(getGlide)

								v108 = if ok then result else false
							else
								v108 = false
							end

							if v108 then
								return false, "Character is busy."
							end

							if isTooCloseToGround(Character, v91) then
								return false, "Too close to ground."
							end

							if typeof(t1.OnBeforeStart) == "function" then
								local ok, result = pcall(t1.OnBeforeStart)

								if not ok then
									warn("GlideClient OnBeforeStart failed:", result)
								end
							end

							local v113 = startGlideWindLoop(Character, humanoidRootPart, t1)

							cleanupBodyMovers(Character)

							local v114 = getCharacterMass(Character)
							local v115 = time()
							local v116 = t1.DefaultFov or 70
							local v117 = t1.GlideFov or 120
							local v118 = t1.Velocity or 130
							local v119 = t1.GlidingSpeed or t1.MaxForce or 4000000
							local v120 = t1.MaxDuration or 15
							local setGlideCd = t1.SetGlideCd

							if typeof(setGlideCd) == "function" then
								pcall(setGlideCd, true)
							end

							local setGlide = t1.SetGlide

							if typeof(setGlide) == "function" then
								pcall(setGlide, true)
							end

							setCameraFov(v117, t1.FovInTime or 1)

							if v88 then
								v88:FireServer(player)
							end

							if v89 then
								v89:Play(t1.AnimationFadeIn or 0.1)
							end

							local glideBodyForce: BodyForce = Instance.new("BodyForce")

							glideBodyForce.Name = "GlideBodyForce"
							glideBodyForce.Force = Vector3.new(0, v114 * workspace.Gravity, 0)
							glideBodyForce.Parent = humanoidRootPart

							local glideBodyVelocity: BodyVelocity = Instance.new("BodyVelocity")

							glideBodyVelocity.Name = "GlideBodyVelocity"
							glideBodyVelocity.MaxForce = Vector3.new(1, 1, 1) * v119
							glideBodyVelocity.Velocity = humanoidRootPart.AssemblyLinearVelocity
							glideBodyVelocity.Parent = humanoidRootPart
							v119 = false

							while true do
								task.wait(t1.UpdateInterval or 0.1)

								if not Character.Parent or not humanoidRootPart.Parent or not head.Parent or not glideBodyVelocity.Parent then
									break
								end

								local v125 = Humanoid:GetState()

								if v125 == Enum.HumanoidStateType.Landed or v125 == Enum.HumanoidStateType.Running or v125 == Enum.HumanoidStateType.RunningNoPhysics then
									v119 = true
								end

								if t1.CheckGroundDuringGlide ~= false and isTooCloseToGround(Character, v92) then
									v119 = true
								end

								if t1.RequireGroundBelow == true and not hasGroundBelow(Character, t1.GroundBelowDistance or 500) then
									v119 = true
								end

								if not v119 then
									local v126 = getGlideVelocity(humanoidRootPart, head, v118, t1)
									local v127 = glideBodyVelocity.Velocity

									if v127.Magnitude < 1 then
										v127 = humanoidRootPart.AssemblyLinearVelocity
									end

									local v128 = math.clamp(t1.GlideSmoothing or 0.25, 0, 1)

									glideBodyVelocity.Velocity = v127:Lerp(v126, v128)
								end

								local v129 = t1.GetGlide
								local v130

								if typeof(v129) == "function" then
									local ok, result = pcall(v129)

									v130 = if ok then result else false
								else
									v130 = false
								end

								if v130 == false or v119 or v120 < time() - v115 then
									break
								end
							end

							local v133 = t1.SetGlide

							if typeof(v133) == "function" then
								pcall(v133, false)
							end

							if v89 then
								v89:Stop(t1.AnimationFadeOut or 0.2)
							end

							if v88 then
								v88:FireServer()
							end

							if glideBodyVelocity.Parent then
								glideBodyVelocity:Destroy()
							end

							if glideBodyForce.Parent then
								glideBodyForce:Destroy()
							end

							stopGlideWindLoop(v113, t1)

							if typeof(t1.OnAfterStop) == "function" then
								local ok, result = pcall(t1.OnAfterStop)

								if not ok then
									warn("GlideClient OnAfterStop failed:", result)
								end
							end

							if UserInputService then
								UserInputService.MouseBehavior = Enum.MouseBehavior.Default
							end

							setCameraFov(v116, t1.FovOutTime or 0.45)
							task.wait(t1.CooldownResetDelay or 0.5)

							local v136 = t1.SetGlideCd

							if typeof(v136) == "function" then
								pcall(v136, false)
							end

							return true
						end

						return false, "Character is busy."
					end

					return false, "Glide is blocked."
				end

				return false, "Glide is blocked."
			end

			return false, "Missing HumanoidRootPart or Head."
		end

		return false, "Missing character or humanoid."
	end,
	Stop = function(p26)
		local setGlide = (p26 or {}).SetGlide

		if typeof(setGlide) == "function" then
			pcall(setGlide, false)
		end
	end
}
