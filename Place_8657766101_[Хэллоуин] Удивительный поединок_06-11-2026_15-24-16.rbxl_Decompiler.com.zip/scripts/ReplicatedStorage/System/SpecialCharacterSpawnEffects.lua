-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local tweenService: TweenService = game:GetService("TweenService")
local characters: Instance = replicatedStorage:WaitForChild("Characters")

local function tweenTransparency(p1, p2, p3)
	if not p1 or not p1.Parent then
		return
	end

	local tweenInfo = TweenInfo.new(p3)

	tweenService:Create(p1, tweenInfo, { Transparency = p2 }):Play()
end
local function getHeadWeldedParts(p4)
	local t2: {[any]: any} = {}
	local head = p4:FindFirstChild("Head")

	if not head or not head:IsA("BasePart") then
		return t2
	end

	local t3: {[any]: any} = {}

	for _, v in ipairs(p4:GetDescendants()) do
		if v:IsA("Weld") or v:IsA("WeldConstraint") then
			local vPart0 = v.Part0
			local vPart1 = v.Part1

			if vPart0 and vPart1 then
				t3[vPart0] = t3[vPart0] or {}
				t3[vPart1] = t3[vPart1] or {}
				table.insert(t3[vPart0], vPart1)
				table.insert(t3[vPart1], vPart0)
			end
		end
	end

	local t4: {[any]: any} = { head }
	local n1: number = 1

	t2[head] = true

	while n1 <= #t4 do
		local v21 = t4[n1]

		n1 += 1

		for _, v in ipairs(t3[v21] or {}) do
			if not t2[v] then
				t2[v] = true
				table.insert(t4, v)
			end
		end
	end

	return t2
end

local t1: {[any]: any} = {
	MoonKnight = function(p5)
		if p5.Parent and not p5:GetAttribute("SpecialSpawnEffectPlayed") then
			p5:SetAttribute("SpecialSpawnEffectPlayed", true)

			local mrKnightVal = p5:FindFirstChild("MrKnightVal")
			local moonKnightVal = p5:FindFirstChild("MoonKnightVal")
			local baseVal = p5:FindFirstChild("BaseVal")

			if mrKnightVal and moonKnightVal and baseVal then
				mrKnightVal.Value = false
				moonKnightVal.Value = false
				baseVal.Value = true
				task.wait(0.45)

				if not p5.Parent then
					return
				end

				local moonKnight: Instance = characters:FindFirstChild("MoonKnight")
				local remotes: Instance = moonKnight and moonKnight:FindFirstChild("Remotes")
				local v30: Instance = remotes

				if v30 then
					v30 = remotes:FindFirstChild("MoonKnightMenuTransformation")
				end

				if v30 and v30:IsA("BindableEvent") then
					v30:Fire(p5)
				end

				local v31 = getHeadWeldedParts(p5)
				local lowHealthState = p5:FindFirstChild("LowHealthState")

				for _, v in ipairs(p5:GetDescendants()) do
					local vParent = v.Parent

					if v.Name == "MoonKnight" and vParent and vParent:IsA("MeshPart") then
						tweenTransparency(vParent, 0, 0.4)
					elseif v.Name == "BandageTexture" and (not not v:IsA("Texture") or not not v:IsA("Decal")) then
						tweenTransparency(v, 0, 0.4)
					elseif v.Name ~= "Marc" or not vParent or not vParent:IsA("BasePart") then
						if v.Name == "MrKnight" and vParent and vParent:IsA("MeshPart") then
							tweenTransparency(vParent, 1, 0.4)
						elseif v.Name == "MrKnightTexture" and (not not v:IsA("Texture") or not not v:IsA("Decal")) then
							tweenTransparency(v, 1, 0.4)
						end
					elseif not lowHealthState or not v31[vParent] then
						tweenTransparency(vParent, 1, 0.3)
					end
				end

				mrKnightVal.Value = false
				moonKnightVal.Value = true
				baseVal.Value = false

				return
			end

			warn("[SpecialSpawnEffects] Moon Knight preview is missing form values:", p5:GetFullName())

			return
		end
	end,
	DarthVader = function(p6)
		if p6.Parent and not p6:GetAttribute("SpecialSpawnEffectPlayed") then
			p6:SetAttribute("SpecialSpawnEffectPlayed", true)
			task.wait(1)

			if not p6.Parent then
				return
			end

			local saber = p6:FindFirstChild("Saber")

			if not saber then
				warn("[SpecialSpawnEffects] Darth Vader preview is missing Saber:", p6:GetFullName())

				return
			end

			local attachment2 = saber:FindFirstChild("Attachment2")

			if attachment2 then
				tweenService:Create(attachment2, TweenInfo.new(0.2), { Position = Vector3.new(-5.109, 0, 0) }):Play()
			end

			local lightAttachment = saber:FindFirstChild("LightAttachment")

			if lightAttachment then
				local pointLight = lightAttachment:FindFirstChild("PointLight")

				if pointLight then
					tweenService:Create(pointLight, TweenInfo.new(0.2), { Brightness = 1 }):Play()
				end

				local surfaceLight = lightAttachment:FindFirstChild("SurfaceLight")

				if surfaceLight then
					tweenService:Create(surfaceLight, TweenInfo.new(0.2), { Brightness = 5 }):Play()
				end
			end

			local lightAttachment2 = saber:FindFirstChild("LightAttachment2")
			local lightAttachment2SurfaceLight = lightAttachment2 and lightAttachment2:FindFirstChild("SurfaceLight")

			if lightAttachment2SurfaceLight then
				tweenService:Create(lightAttachment2SurfaceLight, TweenInfo.new(0.2), { Brightness = 5 }):Play()
			end

			local saberOnSfx = saber:FindFirstChild("SaberOnSfx")

			if saberOnSfx then
				saberOnSfx:Play()
			end

			local saberTrail = saber:FindFirstChild("SaberTrail")

			if saberTrail then
				saberTrail.Enabled = true
			end

			local saberTrail2 = saber:FindFirstChild("SaberTrail2")

			if saberTrail2 then
				saberTrail2.Enabled = true
			end

			local saber_hum = saber:FindFirstChild("saber_hum")

			if saber_hum then
				tweenService:Create(saber_hum, TweenInfo.new(0.2), { Volume = 0.5 }):Play()
				saber_hum:Play()
			end

			return
		end
	end
}

return {
	Play = function(p7, p8)
		local v50 = t1[p7]

		if not v50 or not p8 or not p8:IsA("Model") then
			return false
		end

		task.spawn(v50, p8)

		return true
	end
}
