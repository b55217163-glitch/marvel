-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local contextActionService: ContextActionService = game:GetService("ContextActionService")
local replicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local runService: RunService = game:GetService("RunService")
local workspace: Workspace = game:GetService("Workspace")
local system: Instance = replicatedStorage:WaitForChild("System")
local controlsBindingDefaults = require(system:WaitForChild("ControlsBindingDefaults"))
local connection = nil
local u8: boolean = false
local uDim2 = UDim2.new(1, -155, 1, -90)
local uDim22 = UDim2.new(0, 70, 0, 70)

local function clampTouchButtonPosition(p1, p2)
	local CurrentCamera: Camera = workspace.CurrentCamera
	local v31 = CurrentCamera and CurrentCamera.ViewportSize or Vector2.new(0, 0)

	if v31.X <= 0 or v31.Y <= 0 then
		return p1
	end

	local v32 = p2 or uDim22
	local v33 = math.max(44, v32.X.Scale * v31.X + v32.X.Offset)
	local v34 = math.max(44, v32.Y.Scale * v31.Y + v32.Y.Offset)
	local n1 = p1.X.Scale * v31.X + p1.X.Offset
	local n2 = p1.Y.Scale * v31.Y + p1.Y.Offset
	local v37 = math.max(8, v31.X - v33 - 8)
	local v38 = math.max(8, v31.Y - v34 - 8)

	if n1 < 8 or n1 > v37 or n2 < 8 or v38 < n2 then
		return uDim2
	end

	return p1
end
local function getSavedSprintButtonPosition(p3)
	local menuRemotes: Instance = replicatedStorage:FindFirstChild("MenuRemotes")
	local loadMobileMovesetLayout: Instance = menuRemotes and menuRemotes:FindFirstChild("LoadMobileMovesetLayout")

	if not loadMobileMovesetLayout or not loadMobileMovesetLayout:IsA("RemoteFunction") then
		return uDim2
	end

	local ok, result = pcall(function()
		return loadMobileMovesetLayout:InvokeServer()
	end)

	local v44 = ok and typeof(result) == "table" and result.Sprint or nil
	local v45 = typeof(v44) == "table" and v44.Position or nil
	local v46 = typeof(v44) == "table" and v44.Size or nil

	if typeof(v45) == "table" then
		local uDim2New = UDim2.new
		local v48 = typeof(v45.XScale) == "number" and v45.XScale or 1
		local v49 = typeof(v45.XOffset) == "number" and v45.XOffset or -155
		local v50 = typeof(v45.YScale) == "number" and v45.YScale or 1
		local typeName: string = typeof(v45.YOffset)
		local v52 = uDim2New(v48, v49, v50, typeName == "number" and v45.YOffset or -90)
		local v53 = uDim22

		if typeof(v46) == "table" then
			local v54 = UDim2.new
			local v55 = typeof(v46.XScale) == "number" and v46.XScale or 0
			local v56 = typeof(v46.XOffset) == "number" and v46.XOffset or 70
			local v57 = typeof(v46.YScale) == "number" and v46.YScale or 0
			local typeName2: string = typeof(v46.YOffset)

			v53 = v54(v55, v56, v57, typeName2 == "number" and v46.YOffset or 70)
		end

		local v59 = p3

		if v59 then
			v59 = p3:FindFirstChild("PlayerGui")
		end

		local moveset = v59 and v59:FindFirstChild("Moveset")

		v59 = moveset

		if v59 then
			v59 = moveset:FindFirstChild("Frame")
		end

		local hold = v59 and v59:FindFirstChild("Hold")

		if hold and hold:IsA("GuiObject") and hold.AbsoluteSize.X > 0 and hold.AbsoluteSize.Y > 0 then
			local n1 = hold.AbsolutePosition.X + v52.X.Scale * hold.AbsoluteSize.X + v52.X.Offset
			local n2 = hold.AbsolutePosition.Y + v52.Y.Scale * hold.AbsoluteSize.Y + v52.Y.Offset
			local v64 = math.max(44, v53.X.Scale * hold.AbsoluteSize.X + v53.X.Offset)
			local v65 = math.max(44, v53.Y.Scale * hold.AbsoluteSize.Y + v53.Y.Offset)
			local CurrentCamera: Camera = workspace.CurrentCamera
			local v67 = CurrentCamera and CurrentCamera.ViewportSize or Vector2.new(0, 0)

			if v67.X > 0 and v67.Y > 0 then
				local uDim23 = UDim2.new(1, n1 - v67.X, 1, n2 - v67.Y)

				return uDim23, UDim2.new(0, v64, 0, v65)
			end

			local uDim24 = UDim2.new(0, n1, 0, n2)

			return uDim24, UDim2.new(0, v64, 0, v65)
		end

		return uDim2, uDim22
	end

	return uDim2
end
local function playerHasAutoRun(p4)
	local v71 = p4

	if v71 then
		v71 = p4:FindFirstChild("AutoRun") ~= nil
	end

	return v71
end
local function getSprintHumanoid(player)
	local character = player and player.Character

	if not character then
		return nil, nil
	end

	return character, character:FindFirstChildOfClass("Humanoid")
end
local function hasSprintLockout(p6, p7)
	if p6 and p7 and not (p7.Health <= 0) then
		local v76 = p7.Sit

		if not v76 then
			v76 = true

			if p6:FindFirstChild("CantAttack") == nil then
				v76 = true

				if p6:FindFirstChild("Cantattack") == nil then
					v76 = true

					if p6:FindFirstChild("Disabled") == nil then
						v76 = p6:FindFirstChild("Blocking") ~= nil
					end
				end
			end
		end

		return v76
	end

	return true
end
local function stopAutoRun(p8)
	if u8 then
		u8 = false
		p8("RunBind", Enum.UserInputState.End)
	end
end
local function getPlayerBindingsFolder(p9)
	return p9 and p9:FindFirstChild("ControlsBindings")
end
local function getDefaultBinding(p10, p11)
	local v81 = controlsBindingDefaults.GetActionData(p10)

	return v81 and v81.Default and v81.Default[p11] or ""
end
local function getCustomBinding(p12, p13, p14)
	local controlsBindings = p12 and p12:FindFirstChild("ControlsBindings")
	local v86 = controlsBindings and controlsBindings:FindFirstChild(p13)
	local v87 = v86

	if v87 then
		v87 = v86:FindFirstChild(p14)
	end

	if v87 and v87:IsA("StringValue") then
		return v87.Value, true
	end

	return nil, false
end
local function getBinding(p15, p16, p17)
	local controlsBindings = p15 and p15:FindFirstChild("ControlsBindings")
	local v92 = controlsBindings and controlsBindings:FindFirstChild(p16)
	local v93 = v92

	if v93 then
		v93 = v92:FindFirstChild(p17)
	end

	local v94
	local u95

	if v93 and v93:IsA("StringValue") then
		v94 = v93.Value
		u95 = true
	else
		v94 = nil
		u95 = false
	end

	if u95 then
		return v94, true
	end

	local v96 = controlsBindingDefaults.GetActionData(p16)

	return v96 and v96.Default and v96.Default[p17] or "", false
end

local t1: {[any]: any} = {
	One = { "MoveOne" },
	Two = { "MoveTwo" },
	Three = { "MoveThree" },
	Four = { "MoveFour" },
	Five = { "MoveFive" },
	E = { "SpecialMove", "ThanosPowerStone" },
	F = { "Guard" },
	LeftShift = { "Sprint" },
	Eight = { "MoonKnightForm" },
	Nine = { "MrKnightForm" },
	R = { "ThanosSpaceStone" },
	T = { "ThanosRealityStone" },
	G = { "Emote" },
	P = { "PrivateServerCommands" },
	K = { "ShiftLock" }
}
local t2: {[any]: any} = {
	DPadUp = { "MoveOne" },
	DPadDown = { "MoveTwo" },
	DPadLeft = { "MoveThree" },
	DPadRight = { "MoveFour" },
	ButtonR1 = { "MoveFive" },
	ButtonL1 = { "SpecialMove", "ThanosPowerStone" },
	ButtonR2 = { "Combat" },
	ButtonL2 = { "Guard" },
	ButtonL3 = { "Sprint" },
	ButtonSelect = { "MoonKnightForm" },
	ButtonStart = { "MrKnightForm" },
	ButtonX = { "ThanosSpaceStone" },
	ButtonB = { "ThanosRealityStone" },
	ButtonY = { "Emote", "ThanosTimeStone", "ComboBreaker" }
}
local t3: {[any]: any} = {
	MouseButton1 = { "Combat" },
	MouseButton2 = {},
	MouseButton3 = {}
}

local function getKeyCodeByName(p25)
	if typeof(p25) == "string" and p25 ~= "" then
		local ok, result = pcall(function()
			return Enum.KeyCode[p25]
		end)

		if ok then
			return result
		end

		return nil
	end

	return nil
end

local t4: {[any]: any} = {
	MouseButton1 = Enum.UserInputType.MouseButton1,
	MouseButton2 = Enum.UserInputType.MouseButton2,
	MouseButton3 = Enum.UserInputType.MouseButton3
}

local function getInputTypeByName(p26)
	return t4[p26]
end

local module: {[any]: any} = {
	GetBinding = function(p18, p19, p20)
		local controlsBindings = p18 and p18:FindFirstChild("ControlsBindings")
		local v105 = controlsBindings and controlsBindings:FindFirstChild(p19)
		local v106 = v105

		if v106 then
			v106 = v105:FindFirstChild(p20)
		end

		local v107
		local u108

		if v106 and v106:IsA("StringValue") then
			v107 = v106.Value
			u108 = true
		else
			v107 = nil
			u108 = false
		end

		if u108 then
			return v107
		end

		local v109 = controlsBindingDefaults.GetActionData(p19)

		return v109 and v109.Default and v109.Default[p20] or ""
	end,
	HasCustomBinding = function(p21, p22)
		local controlsBindings = p21 and p21:FindFirstChild("ControlsBindings")
		local v113 = controlsBindings and controlsBindings:FindFirstChild(p22)
		local v114 = v113

		if v114 then
			v114 = v113:FindFirstChild("Keyboard")
		end

		local v115 = v114 and v114:IsA("StringValue")
		local v116 = v114.Value

		v116 = p21

		if v116 then
			v116 = p21:FindFirstChild("ControlsBindings")
		end

		local v117 = v116 and v116:FindFirstChild(p22)

		v116 = v117

		if v116 then
			v116 = v117:FindFirstChild("Controller")
		end

		local v118 = v116 and v116:IsA("StringValue")

		v114 = v116.Value
		v114 = p21

		if v114 then
			v114 = p21:FindFirstChild("ControlsBindings")
		end

		local v119 = v114 and v114:FindFirstChild(p22)

		v114 = v119

		if v114 then
			v114 = v119:FindFirstChild("VR")
		end

		local v120 = v114 and v114:IsA("StringValue")

		v117 = v114.Value

		return (if v115 then true else false) or (if v118 then true else false) or (if v120 then true else false)
	end,
	DefaultInputWasRebound = function(p23, input)
		local v123 = nil

		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			v123 = t3.MouseButton1
		elseif input.UserInputType == Enum.UserInputType.MouseButton2 then
			v123 = t3.MouseButton2
		elseif input.UserInputType == Enum.UserInputType.MouseButton3 then
			v123 = t3.MouseButton3
		elseif input.KeyCode.Name ~= "Unknown" then
			v123 = t2[input.KeyCode.Name] or t1[input.KeyCode.Name]
		end

		if not v123 then
			return false
		end

		for _, v in ipairs(v123) do
			local controlsBindings = p23 and p23:FindFirstChild("ControlsBindings")
			local v127 = controlsBindings and controlsBindings:FindFirstChild(v)
			local v128 = v127

			if v128 then
				v128 = v127:FindFirstChild("Keyboard")
			end

			local v129 = if v128 and v128:IsA("StringValue") then v128.Value else nil
			local v130 = p23 and p23:FindFirstChild("ControlsBindings")
			local v131 = v130 and v130:FindFirstChild(v)

			v127 = v131

			if v127 then
				v127 = v131:FindFirstChild("Controller")
			end

			v128 = if v127 and v127:IsA("StringValue") then v127.Value else nil

			local v132 = p23 and p23:FindFirstChild("ControlsBindings")
			local v133 = v132 and v132:FindFirstChild(v)

			v131 = v133

			if v131 then
				v131 = v133:FindFirstChild("VR")
			end

			v127 = if v131 and v131:IsA("StringValue") then v131.Value else nil

			if v129 ~= nil and v129 ~= (controlsBindingDefaults.GetActionData(v) and controlsBindingDefaults.GetActionData(v).Default and controlsBindingDefaults.GetActionData(v).Default.Keyboard or "") then
				return true
			end

			if v128 ~= nil and v128 ~= (controlsBindingDefaults.GetActionData(v) and controlsBindingDefaults.GetActionData(v).Default and controlsBindingDefaults.GetActionData(v).Default.Controller or "") then
				return true
			end

			if v127 ~= nil and v127 ~= (controlsBindingDefaults.GetActionData(v) and controlsBindingDefaults.GetActionData(v).Default and controlsBindingDefaults.GetActionData(v).Default.VR or "") then
				return true
			end
		end

		return false
	end,
	InputMatches = function(p27, input, p29)
		local controlsBindings = p27 and p27:FindFirstChild("ControlsBindings")
		local v138 = controlsBindings and controlsBindings:FindFirstChild(p29)
		local v139 = v138

		if v139 then
			v139 = v138:FindFirstChild("Keyboard")
		end

		local v140
		local u141

		if v139 and v139:IsA("StringValue") then
			v140 = v139.Value
			u141 = true
		else
			v140 = nil
			u141 = false
		end

		local v142

		if u141 then
			v142 = v140
		else
			local v143 = controlsBindingDefaults.GetActionData(p29)

			v142 = v143 and v143.Default and v143.Default.Keyboard or ""
		end

		local v144 = p27 and p27:FindFirstChild("ControlsBindings")
		local v145 = v144 and v144:FindFirstChild(p29)

		v138 = v145

		if v138 then
			v138 = v145:FindFirstChild("Controller")
		end

		local v146
		local u147

		if v138 and v138:IsA("StringValue") then
			v146 = v138.Value
			u147 = true
		else
			v146 = nil
			u147 = false
		end

		local v148

		if u147 then
			v148 = v146
		else
			local v149 = controlsBindingDefaults.GetActionData(p29)

			v148 = v149 and v149.Default and v149.Default.Controller or ""
		end

		local v150 = p27 and p27:FindFirstChild("ControlsBindings")
		local v151 = v150 and v150:FindFirstChild(p29)

		v145 = v151

		if v145 then
			v145 = v151:FindFirstChild("VR")
		end

		local v152
		local u153

		if v145 and v145:IsA("StringValue") then
			v152 = v145.Value
			u153 = true
		else
			v152 = nil
			u153 = false
		end

		local v154

		if u153 then
			v154 = v152
		else
			local v155 = controlsBindingDefaults.GetActionData(p29)

			v154 = v155 and v155.Default and v155.Default.VR or ""
		end

		if v142 ~= "" then
			local v156 = t4[v142]

			if v156 and v156 == input.UserInputType then
				return true
			end

			local v158

			if typeof(v142) == "string" and v142 ~= "" then
				local ok, result = pcall(function()
					return Enum.KeyCode[v142]
				end)

				v158 = if ok then result else nil
			else
				v158 = nil
			end

			if v158 and v158 == input.KeyCode then
				return true
			end
		end

		if v148 ~= "" then
			local v162

			if typeof(v148) == "string" and v148 ~= "" then
				local ok, result = pcall(function()
					return Enum.KeyCode[v148]
				end)

				v162 = if ok then result else nil
			else
				v162 = nil
			end

			if v162 and v162 == input.KeyCode then
				return true
			end
		end

		if v154 == "" then
			return false
		end

		local v166

		if typeof(v154) == "string" and v154 ~= "" then
			local ok, result = pcall(function()
				return Enum.KeyCode[v154]
			end)

			v166 = if ok then result else nil
		else
			v166 = nil
		end

		if v166 and v166 == input.KeyCode then
			return true
		end

		return false
	end,
	GetDefaultKeyboardMap = function()
		local t6: {[any]: any} = {}

		for k, v in pairs(controlsBindingDefaults.Actions) do
			local keyboard = v.Default.Keyboard

			if keyboard and keyboard ~= "" then
				t6[k] = keyboard
			end
		end

		return t6
	end,
	BindSprint = function(p30, p31, p32)
		contextActionService:UnbindAction("RunBind")

		if connection then
			connection:Disconnect()
			connection = nil
		end

		u8 = false

		local controlsBindings = p30 and p30:FindFirstChild("ControlsBindings")
		local sprint = controlsBindings and controlsBindings:FindFirstChild("Sprint")
		local v178 = sprint

		if v178 then
			v178 = sprint:FindFirstChild("Keyboard")
		end

		local v179
		local u180

		if v178 and v178:IsA("StringValue") then
			v179 = v178.Value
			u180 = true
		else
			v179 = nil
			u180 = false
		end

		local v181

		if u180 then
			v181 = v179
		else
			local v182 = controlsBindingDefaults.GetActionData("Sprint")

			v181 = v182 and v182.Default and v182.Default.Keyboard or ""
		end

		local v183 = p30 and p30:FindFirstChild("ControlsBindings")
		local v184 = v183 and v183:FindFirstChild("Sprint")
		local v185 = v184

		if v185 then
			v185 = v184:FindFirstChild("Controller")
		end

		local v186
		local u187

		if v185 and v185:IsA("StringValue") then
			v186 = v185.Value
			u187 = true
		else
			v186 = nil
			u187 = false
		end

		local v188

		if u187 then
			v188 = v186
		else
			local v189 = controlsBindingDefaults.GetActionData("Sprint")

			v188 = v189 and v189.Default and v189.Default.Controller or ""
		end

		local t7: {[any]: any} = {}

		if v181 ~= "" then
			local v192

			if typeof(v181) == "string" and v181 ~= "" then
				local ok, result = pcall(function()
					return Enum.KeyCode[v181]
				end)

				v192 = if ok then result else nil
			else
				v192 = nil
			end

			if v192 then
				local v196

				if typeof(v181) == "string" and v181 ~= "" then
					local ok, result = pcall(function()
						return Enum.KeyCode[v181]
					end)

					v196 = if ok then result else nil
				else
					v196 = nil
				end

				table.insert(t7, v196)
			end
		end

		if v188 ~= "" then
			local v200

			if typeof(v188) == "string" and v188 ~= "" then
				local ok, result = pcall(function()
					return Enum.KeyCode[v188]
				end)

				v200 = if ok then result else nil
			else
				v200 = nil
			end

			if v200 then
				local v204

				if typeof(v188) == "string" and v188 ~= "" then
					local ok, result = pcall(function()
						return Enum.KeyCode[v188]
					end)

					v204 = if ok then result else nil
				else
					v204 = nil
				end

				table.insert(t7, v204)
			end
		end

		if #t7 == 0 then
			t7 = { Enum.KeyCode.LeftShift, Enum.KeyCode.ButtonL3 }
		end

		contextActionService:BindAction("RunBind", function(p33, p34, p35)
			if p34 == Enum.UserInputState.End and u8 then
				return Enum.ContextActionResult.Sink
			end

			return p31(p33, p34, p35)
		end, p32 ~= false, table.unpack(t7))
		pcall(function()
			contextActionService:SetTitle("RunBind", "Sprint")

			local v233, v234 = getSavedSprintButtonPosition(p30)
			local v235 = clampTouchButtonPosition(v233, v234)

			contextActionService:SetPosition("RunBind", v235)
		end)

		local n1 = 0
		local n2 = 0

		connection = runService.Heartbeat:Connect(function()
			local v236 = p30
			local character = v236 and v236.Character
			local v238
			local humanoid

			if not character then
				v238 = nil
				humanoid = nil
			else
				v238 = character
				humanoid = character:FindFirstChildOfClass("Humanoid")
			end

			local v240 = p30

			v236 = v240

			if v236 then
				v236 = v240:FindFirstChild("AutoRun") ~= nil
			end

			if v236 then
				v236 = not hasSprintLockout(v238, humanoid) and humanoid.MoveDirection.Magnitude > 0.05
			end

			local v241 = os.clock()

			if v236 then
				n1 = v241

				if not u8 then
					u8 = true
					n2 = v241
					p31("RunBind", Enum.UserInputState.Begin)

					return
				end

				if v241 - n2 > 0.2 then
					n2 = v241
					p31("RunBind", Enum.UserInputState.Begin)

					return
				end
			elseif u8 and v241 - n1 > 0.2 and u8 then
				u8 = false
				p31("RunBind", Enum.UserInputState.End)
			end
		end)
	end,
	OpenEmotesMenu = function()
		local starterGui: StarterGui = game:GetService("StarterGui")

		pcall(function()
			starterGui:SetCoreGuiEnabled(Enum.CoreGuiType.EmotesMenu, true)
		end)

		return (pcall(function()
			starterGui:SetCore("EmotesMenuOpen", true)
		end))
	end,
	ApplyShiftLockBinding = function(p36)
		local controlsBindings = p36 and p36:FindFirstChild("ControlsBindings")
		local shiftLock = controlsBindings and controlsBindings:FindFirstChild("ShiftLock")
		local v213 = shiftLock

		if v213 then
			v213 = shiftLock:FindFirstChild("Keyboard")
		end

		local v214
		local u215

		if v213 and v213:IsA("StringValue") then
			v214 = v213.Value
			u215 = true
		else
			v214 = nil
			u215 = false
		end

		local v216

		if u215 then
			v216 = v214
		else
			local v217 = controlsBindingDefaults.GetActionData("ShiftLock")

			v216 = v217 and v217.Default and v217.Default.Keyboard or ""
		end

		if v216 == "" then
			v216 = "K"
		end

		local v219

		if typeof(v216) == "string" and v216 ~= "" then
			local ok, result = pcall(function()
				return Enum.KeyCode[v216]
			end)

			v219 = if ok then result else nil
		else
			v219 = nil
		end

		if not v219 then
			v216 = "K"
		end

		local playerScripts = p36 and p36:FindFirstChild("PlayerScripts")
		local playerModule = playerScripts and playerScripts:FindFirstChild("PlayerModule")
		local v224 = playerModule

		if v224 then
			v224 = playerModule:FindFirstChild("CameraModule")
		end

		local mouseLockController = v224 and v224:FindFirstChild("MouseLockController")

		if not mouseLockController then
			return false
		end

		local boundKeys = mouseLockController:FindFirstChild("BoundKeys")

		if not boundKeys then
			boundKeys = Instance.new("StringValue")
			boundKeys.Name = "BoundKeys"
			boundKeys.Parent = mouseLockController
		end

		boundKeys.Value = v216

		return true
	end
}

function module.ShouldIgnoreDefaultInput(p37, p38)
	return module.DefaultInputWasRebound(p37, p38)
end
function module.BindSuppression(_)
	contextActionService:UnbindAction("ControlsRuntimeSuppressReboundDefaults")
end

return module
