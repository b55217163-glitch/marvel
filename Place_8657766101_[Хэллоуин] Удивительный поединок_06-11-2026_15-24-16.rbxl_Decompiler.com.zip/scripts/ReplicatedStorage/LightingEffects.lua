-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local tweenService: TweenService = game:GetService("TweenService")
local lighting: Lighting = game:GetService("Lighting")
local players: Players = game:GetService("Players")
local t1 = {
	Enabled = true,
	Brightness = 0,
	Contrast = 0,
	Saturation = 0,
	TintColor = Color3.new(1, 1, 1)
}
local t2: {[any]: any} = {
	Enabled = true,
	Brightness = 0,
	Contrast = 0,
	Saturation = 0.8,
	TintColor = Color3.new(1, 1, 1)
}
local color3 = Color3.fromRGB(142, 142, 142)
local color32 = Color3.fromRGB(0, 0, 0)
local color33 = Color3.fromRGB(235, 240, 240)
local color34 = Color3.fromRGB(210, 220, 240)
local module: {[any]: any} = {
	PersistentColorPreset = nil,
	BlurToken = 0,
	MaxBlurHoldTime = 8,
	NeutralColorCorrection = t1,
	Defaults = {
		ColorCorrection = t2,
		Bloom = { Enabled = true, Intensity = 2, Threshold = 1.8, Size = 32 },
		Blur = { Enabled = false, Size = 0 },
		DepthOfField = {
			Enabled = true,
			FocusDistance = 0,
			InFocusRadius = 75,
			NearIntensity = 0,
			FarIntensity = 0.3
		},
		Lighting = {
			ExposureCompensation = 0,
			Brightness = 2.2,
			ClockTime = 7.5,
			GlobalShadows = true,
			Ambient = color3,
			OutdoorAmbient = color32
		},
		Atmosphere = {
			Density = 0.45,
			MaxDensityFromDenVal = 0.43,
			Haze = 0,
			Glare = 0,
			Color = color33,
			Decay = color34
		},
		SunRays = { Enabled = true, Intensity = 0.15, Spread = 0.35 }
	}
}

module.MainBase = module.Defaults
t2 = {
	Brightness = 0,
	Contrast = 0,
	Saturation = -1.8,
	TintColor = Color3.new(1, 1, 1)
}
local t4: {[any]: any} = {
	Brightness = 0,
	Contrast = 2,
	Saturation = 0,
	TintColor = Color3.new(0.765, 0.565, 1)
}
local t5: {[any]: any} = {
	Brightness = 0,
	Contrast = 1,
	Saturation = 0,
	TintColor = Color3.new(0.196, 0.557, 0.192)
}
local t6: {[any]: any} = {
	Brightness = 0,
	Contrast = 1,
	Saturation = 0,
	TintColor = Color3.new(1, 0.443, 0.345)
}
local t7 = {
	Brightness = -0.1,
	Contrast = 1,
	Saturation = 0,
	TintColor = Color3.new(0.929, 0.447, 0.38)
}
local color35 = Color3.fromRGB(255, 145, 210)

module.Presets = {
	BlackWhite60s = t2,
	Wednesday = t4,
	TimeStop = t5,
	KratosRage = t6,
	GoreHit = t7,
	InLove = {
		Brightness = 0.08,
		Contrast = 0.65,
		Saturation = 0.45,
		TintColor = color35
	}
}
module.DisabledByDefault = {}
t1 = function(p1)
	return lighting:FindFirstChild(p1)
end
t7 = function()
	local LocalPlayer: Player = players.LocalPlayer
	local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

	return localPlayerCharacter ~= nil and localPlayerCharacter.Parent ~= nil and localPlayerCharacter:FindFirstChild("WandaMax") ~= nil and localPlayerCharacter:FindFirstChild("60s") ~= nil
end

local function canSet(p2, p3)
	return pcall(function()
		local v239 = p2[p3]
	end)
end
local function setProperties(p4, p5)
	if not p4 then
		return
	end

	for k, v in pairs(p5) do
		if k ~= "Enabled" and pcall(function()
			local v240 = p4[k]
		end) then
			pcall(function()
				p4[k] = v
			end)
		end
	end
end
local function getCurrentMapAmbient()
	local map: Instance = workspace:FindFirstChild("Map")
	local ambientBool: Instance = map and map:FindFirstChild("AmbientBool", true)

	if ambientBool and ambientBool:IsA("Color3Value") then
		return ambientBool.Value
	end

	return module.Defaults.Lighting.Ambient
end
local function getCurrentMapOutdoorAmbient()
	local map: Instance = workspace:FindFirstChild("Map")
	local outdoorAmbientBool: Instance = map and map:FindFirstChild("OutdoorAmbientBool", true)

	if outdoorAmbientBool and outdoorAmbientBool:IsA("Color3Value") then
		return outdoorAmbientBool.Value
	end

	return module.Defaults.Lighting.OutdoorAmbient
end
local function getCurrentMapClockTime()
	local map: Instance = workspace:FindFirstChild("Map")
	local clockTime: Instance = map and map:FindFirstChild("ClockTime", true)

	if clockTime and clockTime:IsA("NumberValue") then
		return (math.clamp(clockTime.Value, 0, 24))
	end

	return module.Defaults.Lighting.ClockTime
end
function module.ApplyDarkness(p6)
	local v40 = p6 or 0
	local atmosphere: Instance = lighting:FindFirstChildOfClass("Atmosphere")

	if atmosphere then
		module.Tween(atmosphere, v40, { Density = 1 })
	end

	module.Tween(lighting, v40, { ClockTime = 0, Brightness = -0.8 })
end
function module.ResetToCurrentMapLighting(p7)
	local v43
	local v44 = p7 or 0.3
	local atmosphere: Instance = lighting:FindFirstChildOfClass("Atmosphere")

	if atmosphere then
		local denVal: Instance = atmosphere:FindFirstChild("DenVal")
		local v47 = atmosphere.Density

		if denVal and denVal:IsA("NumberValue") then
			v47 = denVal.Value
		end

		module.Tween(atmosphere, v44, { Density = v47 })
	end

	local tween = module.Tween
	local t8: {[any]: any} = { Brightness = module.Defaults.Lighting.Brightness, ClockTime = v43 }
	local map: Instance = workspace:FindFirstChild("Map")
	local clockTime: Instance = map and map:FindFirstChild("ClockTime", true)

	if clockTime and clockTime:IsA("NumberValue") then
		local v43 = math.clamp(clockTime.Value, 0, 24)
	else
		v43 = module.Defaults.Lighting.ClockTime
	end

	tween(lighting, v44, t8)
end
local function setEnabled(p8, p9)
	if p8 and pcall(function()
		local v241 = p8[s1]
	end) then
		pcall(function()
			p8.Enabled = p9
		end)

		return
	end
end
local function isDepthOfFieldAllowed()
	local LocalPlayer: Player = players.LocalPlayer
	local u55: boolean = true

	if LocalPlayer ~= nil then
		u55 = LocalPlayer:FindFirstChild("DepthOfFieldOff") == nil
	end

	return u55
end
function module.Tween(p10, p11, p12)
	if not p10 then
		return nil
	end

	local t9: {[any]: any} = {}

	for k, v in pairs(p12) do
		if k ~= "Enabled" and pcall(function()
			local v243 = p10[k]
		end) then
			t9[k] = v
		end
	end

	if next(t9) == nil then
		return nil
	end

	local tweenInfo = TweenInfo.new(p11 or 0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v63: Tween = tweenService:Create(p10, tweenInfo, t9)

	v63:Play()

	return v63
end
function module.SetEffectEnabled(p13, p14)
	local foundChild: Instance = lighting:FindFirstChild(p13)

	if foundChild then
		local s1: string = "Enabled"

		if not pcall(function()
			local v244 = foundChild[s1]
		end) then
			return
		end

		pcall(function()
			foundChild.Enabled = p14
		end)

		return
	end
end
function module.DisableDefaultSpecialEffects(p15)
	for _, v in ipairs(module.DisabledByDefault) do
		module.SetEffectEnabled(v, false)
	end

	local hasCharacterValues = (p15 or {}).HasCharacterValues
end
function module.ResetColorCorrection(p16, p17)
	local s1 = "ColorCorrection"

	if typeof(p16) == "string" then
		s1 = p16
	else
		p17 = p16
	end

	local foundChild: Instance = lighting:FindFirstChild(s1)
	local v76 = s1 == "ColorCorrection" and module.Defaults.ColorCorrection or module.NeutralColorCorrection

	if not foundChild then
		return
	end

	local enabled = v76.Enabled

	if foundChild then
		local s2: string = "Enabled"

		if pcall(function()
			local v245 = foundChild[s2]
		end) then
			pcall(function()
				foundChild.Enabled = enabled
			end)
		end
	end

	module.Tween(foundChild, p17 or 0.35, {
		TintColor = v76.TintColor,
		Brightness = v76.Brightness,
		Contrast = v76.Contrast,
		Saturation = v76.Saturation
	})
end
function module.ResetBloom(p18)
	local bloom: Instance = lighting:FindFirstChild("Bloom")
	local v81 = module.Defaults.Bloom

	if not bloom then
		return
	end

	local enabled = v81.Enabled

	if bloom then
		local s1: string = "Enabled"

		if pcall(function()
			local v246 = bloom[s1]
		end) then
			pcall(function()
				bloom.Enabled = enabled
			end)
		end
	end

	module.Tween(bloom, p18 or 0.5, {
		Intensity = v81.Intensity,
		Threshold = v81.Threshold,
		Size = v81.Size
	})
end
function module.SetBlur(p19, p20, p21)
	local v87 = math.clamp(p19 or 0, 0, 100)
	local v88 = p20 or 0.35
	local v89: {[any]: any} = module

	v89.BlurToken = v89.BlurToken + 1

	local blurToken = module.BlurToken
	local blurEffect: Instance = lighting:FindFirstChild("BlurEffect")

	if blurEffect then
		local s1: string = "Enabled"

		if pcall(function()
			local v247 = blurEffect[s1]
		end) then
			local u93: boolean = true

			pcall(function()
				blurEffect.Enabled = u93
			end)
		end

		module.Tween(blurEffect, v88, { Size = v87 })

		if v87 <= 0 then
			task.delay(v88, function()
				local v248 = blurToken == module.BlurToken and blurEffect and blurEffect.Parent and blurEffect.Size <= 0.01 and blurEffect

				if v248 then
					local s1: string = "Enabled"

					if not pcall(function()
						local v266 = v248[s1]
					end) then
						return
					end

					local u250: boolean = false

					pcall(function()
						v248.Enabled = u250
					end)

					return
				end
			end)

			return
		end

		task.delay(p21 or module.MaxBlurHoldTime, function()
			if blurToken == module.BlurToken and blurEffect and blurEffect.Parent and blurEffect.Size > 0.01 then
				module.SetBlur(0, 0.35)
			end
		end)

		return
	end
end
function module.SetDepthOfField(p22, p23, p24, p25)
	local depthOfField: Instance = lighting:FindFirstChild("DepthOfField")

	if not depthOfField then
		return
	end

	local t10 = p23 or {}
	local u100: boolean = false

	if p22 == true then
		u100 = true

		if p25 ~= true then
			local LocalPlayer: Player = players.LocalPlayer

			u100 = true

			if LocalPlayer ~= nil then
				u100 = LocalPlayer:FindFirstChild("DepthOfFieldOff") == nil
			end
		end
	end

	if depthOfField then
		local s1: string = "Enabled"

		if pcall(function()
			local v251 = depthOfField[s1]
		end) then
			pcall(function()
				depthOfField.Enabled = u100
			end)
		end
	end

	module.Tween(depthOfField, p24 or 0.35, {
		FocusDistance = t10.FocusDistance or module.Defaults.DepthOfField.FocusDistance,
		InFocusRadius = t10.InFocusRadius or module.Defaults.DepthOfField.InFocusRadius,
		NearIntensity = t10.NearIntensity or module.Defaults.DepthOfField.NearIntensity,
		FarIntensity = t10.FarIntensity or module.Defaults.DepthOfField.FarIntensity
	})
end
function module.ResetLighting(p26, p27)
	local v105 = table.clone(module.Defaults.Lighting)

	if (p27 or {}).KeepClockTime == true then
		v105.ClockTime = nil
	end

	local map: Instance = workspace:FindFirstChild("Map")
	local ambientBool: Instance = map and map:FindFirstChild("AmbientBool", true)

	v105.Ambient = if ambientBool and ambientBool:IsA("Color3Value") then ambientBool.Value else module.Defaults.Lighting.Ambient

	local map2: Instance = workspace:FindFirstChild("Map")
	local outdoorAmbientBool: Instance = map2 and map2:FindFirstChild("OutdoorAmbientBool", true)

	v105.OutdoorAmbient = if outdoorAmbientBool and outdoorAmbientBool:IsA("Color3Value") then outdoorAmbientBool.Value else module.Defaults.Lighting.OutdoorAmbient
	module.Tween(lighting, p26 or 0.5, v105)
end
function module.ResetAtmosphere(p28)
	local atmosphere: Instance = lighting:FindFirstChildOfClass("Atmosphere")

	if not atmosphere then
		return
	end

	local v112 = module.Defaults.Atmosphere
	local v113 = v112.Density
	local denVal: Instance = atmosphere:FindFirstChild("DenVal")

	if denVal and denVal:IsA("NumberValue") then
		v113 = math.min(denVal.Value, v112.MaxDensityFromDenVal)
	end

	module.Tween(atmosphere, p28 or 0.5, {
		Density = v113,
		Color = v112.Color,
		Decay = v112.Decay,
		Haze = v112.Haze,
		Glare = v112.Glare
	})
end
function module.ResetSunRays(p29)
	local sunRays: Instance = lighting:FindFirstChild("SunRays")

	if not sunRays then
		return
	end

	local v117 = module.Defaults.SunRays
	local map: Instance = workspace:FindFirstChild("Map")
	local v119 = map

	if v119 then
		v119 = map:FindFirstChild("NoSunRays", true) ~= nil
	end

	local v120 = v117.Enabled and not v119

	if sunRays then
		local s1: string = "Enabled"

		if pcall(function()
			local v252 = sunRays[s1]
		end) then
			pcall(function()
				sunRays.Enabled = v120
			end)
		end
	end

	module.Tween(sunRays, p29 or 0.5, { Intensity = v117.Intensity, Spread = v117.Spread })
end
function module.ResetDefault(p30)
	local t11
	local t12
	local LocalPlayer
	local v126
	local u127
	local foundChild
	local t13
	local LocalPlayer2
	local v131
	local u132
	local foundChild2

	t11 = p30 or {}
	t12 = t11
	module.PersistentColorPreset = nil
	module.ClearInLove(true)

	if t12.PreserveWanda60s == true then
		module.ApplyWanda60s(t12.ColorDuration or 0.35)
	else
		LocalPlayer = players.LocalPlayer
		v126 = LocalPlayer and LocalPlayer.Character
		u127 = false

		if v126 == nil then
		else
			u127 = false

			if v126.Parent == nil then
			else
				u127 = false

				if v126:FindFirstChild("WandaMax") == nil then
				else
					foundChild = v126:FindFirstChild("60s")
					u127 = foundChild ~= nil
				end
			end
		end

		if u127 then
			module.ApplyWanda60s(t12.ColorDuration or 0.35)
		else
			module.ClearWanda60s(t12.ColorDuration or 0.35)
		end
	end

	module.DisableDefaultSpecialEffects(t12)
	module.ResetColorCorrection(t12.ColorDuration or 0.35)
	module.ResetColorCorrection("ColorCorrection_Gore", t12.ColorDuration or 0.35)
	module.ResetColorCorrection("ColorCorrection_Death", t12.ColorDuration or 0.35)
	module.ResetColorCorrection("ColorCorrection_Flash", t12.ColorDuration or 0.35)
	module.ResetPibbyColor(t12.ColorDuration or 0.35)
	module.SetBlur(0, t12.BlurDuration or 0.35)
	module.SetDepthOfField(module.Defaults.DepthOfField.Enabled, nil, t12.DepthDuration or 0.35, false)
	module.ResetBloom(t12.BloomDuration or 0.5)
	t13 = { KeepClockTime = true }
	module.ResetLighting(t12.LightingDuration or 0.5, t13)

	if t12.ResetAtmosphere == true then
		module.ResetAtmosphere(t12.AtmosphereDuration or 0.5)
	end

	module.ResetSunRays(t12.SunRaysDuration or 0.5)

	if t12.PreserveWanda60s == true then
		module.ApplyWanda60s(t12.ColorDuration or 0.35)
	else
		LocalPlayer2 = players.LocalPlayer
		v131 = LocalPlayer2 and LocalPlayer2.Character
		u132 = false

		if v131 == nil then
		else
			u132 = false

			if v131.Parent == nil then
			else
				u132 = false

				if v131:FindFirstChild("WandaMax") == nil then
				else
					foundChild2 = v131:FindFirstChild("60s")
					u132 = foundChild2 ~= nil
				end
			end
		end

		if u132 then
			module.ApplyWanda60s(t12.ColorDuration or 0.35)
		end
	end
end
function module.ApplyColor(p31, p32, p33)
	local foundChild: Instance = lighting:FindFirstChild(p33 or "ColorCorrection")

	if not foundChild then
		return
	end

	local s1: string = "Enabled"

	if pcall(function()
		local v253 = foundChild[s1]
	end) then
		local u139: boolean = true

		pcall(function()
			foundChild.Enabled = u139
		end)
	end

	module.Tween(foundChild, p32 or 0.2, p31)
end
function module.SetSaturation(p34, p35)
	module.ApplyColor({ Saturation = p34 or 0 }, p35 or 0.05)
end
function module.ApplyPreset(p36, p37, p38)
	local v145 = module.Presets[p36]

	if not v145 then
		return
	end

	module.ApplyColor(v145, p37 or 0.2, p38)
end
function module.ApplyPibbyColor(p39, p40)
	local colorCorrection_Pibby = lighting:FindFirstChild("ColorCorrection_Pibby")

	if not colorCorrection_Pibby then
		colorCorrection_Pibby = Instance.new("ColorCorrectionEffect")
		colorCorrection_Pibby.Name = "ColorCorrection_Pibby"
		colorCorrection_Pibby.Parent = lighting
	end

	if colorCorrection_Pibby then
		local s1: string = "Enabled"

		if pcall(function()
			local v254 = colorCorrection_Pibby[s1]
		end) then
			local u150: boolean = true

			pcall(function()
				colorCorrection_Pibby.Enabled = u150
			end)
		end
	end

	module.Tween(colorCorrection_Pibby, p40 or 0.1, p39)
end
function module.ResetPibbyColor(p41)
	local colorCorrection_Pibby: Instance = lighting:FindFirstChild("ColorCorrection_Pibby")

	if not colorCorrection_Pibby then
		return
	end

	module.Tween(colorCorrection_Pibby, p41 or 0.25, module.NeutralColorCorrection)
	task.delay(p41 or 0.25, function()
		if colorCorrection_Pibby and colorCorrection_Pibby.Parent then
			colorCorrection_Pibby.Parent = nil
		end
	end)
end
function module.ApplyWanda60s(p42)
	local colorCorrection_Wanda60s = lighting:FindFirstChild("ColorCorrection_Wanda60s")

	if not colorCorrection_Wanda60s then
		colorCorrection_Wanda60s = Instance.new("ColorCorrectionEffect")
		colorCorrection_Wanda60s.Name = "ColorCorrection_Wanda60s"
		colorCorrection_Wanda60s.Parent = lighting
	end

	if colorCorrection_Wanda60s then
		local s1: string = "Enabled"

		if pcall(function()
			local v255 = colorCorrection_Wanda60s[s1]
		end) then
			local u156: boolean = true

			pcall(function()
				colorCorrection_Wanda60s.Enabled = u156
			end)
		end
	end

	module.Tween(colorCorrection_Wanda60s, p42 or 0.2, {
		Brightness = 0,
		Contrast = 0,
		Saturation = -1.8,
		TintColor = Color3.new(1, 1, 1)
	})
end
function module.ClearWanda60s(p43, p44)
	if p44 ~= true then
		local LocalPlayer: Player = players.LocalPlayer
		local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

		if localPlayerCharacter ~= nil and localPlayerCharacter.Parent ~= nil and localPlayerCharacter:FindFirstChild("WandaMax") ~= nil and localPlayerCharacter:FindFirstChild("60s") ~= nil then
			module.ApplyWanda60s(p43 or 0.2)

			return
		end
	end

	local colorCorrection_Wanda60s: Instance = lighting:FindFirstChild("ColorCorrection_Wanda60s")

	if not colorCorrection_Wanda60s then
		return
	end

	module.Tween(colorCorrection_Wanda60s, p43 or 0.35, module.NeutralColorCorrection)
	task.delay(p43 or 0.35, function()
		if p44 ~= true then
			local LocalPlayer: Player = players.LocalPlayer
			local localPlayerCharacter = LocalPlayer and LocalPlayer.Character

			if localPlayerCharacter ~= nil and localPlayerCharacter.Parent ~= nil and localPlayerCharacter:FindFirstChild("WandaMax") ~= nil and localPlayerCharacter:FindFirstChild("60s") ~= nil then
				module.ApplyWanda60s(0.15)

				return
			end
		end

		if colorCorrection_Wanda60s and colorCorrection_Wanda60s.Parent then
			colorCorrection_Wanda60s.Parent = nil
		end
	end)
end
function module.ApplyPersistentPreset(persistentColorPreset, p46)
	local v164 = module.Presets[persistentColorPreset]

	if not v164 then
		return
	end

	module.PersistentColorPreset = persistentColorPreset
	module.ApplyColor(v164, p46 or 0.2)
end
function module.ReapplyPersistentPreset(p47)
	if not module.PersistentColorPreset then
		return
	end

	local v166 = module.Presets[module.PersistentColorPreset]

	if not v166 then
		return
	end

	module.ApplyColor(v166, p47 or 0.2)
end
function module.ApplyColorFromTemplate(p48, p49)
	local foundChild: Instance = lighting:FindFirstChild(p48)

	if not foundChild then
		return
	end

	local t14: {[any]: any} = {}

	for _, v in ipairs({ "TintColor", "Brightness", "Contrast", "Saturation" }) do
		if pcall(function()
			local v258 = foundChild[v]
		end) then
			t14[v] = foundChild[v]
		end
	end

	module.ApplyColor(t14, p49)
end

module.InLoveId = 0

function module.ApplyInLove(p50)
	local v174: {[any]: any} = module

	v174.InLoveId = v174.InLoveId + 1

	local inLoveId = module.InLoveId
	local colorCorrection_InLove = lighting:FindFirstChild("ColorCorrection_InLove")

	if not colorCorrection_InLove then
		colorCorrection_InLove = Instance.new("ColorCorrectionEffect")
		colorCorrection_InLove.Name = "ColorCorrection_InLove"
		colorCorrection_InLove.Parent = lighting
	end

	if colorCorrection_InLove then
		local s1: string = "Enabled"

		if pcall(function()
			local v259 = colorCorrection_InLove[s1]
		end) then
			local u178: boolean = true

			pcall(function()
				colorCorrection_InLove.Enabled = u178
			end)
		end
	end

	local tween = module.Tween
	local color36 = Color3.fromRGB(241, 198, 244)

	tween(colorCorrection_InLove, 2, {
		Brightness = 0.08,
		Contrast = 0.65,
		Saturation = 0.45,
		TintColor = color36
	})
	module.SetBlur(3, 0.35)

	local bloom: Instance = lighting:FindFirstChild("Bloom")

	if bloom then
		local s2: string = "Enabled"

		if pcall(function()
			local v260 = bloom[s2]
		end) then
			local u183: boolean = true

			pcall(function()
				bloom.Enabled = u183
			end)
		end

		module.Tween(bloom, 2, { Intensity = 2.5, Threshold = 1.1, Size = 45 })
	end

	task.delay(p50 or 10 or 10, function()
		if inLoveId ~= module.InLoveId then
			return
		end

		module.ClearInLove()
	end)
end
function module.ClearInLove(p51)
	local v185: {[any]: any} = module

	v185.InLoveId = v185.InLoveId + 1

	local colorCorrection_InLove: Instance = lighting:FindFirstChild("ColorCorrection_InLove")

	if colorCorrection_InLove then
		if p51 then
			colorCorrection_InLove:Destroy()
		else
			module.Tween(colorCorrection_InLove, 0.6, module.NeutralColorCorrection)
			task.delay(0.6, function()
				if colorCorrection_InLove and colorCorrection_InLove.Parent then
					colorCorrection_InLove:Destroy()
				end
			end)
		end
	end

	module.SetBlur(0, if p51 then 0 else 0.6)
	module.ResetBloom(if p51 then 0 else 0.6)
end
function module.FlashColor(p52, p53, p54)
	local t15 = p52

	if not t15 then
		t15 = {
			Brightness = 0.15,
			Contrast = 0.25,
			Saturation = 0.1,
			TintColor = Color3.fromRGB(255, 80, 80)
		}
	end

	module.ApplyColor(t15, p53 or 0.08, "ColorCorrection_Flash")
	task.delay(p53 or 0.08, function()
		module.ResetColorCorrection("ColorCorrection_Flash", p54 or 0.25)
	end)
end
function module.ResetRumblingAtmosphere(p55)
	local atmosphere = game.Lighting:FindFirstChildOfClass("Atmosphere")

	if not atmosphere then
		return
	end

	local map: Instance = workspace:FindFirstChild("Map")
	local v194 = map and map:FindFirstChildOfClass("Atmosphere")

	if not v194 and map then
		for _, v in ipairs(map:GetDescendants()) do
			if v:IsA("Atmosphere") then
				v194 = v

				break
			end
		end
	end

	local v197 = v194 and v194.Glare or 0
	local v198 = v194 and v194.Haze or 0
	local tweenInfo = TweenInfo.new(p55 or 5)

	tweenService:Create(atmosphere, tweenInfo, { Glare = v197, Haze = v198 }):Play()
end
function module.PulseBloom(p56, p57, p58)
	local bloom: Instance = lighting:FindFirstChild("Bloom")

	if not bloom then
		return
	end

	local s1: string = "Enabled"

	if pcall(function()
		local v261 = bloom[s1]
	end) then
		local u205: boolean = true

		pcall(function()
			bloom.Enabled = u205
		end)
	end

	module.Tween(bloom, p57 or 0.08, p56 or { Intensity = 0.6, Threshold = 0.8, Size = 70 })
	task.delay(p57 or 0.08, function()
		module.ResetBloom(p58 or 0.25)
	end)
end
function module.SnapFlash()
	module.ApplyColor({ Brightness = 1 }, 0.25, "ColorCorrection_Flash")
	task.delay(2, function()
		module.ResetColorCorrection("ColorCorrection_Flash", 1)
	end)
end
function module.PulseBlockImpactBloom()
	local bloom: Instance = lighting:FindFirstChild("Bloom")

	if not bloom then
		return
	end

	local s1: string = "Enabled"

	if pcall(function()
		local v262 = bloom[s1]
	end) then
		local u208: boolean = true

		pcall(function()
			bloom.Enabled = u208
		end)
	end

	setProperties(bloom, { Intensity = 2, Threshold = 0.4, Size = 3 })
	module.Tween(bloom, 8, {
		Threshold = module.Defaults.Bloom.Threshold,
		Intensity = module.Defaults.Bloom.Intensity,
		Size = module.Defaults.Bloom.Size
	})
end
function module.GoreHit(p59)
	module.ApplyPreset("GoreHit", p59 or 0.6, "ColorCorrection_Gore")
end
function module.ResetFromHit(p60)
	module.ResetColorCorrection("ColorCorrection_Gore", p60 or 0.4)
end
function module.DeadFlash(p61, p62)
	module.ApplyColor({
		Brightness = 0,
		Contrast = 0,
		Saturation = 0,
		TintColor = Color3.new(1, 0, 0)
	}, p61 or 0.3, "ColorCorrection_Death")
	task.delay(p61 or 0.3, function()
		module.ResetColorCorrection("ColorCorrection_Death", p62 or 0.5)
	end)
end
function module.SetBrightness(p63, p64)
	module.ApplyColor({ Brightness = p63 or 0 }, p64 or 0.3)
end
function module.RageBrightness(p65)
	module.SetBrightness(-0.3, p65 or 0.3)
end
local function runSoldierBoyPulse(p66)
	for _ = 1, p66 or 6 do
		module.ApplyColor({ Contrast = 0.5 }, 0.4)
		task.wait(0.4)
		module.ApplyColor({ Contrast = 0 }, 0.4)
		task.wait(0.4)
	end

	module.ResetColorCorrection(0.2)
end
function module.SoldierBoyPulse(p67)
	task.spawn(runSoldierBoyPulse, p67)
end
function module.SoldierBoyPulseAsync(p68)
	module.SoldierBoyPulse(p68)
end
function module.ApplyStorm()
	local colorCorrection_Storm = lighting:FindFirstChild("ColorCorrection_Storm")

	if not colorCorrection_Storm then
		colorCorrection_Storm = Instance.new("ColorCorrectionEffect")
		colorCorrection_Storm.Name = "ColorCorrection_Storm"
		colorCorrection_Storm.Parent = lighting
	end

	if colorCorrection_Storm then
		local s1: string = "Enabled"

		if pcall(function()
			local v263 = colorCorrection_Storm[s1]
		end) then
			local u222: boolean = true

			pcall(function()
				colorCorrection_Storm.Enabled = u222
			end)
		end
	end

	local tween = module.Tween
	local color37 = Color3.fromRGB(175, 125, 255)

	tween(colorCorrection_Storm, 0.35, {
		Brightness = -0.08,
		Contrast = 0.45,
		Saturation = -0.1,
		TintColor = color37
	})
end
function module.ClearStorm()
	local colorCorrection_Storm: Instance = lighting:FindFirstChild("ColorCorrection_Storm")

	if colorCorrection_Storm then
		module.Tween(colorCorrection_Storm, 0.35, {
			Brightness = 0,
			Contrast = 0,
			Saturation = 0,
			TintColor = Color3.new(1, 1, 1)
		})
		task.delay(0.35, function()
			if colorCorrection_Storm and colorCorrection_Storm.Parent then
				colorCorrection_Storm:Destroy()
			end
		end)
	end

	local bloom_Storm: Instance = lighting:FindFirstChild("Bloom_Storm")

	if bloom_Storm then
		bloom_Storm:Destroy()
	end
end
function module.StormThunderFlash()
	local bloom_Storm = lighting:FindFirstChild("Bloom_Storm")

	if not bloom_Storm then
		bloom_Storm = Instance.new("BloomEffect")
		bloom_Storm.Name = "Bloom_Storm"
		bloom_Storm.Intensity = 0
		bloom_Storm.Threshold = 0.7
		bloom_Storm.Size = 56
		bloom_Storm.Parent = lighting
	end

	bloom_Storm.Enabled = true
	module.Tween(bloom_Storm, 0.04, { Intensity = 5, Threshold = 0.25, Size = 80 })
	task.delay(0.06, function()
		if bloom_Storm and bloom_Storm.Parent then
			module.Tween(bloom_Storm, 0.18, { Intensity = 0, Threshold = 0.7, Size = 56 })
		end
	end)

	local flashColor = module.FlashColor
	local color38 = Color3.fromRGB(220, 200, 255)

	flashColor({
		Brightness = 0.45,
		Contrast = 0.25,
		Saturation = -0.1,
		TintColor = color38
	}, 0.04, 0.18)
end

module.InvisibilityId = 0

function module.ApplyInvisibility()
	local v230: {[any]: any} = module

	v230.InvisibilityId = v230.InvisibilityId + 1

	local colorCorrection_Invisibility = lighting:FindFirstChild("ColorCorrection_Invisibility")

	if not colorCorrection_Invisibility then
		colorCorrection_Invisibility = Instance.new("ColorCorrectionEffect")
		colorCorrection_Invisibility.Name = "ColorCorrection_Invisibility"
		colorCorrection_Invisibility.Parent = lighting
	end

	if colorCorrection_Invisibility then
		local s1: string = "Enabled"

		if pcall(function()
			local v264 = colorCorrection_Invisibility[s1]
		end) then
			local u233: boolean = true

			pcall(function()
				colorCorrection_Invisibility.Enabled = u233
			end)
		end
	end

	module.Tween(colorCorrection_Invisibility, 0.45, { Brightness = -0.08, Contrast = 0.35, Saturation = -0.15 })
	module.SetBlur(3, 0.35)

	local bloom: Instance = lighting:FindFirstChild("Bloom")

	if bloom then
		local s2: string = "Enabled"

		if pcall(function()
			local v265 = bloom[s2]
		end) then
			local u236: boolean = true

			pcall(function()
				bloom.Enabled = u236
			end)
		end

		module.Tween(bloom, 0.4, { Intensity = 3.5, Threshold = 1, Size = 45 })
	end
end
function module.ClearInvisibility()
	local v237: {[any]: any} = module

	v237.InvisibilityId = v237.InvisibilityId + 1

	local colorCorrection_Invisibility: Instance = lighting:FindFirstChild("ColorCorrection_Invisibility")

	if colorCorrection_Invisibility then
		module.Tween(colorCorrection_Invisibility, 0.5, {
			Brightness = 0,
			Contrast = 0,
			Saturation = 0,
			TintColor = Color3.new(1, 1, 1)
		})
		task.delay(0.5, function()
			if colorCorrection_Invisibility and colorCorrection_Invisibility.Parent then
				colorCorrection_Invisibility:Destroy()
			end
		end)
	end

	module.SetBlur(0, 0.45)
	module.ResetBloom(0.5)
end

return module
