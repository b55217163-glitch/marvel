-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {}

module.__index = module

local debugProfilebegin = debug.profilebegin
local debugProfileend = debug.profileend
local cFrameNew = CFrame.new
local cFrameAngles = CFrame.Angles
local mathRad = math.rad
local vector3 = Vector3.new()
local cameraShakeInstance = require(script.CameraShakeInstance)
local cameraShakeInstanceCameraShakeState = cameraShakeInstance.CameraShakeState

module.CameraShakeInstance = cameraShakeInstance
module.Presets = require(script.CameraShakePresets)

function module.new(p1, p2)
	local typeName: string = type(p1)

	assert(typeName == "number", "RenderPriority must be a number (e.g.: Enum.RenderPriority.Camera.Value)")

	local typeName2: string = type(p2)

	assert(typeName2 == "function", "Callback must be a function")

	return (setmetatable({
		_running = false,
		_renderName = "CameraShaker",
		_renderPriority = p1,
		_posAddShake = vector3,
		_rotAddShake = vector3,
		_camShakeInstances = {},
		_removeInstances = {},
		_callback = p2
	}, module))
end
function module.Start(p3)
	if p3._running then
		return
	end

	p3._running = true

	local _callback = p3._callback

	game:GetService("RunService"):BindToRenderStep(p3._renderName, p3._renderPriority, function(p4)
		debugProfilebegin("CameraShakerUpdate")

		local v57 = p3:Update(p4)

		debugProfileend()
		_callback(v57)
	end)
end
function module.Stop(p5)
	if not p5._running then
		return
	end

	game:GetService("RunService"):UnbindFromRenderStep(p5._renderName)
	p5._running = false
end
function module.Update(p6, p7)
	local v19 = vector3
	local v20 = vector3
	local _camShakeInstances = p6._camShakeInstances

	for i = 1, #_camShakeInstances do
		local v23 = _camShakeInstances[i]
		local v24 = v23:GetState()

		if v24 == cameraShakeInstanceCameraShakeState.Inactive and v23.DeleteOnInactive then
			p6._removeInstances[#p6._removeInstances + 1] = i
		elseif v24 ~= cameraShakeInstanceCameraShakeState.Inactive then
			local v25 = v23:UpdateShake(p7)

			v19 += v25 * v23.PositionInfluence
			v20 += v25 * v23.RotationInfluence
		end
	end

	for i = #p6._removeInstances, 1, -1 do
		table.remove(_camShakeInstances, p6._removeInstances[i])
		p6._removeInstances[i] = nil
	end

	local v27 = math.clamp(v19.X, -0.75, 0.75)
	local v28 = math.clamp(v19.Y, -0.75, 0.75)
	local v29 = math.clamp(v19.Z, -0.75, 0.75)
	local vector32 = Vector3.new(v27, v28, v29)
	local _posAddShake = p6._posAddShake

	v29 = math.clamp(p7 * 20, 0, 1)
	p6._posAddShake = _posAddShake:Lerp(vector32, v29)
	v28 = cFrameNew(p6._posAddShake)

	local v32 = mathRad(v20.Y)

	v29 = cFrameAngles(0, v32, 0)

	local v33 = mathRad(v20.X)

	v32 = mathRad(v20.Z)

	local v34 = cFrameAngles(v33, 0, v32)

	return v28 * v29 * v34
end
function module.Shake(p8, p9)
	local u37 = false

	if type(p9) == "table" then
		u37 = p9._camShakeInstance
	end

	assert(u37, "ShakeInstance must be of type CameraShakeInstance")
	p8._camShakeInstances[#p8._camShakeInstances + 1] = p9

	return p9
end
function module.ShakeSustain(p10, p11)
	local u40 = false

	if type(p11) == "table" then
		u40 = p11._camShakeInstance
	end

	assert(u40, "ShakeInstance must be of type CameraShakeInstance")
	p10._camShakeInstances[#p10._camShakeInstances + 1] = p11
	p11:StartFadeIn(p11.fadeInDuration)

	return p11
end
function module.ShakeOnce(p12, p13, p14, p15, p16, p17, p18)
	local v48 = cameraShakeInstance.new(p13, p14, p15, p16)

	v48.PositionInfluence = typeof(p17) == "Vector3" and p17 or Vector3.new(0.15, 0.15, 0.15)
	v48.RotationInfluence = typeof(p18) == "Vector3" and p18 or Vector3.new(1, 1, 1)
	p12._camShakeInstances[#p12._camShakeInstances + 1] = v48

	return v48
end
function module.StartShake(p19, p20, p21, p22, p23, p24)
	local v55 = cameraShakeInstance.new(p20, p21, p22)

	v55.PositionInfluence = typeof(p23) == "Vector3" and p23 or Vector3.new(0.15, 0.15, 0.15)
	v55.RotationInfluence = typeof(p24) == "Vector3" and p24 or Vector3.new(1, 1, 1)
	v55:StartFadeIn(p22)
	p19._camShakeInstances[#p19._camShakeInstances + 1] = v55

	return v55
end

return module
