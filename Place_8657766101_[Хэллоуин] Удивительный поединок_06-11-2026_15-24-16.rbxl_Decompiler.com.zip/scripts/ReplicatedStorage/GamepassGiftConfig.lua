-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {
	CharacterGamepasses = {
		Thanos = {
			GamePassId = 71455905,
			GiftProductId = 3709547023,
			Pack = { "Thanos" }
		},
		Wanda = {
			GamePassId = 57444464,
			GiftProductId = 3709547101,
			Pack = { "Wanda" }
		},
		GigaChad = {
			GamePassId = 66966840,
			GiftProductId = 3709546983,
			DisplayName = "Speed + GigaChad Pack",
			Pack = { "GigaChad", "Gigachad", "Speed" }
		},
		Gigachad = {
			GamePassId = 66966840,
			GiftProductId = 3709546983,
			DisplayName = "Speed + GigaChad Pack",
			Pack = { "GigaChad", "Gigachad", "Speed" }
		},
		Speed = {
			GamePassId = 66966840,
			GiftProductId = 3709546983,
			DisplayName = "Speed + GigaChad Pack",
			Pack = { "GigaChad", "Gigachad", "Speed" }
		}
	},
	ProductToCharacter = {}
}

for k, v in pairs(module.CharacterGamepasses) do
	if typeof(v.GiftProductId) == "number" and v.GiftProductId > 0 then
		module.ProductToCharacter[v.GiftProductId] = k
	end
end

return module
