-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {}

module.__index = module

function module.new(p1, p2, p3, p4)
	local v6 = p1.WorldCFrame:ToObjectSpace(p2.WorldCFrame):Inverse()
	local v7 = p1.CFrame:ToObjectSpace(p2.CFrame):Inverse()
	local v8 = p2.WorldCFrame:ToObjectSpace(p3.CFrame):Inverse()

	return (setmetatable({
		RestLength = 0,
		Weight = 0.7,
		ParentIndex = 0,
		IsColliding = false,
		RestPosition = Vector3.new(0, 0, 0),
		Anchored = false,
		Bone = p1,
		Transform = v6,
		LocalTransform = v7,
		RootTransform = v8,
		Radius = p4.Radius,
		TransformOffset = CFrame.identity,
		LastTransformOffset = CFrame.identity,
		LocalTransformOffset = CFrame.identity,
		BoneTransform = CFrame.identity,
		CalculatedWorldCFrame = p1.WorldCFrame,
		CalculatedWorldPosition = p1.WorldPosition,
		Position = p1.WorldPosition,
		LastPosition = p1.WorldPosition,
		RecyclingBin = {}
	}, module))
end

return module
