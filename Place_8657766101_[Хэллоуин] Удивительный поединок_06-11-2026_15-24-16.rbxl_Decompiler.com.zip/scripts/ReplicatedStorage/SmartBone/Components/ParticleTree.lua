-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local random = Random.new(1029410295159813)
local module: {[any]: any} = {}

module.__index = module

function module.new(p1, rootPart, p3)
	return (setmetatable({
		BoneTotalLength = 0,
		DistanceFromCamera = 100,
		Force = Vector3.new(0, 0, 0),
		RestGravity = Vector3.new(0, 0, 0),
		ObjectMove = Vector3.new(0, 0, 0),
		ObjectPreviousPosition = Vector3.new(0, 0, 0),
		WindOffset = random:NextNumber(0, 1000000),
		Root = p1:IsA("Bone") and p1 or nil,
		RootPart = rootPart,
		RootWorldToLocal = p1.WorldCFrame:ToObjectSpace(p1.CFrame),
		Particles = {},
		LocalCFrame = p1.WorldCFrame,
		LocalGravity = p1.CFrame:PointToWorldSpace(p3).Unit * p3.Magnitude
	}, module))
end

return module
