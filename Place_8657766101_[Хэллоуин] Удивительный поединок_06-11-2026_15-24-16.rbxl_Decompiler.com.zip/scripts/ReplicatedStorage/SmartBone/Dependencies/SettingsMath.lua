-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local function Clamp(p1, p2)
	return function(p3)
		return (math.clamp(p3, p1, p2))
	end
end
local function Offset(p5)
	return function(p6)
		return p6 + p5
	end
end

local n1: number = 0
local n2: number = 1
local n3: number = 0
local n4: number = 1
local n5: number = 0
local n6: number = 1
local n7: number = 0
local n8: number = 1
local n9: number = 0
local n10: number = 1
local n11: number = 0
local n12: number = 165
local n13: number = 0
local n14: number = 10
local vectorValue = Vector3.new(0, -0.01, 0)

return {
	Damping = function(p7)
		return (math.clamp(p7, n1, n2))
	end,
	AnchorDepth = function(p4)
		return (math.floor(p4))
	end,
	Stiffness = function(p8)
		return (math.clamp(p8, n3, n4))
	end,
	Inertia = function(p9)
		return (math.clamp(p9, n5, n6))
	end,
	Elasticity = function(p10)
		return (math.clamp(p10, n7, n8))
	end,
	BlendWeight = function(p11)
		return (math.clamp(p11, n9, n10))
	end,
	UpdateRate = function(p12)
		return (math.clamp(p12, n11, n12))
	end,
	WindStrength = function(p13)
		return (math.clamp(p13, n13, n14))
	end,
	Gravity = function(p14)
		return p14 + vectorValue
	end
}
