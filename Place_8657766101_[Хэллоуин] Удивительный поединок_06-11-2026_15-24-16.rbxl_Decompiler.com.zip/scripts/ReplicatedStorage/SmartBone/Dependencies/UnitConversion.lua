-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local module: {[any]: any} = {
	Conversions = {
		Kilometer = 280.0336040324839,
		Hektometer = 28.00336040324839,
		Decameter = 2.800336040324839,
		Meter = 0.2800336040324839,
		Decimeter = 0.02800336040324839,
		Centimeter = 0.002800336040324839,
		Millimeter = 0.0002800336040324839,
		Miles = 4850.975973116774,
		Yards = 2.7562363483618033,
		Feet = 0.9187454494539344,
		Inches = 0.07656212078782787
	}
}

function module.Convert(p1, p2)
	local u4 = false

	if module.Conversions[p2] ~= nil then
		u4 = p1 * module.Conversions[p2]
	end

	return u4
end
function module.ConvertInverse(p3, p4)
	local u7 = false

	if module.Conversions[p4] ~= nil then
		u7 = module.Conversions[p4] / p3
	end

	return u7
end
function module.ConvertRounded(p5, p6)
	local u10 = false

	if module.Conversions[p6] ~= nil then
		u10 = math.floor(p5 * module.Conversions[p6])
	end

	return u10
end

return module
