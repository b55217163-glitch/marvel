-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
return {
	WithinViewport = function(p1)
		local CurrentCamera: Camera = workspace.CurrentCamera
		local v3
		local v4

		if p1:IsA("Model") then
			local v5, v6 = p1:GetBoundingBox()

			v3 = v5
			v4 = v6
		else
			if not p1:IsA("BasePart") then
				warn("Object is neither a Model nor a BasePart! Disregarding Camera check!")

				return false
			end

			v3 = p1.CFrame
			v4 = p1.Size
		end

		for i = 1, 8 do
			local cFrame = CFrame.new(v4.X * (if i % 2 == 0 then 0.5 else -0.5), v4.Y * (if i % 4 > 1 then 0.5 else -0.5), v4.Z * (if i % 8 > 3 then 0.5 else -0.5))

			if CurrentCamera:WorldToViewportPoint((v3 * cFrame).Position) then
				return true
			end
		end

		return false
	end
}
