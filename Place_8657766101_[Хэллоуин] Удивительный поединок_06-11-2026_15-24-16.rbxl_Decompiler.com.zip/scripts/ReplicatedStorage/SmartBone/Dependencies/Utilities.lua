-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
return {
	ShallowCopy = function(p1)
		local t1: {[any]: any} = {}

		for k, v in pairs(p1) do
			t1[k] = v
		end

		return t1
	end,
	Lerp = function(p2, p3, p4)
		return p2 + (p3 - p2) * p4
	end,
	GetRotationBetween = function(p5, p6, p7)
		local v11 = p5:Dot(p6)
		local v12 = p5:Cross(p6)

		if v11 < -0.99999 then
			return CFrame.fromAxisAngle(p7, 3.141592653589793)
		end

		return CFrame.new(0, 0, 0, v12.X, v12.Y, v12.Z, 1 + v11)
	end,
	GetHierarchyLength = function(p8, p9)
		if p8 == p9 then
			warn("Child and Root are the same Instance!")

			return
		end

		if p8 == nil then
			warn("Child is nil!")

			return
		end

		local v15 = p8
		local n1: number = 0

		repeat
			n1 += 1
			v15 = v15.Parent
		until p9 == v15

		return n1
	end,
	WaitForChildOfClass = function(p10, p11, p12)
		local v20 = os.clock()
		local v21 = p12 or 10

		repeat
			task.wait(0.1)
		until not not p10:FindFirstChildOfClass(p11) or v21 < os.clock() - v20

		return p10:FindFirstChildOfClass(p11)
	end
}
