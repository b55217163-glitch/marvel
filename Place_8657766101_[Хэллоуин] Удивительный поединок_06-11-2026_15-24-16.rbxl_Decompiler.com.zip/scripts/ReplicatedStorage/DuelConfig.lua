-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
return {
	PUBLIC_RELEASE = true,
	TESTER_GAMEPASS_ID = 0,
	TEST_USER_IDS = {},
	BANNED_DUEL_CHARS = { thanos = true, wanda = true, gigachad = true, speed = true },
	MIN_DUEL_KILLS = 500
}
