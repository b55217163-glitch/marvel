-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled using ByteFall
-- discord.gg/pHTnqmmWzk
local players: Players = game:GetService("Players")
local debris: Debris = game:GetService("Debris")

game:GetService("ReplicatedStorage")

local function applyKBServer(p1, p2, p3, p4, p5)
	local humanoidRootPart = p2 and p2:FindFirstChild("HumanoidRootPart")

	if humanoidRootPart and not humanoidRootPart.Anchored then
		pcall(function()
			humanoidRootPart:SetNetworkOwner(nil)
		end)

		local v10 = math.clamp(p4 or 0.2, 0.08, 0.4)
		local v11 = math.clamp(p3 or 120, -140, 140)
		local lookVector = p1.CFrame.LookVector
		local vector3 = Vector3.new(lookVector.X, 0, lookVector.Z)

		if vector3.Magnitude < 0.001 then
			vector3 = Vector3.new(0, 0, 1)
		end

		local vector3Unit = vector3.Unit
		local v15 = p5 and math.clamp(math.max(55, math.abs(v11) * 0.75), 0, 120) or 0
		local vector32 = Vector3.new(vector3Unit.X * v11, v15, vector3Unit.Z * v11)

		humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		humanoidRootPart.AssemblyLinearVelocity = vector32

		local rootAttachment = humanoidRootPart:FindFirstChild("RootAttachment")

		if not rootAttachment then
			rootAttachment = humanoidRootPart:FindFirstChildWhichIsA("Attachment")
		end

		if not rootAttachment then
			rootAttachment = Instance.new("Attachment")
			rootAttachment.Name = "RootAttachment"
			rootAttachment.Parent = humanoidRootPart
		end

		local mp_kb: LinearVelocity = Instance.new("LinearVelocity")

		mp_kb.Name = "MP_KB"
		mp_kb.RelativeTo = Enum.ActuatorRelativeTo.World
		mp_kb.VectorVelocity = vector32
		mp_kb.MaxForce = 800000
		mp_kb.Attachment0 = rootAttachment
		mp_kb.Parent = humanoidRootPart
		debris:AddItem(mp_kb, v10)
		task.delay(v10 + 0.02, function()
			if humanoidRootPart.Parent then
				local humanoidRootPartAssemblyLinearVelocity = humanoidRootPart.AssemblyLinearVelocity
				local vector33 = Vector3.new(humanoidRootPartAssemblyLinearVelocity.X, 0, humanoidRootPartAssemblyLinearVelocity.Z)
				local v21 = if p5 then humanoidRootPartAssemblyLinearVelocity.Y > 0 and math.min(humanoidRootPartAssemblyLinearVelocity.Y * 0.5, 120) or 0 else 0
				local vector34 = Vector3.new(0, v21, 0)

				humanoidRootPart.AssemblyLinearVelocity = vector33 * 0.15 + vector34
				humanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
			end

			local v23: Player = players:GetPlayerFromCharacter(p2)

			pcall(function()
				humanoidRootPart:SetNetworkOwner(v23)
			end)
		end)

		return
	end
end

return {}
